/**
 * 
 */
package net.jadoth.identity;

/**
 * Objects of this type can have an <code>Identity</code> of type <code>I</code> set for the context they stand for. 
 * @author Thomas Muenz
 *
 */
public interface IdentityReceivingContext<I>
{
	public void setContextIdentity(Identity<I> identity);
}
