/**
 * 
 */
package net.jadoth.identity;

/**
 * @author Thomas Muenz
 *
 */
public interface GenericIdentityResolver<T> extends IdentityResolver<T, Identity<T>>
{
	public T resolveIdentity(Identity<T> identity);
}
