/**
 * 
 */
package net.jadoth.identity;

/**
 * @author Thomas Muenz
 *
 */
public interface IdentityResolver<T, I extends Identity<T>>
{
	public T resolveIdentity(I identity);
}
