/**
 * 
 */
package net.jadoth.lang;

import java.util.Comparator;

/**
 * Useful for implementing SQL-like "ORDER BY" for collections.
 * 
 * @author Thomas Muenz
 *
 */
public class ComparatorSequence<T> implements Comparator<T>
{
	final private Comparator<T>[] comparators;

	public ComparatorSequence(final Comparator<T>... comparators)
	{
		super();
		this.comparators = comparators;
	}

	@Override
	public int compare(final T o1, final T o2)
	{
		int c;
		for(final Comparator<T> cmp : this.comparators){
			if((c = cmp.compare(o1, o2)) != 0) return c;
		}
		return 0;
	}
	
	
}
