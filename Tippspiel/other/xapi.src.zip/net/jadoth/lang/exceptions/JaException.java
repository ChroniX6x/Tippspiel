/**
 * 
 */
package net.jadoth.lang.exceptions;

import net.jadoth.Jadoth;

/**
 * @author Thomas Muenz
 *
 */
public class JaException extends RuntimeException
{

	private static final long serialVersionUID = 8304457904978222448L;
	
	

	///////////////////////////////////////////////////////////////////////////
	// constructors //
	/////////////////
	
	public JaException()
	{
		super();
	}

	/**
	 * @param message
	 */
	public JaException(String message)
	{
		super(message);
	}

	/**
	 * @param cause
	 */
	public JaException(Throwable cause)
	{
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public JaException(String message, Throwable cause)
	{
		super(message, cause);
	}
	
	
	
	///////////////////////////////////////////////////////////////////////////
	// declared methods //
	/////////////////////
		
	public JaException removeHighestStrackTraceElement(final int n)
	{
		return Jadoth.removeHighestStrackTraceElement(this, n);
	}

}
