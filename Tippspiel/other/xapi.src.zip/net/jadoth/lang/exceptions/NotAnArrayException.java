/*
 * Copyright (c) 2008-2010, Thomas M�nz
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package net.jadoth.lang.exceptions;

// TODO: Auto-generated Javadoc
/**
 * The Class NoArrayRuntimeException.
 * 
 * @author Thomas M�nzuenz
 */
public class NotAnArrayException extends ClassCastException 
{

	/** The Constant serialVersionUID. */
	private static final long serialVersionUID = 1172749786323032546L;

	/** The wrong class. */
	private final Class<?> wrongClass;
	
	private final Throwable cause;
	
	/**
	 * Instantiates a new no array runtime exception.
	 */
	public NotAnArrayException() 
	{
		super();
		this.wrongClass = null;
		this.cause = null;
	}

	/**
	 * Instantiates a new no array runtime exception.
	 * 
	 * @param message the message
	 * @param cause the cause
	 */
	public NotAnArrayException(String message, Throwable cause) 
	{
		super(message);
		this.wrongClass = null;
		this.cause = cause;
	}

	/**
	 * Instantiates a new no array runtime exception.
	 * 
	 * @param message the message
	 */
	public NotAnArrayException(String message) {
		super(message);
		this.wrongClass = null;
		this.cause = null;
	}

	/**
	 * Instantiates a new no array runtime exception.
	 * 
	 * @param cause the cause
	 */
	public NotAnArrayException(Throwable cause) {
		super();
		this.wrongClass = null;
		this.cause = cause;
	}
	
	
	/**
	 * Instantiates a new no array runtime exception.
	 * 
	 * @param wrongClass the wrong class
	 */
	public NotAnArrayException(Class<?> wrongClass) {
		super();
		this.wrongClass = wrongClass;
		this.cause = null;
	}

	/**
	 * Instantiates a new no array runtime exception.
	 * 
	 * @param wrongClass the wrong class
	 * @param cause the cause
	 */
	public NotAnArrayException(Class<?> wrongClass, Throwable cause) {
		super();
		this.wrongClass = wrongClass;
		this.cause = cause;
	}
	
	/**
	 * Instantiates a new no array runtime exception.
	 * 
	 * @param wrongClass the wrong class
	 * @param message the message
	 */
	public NotAnArrayException(Class<?> wrongClass, String message) {
		super(message);
		this.wrongClass = wrongClass;
		this.cause = null;
	}
	
	/**
	 * Instantiates a new no array runtime exception.
	 * 
	 * @param wrongClass the wrong class
	 * @param message the message
	 * @param cause the cause
	 */
	public NotAnArrayException(Class<?> wrongClass, String message, Throwable cause) {
		super(message);
		this.wrongClass = wrongClass;
		this.cause = cause;
	}
	
	/**
	 * Gets the wrong class.
	 * 
	 * @return the wrong class
	 */
	public Class<?> getWrongClass() {
		return wrongClass;
	}
	
	
	/**
	 * @return
	 */
	@Override
	public Throwable getCause()
	{
		return this.cause;
	}
	

	/**
	 * @return
	 * @see java.lang.Throwable#getMessage()
	 */
	@Override
	public String getMessage() {
		return "Wrong Class: "+wrongClass.getName();
	}

	
	
	
}
