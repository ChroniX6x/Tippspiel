/**
 *
 */
package net.jadoth.lang;

/**
 * Copyable objects can create copies of themselves that will behave exacely as they do.<br>
 * This does not neccessarily mean that all data is copied. E.g. fields that do internal caching and are set on
 * demand could be left out in the copy process.
 *
 * @author Thomas Muenz
 *
 */
public interface Copyable
{
	public Copyable copy();
}
