/**
 * 
 */
package net.jadoth.lang.aspects;

/**
 * @author Thomas Muenz
 *
 */
public interface AspectContext
{

}
