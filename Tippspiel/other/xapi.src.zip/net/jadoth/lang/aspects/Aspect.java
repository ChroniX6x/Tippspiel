/**
 * 
 */
package net.jadoth.lang.aspects;

import net.jadoth.lang.signalthrows.ThrowBreak;
import net.jadoth.lang.signalthrows.ThrowContinue;
import net.jadoth.lang.signalthrows.ThrowReturn;

/**
 * @author Thomas Muenz
 *
 */
public interface Aspect<C extends AspectContext>
{
	public Object invoke(C context) throws ThrowBreak, ThrowContinue, ThrowReturn;
}
