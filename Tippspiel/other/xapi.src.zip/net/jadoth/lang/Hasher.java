/**
 *
 */
package net.jadoth.lang;

/**
 * @author TM
 *
 */
public interface Hasher<T>
{
	public int hashCode(T object);
}
