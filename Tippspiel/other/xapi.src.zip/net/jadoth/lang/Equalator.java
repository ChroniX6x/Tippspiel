/**
 *
 */
package net.jadoth.lang;

/**
 * @author TM
 *
 */
public interface Equalator<T>
{
	public boolean equal(T object1, T object2);
}
