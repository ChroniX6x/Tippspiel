/**
 *
 */
package net.jadoth.lang;

/**
 * @author TM
 *
 */
public interface HashEqualator<T> extends Equalator<T>, Hasher<T>
{
	public boolean equal(T object, T object2);

	public int hashCode(T object);
}
