/**
 *
 */
package net.jadoth.lang.functional.controlflow;



/**
 * @author Thomas Muenz
 *
 */
public interface TProcessable<T, P extends TOperation<T>>
{
	public TProcessable<T,P> process(P processor);
}
