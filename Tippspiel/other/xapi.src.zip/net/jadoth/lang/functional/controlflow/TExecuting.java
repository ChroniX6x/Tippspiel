/**
 *
 */
package net.jadoth.lang.functional.controlflow;



/**
 * @author Thomas Muenz
 *
 */
public interface TExecuting<T, O extends TOperation<T>>
{
	public TExecuting<T,O> execute(O operation);
}
