/**
 * 
 */
package net.jadoth.lang.functional.controlflow;

import net.jadoth.lang.signalthrows.ThrowBreak;
import net.jadoth.lang.signalthrows.ThrowContinue;
import net.jadoth.lang.signalthrows.ThrowReturn;


/**
 * @author Thomas Muenz
 *
 */
public interface _charControllingProcessor
{
	public void process(char c) throws ThrowBreak, ThrowContinue, ThrowReturn;
}
