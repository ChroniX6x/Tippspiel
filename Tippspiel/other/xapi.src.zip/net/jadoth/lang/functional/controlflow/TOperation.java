/**
 *
 */
package net.jadoth.lang.functional.controlflow;

import net.jadoth.lang.functional.Operation;
import net.jadoth.lang.signalthrows.ThrowBreak;
import net.jadoth.lang.signalthrows.ThrowContinue;
import net.jadoth.lang.signalthrows.ThrowReturn;


/**
 * {@link Operation} that utilizes branching throws like {@link ThrowBreak}, {@link ThrowContinue}, {@link ThrowReturn}.
 *
 * @see Operation
 * @author Thomas Muenz
 *
 */
public interface TOperation<T>
{
	public void execute(T e) throws ThrowBreak, ThrowContinue, ThrowReturn;
}
