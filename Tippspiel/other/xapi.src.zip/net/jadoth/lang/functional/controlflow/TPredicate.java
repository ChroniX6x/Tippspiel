/**
 *
 */
package net.jadoth.lang.functional.controlflow;

import net.jadoth.lang.functional.Predicate;
import net.jadoth.lang.signalthrows.ThrowBreak;
import net.jadoth.lang.signalthrows.ThrowContinue;
import net.jadoth.lang.signalthrows.ThrowReturn;


/**
 * {@link Predicate} that utilizes branching throws like {@link ThrowBreak}, {@link ThrowContinue}, {@link ThrowReturn}.
 *
 * @author Thomas Muenz
 *
 */
public interface TPredicate<T>
{
	public boolean apply(T e) throws ThrowBreak, ThrowContinue, ThrowReturn;
}
