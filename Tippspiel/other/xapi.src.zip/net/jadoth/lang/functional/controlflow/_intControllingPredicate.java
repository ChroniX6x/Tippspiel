/**
 *
 */
package net.jadoth.lang.functional.controlflow;

import net.jadoth.lang.signalthrows.ThrowBreak;
import net.jadoth.lang.signalthrows.ThrowContinue;
import net.jadoth.lang.signalthrows.ThrowReturn;


/**
 * @author Thomas Muenz
 *
 */
public interface _intControllingPredicate
{
	public boolean apply(int i) throws ThrowBreak, ThrowContinue, ThrowReturn;
}
