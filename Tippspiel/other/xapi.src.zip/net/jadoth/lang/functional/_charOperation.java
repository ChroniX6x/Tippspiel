/**
 * 
 */
package net.jadoth.lang.functional;

/**
 * @author Thomas Muenz
 *
 */
public interface _charOperation
{
	public void execute(char c);
}
