/**
 * 
 */
package net.jadoth.lang.functional;

/**
 * @author Thomas Muenz
 *
 */
public interface _intOperation
{
	public void execute(int i);
}
