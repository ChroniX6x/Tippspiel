/**
 *
 */
package net.jadoth.lang.functional;



/**
 * @author Thomas Muenz
 *
 */
public abstract class Condition<T> implements Predicate<T>
{

	public final Condition<T> and(final Predicate<T> andPredicate)
	{
		return new Condition<T>(){
			@Override public boolean apply(final T t)
			{
				return Condition.this.apply(t) && andPredicate.apply(t);
			}
		};
	}

	public final Condition<T> or(final Predicate<T> orPredicate)
	{
		return new Condition<T>(){
			@Override public boolean apply(final T t)
			{
				return Condition.this.apply(t) || orPredicate.apply(t);
			}
		};
	}

}
