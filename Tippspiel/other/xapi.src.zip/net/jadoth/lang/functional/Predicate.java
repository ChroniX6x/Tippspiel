/**
 *
 */
package net.jadoth.lang.functional;

/**
 * @author Thomas M�nz
 *
 */
public interface Predicate<E>
{
	public boolean apply(E e);

}
