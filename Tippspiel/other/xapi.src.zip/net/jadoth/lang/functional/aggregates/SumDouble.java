/**
 * 
 */
package net.jadoth.lang.functional.aggregates;

import net.jadoth.collections.XGettingCollection;

/**
 * @author Thomas Muenz
 *
 */
public final class SumDouble implements Aggregate<Double, Double>
{
	private double sum = 0;	
	
	public SumDouble(final XGettingCollection<Double> c)
	{
		super();
		c.execute(this);
	}

	@Override
	public void execute(final Double n)
	{
		if(n != null) this.sum += n;		
	}
	
	public Double yield()
	{
		return this.sum;
	}
	
	/**
	 * @return
	 * @see net.jadoth.lang.functional.aggregates.Aggregate#reset()
	 */
	@Override
	public Aggregate<Double, Double> reset()
	{
		this.sum = 0;
		return this;
	}
}
