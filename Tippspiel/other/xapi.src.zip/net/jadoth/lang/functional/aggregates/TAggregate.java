/**
 * 
 */
package net.jadoth.lang.functional.aggregates;

import net.jadoth.lang.functional.controlflow.TOperation;
import net.jadoth.lang.signalthrows.ThrowBreak;
import net.jadoth.lang.signalthrows.ThrowContinue;
import net.jadoth.lang.signalthrows.ThrowReturn;

/**
 * @author Thomas Muenz
 *
 */
public interface TAggregate<E, R> extends TOperation<E>
{
	@Override
	public void execute(E element) throws ThrowBreak, ThrowContinue, ThrowReturn;
	
	public R yield();
	
	public TAggregate<E, R> reset();
}
