/**
 *
 */
package net.jadoth.lang.functional.aggregates;

import net.jadoth.collections.XGettingCollection;


/**
 * @author Thomas Muenz
 *
 */
public final class SumInteger implements Aggregate<Integer, Integer>
{
	private int sum = 0;

	public SumInteger()
	{
		super();
	}

	public SumInteger(final XGettingCollection<Integer> c)
	{
		super();
		c.aggregate(this);
	}

	@Override
	public void execute(final Integer n)
	{
		if(n != null) this.sum += n;
	}

	public Integer yield()
	{
		return this.sum;
	}

	/**
	 * @return
	 * @see net.jadoth.lang.functional.aggregates.Aggregate#reset()
	 */
	@Override
	public Aggregate<Integer, Integer> reset()
	{
		this.sum = 0;
		return this;
	}
}
