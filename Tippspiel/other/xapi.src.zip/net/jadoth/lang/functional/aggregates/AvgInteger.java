/**
 *
 */
package net.jadoth.lang.functional.aggregates;

import net.jadoth.collections.XGettingCollection;


/**
 * @author Thomas Muenz
 *
 */
public final class AvgInteger implements Aggregate<Integer, Integer>
{
	private int sum = 0;
	private int count = 0;

	public AvgInteger()
	{
		super();
	}

	public AvgInteger(final XGettingCollection<Integer> c)
	{
		super();
		c.aggregate(this);
	}

	@Override
	public void execute(final Integer n)
	{
		if(n != null){
			this.sum += n;
		}
		this.count++;
	}

	public Integer yield()
	{
		return this.sum/this.count;
	}

	/**
	 * @return
	 * @see net.jadoth.lang.functional.aggregates.Aggregate#reset()
	 */
	@Override
	public Aggregate<Integer, Integer> reset()
	{
		this.sum = 0;
		return this;
	}
}
