/**
 * 
 */
package net.jadoth.lang.functional.aggregates;

import net.jadoth.collections.XGettingCollection;

/**
 * @author Thomas Muenz
 *
 */
public final class SumLong implements Aggregate<Long, Long>
{
	private long sum = 0;	
	
	public SumLong(final XGettingCollection<Long> c)
	{
		super();
		c.execute(this);
	}

	@Override
	public void execute(final Long n)
	{
		if(n != null) this.sum += n;		
	}
	
	public Long yield()
	{
		return this.sum;
	}
	
	/**
	 * @return
	 * @see net.jadoth.lang.functional.aggregates.Aggregate#reset()
	 */
	@Override
	public Aggregate<Long, Long> reset()
	{
		this.sum = 0;
		return this;
	}
}
