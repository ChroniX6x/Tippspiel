/**
 * 
 */
package net.jadoth.lang.functional.aggregates;

import net.jadoth.collections.XGettingCollection;

/**
 * @author Thomas Muenz
 *
 */
public final class SumFloat implements Aggregate<Float, Double>
{
	private double sum = 0;	
	
	public SumFloat(final XGettingCollection<Float> c)
	{
		super();
		c.execute(this);
	}

	@Override
	public void execute(final Float n)
	{
		if(n != null) this.sum += n;		
	}
	
	public Double yield()
	{
		return this.sum;
	}
	
	/**
	 * @return
	 * @see net.jadoth.lang.functional.aggregates.Aggregate#reset()
	 */
	@Override
	public Aggregate<Float, Double> reset()
	{
		this.sum = 0;
		return this;
	}
}
