/**
 * 
 */
package net.jadoth.lang.functional.aggregates;

import net.jadoth.collections.XGettingCollection;

/**
 * @author Thomas Muenz
 *
 */
public final class SumByte implements Aggregate<Byte, Integer>
{
	private int sum = 0;	
	
	public SumByte(final XGettingCollection<Byte> c)
	{
		super();
		c.execute(this);
	}

	@Override
	public void execute(final Byte n)
	{
		if(n != null) this.sum += n;		
	}
	
	public Integer yield()
	{
		return this.sum;
	}
	
	/**
	 * @return
	 * @see net.jadoth.lang.functional.aggregates.Aggregate#reset()
	 */
	@Override
	public Aggregate<Byte, Integer> reset()
	{
		this.sum = 0;
		return this;
	}
}
