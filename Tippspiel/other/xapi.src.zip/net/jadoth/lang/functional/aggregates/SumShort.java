/**
 * 
 */
package net.jadoth.lang.functional.aggregates;

import net.jadoth.collections.XGettingCollection;

/**
 * @author Thomas Muenz
 *
 */
public final class SumShort implements Aggregate<Short, Integer>
{
	private int sum = 0;	
	
	public SumShort(final XGettingCollection<Short> c)
	{
		super();
		c.execute(this);
	}

	@Override
	public void execute(final Short n)
	{
		if(n != null) this.sum += n;		
	}
	
	public Integer yield()
	{
		return this.sum;
	}
	
	/**
	 * @return
	 * @see net.jadoth.lang.functional.aggregates.Aggregate#reset()
	 */
	@Override
	public Aggregate<Short, Integer> reset()
	{
		this.sum = 0;
		return this;
	}
}
