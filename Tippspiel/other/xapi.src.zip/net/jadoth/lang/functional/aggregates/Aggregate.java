/**
 * 
 */
package net.jadoth.lang.functional.aggregates;

import net.jadoth.lang.functional.Operation;

/**
 * @author Thomas Muenz
 *
 */
public interface Aggregate<E, R> extends Operation<E>
{
	@Override
	public void execute(E element);
	
	public R yield();
	
	public Aggregate<E, R> reset();
}
