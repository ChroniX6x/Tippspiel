/**
 * 
 */
package net.jadoth.lang.functional.iterables;

import java.util.Iterator;

/**
 * @author Thomas Muenz
 *
 */
public class ArrayIterator<E> implements Iterator<E>
{
	///////////////////////////////////////////////////////////////////////////
	// instance fields  //
	/////////////////////
	
	private final E[] array;
	
	int index = 0;

	
	
	///////////////////////////////////////////////////////////////////////////
	// constructors     //
	/////////////////////
	
	public ArrayIterator(final E[] array)
	{
		super();
		this.array = array;
	}



	/**
	 * @return
	 * @see java.util.Iterator#hasNext()
	 */
	@Override
	public boolean hasNext()
	{
		return this.index < this.array.length;
	}



	/**
	 * @return
	 * @see java.util.Iterator#next()
	 */
	@Override
	public E next()
	{
		return this.array[this.index++];
	}



	/**
	 * 
	 * @see java.util.Iterator#remove()
	 */
	@Override
	public void remove()
	{
		throw new UnsupportedOperationException();		
	}	
	
}
