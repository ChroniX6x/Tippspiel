/**
 *
 */
package net.jadoth.lang.functional;

import net.jadoth.lang.functional.controlflow.TPredicate;
import net.jadoth.lang.signalthrows.ThrowBreak;
import net.jadoth.lang.signalthrows.ThrowContinue;
import net.jadoth.lang.signalthrows.ThrowReturn;



/**
 * @author Thomas Muenz
 *
 */
public abstract class TCondition<T> implements TPredicate<T>
{

	public final TCondition<T> and(final TPredicate<T> andPredicate)
	{
		return new TCondition<T>(){
			@Override public boolean apply(final T t) throws ThrowBreak, ThrowContinue, ThrowReturn
			{
				return TCondition.this.apply(t) && andPredicate.apply(t);
			}
		};
	}

	public final TCondition<T> or(final TPredicate<T> orPredicate)
	{
		return new TCondition<T>(){
			@Override public boolean apply(final T t) throws ThrowBreak, ThrowContinue, ThrowReturn
			{
				return TCondition.this.apply(t) || orPredicate.apply(t);
			}
		};
	}

}
