/**
 *
 */
package net.jadoth.lang.functional;


/**
 * @author Thomas Muenz
 *
 */
public interface Processable<T, P extends Operation<T>>
{
	public Processable<T,P> process(P processor);
}
