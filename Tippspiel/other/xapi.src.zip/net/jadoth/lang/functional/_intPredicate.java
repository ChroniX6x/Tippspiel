/**
 *
 */
package net.jadoth.lang.functional;

/**
 * @author Thomas M�nz
 *
 */
public interface _intPredicate
{
	public boolean apply(int i);
}
