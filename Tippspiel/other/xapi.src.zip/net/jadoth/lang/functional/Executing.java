/**
 *
 */
package net.jadoth.lang.functional;



/**
 * @author Thomas Muenz
 *
 */
public interface Executing<T, O extends Operation<T>>
{
	public Executing<T,O> execute(O operation);
}
