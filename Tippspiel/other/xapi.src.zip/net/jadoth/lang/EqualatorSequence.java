/**
 * 
 */
package net.jadoth.lang;


/**
 * Useful for implementing SQL-like "GROUP BY" for collections. 
 * 
 * @author Thomas Muenz
 *
 */
public class EqualatorSequence<T> implements Equalator<T>
{
	final private Equalator<T>[] equalators;

	public EqualatorSequence(final Equalator<T>... equalators)
	{
		super();
		this.equalators = equalators;
	}

	@Override
	public boolean equal(final T o1, final T o2)
	{			
		for(final Equalator<T> eq : this.equalators){
			if(!eq.equal(o1, o2)) return false;
		}
		return true;
	}	
	
}
