/**
 * 
 */
package net.jadoth.cql;

import net.jadoth.collections.Collecting;
import net.jadoth.lang.Equalator;

/**
 * @author Thomas Muenz
 *
 */
public interface CqlAggregator<E, P, C extends Collecting<E>> extends CqlProjector<E, P, C>
{		
	public boolean aggregate(E element, Equalator<E> equalator);
	
	public CqlAggregator<E, P, C> reset();
	
}
