package net.jadoth.criteria;
/**
 * 
 */

/**
 * @author Thomas Muenz
 *
 */
public abstract class Criteria<T> implements Criterion<T>
{
	///////////////////////////////////////////////////////////////////////////
	// instance fields //
	////////////////////
	
	private final Criterion<T>[] criteria;

	
	
	///////////////////////////////////////////////////////////////////////////
	// constructors //
	/////////////////
	
	public Criteria(final Criterion<T>... criteria)
	{
		super();
		this.criteria = criteria;
	}

	
	
	///////////////////////////////////////////////////////////////////////////
	// getters          //
	/////////////////////
	
	/**
	 * @return the criteria
	 */
	public Criterion<T>[] getCriteria()
	{
		return this.criteria;
	}	

	
	
	
	
	//Below here are just String representation methods that don't influence actual logic	
	
	protected abstract StringBuilder assembleOperator(StringBuilder sb);
	
	protected StringBuilder assemble(final StringBuilder sb)
	{
		sb.append('(');
		boolean notEmtpy = false;
		for(final Criterion<T> c : this.criteria) {
			if(notEmtpy){
				this.assembleOperator(sb);
			}
			else {
				notEmtpy = true;
			}
			sb.append(c);
		}
		sb.append(')');
		return sb;
	}
	
	/**
	 * @return
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString()
	{
		return this.assemble(new StringBuilder(1024)).toString();
	}
	
}
