package net.jadoth.criteria;

/**
 * 
 */

/**
 * @author Thomas Muenz
 *
 */
public class AllCriteria<T> extends Criteria<T>
{
	///////////////////////////////////////////////////////////////////////////
	// constructors //
	/////////////////
	
	/**
	 * Note that best performance is achieved when ordering criteria in ascending order of estimated probability
	 * (starting with the least probable criterion)
	 * 
	 * @param criteria
	 */
	public AllCriteria(final Criterion<T>... criteria)
	{
		super(criteria);
	}

	
	
	///////////////////////////////////////////////////////////////////////////
	// override methods //
	/////////////////////
	
	@Override
	public boolean evaluate(final T... criterionElements)
	{
		for(final Criterion<T> element : this.getCriteria()) {
			if(!element.evaluate(criterionElements)) return false;			
		}		
		return true;
	}


	
	//Below here are just String representation methods that don't influence actual logic	
	
	/**
	 * @param sb
	 * @return
	 * @see net.jadoth.criteria.Criteria#assembleOperator(java.lang.StringBuilder)
	 */	
	@Override
	protected StringBuilder assembleOperator(final StringBuilder sb)
	{
		return sb.append(' ').append('&').append('&').append(' ');
	}
	
}
