package net.jadoth.criteria;

/**
 * 
 */

/**
 * @author Thomas Muenz
 *
 */
public class AnyCriteria<T> extends Criteria<T>
{
	///////////////////////////////////////////////////////////////////////////
	// constructors //
	/////////////////
	
	/**
	 * Note that best performance is achieved when ordering criteria in descending order of estimated probability
	 * (starting with the most probable criterion)
	 * 
	 * @param criteria
	 */
	public AnyCriteria(final Criterion<T>... criteria)
	{
		super(criteria);
	}


	
	///////////////////////////////////////////////////////////////////////////
	// override methods //
	/////////////////////
	
	@Override
	public boolean evaluate(final T... criterionElements)
	{
		for(final Criterion<T> element : this.getCriteria()) {
			if(element.evaluate(criterionElements)) return true;			
		}		
		return false;
	}
	
	
	//Below here are just String representation methods that don't influence actual logic	
	
	@Override
	protected StringBuilder assembleOperator(final StringBuilder sb)
	{
		return sb.append(' ').append('|').append('|').append(' ');
	}
}
