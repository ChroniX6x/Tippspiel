/**
 * 
 */
package net.jadoth.criteria;

/**
 * @author Thomas Muenz
 *
 */
public class NotCriterion<T> implements Criterion<T>
{
	///////////////////////////////////////////////////////////////////////////
	// instance fields //
	////////////////////
	
	private final Criterion<T> criterion;
	
	
	
	///////////////////////////////////////////////////////////////////////////
	// constructors //
	/////////////////
	
	public NotCriterion(final Criterion<T> criterion)
	{
		this.criterion = criterion;
	}

	
	
	///////////////////////////////////////////////////////////////////////////
	// override methods //
	/////////////////////

	/**
	 * @param criterionElements
	 * @return
	 */
	@Override
	public boolean evaluate(final T... criterionElements)
	{
		return !this.criterion.evaluate(criterionElements);
	}

	
	
	//Below here are just String representation methods that don't influence actual logic	

	@Override
	public String toString()
	{
		return '!'+this.criterion.toString();
	}	
	
}
