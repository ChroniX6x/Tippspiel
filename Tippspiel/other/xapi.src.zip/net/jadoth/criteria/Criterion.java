package net.jadoth.criteria;

/**
 * 
 */

/**
 * @author Thomas Muenz
 *
 */
public interface Criterion<T>
{
	boolean evaluate(T... criterionElements);
}
