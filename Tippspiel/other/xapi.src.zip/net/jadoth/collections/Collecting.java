/**
 * 
 */
package net.jadoth.collections;

/**
 * @author Thomas Muenz
 *
 */
public interface Collecting<E>
{
	/**
	 * Add the passed element to be added to this Collecting instance.<br>
	 * Returns <tt>true</tt> if this instance has been changed as a consequence of the call. 
	 * @param e
	 * @return
	 */
	public boolean add(E e);
}
