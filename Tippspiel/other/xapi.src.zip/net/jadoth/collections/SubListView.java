/**
 *
 */
package net.jadoth.collections;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import net.jadoth.lang.Equalator;
import net.jadoth.lang.functional.Operation;
import net.jadoth.lang.functional.Predicate;
import net.jadoth.lang.functional.aggregates.Aggregate;
import net.jadoth.lang.functional.aggregates.TAggregate;
import net.jadoth.lang.functional.controlflow.TOperation;
import net.jadoth.lang.functional.controlflow.TPredicate;
import net.jadoth.util.VarChar;

/**
 * @author Thomas Muenz
 *
 */
public class SubListView<E> implements XGettingList<E>
{

	/**
	 * @param e
	 * @return
	 * @see net.jadoth.collections.XGettingList#add(java.lang.Object)
	 */
	@Override
	public boolean add(final E e)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param index
	 * @param element
	 * @see net.jadoth.collections.XGettingList#add(int, java.lang.Object)
	 */
	@Override
	public void add(final int index, final E element)
	{
		// TODO Auto-generated method stub

	}

	/**
	 * @param c
	 * @return
	 * @see net.jadoth.collections.XGettingList#addAll(java.util.Collection)
	 */
	@Override
	public boolean addAll(final Collection<? extends E> c)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param index
	 * @param c
	 * @return
	 * @see net.jadoth.collections.XGettingList#addAll(int, java.util.Collection)
	 */
	@Override
	public boolean addAll(final int index, final Collection<? extends E> c)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param element
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingList#binarySearch(java.lang.Object, java.util.Comparator)
	 */
	@Override
	public int binarySearch(final E element, final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 *
	 * @see net.jadoth.collections.XGettingList#clear()
	 */
	@Override
	public void clear()
	{
		// TODO Auto-generated method stub

	}

	/**
	 * @param o
	 * @return
	 * @deprecated
	 * @see net.jadoth.collections.XGettingList#contains(java.lang.Object)
	 */
	@Deprecated
	@Override
	public boolean contains(final Object o)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param c
	 * @return
	 * @deprecated
	 * @see net.jadoth.collections.XGettingList#containsAll(java.util.Collection)
	 */
	@Deprecated
	@Override
	public boolean containsAll(final Collection<?> c)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @return
	 * @see net.jadoth.collections.XGettingList#copy()
	 */
	@Override
	public XList<E> copy()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param targetCollection
	 * @return
	 * @see net.jadoth.collections.XGettingList#copyRange(int, int, net.jadoth.collections.Collecting)
	 */
	@Override
	public <L extends Collecting<E>> L copyRange(final int startIndex, final int endIndex, final L targetCollection)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param index
	 * @return
	 * @see net.jadoth.collections.XGettingList#get(int)
	 */
	@Override
	public E get(final int index)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return
	 * @see net.jadoth.collections.XGettingList#getFirst()
	 */
	@Override
	public E getFirst()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return
	 * @see net.jadoth.collections.XGettingList#getLast()
	 */
	@Override
	public E getLast()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param o
	 * @return
	 * @see net.jadoth.collections.XGettingList#indexOf(java.lang.Object)
	 */
	@Override
	public int indexOf(final Object o)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param element
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingList#indexOf(java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int indexOf(final E element, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#indexOf(net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public int indexOf(final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#indexOf(net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public int indexOf(final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param element
	 * @return
	 * @see net.jadoth.collections.XGettingList#indexOfId(java.lang.Object)
	 */
	@Override
	public int indexOfId(final E element)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @return
	 * @see net.jadoth.collections.XGettingList#isEmpty()
	 */
	@Override
	public boolean isEmpty()
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingList#isSorted(java.util.Comparator)
	 */
	@Override
	public boolean isSorted(final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @return
	 * @see net.jadoth.collections.XGettingList#iterator()
	 */
	@Override
	public Iterator<E> iterator()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param o
	 * @return
	 * @see net.jadoth.collections.XGettingList#lastIndexOf(java.lang.Object)
	 */
	@Override
	public int lastIndexOf(final Object o)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param element
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingList#lastIndexOf(java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int lastIndexOf(final E element, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param element
	 * @return
	 * @see net.jadoth.collections.XGettingList#lastIndexOfId(java.lang.Object)
	 */
	@Override
	public int lastIndexOfId(final E element)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @return
	 * @see net.jadoth.collections.XGettingList#listIterator()
	 */
	@Override
	public ListIterator<E> listIterator()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param index
	 * @return
	 * @see net.jadoth.collections.XGettingList#listIterator(int)
	 */
	@Override
	public ListIterator<E> listIterator(final int index)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingList#maxIndex(java.util.Comparator)
	 */
	@Override
	public int maxIndex(final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingList#minIndex(java.util.Comparator)
	 */
	@Override
	public int minIndex(final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param o
	 * @return
	 * @see net.jadoth.collections.XGettingList#remove(java.lang.Object)
	 */
	@Override
	public boolean remove(final Object o)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param index
	 * @return
	 * @see net.jadoth.collections.XGettingList#remove(int)
	 */
	@Override
	public E remove(final int index)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param c
	 * @return
	 * @deprecated
	 * @see net.jadoth.collections.XGettingList#removeAll(java.util.Collection)
	 */
	@Deprecated
	@Override
	public boolean removeAll(final Collection<?> c)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param c
	 * @return
	 * @deprecated
	 * @see net.jadoth.collections.XGettingList#retainAll(java.util.Collection)
	 */
	@Deprecated
	@Override
	public boolean retainAll(final Collection<?> c)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param <R>
	 * @param startIndex
	 * @param endIndex
	 * @param aggregate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngAggregate(int, int, net.jadoth.lang.functional.aggregates.Aggregate)
	 */
	@Override
	public <R> R rngAggregate(final int startIndex, final int endIndex, final Aggregate<E, R> aggregate)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <R>
	 * @param startIndex
	 * @param endIndex
	 * @param aggregate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngAggregate(int, int, net.jadoth.lang.functional.aggregates.TAggregate)
	 */
	@Override
	public <R> R rngAggregate(final int startIndex, final int endIndex, final TAggregate<E, R> aggregate)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param vc
	 * @see net.jadoth.collections.XGettingList#rngAppendTo(int, int, net.jadoth.util.VarChar)
	 */
	@Override
	public void rngAppendTo(final int startIndex, final int endIndex, final VarChar vc)
	{
		// TODO Auto-generated method stub

	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param vc
	 * @param seperator
	 * @see net.jadoth.collections.XGettingList#rngAppendTo(int, int, net.jadoth.util.VarChar, java.lang.String)
	 */
	@Override
	public void rngAppendTo(final int startIndex, final int endIndex, final VarChar vc, final String seperator)
	{
		// TODO Auto-generated method stub

	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param vc
	 * @param seperator
	 * @see net.jadoth.collections.XGettingList#rngAppendTo(int, int, net.jadoth.util.VarChar, char)
	 */
	@Override
	public void rngAppendTo(final int startIndex, final int endIndex, final VarChar vc, final char seperator)
	{
		// TODO Auto-generated method stub

	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngApplies(int, int, net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public boolean rngApplies(final int startIndex, final int endIndex, final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngApplies(int, int, net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public boolean rngApplies(final int startIndex, final int endIndex, final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngBinarySearch(int, int, java.lang.Object, java.util.Comparator)
	 */
	@Override
	public int rngBinarySearch(final int startIndex, final int endIndex, final E element, final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngContains(int, int, net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public boolean rngContains(final int startIndex, final int endIndex, final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngContains(int, int, net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public boolean rngContains(final int startIndex, final int endIndex, final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngContains(int, int, java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public boolean rngContains(final int startIndex, final int endIndex, final E element, final Equalator<E> comparator)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @param ignoreNulls
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngContainsAll(int, int, Collection, boolean, net.jadoth.lang.Equalator)
	 */
	@Override
	public boolean rngContainsAll(final int startIndex, final int endIndex, final Collection<E> c, final boolean ignoreNulls, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @param ignoreNulls
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngContainsAll(int, int, java.util.Collection, boolean)
	 */
	@Override
	public boolean rngContainsAll(final int startIndex, final int endIndex, final Collection<?> c, final boolean ignoreNulls)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param o
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngContainsId(int, int, java.lang.Object)
	 */
	@Override
	public boolean rngContainsId(final int startIndex, final int endIndex, final E o)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param targetCollection
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngCopyTo(int, int, net.jadoth.collections.Collecting, net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public <L extends Collecting<E>> L rngCopyTo(final int startIndex, final int endIndex, final L targetCollection, final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param targetCollection
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngCopyTo(int, int, net.jadoth.collections.Collecting, net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public <L extends Collecting<E>> L rngCopyTo(final int startIndex, final int endIndex, final L targetCollection, final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param targetCollection
	 * @param predicate
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngCopyTo(int, int, net.jadoth.collections.Collecting, net.jadoth.lang.functional.Predicate, int)
	 */
	@Override
	public <L extends Collecting<E>> L rngCopyTo(final int startIndex, final int endIndex, final L targetCollection, final Predicate<E> predicate,final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param targetCollection
	 * @param predicate
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngCopyTo(int, int, net.jadoth.collections.Collecting, net.jadoth.lang.functional.controlflow.TPredicate, int)
	 */
	@Override
	public <L extends Collecting<E>> L rngCopyTo(final int startIndex, final int endIndex, final L targetCollection, final TPredicate<E> predicate,final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngCount(int, int, java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int rngCount(final int startIndex, final int endIndex, final E element, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngCount(int, int, java.lang.Object)
	 */
	@Override
	public int rngCount(final int startIndex, final int endIndex, final E element)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngCount(int, int, net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public int rngCount(final int startIndex, final int endIndex, final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngCount(int, int, net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public int rngCount(final int startIndex, final int endIndex, final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param list
	 * @param length
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngEqualsContent(int, java.util.List, int, net.jadoth.lang.Equalator)
	 */
	@Override
	public boolean rngEqualsContent(final int startIndex, final List<E> list, final int length, final Equalator<E> comparator)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param <C>
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @param comparatorr
	 * @param targetCollection
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngExcept(int, int, net.jadoth.collections.XGettingCollection, net.jadoth.lang.Equalator, net.jadoth.collections.Collecting)
	 */
	@Override
	public <C extends Collecting<E>> C rngExcept(final int startIndex, final int endIndex, final XGettingCollection<E> c, final Equalator<E> comparatorr, final C targetCollection)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param operation
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngExecute(int, int, net.jadoth.lang.functional.Operation)
	 */
	@Override
	public XList<E> rngExecute(final int startIndex, final int endIndex, final Operation<E> operation)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param operation
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngExecute(int, int, net.jadoth.lang.functional.controlflow.TOperation)
	 */
	@Override
	public XList<E> rngExecute(final int startIndex, final int endIndex, final TOperation<E> operation)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param ignoreMultipleNulls
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngHasUniqueValues(int, int, boolean)
	 */
	@Override
	public boolean rngHasUniqueValues(final int startIndex, final int endIndex, final boolean ignoreMultipleNulls)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param ignoreMultipleNulls
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngHasUniqueValues(int, int, boolean, net.jadoth.lang.Equalator)
	 */
	@Override
	public boolean rngHasUniqueValues(final int startIndex, final int endIndex, final boolean ignoreMultipleNulls, final Equalator<E> comparator)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngIndexOf(int, int, java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int rngIndexOf(final int startIndex, final int endIndex, final E element, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngIndexOf(int, int, net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public int rngIndexOf(final int startIndex, final int endIndex, final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngIndexOf(int, int, net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public int rngIndexOf(final int startIndex, final int endIndex, final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngIndexOfId(int, int, java.lang.Object)
	 */
	@Override
	public int rngIndexOfId(final int startIndex, final int endIndex, final E element)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param <C>
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @param comparator
	 * @param targetCollection
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngIntersect(int, int, net.jadoth.collections.XGettingCollection, net.jadoth.lang.Equalator, net.jadoth.collections.Collecting)
	 */
	@Override
	public <C extends Collecting<E>> C rngIntersect(final int startIndex, final int endIndex, final XGettingCollection<E> c, final Equalator<E> comparator, final C targetCollection)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngIsSorted(int, int, java.util.Comparator)
	 */
	@Override
	public boolean rngIsSorted(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngMax(int, int, java.util.Comparator)
	 */
	@Override
	public E rngMax(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngMaxIndex(int, int, java.util.Comparator)
	 */
	@Override
	public int rngMaxIndex(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngMin(int, int, java.util.Comparator)
	 */
	@Override
	public E rngMin(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngMinIndex(int, int, java.util.Comparator)
	 */
	@Override
	public int rngMinIndex(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param operation
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngProcess(int, int, net.jadoth.lang.functional.Operation)
	 */
	@Override
	public XList<E> rngProcess(final int startIndex, final int endIndex, final Operation<E> operation)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param operation
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngProcess(int, int, net.jadoth.lang.functional.controlflow.TOperation)
	 */
	@Override
	public XList<E> rngProcess(final int startIndex, final int endIndex, final TOperation<E> operation)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngScan(int, int, net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public int rngScan(final int startIndex, final int endIndex, final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngScan(int, int, net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public int rngScan(final int startIndex, final int endIndex, final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngSearch(int, int, java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public E rngSearch(final int startIndex, final int endIndex, final E element, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngSearch(int, int, net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public E rngSearch(final int startIndex, final int endIndex, final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngSearch(int, int, net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public E rngSearch(final int startIndex, final int endIndex, final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param type
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngToArray(int, int, java.lang.Class)
	 */
	@Override
	public E[] rngToArray(final int startIndex, final int endIndex, final Class<E> type)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngToArray(int, int)
	 */
	@Override
	public Object[] rngToArray(final int startIndex, final int endIndex)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <T>
	 * @param startIndex
	 * @param endIndex
	 * @param a
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngToArray(int, int, T[])
	 */
	@Override
	public <T> T[] rngToArray(final int startIndex, final int endIndex, final T[] a)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <C>
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @param comparatorr
	 * @param targetCollection
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngUnion(int, int, net.jadoth.collections.XGettingCollection, net.jadoth.lang.Equalator, net.jadoth.collections.Collecting)
	 */
	@Override
	public <C extends Collecting<E>> C rngUnion(final int startIndex, final int endIndex, final XGettingCollection<E> c, final Equalator<E> comparatorr, final C targetCollection)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#scan(net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public int scan(final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#scan(net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public int scan(final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param index
	 * @param element
	 * @return
	 * @see net.jadoth.collections.XGettingList#set(int, java.lang.Object)
	 */
	@Override
	public E set(final int index, final E element)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return
	 * @see net.jadoth.collections.XGettingList#size()
	 */
	@Override
	public int size()
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param fromIndex
	 * @param toIndex
	 * @return
	 * @see net.jadoth.collections.XGettingList#subList(int, int)
	 */
	@Override
	public SubList<E> subList(final int fromIndex, final int toIndex)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return
	 * @see net.jadoth.collections.XGettingList#toArray()
	 */
	@Override
	public Object[] toArray()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <T>
	 * @param a
	 * @return
	 * @see net.jadoth.collections.XGettingList#toArray(T[])
	 */
	@Override
	public <T> T[] toArray(final T[] a)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return
	 * @see net.jadoth.collections.XGettingList#toReversed()
	 */
	@Override
	public XList<E> toReversed()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <R>
	 * @param aggregate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#aggregate(net.jadoth.lang.functional.aggregates.Aggregate)
	 */
	@Override
	public <R> R aggregate(final Aggregate<E, R> aggregate)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <R>
	 * @param aggregate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#aggregate(net.jadoth.lang.functional.aggregates.TAggregate)
	 */
	@Override
	public <R> R aggregate(final TAggregate<E, R> aggregate)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param vc
	 * @see net.jadoth.collections.XGettingCollection#appendTo(net.jadoth.util.VarChar)
	 */
	@Override
	public void appendTo(final VarChar vc)
	{
		// TODO Auto-generated method stub

	}

	/**
	 * @param vc
	 * @param seperator
	 * @see net.jadoth.collections.XGettingCollection#appendTo(net.jadoth.util.VarChar, char)
	 */
	@Override
	public void appendTo(final VarChar vc, final char seperator)
	{
		// TODO Auto-generated method stub

	}

	/**
	 * @param vc
	 * @param seperator
	 * @see net.jadoth.collections.XGettingCollection#appendTo(net.jadoth.util.VarChar, java.lang.String)
	 */
	@Override
	public void appendTo(final VarChar vc, final String seperator)
	{
		// TODO Auto-generated method stub

	}

	/**
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#applies(net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public boolean applies(final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#applies(net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public boolean applies(final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param element
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#contains(java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public boolean contains(final E element, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#contains(net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public boolean contains(final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#contains(net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public boolean contains(final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param c
	 * @param ignoreNulls
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#containsAll(java.util.Collection, boolean, net.jadoth.lang.Equalator)
	 */
	@Override
	public boolean containsAll(final Collection<E> c, final boolean ignoreNulls, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param c
	 * @param ignoreNulls
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#containsAll(java.util.Collection, boolean)
	 */
	@Override
	public boolean containsAll(final Collection<E> c, final boolean ignoreNulls)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param element
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#containsId(java.lang.Object)
	 */
	@Override
	public boolean containsId(final E element)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param <C>
	 * @param targetCollection
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#copyTo(net.jadoth.collections.Collecting, net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public <C extends Collecting<E>> C copyTo(final C targetCollection, final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <C>
	 * @param targetCollection
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#copyTo(net.jadoth.collections.Collecting, net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public <C extends Collecting<E>> C copyTo(final C targetCollection, final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <C>
	 * @param targetCollection
	 * @param predicate
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#copyTo(net.jadoth.collections.Collecting, net.jadoth.lang.functional.Predicate, int)
	 */
	@Override
	public <C extends Collecting<E>> C copyTo(final C targetCollection, final Predicate<E> predicate,final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <C>
	 * @param targetCollection
	 * @param predicate
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#copyTo(net.jadoth.collections.Collecting, net.jadoth.lang.functional.controlflow.TPredicate, int)
	 */
	@Override
	public <C extends Collecting<E>> C copyTo(final C targetCollection, final TPredicate<E> predicate,final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param element
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#count(java.lang.Object)
	 */
	@Override
	public int count(final E element)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param element
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#count(java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int count(final E element, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#count(net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public int count(final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#count(net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public int count(final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param <C>
	 * @param targetCollection
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#distinct(net.jadoth.collections.Collecting)
	 */
	@Override
	public <C extends Collecting<E>> C distinct(final C targetCollection)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <C>
	 * @param targetCollection
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#distinct(net.jadoth.collections.Collecting, net.jadoth.lang.Equalator)
	 */
	@Override
	public <C extends Collecting<E>> C distinct(final C targetCollection, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param list
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#equals(net.jadoth.collections.XGettingCollection, net.jadoth.lang.Equalator)
	 */
	@Override
	public boolean equals(final XGettingCollection<E> list, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param list
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#equalsContent(java.util.Collection, net.jadoth.lang.Equalator)
	 */
	@Override
	public boolean equalsContent(final Collection<E> list, final Equalator<E> comparator)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param <C>
	 * @param other
	 * @param comparator
	 * @param target
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#except(net.jadoth.collections.XGettingCollection, net.jadoth.lang.Equalator, net.jadoth.collections.Collecting)
	 */
	@Override
	public <C extends Collecting<E>> C except(final XGettingCollection<E> other, final Equalator<E> comparator, final C target)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param operation
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#execute(net.jadoth.lang.functional.Operation)
	 */
	@Override
	public XGettingCollection<E> execute(final Operation<E> operation)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param operation
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#execute(net.jadoth.lang.functional.controlflow.TOperation)
	 */
	@Override
	public XGettingCollection<E> execute(final TOperation<E> operation)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param ignoreMultipleNulls
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#hasUniqueValues(boolean)
	 */
	@Override
	public boolean hasUniqueValues(final boolean ignoreMultipleNulls)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param ignoreMultipleNulls
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#hasUniqueValues(boolean, net.jadoth.lang.Equalator)
	 */
	@Override
	public boolean hasUniqueValues(final boolean ignoreMultipleNulls, final Equalator<E> comparator)
	{
		// TODO Auto-generated method stub
		return false;
	}

	/**
	 * @param <C>
	 * @param other
	 * @param comparator
	 * @param target
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#intersect(net.jadoth.collections.XGettingCollection, net.jadoth.lang.Equalator, net.jadoth.collections.Collecting)
	 */
	@Override
	public <C extends Collecting<E>> C intersect(final XGettingCollection<E> other, final Equalator<E> comparator, final C target)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#max(java.util.Comparator)
	 */
	@Override
	public E max(final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#min(java.util.Comparator)
	 */
	@Override
	public E min(final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param operation
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#process(net.jadoth.lang.functional.Operation)
	 */
	@Override
	public XGettingCollection<E> process(final Operation<E> operation)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param operation
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#process(net.jadoth.lang.functional.controlflow.TOperation)
	 */
	@Override
	public XGettingCollection<E> process(final TOperation<E> operation)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param element
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#search(java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public E search(final E element, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#search(net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public E search(final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#search(net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public E search(final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param type
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#toArray(java.lang.Class)
	 */
	@Override
	public E[] toArray(final Class<E> type)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param <C>
	 * @param other
	 * @param comparator
	 * @param target
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#union(net.jadoth.collections.XGettingCollection, net.jadoth.lang.Equalator, net.jadoth.collections.Collecting)
	 */
	@Override
	public <C extends Collecting<E>> C union(final XGettingCollection<E> other, final Equalator<E> comparator, final C target)
	{
		// TODO Auto-generated method stub
		return null;
	}
// (01.10.2010)TODO SubListView
}
