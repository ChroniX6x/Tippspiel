/**
 * 
 */
package net.jadoth.collections;

/**
 * @author Thomas Muenz
 *
 */
public class LimitList<E> //implements XList<E>
{
/*
See text in XList interface for full description
  
implementation class |   get  |   set  |   add  | remove | insert | growing
GrowList                  v        v        v        v        v        v
LimitedList               v        v        v        v        v
FixedList                 v        v
ConstList                 v
*/	
}
