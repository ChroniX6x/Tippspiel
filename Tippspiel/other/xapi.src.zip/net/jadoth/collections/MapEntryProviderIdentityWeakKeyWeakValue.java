/**
 * 
 */
package net.jadoth.collections;

/**
 * @author TM
 *
 */
public class MapEntryProviderIdentityWeakKeyWeakValue
{

}
