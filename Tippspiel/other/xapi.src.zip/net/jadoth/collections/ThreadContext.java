/**
 * 
 */
package net.jadoth.collections;

import java.lang.ref.WeakReference;

import net.jadoth.lang.reflection.Instantiator;

/**
 * @author Thomas Muenz
 *
 */
public class ThreadContext<E>
{
	///////////////////////////////////////////////////////////////////////////
	// constants        //
	/////////////////////
	
	private static final int LENGTH = 128;
	private static final int LENGTH_MINUS_ONE = LENGTH-1;
	
	
	
	///////////////////////////////////////////////////////////////////////////
	// instance fields  //
	/////////////////////
	
	private Entry[] table = new Entry[LENGTH];
	private final Instantiator<E> instantiator;
	
	
	
	///////////////////////////////////////////////////////////////////////////
	// constructors     //
	/////////////////////
	
	public ThreadContext(final Instantiator<E> instantiator)
	{
		super();
		this.instantiator = instantiator;
	}

	
	
	///////////////////////////////////////////////////////////////////////////
	// declared methods //
	/////////////////////

	@SuppressWarnings("unchecked")
	public E get()
	{
//		final Thread currentThread = Thread.currentThread();
//		final int hash = System.identityHashCode(currentThread);
//		final Entry[] table = this.table;
//		Entry e = table[hash & LENGTH_MINUS_ONE];
//		
//		if(e == null){
//			synchronized(table) {
//				final E newInstance = this.instantiator.newInstance();
//				table[hash & LENGTH_MINUS_ONE] = new Entry(currentThread, newInstance);
//				return newInstance;	
//			}			
//		}
//		
//		synchronized(e) {
//			Thread entryThread;
//			do{
//				if((entryThread = e.keyThreadRef.get()) == currentThread){
//					return (E)e.value;				
//				}
//				else if(entryThread == null){
//					table[hash & LENGTH_MINUS_ONE] = (e = e.next);
//				}
//			}
//			while(e != null);
//			
//			
//			Entry nextEntry;
//			while((nextEntry = e.next) != null){
//				
//				if((entryThread = e.keyThreadRef.get()) == currentThread) break;
//				e = e.next;
//			}
//			if(e != null){
//				return (E)e.value;
//			}
//		}
		// (20.09.2010)FIXME: ThreadContext
		return null;		
	}
	
}



final class Entry 
{
	WeakReference<Thread> keyThreadRef;
	Object value;
	Entry prev;
	Entry next;
	
	Entry(final Thread thread, final Object value)
	{
		super();
		this.keyThreadRef = new WeakReference<Thread>(thread);
		this.value = value;
		this.prev = null;
		this.next = null;
	}
	
	Entry(final Entry prev, final Entry next, final Thread thread, final Object value)
	{
		super();
		this.keyThreadRef = new WeakReference<Thread>(thread);
		this.value = value;
		this.prev = prev;
		this.next = next;
	}
	
}
