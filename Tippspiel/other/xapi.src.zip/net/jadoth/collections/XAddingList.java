/**
 *
 */
package net.jadoth.collections;


/**
 * @author Thomas Muenz
 *
 */
public interface XAddingList<E> extends XGettingList<E>, XAddingCollection<E>
{
	public interface Factory<E> extends XGettingList.Factory<E>, XAddingCollection.Factory<E>
	{
		@Override
		public XAddingList<E> createInstance();
	}
	

	
	// no special list adding methods here so far. See XInsertingList for inserts
}
