/**
 *
 */
package net.jadoth.collections;

import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Map;

import net.jadoth.lang.Equalator;
import net.jadoth.lang.functional.Operation;
import net.jadoth.lang.functional.Predicate;
import net.jadoth.lang.functional.aggregates.Aggregate;
import net.jadoth.lang.functional.aggregates.TAggregate;
import net.jadoth.lang.functional.controlflow.TOperation;
import net.jadoth.lang.functional.controlflow.TPredicate;
import net.jadoth.util.VarChar;

/**
 * Public implementation of the Java Collection SubList concept for {@link XList} instances.<br>
 * See {@link List#subList(int, int)}
 *
 * @author Thomas Muenz
 *
 */
public class SubList<E> extends SubListAccessor<E> implements XList<E>
{
	// (15.09.2010 TM)FIXME: SubList
	/*
	 * Three variants:
	 * SubListReadOnlyView implements XGettingList
	 * SubListView extends SubListReadOnlyView implements XSettingList
	 * SubList extends SubListView implements XList
	 */

	/*
	 * Write mini parser and generator to generate appropriate delegation methods
	 */
	// example for adding index delegation
//	add() -> return this.insert(this.offset+this.size, c);

	//example for rng~ method delegation
//	return this.rangeCheck(startIndex, endIndex)
//	?this.list.idRngReplace(this.offset + startIndex, this.offset + endIndex - 1, oldElement, newElement)
//	:this.list.idRngReplace(this.offset + startIndex - 1, this.offset + endIndex, oldElement, newElement)
//	;

	// beware size modification methods!
	// beware special case methods (like truncate())!


	private final XList<E> list;
	private final int offset;
	private int size;

	public SubList(final XList<E> list, final int startIndex, final int endIndex)
	{
		if(startIndex < 0 || endIndex >= list.size() || startIndex > endIndex){
			throw new IndexOutOfBoundsException("Range ["+startIndex+';'+endIndex+"] not in [0;"+list.size()+"].");
		}
		this.list = list;
		this.offset = startIndex;
		this.size = endIndex - startIndex + 1;
	}


	private void rangeCheck(final int index)
	{
		if (index < 0 || index >= this.size){
			throw new IndexOutOfBoundsException("Index: "+index+",Size: "+this.size);
		}
	}

	private boolean rangeCheck(final int startIndex, final int endIndex)
	{
		if(startIndex < 0 || endIndex >= this.size || startIndex > endIndex){
			throw new IndexOutOfBoundsException("Range ["+startIndex+';'+endIndex+"] not in [0;"+this.size+"].");
		}
		return startIndex <= endIndex;
	}


	/**
	 * @param oldElement
	 * @param newElement
	 * @return
	 */
	@Override
	public int replace(final E oldElement, final E newElement, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param oldElement
	 * @param newElement
	 * @param limit
	 * @return
	 */
	@Override
	public int replace(final E oldElement, final E newElement,final int skip, final Integer limit, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param oldElement
	 * @param newElement
	 * @return
	 */
	@Override
	public int replaceOne(final E oldElement, final E newElement, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param oldElement
	 * @param newElement
	 * @return
	 */
	@Override
	public int replace(final E oldElement, final E newElement)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param oldElement
	 * @param newElement
	 * @param limit
	 * @return
	 */
	@Override
	public int replace(final E oldElement, final E newElement,final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param oldElement
	 * @param newElement
	 * @return
	 */
	@Override
	public int replaceOne(final E oldElement, final E newElement)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param replacementMapping
	 * @return
	 */
	@Override
	public int replaceAll(final Map<E, E> replacementMapping)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param vc
	 */
	@Override
	public void appendTo(final VarChar vc)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub

	}


	/**
	 * @param vc
	 * @param seperator
	 */
	@Override
	public void appendTo(final VarChar vc, final char seperator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub

	}


	/**
	 * @param vc
	 * @param seperator
	 */
	@Override
	public void appendTo(final VarChar vc, final String seperator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub

	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public boolean applies(final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public boolean applies(final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 *
	 */
	@Override
	public void clear()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub

	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public boolean contains(final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public boolean contains(final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param element
	 * @param equalator
	 * @return
	 */
	@Override
	public boolean contains(final E element, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public int count(final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public int count(final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}




	/**
	 * @param element
	 * @return
	 */
	@Override
	public int count(final E element, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param element
	 * @return
	 */
	@Override
	public E search(final E element, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param list
	 * @param comparator
	 * @return
	 */
	@Override
	public boolean equals(final XGettingCollection<E> list, final Equalator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param list
	 * @param comparator
	 * @return
	 */
	@Override
	public boolean equalsContent(final Collection<E> list, final Equalator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param <C>
	 * @param other
	 * @param comparator
	 * @param target
	 * @return
	 */
	@Override
	public <C extends Collecting<E>> C except(final XGettingCollection<E> other, final Equalator<E> comparator, final C target)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param operation
	 * @return
	 */
	@Override
	public SubList<E> execute(final Operation<E> operation)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param operation
	 * @return
	 */
	@Override
	public SubList<E> execute(final TOperation<E> operation)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param comparator
	 * @return
	 */
	@Override
	public boolean hasUniqueValues(final boolean ignoreMultipleNulls, final Equalator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param element
	 * @return
	 */
	@Override
	public boolean containsId(final E element)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param element
	 * @return
	 */
	@Override
	public int count(final E element)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param ignoreMultipleNullValues
	 * @return
	 */
	@Override
	public boolean hasUniqueValues(final boolean ignoreMultipleNullValues)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param <C>
	 * @param other
	 * @param comparator
	 * @param target
	 * @return
	 */
	@Override
	public <C extends Collecting<E>> C intersect(final XGettingCollection<E> other, final Equalator<E> comparator, final C target)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @return
	 */
	@Override
	public boolean isEmpty()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param comparator
	 * @return
	 */
	@Override
	public E max(final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param comparator
	 * @return
	 */
	@Override
	public E min(final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param operation
	 * @return
	 */
	@Override
	public SubList<E> process(final Operation<E> operation)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param operation
	 * @return
	 */
	@Override
	public SubList<E> process(final TOperation<E> operation)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public E search(final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public E search(final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @return
	 */
	@Override
	public int size()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @return
	 */
	@Override
	public Object[] toArray()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param <T>
	 * @param a
	 * @return
	 */
	@Override
	public <T> T[] toArray(final T[] a)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param type
	 * @return
	 */
	@Override
	public E[] toArray(final Class<E> type)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param <C>
	 * @param other
	 * @param comparator
	 * @param target
	 * @return
	 */
	@Override
	public <C extends Collecting<E>> C union(final XGettingCollection<E> other, final Equalator<E> comparator, final C target)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @return
	 */
	@Override
	public Iterator<E> iterator()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param e
	 * @return
	 */
	@Override
	public boolean add(final E e)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param elements
	 * @return
	 */
	@Override
	public XAddingCollection<E> add(final E... elements)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param elements
	 * @return
	 */
	@Override
	public XAddingCollection<E> add(final Iterable<? extends E> elements)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param elements
	 * @param srcIndex
	 * @param srcLength
	 * @param predicate
	 * @param limit
	 * @return
	 */
	@Override
	public XAddingCollection<E> add(final E[] elements, final int srcIndex, final int srcLength, final Predicate<E> predicate, final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param elements
	 * @param srcIndex
	 * @param srcLength
	 * @param predicate
	 * @param limit
	 * @return
	 */
	@Override
	public XAddingCollection<E> add(final Iterable<? extends E> elements, final int srcIndex, final Integer srcLength, final Predicate<E> predicate, final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param elements
	 * @param srcIndex
	 * @param srcLength
	 * @param predicate
	 * @param limit
	 * @return
	 */
	@Override
	public XAddingCollection<E> add(final E[] elements, final int srcIndex, final int srcLength, final TPredicate<E> predicate, final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param elements
	 * @param srcIndex
	 * @param srcLength
	 * @param predicate
	 * @param limit
	 * @return
	 */
	@Override
	public XAddingCollection<E> add(final Iterable<? extends E> elements, final int srcIndex, final Integer srcLength, final TPredicate<E> predicate, final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param c
	 * @return
	 */
	@Override
	public boolean addAll(final Collection<? extends E> c)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param element
	 * @return
	 */
	@Override
	public int remove(final E element, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param element
	 * @param limit
	 * @return
	 */
	@Override
	public int remove(final E element,final int skip, final Integer limit, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param c
	 * @param ingoreNulls
	 * @return
	 */
	@Override
	public int removeAll(final XCollection<E> c, final boolean ingoreNulls, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param keepMultipleNullValues
	 * @return
	 */
	@Override
	public int removeDuplicates(final boolean keepMultipleNullValues, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param element
	 * @return
	 */
	@Override
	public E removeOne(final E element, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param c
	 * @return
	 */
	@Override
	public int retainAll(final XCollection<E> c, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}



	/**
	 * @param element
	 * @return
	 */
	@Override
	public int removeId(final E element)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param element
	 * @param limit
	 * @return
	 */
	@Override
	public int removeId(final E element,final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param c
	 * @param ingoreNulls
	 * @return
	 */
	@Override
	public int removeAllId(final XCollection<E> c, final boolean ingoreNulls)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param keepMultipleNullValues
	 * @return
	 */
	@Override
	public int removeDuplicates(final boolean keepMultipleNullValues)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param element
	 * @return
	 */
	@Override
	public E removeOne(final E element)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param c
	 * @return
	 */
	@Override
	public int retainAllId(final XCollection<E> c)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public int reduce(final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public int reduce(final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @param limit
	 * @return
	 */
	@Override
	public int reduce(final Predicate<E> predicate,final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @param limit
	 * @return
	 */
	@Override
	public int reduce(final TPredicate<E> predicate,final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}



	/**
	 * @return
	 */
	@Override
	public XList<E> truncate()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElement
	 * @param newElement
	 * @return
	 */
	@Override
	public int rngReplace(
		final int startIndex,
		final int endIndex,
		final E oldElement,
		final E newElement,
		final Equalator<E> equalator
	)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElement
	 * @param newElement
	 * @param limit
	 * @return
	 */
	@Override
	public int rngReplace(
		final int startIndex,
		final int endIndex,
		final E oldElement,
		final E newElement,
		final int skip,
		final Integer limit,
		final Equalator<E> equalator
		)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElement
	 * @param newElement
	 * @return
	 */
	@Override
	public int rngReplaceOne(
		final int startIndex,
		final int endIndex,
		final E oldElement,
		final E newElement,
		final Equalator<E> equalator
	)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @return
	 */
	@Override
	public XList<E> fill(final int startIndex, final int endIndex, final E element)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElement
	 * @param newElement
	 * @return
	 */
	@Override
	public int rngReplace(final int startIndex, final int endIndex, final E oldElement, final E newElement)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElement
	 * @param newElement
	 * @param limit
	 * @return
	 */
	@Override
	public int rngReplace(final int startIndex, final int endIndex, final E oldElement, final E newElement,final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElement
	 * @param newElement
	 * @return
	 */
	@Override
	public int rngReplaceOne(final int startIndex, final int endIndex, final E oldElement, final E newElement)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @return
	 */
	@Override
	public XList<E> reverse()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param replacementMapping
	 * @return
	 */
	@Override
	public int rngReplaceAll(final int startIndex, final int endIndex, final Map<E, E> replacementMapping)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @return
	 */
	@Override
	public XList<E> rngReverse(final int startIndex, final int endIndex)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @return
	 */
	@Override
	public XList<E> rngShuffle(final int startIndex, final int endIndex)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 */
	@Override
	public XList<E> rngSortMerge(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 */
	@Override
	public XList<E> rngSortQuick(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param index
	 * @param element
	 * @return
	 */
	@Override
	public E set(final int index, final E element)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param elements
	 * @return
	 */
	@Override
	public XList<E> set(final int startIndex, final E... elements)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param elements
	 * @param elementsStartIndex
	 * @param length
	 * @return
	 */
	@Override
	public XList<E> set(final int startIndex, final E[] elements, final int elementsStartIndex, final int length)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param elements
	 * @param elementsStartIndex
	 * @param length
	 * @return
	 */
	@Override
	public XList<E> set(final int startIndex, final List<E> elements, final int elementsStartIndex, final int length)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param element
	 */
	@Override
	public void setFirst(final E element)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub

	}


	/**
	 * @param element
	 */
	@Override
	public void setLast(final E element)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub

	}


	/**
	 * @return
	 */
	@Override
	public XList<E> shuffle()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param comparator
	 * @return
	 */
	@Override
	public XList<E> sortMerge(final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param comparator
	 * @return
	 */
	@Override
	public XList<E> sortQuick(final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param indexA
	 * @param indexB
	 */
	@Override
	public void swap(final int indexA, final int indexB)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub

	}


	/**
	 * @param indexA
	 * @param indexB
	 * @param length
	 */
	@Override
	public void swap(final int indexA, final int indexB, final int length)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub

	}


	/**
	 * @param element
	 * @param comparator
	 * @return
	 */
	@Override
	public int binarySearch(final E element, final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @return
	 */
	@Override
	public XList<E> copy()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param o
	 * @return
	 */
	@Override
	public int indexOf(final E o, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param o
	 * @return
	 */
	@Override
	public int lastIndexOf(final E o, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}




	/**
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @param ignoreNulls
	 * @return
	 */
	@Override
	public boolean rngContainsAll(final int startIndex, final int endIndex, final Collection<E> c, final boolean ignoreNulls, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @return
	 */
	@Override
	public int rngCount(final int startIndex, final int endIndex, final E element, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}



	/**
	 * @param startIndex
	 * @param endIndex
	 * @param o
	 * @return
	 */
	@Override
	public int rngIndexOf(final int startIndex, final int endIndex, final E o, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param index
	 * @return
	 */
	@Override
	public E get(final int index)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @return
	 */
	@Override
	public E getFirst()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @return
	 */
	@Override
	public E getLast()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param o
	 * @return
	 */
	@Override
	public int indexOfId(final E o)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param o
	 * @return
	 */
	@Override
	public int lastIndexOfId(final E o)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param o
	 * @return
	 */
	@Override
	public boolean rngContainsId(final int startIndex, final int endIndex, final E o)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @param ignoreNulls
	 * @return
	 */
	@Override
	public boolean rngContainsAll(final int startIndex, final int endIndex, final Collection<?> c, final boolean ignoreNulls)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @return
	 */
	@Override
	public int rngCount(final int startIndex, final int endIndex, final E element)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param ignoreMultipleNullValues
	 * @return
	 */
	@Override
	public boolean rngHasUniqueValues(final int startIndex, final int endIndex, final boolean ignoreMultipleNullValues)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param o
	 * @return
	 */
	@Override
	public int rngIndexOfId(final int startIndex, final int endIndex, final E o)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public int indexOf(final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public int indexOf(final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param comparator
	 * @return
	 */
	@Override
	public boolean isSorted(final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @return
	 */
	@Override
	public ListIterator<E> listIterator()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param i
	 * @return
	 */
	@Override
	public ListIterator<E> listIterator(final int i)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param comparator
	 * @return
	 */
	@Override
	public int maxIndex(final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param comparator
	 * @return
	 */
	@Override
	public int minIndex(final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param vc
	 */
	@Override
	public void rngAppendTo(final int startIndex, final int endIndex, final VarChar vc)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub

	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param vc
	 * @param seperator
	 */
	@Override
	public void rngAppendTo(final int startIndex, final int endIndex, final VarChar vc, final String seperator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub

	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param vc
	 * @param seperator
	 */
	@Override
	public void rngAppendTo(final int startIndex, final int endIndex, final VarChar vc, final char seperator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub

	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public boolean rngApplies(final int startIndex, final int endIndex, final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public boolean rngApplies(final int startIndex, final int endIndex, final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @param comparator
	 * @return
	 */
	@Override
	public int rngBinarySearch(final int startIndex, final int endIndex, final E element, final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public boolean rngContains(final int startIndex, final int endIndex, final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public boolean rngContains(final int startIndex, final int endIndex, final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @param comparator
	 * @return
	 */
	@Override
	public boolean rngContains(final int startIndex, final int endIndex, final E element, final Equalator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public int rngCount(final int startIndex, final int endIndex, final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public int rngCount(final int startIndex, final int endIndex, final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @return
	 */
	@Override
	public E rngSearch(final int startIndex, final int endIndex, final E element, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param list
	 * @param length
	 * @param comparator
	 * @return
	 */
	@Override
	public boolean rngEqualsContent(final int startIndex, final List<E> list, final int length, final Equalator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param <C>
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @param comparatorr
	 * @param targetCollection
	 * @return
	 */
	@Override
	public <C extends Collecting<E>> C rngExcept(final int startIndex, final int endIndex, final XGettingCollection<E> c, final Equalator<E> comparatorr, final C targetCollection)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param operation
	 * @return
	 */
	@Override
	public XList<E> rngExecute(final int startIndex, final int endIndex, final Operation<E> operation)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param operation
	 * @return
	 */
	@Override
	public XList<E> rngExecute(final int startIndex, final int endIndex, final TOperation<E> operation)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 */
	@Override
	public boolean rngHasUniqueValues(final int startIndex, final int endIndex, final boolean ignoreMultipleNulls, final Equalator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public int rngIndexOf(final int startIndex, final int endIndex, final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public int rngIndexOf(final int startIndex, final int endIndex, final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param <C>
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @param comparator
	 * @param targetCollection
	 * @return
	 */
	@Override
	public <C extends Collecting<E>> C rngIntersect(final int startIndex, final int endIndex, final XGettingCollection<E> c, final Equalator<E> comparator, final C targetCollection)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 */
	@Override
	public boolean rngIsSorted(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 */
	@Override
	public E rngMax(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 */
	@Override
	public int rngMaxIndex(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 */
	@Override
	public E rngMin(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 */
	@Override
	public int rngMinIndex(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param operation
	 * @return
	 */
	@Override
	public XList<E> rngProcess(final int startIndex, final int endIndex, final Operation<E> operation)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param operation
	 * @return
	 */
	@Override
	public XList<E> rngProcess(final int startIndex, final int endIndex, final TOperation<E> operation)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public int rngScan(final int startIndex, final int endIndex, final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public int rngScan(final int startIndex, final int endIndex, final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public E rngSearch(final int startIndex, final int endIndex, final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public E rngSearch(final int startIndex, final int endIndex, final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param type
	 * @return
	 */
	@Override
	public E[] rngToArray(final int startIndex, final int endIndex, final Class<E> type)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @return
	 */
	@Override
	public Object[] rngToArray(final int startIndex, final int endIndex)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param <T>
	 * @param startIndex
	 * @param endIndex
	 * @param a
	 * @return
	 */
	@Override
	public <T> T[] rngToArray(final int startIndex, final int endIndex, final T[] a)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param <C>
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @param comparatorr
	 * @param targetCollection
	 * @return
	 */
	@Override
	public <C extends Collecting<E>> C rngUnion(final int startIndex, final int endIndex, final XGettingCollection<E> c, final Equalator<E> comparatorr, final C targetCollection)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public int scan(final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @return
	 */
	@Override
	public int scan(final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param fromIndex
	 * @param toIndex
	 * @return
	 */
	@Override
	public SubList<E> subList(final int fromIndex, final int toIndex)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @return
	 */
	@Override
	public XList<E> toReversed()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param index
	 * @param element
	 * @return
	 */
	@Override
	public XInsertingList<E> insert(final int index, final E element)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param index
	 * @param elements
	 * @return
	 */
	@Override
	public XInsertingList<E> insert(final int index, final E... elements)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param index
	 * @param elements
	 * @return
	 */
	@Override
	public XInsertingList<E> insert(final int index, final Iterable<? extends E> elements)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param index
	 * @param elements
	 * @param srcIndex
	 * @param srcLength
	 * @param predicate
	 * @param limit
	 * @return
	 */
	@Override
	public XInsertingList<E> insert(final int index, final E[] elements, final int srcIndex, final int srcLength, final Predicate<E> predicate, final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param index
	 * @param elements
	 * @param srcIndex
	 * @param srcLength
	 * @param predicate
	 * @param limit
	 * @return
	 */
	@Override
	public XInsertingList<E> insert(final int index, final Iterable<? extends E> elements, final int srcIndex, final Integer srcLength, final Predicate<E> predicate, final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param index
	 * @param elements
	 * @param srcIndex
	 * @param srcLength
	 * @param predicate
	 * @param limit
	 * @return
	 */
	@Override
	public XInsertingList<E> insert(final int index, final E[] elements, final int srcIndex, final int srcLength, final TPredicate<E> predicate, final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param index
	 * @param elements
	 * @param srcIndex
	 * @param srcLength
	 * @param predicate
	 * @param limit
	 * @return
	 */
	@Override
	public XInsertingList<E> insert(final int index, final Iterable<? extends E> elements, final int srcIndex, final Integer srcLength, final TPredicate<E> predicate, final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param element
	 * @return
	 */
	@Override
	public XInsertingList<E> prepend(final E element)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @return
	 */
	@Override
	public int rngRemove(final int startIndex, final int endIndex, final E element, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @param limit
	 * @return
	 */
	@Override
	public int rngRemove(final int startIndex, final int endIndex, final E element, final Equalator<E> equalator,final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @param ignoreNulls
	 * @return
	 */
	@Override
	public int rngRemoveAll(final int startIndex, final int endIndex, final XCollection<? super E> c, final boolean ignoreNulls, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param keepMultipleNulls
	 * @return
	 */
	@Override
	public int rngRemoveDuplicates(final int startIndex, final int endIndex, final boolean keepMultipleNulls, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param o
	 * @return
	 */
	@Override
	public E rngRemoveOne(final int startIndex, final int endIndex, final E o, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @return
	 */
	@Override
	public int rngRetainAll(final int startIndex, final int endIndex, final XCollection<E> c, final Equalator<E> equalator)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @return
	 */
	@Override
	public int rngRemove(final int startIndex, final int endIndex, final E element)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @param limit
	 * @return
	 */
	@Override
	public int rngRemove(final int startIndex, final int endIndex, final E element,final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @param ignoreNulls
	 * @return
	 */
	@Override
	public int rngRemoveAll(final int startIndex, final int endIndex, final XCollection<? super E> c, final boolean ignoreNulls)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param keepMultipleNulls
	 * @return
	 */
	@Override
	public int rngRemoveDuplicates(final int startIndex, final int endIndex, final boolean keepMultipleNulls)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param o
	 * @return
	 */
	@Override
	public E rngRemoveOne(final int startIndex, final int endIndex, final E o)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param c
	 * @return
	 */
	@Override
	public int rngRetainAll(final int startIndex, final int endIndex, final XCollection<E> c)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param index
	 * @return
	 */
	@Override
	public E remove(final int index)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @return
	 */
	@Override
	public E removeFirst()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @return
	 */
	@Override
	public E removeLast()
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @return
	 */
	@Override
	public XList<E> removeRange(final int startIndex, final int endIndex)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return null;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public int rngReduce(final int startIndex, final int endIndex, final Predicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @return
	 */
	@Override
	public int rngReduce(final int startIndex, final int endIndex, final TPredicate<E> predicate)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @param limit
	 * @return
	 */
	@Override
	public int rngReduce(final int startIndex, final int endIndex, final Predicate<E> predicate,final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @param limit
	 * @return
	 */
	@Override
	public int rngReduce(final int startIndex, final int endIndex, final TPredicate<E> predicate,final int skip, final Integer limit)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}




	/**
	 * @param index
	 * @param element
	 */
	@Override
	public void add(final int index, final E element)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub

	}


	/**
	 * @param index
	 * @param c
	 * @return
	 */
	@Override
	public boolean addAll(final int index, final Collection<? extends E> c)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param o
	 * @return
	 */
	@Override
	public boolean contains(final Object o)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param c
	 * @return
	 */
	@Override
	public boolean containsAll(final Collection<?> c)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param o
	 * @return
	 */
	@Override
	public int indexOf(final Object o)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param o
	 * @return
	 */
	@Override
	public int lastIndexOf(final Object o)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return 0;
	}


	/**
	 * @param o
	 * @return
	 */
	@Override
	public boolean remove(final Object o)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param c
	 * @return
	 */
	@Override
	public boolean removeAll(final Collection<?> c)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param c
	 * @return
	 */
	@Override
	public boolean retainAll(final Collection<?> c)
	{
		// (15.09.2010 TM)TODO: TM Auto-generated method stub
		return false;
	}


	/**
	 * @param <R>
	 * @param aggregate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#aggregate(net.jadoth.lang.functional.aggregates.Aggregate)
	 */
	@Override
	public <R> R aggregate(final Aggregate<E, R> aggregate)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <R>
	 * @param startIndex
	 * @param endIndex
	 * @param aggregate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngAggregate(int, int, net.jadoth.lang.functional.aggregates.Aggregate)
	 */
	@Override
	public <R> R rngAggregate(final int startIndex, final int endIndex, final Aggregate<E, R> aggregate)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param targetCollection
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#copyTo(net.jadoth.collections.XGettingCollection, net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public <L extends Collecting<E>> L copyTo(final L targetCollection, final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param targetCollection
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#copyTo(net.jadoth.collections.XGettingCollection, net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public <L extends Collecting<E>> L copyTo(final L targetCollection, final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param targetCollection
	 * @param predicate
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#copyTo(net.jadoth.collections.XGettingCollection, net.jadoth.lang.functional.Predicate, int)
	 */
	@Override
	public <L extends Collecting<E>> L copyTo(final L targetCollection, final Predicate<E> predicate,final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param targetCollection
	 * @param predicate
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#copyTo(net.jadoth.collections.XGettingCollection, net.jadoth.lang.functional.controlflow.TPredicate, int)
	 */
	@Override
	public <L extends Collecting<E>> L copyTo(final L targetCollection, final TPredicate<E> predicate,final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <R>
	 * @param aggregate
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#aggregate(net.jadoth.lang.functional.aggregates.TAggregate)
	 */
	@Override
	public <R> R aggregate(final TAggregate<E, R> aggregate)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <R>
	 * @param startIndex
	 * @param endIndex
	 * @param aggregate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngAggregate(int, int, net.jadoth.lang.functional.aggregates.TAggregate)
	 */
	@Override
	public <R> R rngAggregate(final int startIndex, final int endIndex, final TAggregate<E, R> aggregate)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param target
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XRemovingCollection#moveTo(net.jadoth.collections.XGettingCollection, net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public <L extends Collecting<E>> L moveTo(final L target, final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param target
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XRemovingCollection#moveTo(net.jadoth.collections.XGettingCollection, net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public <L extends Collecting<E>> L moveTo(final L target, final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param target
	 * @param predicate
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XRemovingCollection#moveTo(net.jadoth.collections.XGettingCollection, net.jadoth.lang.functional.Predicate, int)
	 */
	@Override
	public <L extends Collecting<E>> L moveTo(final L target, final Predicate<E> predicate,final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param target
	 * @param predicate
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XRemovingCollection#moveTo(net.jadoth.collections.XGettingCollection, net.jadoth.lang.functional.controlflow.TPredicate, int)
	 */
	@Override
	public <L extends Collecting<E>> L moveTo(final L target, final TPredicate<E> predicate,final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param targetCollection
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngCopyTo(int, int, net.jadoth.collections.XAddingCollection, net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public <L extends Collecting<E>> L rngCopyTo(final int startIndex, final int endIndex, final L targetCollection, final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param targetCollection
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngCopyTo(int, int, net.jadoth.collections.XAddingCollection, net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public <L extends Collecting<E>> L rngCopyTo(final int startIndex, final int endIndex, final L targetCollection, final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param targetCollection
	 * @param predicate
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngCopyTo(int, int, net.jadoth.collections.XAddingCollection, net.jadoth.lang.functional.Predicate, int)
	 */
	@Override
	public <L extends Collecting<E>> L rngCopyTo(final int startIndex, final int endIndex, final L targetCollection, final Predicate<E> predicate,final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param targetCollection
	 * @param predicate
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XGettingList#rngCopyTo(int, int, net.jadoth.collections.XAddingCollection, net.jadoth.lang.functional.controlflow.TPredicate, int)
	 */
	@Override
	public <L extends Collecting<E>> L rngCopyTo(final int startIndex, final int endIndex, final L targetCollection, final TPredicate<E> predicate,final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param targetCollection
	 * @return
	 * @see net.jadoth.collections.XGettingList#copyRange(int, int, net.jadoth.collections.XAddingCollection)
	 */
	@Override
	public <L extends Collecting<E>> L copyRange(final int startIndex, final int endIndex, final L targetCollection)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param target
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XRemovingList#rngMoveTo(int, int, net.jadoth.collections.XAddingCollection, net.jadoth.lang.functional.Predicate)
	 */
	@Override
	public <L extends Collecting<E>> L rngMoveTo(final int startIndex, final int endIndex, final L target, final Predicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param target
	 * @param predicate
	 * @return
	 * @see net.jadoth.collections.XRemovingList#rngMoveTo(int, int, net.jadoth.collections.XAddingCollection, net.jadoth.lang.functional.controlflow.TPredicate)
	 */
	@Override
	public <L extends Collecting<E>> L rngMoveTo(final int startIndex, final int endIndex, final L target, final TPredicate<E> predicate)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param target
	 * @param predicate
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XRemovingList#rngMoveTo(int, int, net.jadoth.collections.XAddingCollection, net.jadoth.lang.functional.Predicate, int)
	 */
	@Override
	public <L extends Collecting<E>> L rngMoveTo(final int startIndex, final int endIndex, final L target, final Predicate<E> predicate,final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <L>
	 * @param startIndex
	 * @param endIndex
	 * @param target
	 * @param predicate
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XRemovingList#rngMoveTo(int, int, net.jadoth.collections.XAddingCollection, net.jadoth.lang.functional.controlflow.TPredicate, int)
	 */
	@Override
	public <L extends Collecting<E>> L rngMoveTo(final int startIndex, final int endIndex, final L target, final TPredicate<E> predicate,final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param c
	 * @param ignoreNulls
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#containsAll(java.util.Collection, boolean, net.jadoth.lang.Equalator)
	 */
	@Override
	public boolean containsAll(final Collection<E> c, final boolean ignoreNulls, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return false;
	}


	/**
	 * @param c
	 * @param ignoreNulls
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#containsAll(java.util.Collection, boolean)
	 */
	@Override
	public boolean containsAll(final Collection<E> c, final boolean ignoreNulls)
	{
		// TODO Auto-generated method stub
		return false;
	}


	/**
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XSettingList#sort(java.util.Comparator)
	 */
	@Override
	public XList<E> sort(final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <C>
	 * @param targetCollection
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#distinct(net.jadoth.collections.Collecting)
	 */
	@Override
	public <C extends Collecting<E>> C distinct(final C targetCollection)
	{
		// TODO Auto-generated method stub
		return null;
	}


	/**
	 * @param <C>
	 * @param targetCollection
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XGettingCollection#distinct(net.jadoth.collections.Collecting, net.jadoth.lang.Equalator)
	 */
	@Override
	public <C extends Collecting<E>> C distinct(final C targetCollection, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param oldElements
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(E[], java.lang.Object)
	 */
	@Override
	public int replaceAll(final E[] oldElements, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}


	/**
	 * @param oldElements
	 * @param newElement
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(E[], java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int replaceAll(final E[] oldElements, final E newElement, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}


	/**
	 * @param oldElements
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(XGettingCollection, java.lang.Object)
	 */
	@Override
	public int replaceAll(final XGettingCollection<E> oldElements, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}


	/**
	 * @param oldElements
	 * @param newElement
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(net.jadoth.collections.XGettingCollection, java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int replaceAll(final XGettingCollection<E> oldElements, final E newElement, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replace(net.jadoth.lang.functional.Predicate, java.lang.Object)
	 */
	@Override
	public int replace(final Predicate<E> predicate, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replace(net.jadoth.lang.functional.controlflow.TPredicate, java.lang.Object)
	 */
	@Override
	public int replace(final TPredicate<E> predicate, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replace(net.jadoth.lang.functional.Predicate, java.lang.Object, int, int)
	 */
	@Override
	public int replace(final Predicate<E> predicate, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replace(net.jadoth.lang.functional.controlflow.TPredicate, java.lang.Object, int, int)
	 */
	@Override
	public int replace(final TPredicate<E> predicate, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceOne(net.jadoth.lang.functional.Predicate, java.lang.Object)
	 */
	@Override
	public int replaceOne(final Predicate<E> predicate, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}


	/**
	 * @param predicate
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceOne(net.jadoth.lang.functional.controlflow.TPredicate, java.lang.Object)
	 */
	@Override
	public int replaceOne(final TPredicate<E> predicate, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}


	/**
	 * @param oldElements
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(E[], java.lang.Object, int, int)
	 */
	@Override
	public int replaceAll(final E[] oldElements, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}


	/**
	 * @param oldElements
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(E[], java.lang.Object, int, int, net.jadoth.lang.Equalator)
	 */
	@Override
	public int replaceAll(final E[] oldElements, final E newElement, final int skip, final Integer limit, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}


	/**
	 * @param oldElements
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(XGettingCollection, java.lang.Object, int, int)
	 */
	@Override
	public int replaceAll(final XGettingCollection<E> oldElements, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}


	/**
	 * @param oldElements
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(net.jadoth.collections.XGettingCollection, java.lang.Object, int, int, net.jadoth.lang.Equalator)
	 */
	@Override
	public int replaceAll(final XGettingCollection<E> oldElements, final E newElement, final int skip, final Integer limit, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}







}
