/**
 *
 */
package net.jadoth.collections;


import net.jadoth.lang.Equalator;
import net.jadoth.lang.functional.Operation;
import net.jadoth.lang.functional.Predicate;
import net.jadoth.lang.functional.Processable;
import net.jadoth.lang.functional.controlflow.TOperation;
import net.jadoth.lang.functional.controlflow.TPredicate;
import net.jadoth.lang.functional.controlflow.TProcessable;

/**
 * @author Thomas Muenz
 *
 */
public interface XRemovingCollection<E>
extends
XGettingCollection<E>,
Processable<E, Operation<E>>,
TProcessable<E, TOperation<E>>
{
	public interface Factory<E> extends XGettingCollection.Factory<E>
	{
		@Override
		public XRemovingCollection<E> createInstance();
	}



	public XRemovingCollection<E> execute( Operation<E> operation);
	public XRemovingCollection<E> execute(TOperation<E> operation);

	public XRemovingCollection<E> process( Operation<E> operation);
	public XRemovingCollection<E> process(TOperation<E> operation);

	public void clear();

	public E removeOne(E element);
	public E removeOne(E element, Equalator<E> equalator);

	public int removeId(E element);
	public int remove  (E element, Equalator<E> equalator);

	public int removeId(E element, int skip, Integer limit);
	public int remove  (E element, int skip, Integer limit, Equalator<E> equalator);

	public int removeAllId(XCollection<E> c, boolean ignoreNulls);
	public int removeAll  (XCollection<E> c, boolean ignoreNulls, Equalator<E> equalator);

	public int retainAllId(XCollection<E> c);
	public int retainAll  (XCollection<E> c, Equalator<E> equalator);

	public int removeDuplicates(boolean ignoreNulls);
	public int removeDuplicates(boolean ignoreNulls, Equalator<E> equalator);
	// intentionally no removeDuplicates(..., skip, limit) as this wouldn't make much sense

	public int reduce( Predicate<E> predicate);
	public int reduce(TPredicate<E> predicate);
	public int reduce( Predicate<E> predicate, int skip, Integer limit);
	public int reduce(TPredicate<E> predicate, int skip, Integer limit);

	public <C extends Collecting<E>> C moveTo(C target,  Predicate<E> predicate);
	public <C extends Collecting<E>> C moveTo(C target, TPredicate<E> predicate);
	public <C extends Collecting<E>> C moveTo(C target,  Predicate<E> predicate, int skip, Integer limit);
	public <C extends Collecting<E>> C moveTo(C target, TPredicate<E> predicate, int skip, Integer limit);

	/**
	 * Clears (and reinitializes if needed) this collection in the fastest possible way, i.e. by allocating a new and
	 * empty internal storage. The collection will be empty after calling this method.
	 * @return this collection
	 */
	public XRemovingCollection<E> truncate();
}
