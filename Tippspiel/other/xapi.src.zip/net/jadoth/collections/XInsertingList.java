/**
 *
 */
package net.jadoth.collections;

import net.jadoth.lang.functional.Predicate;
import net.jadoth.lang.functional.controlflow.TPredicate;


/**
 * @author Thomas Muenz
 *
 */
public interface XInsertingList<E> extends XAddingList<E>
{
	public interface Factory<E> extends XAddingList.Factory<E>
	{
		@Override
		public XInsertingList<E> createInstance();
	}


	public XInsertingList<E> prepend(E element);

	// method signatures blocked by java.util.List
//	public void add(int index, E element);
//	public boolean addAll(int index, final Collection<? extends E> c);

	public XInsertingList<E> insert(int index, E element);
	public XInsertingList<E> insert(int index, E... elements);
	public XInsertingList<E> insert(int index, Iterable<? extends E> elements);

	public XInsertingList<E> insert(int index, E[] elements, int srcIndex, int srcLength, Predicate<E> predicate, int skip, Integer limit);
	public XInsertingList<E> insert(int index, E[] elements, int srcIndex, int srcLength, TPredicate<E> predicate, int skip, Integer limit);

	public XInsertingList<E> insert(int index, Iterable<? extends E> elements, int srcIndex, Integer srcLength, Predicate<E> predicate, int skip, Integer limit);
	public XInsertingList<E> insert(int index, Iterable<? extends E> elements, int srcIndex, Integer srcLength, TPredicate<E> predicate, int skip, Integer limit);

}
