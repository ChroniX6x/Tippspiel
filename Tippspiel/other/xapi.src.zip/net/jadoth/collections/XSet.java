/**
 * 
 */
package net.jadoth.collections;

/**
 * @author Thomas Muenz
 *
 */
public interface XSet
{

}
