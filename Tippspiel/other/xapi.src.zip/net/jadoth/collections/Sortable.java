/**
 * 
 */
package net.jadoth.collections;

import java.util.Comparator;

/**
 * @author Thomas Muenz
 *
 */
public interface Sortable<E>
{
	public Sortable<E> sort(Comparator<E> comparator);
}
