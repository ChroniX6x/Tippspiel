/**
 *
 */
package net.jadoth.collections;


/**
 * A {@link XList} implementation view on an array.<br>
 * <br>
 * Note that any interface method that would have to modify the length of the array (add, remove, insert, clear, etc.)
 * will throw an {@link UnsupportedOperationException} without further ado.
 *
 * @author Thomas Muenz
 *
 */
public class ArrayView<E> //implements XGettingList<E>
{
	// (01.10.2010)TODO ArrayView
}