/**
 * 
 */
package net.jadoth.collections;

import java.util.Comparator;
import java.util.List;
import java.util.Map;

import net.jadoth.lang.Equalator;
import net.jadoth.lang.functional.Operation;
import net.jadoth.lang.functional.Predicate;
import net.jadoth.lang.functional.controlflow.TOperation;
import net.jadoth.lang.functional.controlflow.TPredicate;

/**
 * @author Thomas Muenz
 *
 */
public class SubListAccessor<E> extends SubListView<E> implements XSettingList<E>
{

	@Override
	public SubListAccessor<E> execute(final Operation<E> operation)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SubListAccessor<E> execute(final TOperation<E> operation)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SubListAccessor<E> process(final Operation<E> operation)
	{
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SubListAccessor<E> process(final TOperation<E> operation)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param element
	 * @return
	 * @see net.jadoth.collections.XSettingList#fill(int, int, java.lang.Object)
	 */
	@Override
	public XList<E> fill(final int startIndex, final int endIndex, final E element)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @return
	 * @see net.jadoth.collections.XSettingList#reverse()
	 */
	@Override
	public XList<E> reverse()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElement
	 * @param newElement
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplace(int, int, java.lang.Object, java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int rngReplace(final int startIndex, final int endIndex, final E oldElement, final E newElement, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElement
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplace(int, int, java.lang.Object, java.lang.Object)
	 */
	@Override
	public int rngReplace(final int startIndex, final int endIndex, final E oldElement, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElement
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplace(int, int, java.lang.Object, java.lang.Object, int, int, net.jadoth.lang.Equalator)
	 */
	@Override
	public int rngReplace(final int startIndex, final int endIndex, final E oldElement, final E newElement, final int skip, final Integer limit, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElement
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplace(int, int, java.lang.Object, java.lang.Object, int, int)
	 */
	@Override
	public int rngReplace(final int startIndex, final int endIndex, final E oldElement, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param replacementMapping
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplaceAll(int, int, java.util.Map)
	 */
	@Override
	public int rngReplaceAll(final int startIndex, final int endIndex, final Map<E, E> replacementMapping)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElement
	 * @param newElement
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplaceOne(int, int, java.lang.Object, java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int rngReplaceOne(final int startIndex, final int endIndex, final E oldElement, final E newElement, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElement
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplaceOne(int, int, java.lang.Object, java.lang.Object)
	 */
	@Override
	public int rngReplaceOne(final int startIndex, final int endIndex, final E oldElement, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReverse(int, int)
	 */
	@Override
	public XList<E> rngReverse(final int startIndex, final int endIndex)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngShuffle(int, int)
	 */
	@Override
	public XList<E> rngShuffle(final int startIndex, final int endIndex)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngSortMerge(int, int, java.util.Comparator)
	 */
	@Override
	public XList<E> rngSortMerge(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngSortQuick(int, int, java.util.Comparator)
	 */
	@Override
	public XList<E> rngSortQuick(final int startIndex, final int endIndex, final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param elements
	 * @return
	 * @see net.jadoth.collections.XSettingList#set(int, E[])
	 */
	@Override
	public XList<E> set(final int startIndex, final E... elements)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param elements
	 * @param elementsStartIndex
	 * @param length
	 * @return
	 * @see net.jadoth.collections.XSettingList#set(int, E[], int, int)
	 */
	@Override
	public XList<E> set(final int startIndex, final E[] elements, final int elementsStartIndex, final int length)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param startIndex
	 * @param elements
	 * @param elementsStartIndex
	 * @param length
	 * @return
	 * @see net.jadoth.collections.XSettingList#set(int, java.util.List, int, int)
	 */
	@Override
	public XList<E> set(final int startIndex, final List<E> elements, final int elementsStartIndex, final int length)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param element
	 * @see net.jadoth.collections.XSettingList#setFirst(java.lang.Object)
	 */
	@Override
	public void setFirst(final E element)
	{
		// TODO Auto-generated method stub
		
	}

	/**
	 * @param element
	 * @see net.jadoth.collections.XSettingList#setLast(java.lang.Object)
	 */
	@Override
	public void setLast(final E element)
	{
		// TODO Auto-generated method stub
		
	}

	/**
	 * @return
	 * @see net.jadoth.collections.XSettingList#shuffle()
	 */
	@Override
	public XList<E> shuffle()
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XSettingList#sort(java.util.Comparator)
	 */
	@Override
	public XList<E> sort(final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XSettingList#sortMerge(java.util.Comparator)
	 */
	@Override
	public XList<E> sortMerge(final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param comparator
	 * @return
	 * @see net.jadoth.collections.XSettingList#sortQuick(java.util.Comparator)
	 */
	@Override
	public XList<E> sortQuick(final Comparator<E> comparator)
	{
		// TODO Auto-generated method stub
		return null;
	}

	/**
	 * @param indexA
	 * @param indexB
	 * @see net.jadoth.collections.XSettingList#swap(int, int)
	 */
	@Override
	public void swap(final int indexA, final int indexB)
	{
		// TODO Auto-generated method stub
		
	}

	/**
	 * @param indexA
	 * @param indexB
	 * @param length
	 * @see net.jadoth.collections.XSettingList#swap(int, int, int)
	 */
	@Override
	public void swap(final int indexA, final int indexB, final int length)
	{
		// TODO Auto-generated method stub
		
	}

	/**
	 * @param oldElement
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replace(java.lang.Object, java.lang.Object)
	 */
	@Override
	public int replace(final E oldElement, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param oldElement
	 * @param newElement
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replace(java.lang.Object, java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int replace(final E oldElement, final E newElement, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param oldElement
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replace(java.lang.Object, java.lang.Object, int, int)
	 */
	@Override
	public int replace(final E oldElement, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param oldElement
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replace(java.lang.Object, java.lang.Object, int, int, net.jadoth.lang.Equalator)
	 */
	@Override
	public int replace(final E oldElement, final E newElement, final int skip, final Integer limit, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param predicate
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replace(net.jadoth.lang.functional.Predicate, java.lang.Object)
	 */
	@Override
	public int replace(final Predicate<E> predicate, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param predicate
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replace(net.jadoth.lang.functional.controlflow.TPredicate, java.lang.Object)
	 */
	@Override
	public int replace(final TPredicate<E> predicate, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param predicate
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replace(net.jadoth.lang.functional.Predicate, java.lang.Object, int, int)
	 */
	@Override
	public int replace(final Predicate<E> predicate, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param predicate
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replace(net.jadoth.lang.functional.controlflow.TPredicate, java.lang.Object, int, int)
	 */
	@Override
	public int replace(final TPredicate<E> predicate, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param replacementMapping
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(java.util.Map)
	 */
	@Override
	public int replaceAll(final Map<E, E> replacementMapping)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param oldElements
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(E[], java.lang.Object)
	 */
	@Override
	public int replaceAll(final E[] oldElements, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param oldElements
	 * @param newElement
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(E[], java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int replaceAll(final E[] oldElements, final E newElement, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param oldElements
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(XGettingCollection, java.lang.Object)
	 */
	@Override
	public int replaceAll(final XGettingCollection<E> oldElements, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param oldElements
	 * @param newElement
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(net.jadoth.collections.XGettingCollection, java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int replaceAll(final XGettingCollection<E> oldElements, final E newElement, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param oldElements
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(E[], java.lang.Object, int, int)
	 */
	@Override
	public int replaceAll(final E[] oldElements, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param oldElements
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(E[], java.lang.Object, int, int, net.jadoth.lang.Equalator)
	 */
	@Override
	public int replaceAll(final E[] oldElements, final E newElement, final int skip, final Integer limit, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param oldElements
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(XGettingCollection, java.lang.Object, int, int)
	 */
	@Override
	public int replaceAll(final XGettingCollection<E> oldElements, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param oldElements
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceAll(net.jadoth.collections.XGettingCollection, java.lang.Object, int, int, net.jadoth.lang.Equalator)
	 */
	@Override
	public int replaceAll(final XGettingCollection<E> oldElements, final E newElement, final int skip, final Integer limit, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param oldElement
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceOne(java.lang.Object, java.lang.Object)
	 */
	@Override
	public int replaceOne(final E oldElement, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param oldElement
	 * @param newElement
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceOne(java.lang.Object, java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int replaceOne(final E oldElement, final E newElement, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param predicate
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceOne(net.jadoth.lang.functional.Predicate, java.lang.Object)
	 */
	@Override
	public int replaceOne(final Predicate<E> predicate, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param predicate
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingCollection#replaceOne(net.jadoth.lang.functional.controlflow.TPredicate, java.lang.Object)
	 */
	@Override
	public int replaceOne(final TPredicate<E> predicate, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplace(int, int, net.jadoth.lang.functional.Predicate, java.lang.Object)
	 */
	@Override
	public int rngReplace(final int startIndex, final int endIndex, final Predicate<E> predicate, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplace(int, int, net.jadoth.lang.functional.controlflow.TPredicate, java.lang.Object)
	 */
	@Override
	public int rngReplace(final int startIndex, final int endIndex, final TPredicate<E> predicate, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplace(int, int, net.jadoth.lang.functional.Predicate, java.lang.Object, int, int)
	 */
	@Override
	public int rngReplace(final int startIndex, final int endIndex, final Predicate<E> predicate, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplace(int, int, net.jadoth.lang.functional.controlflow.TPredicate, java.lang.Object, int, int)
	 */
	@Override
	public int rngReplace(final int startIndex, final int endIndex, final TPredicate<E> predicate, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElements
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplaceAll(int, int, E[], java.lang.Object)
	 */
	@Override
	public int rngReplaceAll(final int startIndex, final int endIndex, final E[] oldElements, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElements
	 * @param newElement
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplaceAll(int, int, E[], java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int rngReplaceAll(final int startIndex, final int endIndex, final E[] oldElements, final E newElement, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElements
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplaceAll(int, int, XGettingCollection<E>, java.lang.Object)
	 */
	@Override
	public int rngReplaceAll(final int startIndex, final int endIndex, final XGettingCollection<E> oldElements, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElements
	 * @param newElement
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplaceAll(int, int, net.jadoth.collections.XGettingCollection, java.lang.Object, net.jadoth.lang.Equalator)
	 */
	@Override
	public int rngReplaceAll(final int startIndex, final int endIndex, final XGettingCollection<E> oldElements, final E newElement, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElements
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplaceAll(int, int, E[], java.lang.Object, int, int)
	 */
	@Override
	public int rngReplaceAll(final int startIndex, final int endIndex, final E[] oldElements, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElements
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplaceAll(int, int, E[], java.lang.Object, int, int, net.jadoth.lang.Equalator)
	 */
	@Override
	public int rngReplaceAll(final int startIndex, final int endIndex, final E[] oldElements, final E newElement, final int skip, final Integer limit, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElements
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplaceAll(int, int, XGettingCollection<E>, java.lang.Object, int, int)
	 */
	@Override
	public int rngReplaceAll(final int startIndex, final int endIndex, final XGettingCollection<E> oldElements, final E newElement, final int skip, final Integer limit)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param oldElements
	 * @param newElement
	 * @param skip
	 * @param limit
	 * @param equalator
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplaceAll(int, int, net.jadoth.collections.XGettingCollection, java.lang.Object, int, int, net.jadoth.lang.Equalator)
	 */
	@Override
	public int rngReplaceAll(final int startIndex, final int endIndex, final XGettingCollection<E> oldElements, final E newElement, final int skip, final Integer limit, final Equalator<E> equalator)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplaceOne(int, int, net.jadoth.lang.functional.Predicate, java.lang.Object)
	 */
	@Override
	public int rngReplaceOne(final int startIndex, final int endIndex, final Predicate<E> predicate, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	/**
	 * @param startIndex
	 * @param endIndex
	 * @param predicate
	 * @param newElement
	 * @return
	 * @see net.jadoth.collections.XSettingList#rngReplaceOne(int, int, net.jadoth.lang.functional.controlflow.TPredicate, java.lang.Object)
	 */
	@Override
	public int rngReplaceOne(final int startIndex, final int endIndex, final TPredicate<E> predicate, final E newElement)
	{
		// TODO Auto-generated method stub
		return 0;
	}

	
}