/**
 * 
 */
package net.jadoth.collections;

/**
 * @author Thomas Muenz
 *
 */
public class ListAccessor<E> //implements XSettingList<E>
{

}
