/**
 *
 */
package net.jadoth.collections;

import java.util.List;

/**
 * @author Thomas Muenz
 *
 */


public final class MapEntryProviderIdentity implements MapEntryProvider
{

	/**
	 * @param hash
	 * @param key
	 * @param value
	 * @return
	 * @see net.jadoth.collections.MapEntryProvider#createEntry(int, java.lang.Object, java.lang.Object)
	 */
	@Override
	public <K, V> IdentityMapEntry<K, V> createEntry(final int hash, final K key, final V value)
	{
		return new IdentityMapEntry<K, V>(/*hash, */key, value);
	}

	/**
	 * @param key
	 * @return
	 * @see net.jadoth.collections.MapEntryProvider#hash(java.lang.Object)
	 */
	@Override
	public int hash(final Object key)
	{
		return System.identityHashCode(key);
	}

}


final class IdentityMapEntry<K, V> implements MapEntry<K, V>
{
	private final Object key;
	private Object value;
//	private final int hash;
	private IdentityMapEntry<K, V> next = null;

	IdentityMapEntry(/*final int hash, */final Object key, final Object value)
	{
		super();
//		this.hash = hash;
		this.key = key;
		this.value = value;
	}

	/**
	 * @param hash
	 * @param key
	 * @param value
	 * @param provider
	 * @return
	 * @see net.jadoth.collections.MapEntry#set(int, java.lang.Object, java.lang.Object, net.jadoth.collections.MapEntryProvider)
	 */
	@Override
	public Object set(final int hash, final Object key, final Object value)
	{
		if(this.key == key){
			final Object oldValue = this.value;
			this.value = value;
			return oldValue;
		}

		IdentityMapEntry<K,V> current = this;
		while(current.next != null){
			current = current.next;
			if(current.key == key){
				final Object oldValue = current.value;
				current.value = value;
				return oldValue;
			}
		}
		current.next = new IdentityMapEntry<K,V>(/*hash, */key, value);
		return VarMap.NEW_MARKER;
	}

	/**
	 * @param hash
	 * @param key
	 * @return
	 * @see net.jadoth.collections.MapEntry#get(int, java.lang.Object)
	 */
	@Override
	public Object get(final int hash, final Object key)
	{
		if(this.key == key){
			return this.value;
		}
		IdentityMapEntry<K,V> current = this;
		while((current = current.next) != null){
			if(current.key == key){
				return current.value;
			}
		}
		return null;
	}

	/**
	 * @return
	 * @see net.jadoth.collections.MapEntry#next()
	 */
	@Override
	public MapEntry<K,V> next()
	{
		return this.next();
	}

	/**
	 * @param hash
	 * @param key
	 * @return
	 * @see net.jadoth.collections.MapEntry#remove(int, java.lang.Object)
	 */
	@Override
	public MapEntry<K,V> remove(final int hash, final Object key)
	{
		if(this.key == key){
			return this;
		}
		IdentityMapEntry<K,V> current = this;
		while((current = current.next) != null){
			if(current.key == key){
				return current;
			}
		}
		return null;
	}

	/**
	 * @return
	 * @see net.jadoth.collections.MapEntry#value()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public V value()
	{
		return (V)this.value;
	}

	/**
	 * @param hash
	 * @param key
	 * @return
	 * @see net.jadoth.collections.MapEntry#has(int, java.lang.Object)
	 */
	@Override
	public boolean has(final int hash, final Object key)
	{
		if(this.key == key){
			return true;
		}
		IdentityMapEntry<K,V> current = this;
		while((current = current.next) != null){
			if(current.key == key){
				return true;
			}
		}
		return false;
	}

	/**
	 * @param value
	 * @return
	 * @see net.jadoth.collections.MapEntry#has(java.lang.Object)
	 */
	@Override
	public boolean has(final Object value)
	{
		if(this.value == value){
			return true;
		}
		IdentityMapEntry<K,V> current = this;
		while((current = current.next) != null){
			if(current.value == value){
				return true;
			}
		}
		return false;
	}

	/**
	 * @param valuesList
	 * @return
	 * @see net.jadoth.collections.MapEntry#addValues(java.util.List)
	 */
	@Override
	public int addValues(final List<Object> valuesList)
	{
		valuesList.add(this.value);
		int count = 1;
		IdentityMapEntry<K,V> current = this;
		while((current = current.next) != null){
			valuesList.add(current.value);
			count++;
		}
		return count;
	}

	/**
	 * @return
	 */
	@Override
	public boolean isHollow()
	{
		// concrete reference entries can never become hollow
		return false;
	}

	
	/**
	 * @return
	 * @see net.jadoth.collections.MapEntry#getHash()
	 */
	@Override
	public int getHash()
	{
		return System.identityHashCode(this.key);
	}

	/**
	 * @param entry
	 * @see net.jadoth.collections.MapEntry#setNext(net.jadoth.collections.MapEntry)
	 */
	@Override
	public void setNext(final MapEntry<K,V> entry)
	{
		this.next = (IdentityMapEntry<K,V>)entry;	
	}

	/**
	 * @return
	 * @see net.jadoth.util.KeyValue#key()
	 */
	@SuppressWarnings("unchecked")
	@Override
	public K key()
	{
		return (K)this.key;
	}

}
