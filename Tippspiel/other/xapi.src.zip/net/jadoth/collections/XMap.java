/**
 *
 */
package net.jadoth.collections;

import net.jadoth.util.KeyValue;


/**
 * @author TM
 *
 */
public interface XMap<K,V> extends XList<KeyValue<K,V>>
{
	// Hold a lazy cached KeyValue-ConstList that is nulled on each structural modification
	// Hold a lazy cached KeySet-ConstList that is nulled on each structural modification
	// Hold a lazy cached ValueSet-ConstList that is nulled on each structural modification

	
}
