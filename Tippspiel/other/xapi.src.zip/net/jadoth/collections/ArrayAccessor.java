/**
 *
 */
package net.jadoth.collections;


/**
 * A {@link XList} implementation view on an array.<br>
 * <br>
 * Note that any interface method that would have to modify the length of the array (add, remove, insert, clear, etc.)
 * will throw an {@link UnsupportedOperationException} without further ado.
 *
 * @author Thomas Muenz
 *
 */
public class ArrayAccessor<E> //implements XGetSetList<E>, List<E>
{
	// (13.09.2010 TM)FIXME: copy from GrowList when complete and replace length modifying code with throw ~Exception

	///////////////////////////////////////////////////////////////////////////
	// instance fields //
	////////////////////

	private E[] data;



	///////////////////////////////////////////////////////////////////////////
	// constructors //
	/////////////////

	/**
	 * @param data
	 */
	public ArrayAccessor(final E[] data)
	{
		super();
		this.data = data;
	}



	///////////////////////////////////////////////////////////////////////////
	// getters          //
	/////////////////////

	/**
	 *
	 * @return
	 */

	public E[] getArray()
	{
		return this.data;
	}



	///////////////////////////////////////////////////////////////////////////
	// setters          //
	/////////////////////

	/**
	 * @param array the data to set
	 */
	public void setArray(final E[] array)
	{
		this.data = array;
	}

	public ArrayAccessor<E> wrap(final E[] array)
	{
		this.data = array;
		return this;
	}


	///////////////////////////////////////////////////////////////////////////
	// declared methods //
	/////////////////////

	public GrowList<E> toGrowList()
	{
		return new GrowList<E>(this.data);
	}

//	private String excRangeString(final int startIndex, final int endIndex)
//	{
//		return "Range ["+endIndex+';'+startIndex+"] not in [0;"+(this.data.length-1)+"].";
//	}



	///////////////////////////////////////////////////////////////////////////
	// override methods //
	/////////////////////


}