/**
 *
 */
package net.jadoth.collections;

import net.jadoth.lang.functional.Operation;
import net.jadoth.lang.functional.controlflow.TOperation;


/**
 * @author Thomas Muenz
 *
 */
public interface XCollection<E>
extends
XSettingCollection<E>,
XAddingCollection<E>,
XRemovingCollection<E>
{
	public interface Factory<E>
	extends XSettingCollection.Factory<E>, XAddingCollection.Factory<E>, XRemovingCollection.Factory<E>
	{
		@Override
		public XCollection<E> createInstance();
	}



	public XCollection<E> execute( Operation<E> operation);
	public XCollection<E> execute(TOperation<E> operation);

	public XCollection<E> process( Operation<E> operation);
	public XCollection<E> process(TOperation<E> operation);

}
//(19.08.2010 TM):
/*
HashCollections TO DO (maybe):
EqualityMap
IdentityMap

WeakEqualityMap
WeakIdentityMap

Ganz wichtig:
"ThreadCache" oder sowas:
Map<Thread, Irgendwas):
Threads k�nnen sich global irgendwelche Dinger (z.B. stateful Predicates etc) halten, die sie dann
thread-safe verwenden k�nnen (z.B. State immer wieder resetten und neu setzen statt immer wieder neue Dinger
instanzieren)


EqualitySet
IdentitySet
OrderedEqualitySet
OrderedIdentitySet

WeakEqualitySet
WeakIdentitySet
WeakOrderedEqualitySet
WeakOrderedIdentitySet
 */
