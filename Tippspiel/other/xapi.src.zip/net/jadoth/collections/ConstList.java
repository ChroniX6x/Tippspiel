/**
 *
 */
package net.jadoth.collections;

/**
 * @author TM
 *
 */
public class ConstList //implements XGettingList<E>
{
	/*
	See text in XList interface for full description
	  
	implementation class |   get  |   set  |   add  | remove | insert | growing
	GrowList                  v        v        v        v        v        v
	LimitedList               v        v        v        v        v
	FixedList                 v        v
	ConstList                 v
	*/	
}
