/**
 *
 */
package net.jadoth.collections;

/**
 * @author Thomas Muenz
 *
 */
public interface MapEntryProvider
{
	public <K, V> IdentityMapEntry<K, V> createEntry(final int hash, final K key, final V value);

	public int hash(Object key);
}
