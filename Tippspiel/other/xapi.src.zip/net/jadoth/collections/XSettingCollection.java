/**
 *
 */
package net.jadoth.collections;

import java.util.Map;

import net.jadoth.lang.Equalator;
import net.jadoth.lang.functional.Operation;
import net.jadoth.lang.functional.Predicate;
import net.jadoth.lang.functional.controlflow.TOperation;
import net.jadoth.lang.functional.controlflow.TPredicate;

/**
 * @author Thomas Muenz
 *
 */
public interface XSettingCollection<E> extends XGettingCollection<E>
{
	public interface Factory<E> extends XGettingCollection.Factory<E>
	{
		@Override
		public XSettingCollection<E> createInstance();
	}


	public XSettingCollection<E> execute(Operation<E> operation);
	public XSettingCollection<E> execute(TOperation<E> operation);

	public XSettingCollection<E> process(Operation<E> operation);
	public XSettingCollection<E> process(TOperation<E> operation);


	/**
	 * 
	 * @param oldElement
	 * @param newElement
	 * @return a value greater than or equal to 0 if an element has been found and replaced, a negative value otherwise.
	 */
	public int replaceOne(E oldElement, E newElement);
	/**
	 * 
	 * @param oldElement
	 * @param newElement
	 * @param equalator
	 * @return a value greater than or equal to 0 if an element has been found and replaced, a negative value otherwise.
	 */
	public int replaceOne(E oldElement, E newElement, Equalator<E> equalator);
	/**
	 * 
	 * @param oldElement
	 * @param newElement
	 * @return the amount of replacements that has been executed by the call of this method.
	 */
	public int replace(E oldElement, E newElement);
	/**
	 * 
	 * @param oldElement
	 * @param newElement
	 * @param equalator
	 * @return the amount of replacements that has been executed by the call of this method.
	 */
	public int replace(E oldElement, E newElement, Equalator<E> equalator);
	/**
	 * 
	 * @param oldElement
	 * @param newElement
	 * @param limit
	 * @return the amount of replacements that has been executed by the call of this method.
	 */
	public int replace(E oldElement, E newElement, int skip, Integer limit);
	/**
	 * 
	 * @param oldElement
	 * @param newElement
	 * @param limit
	 * @param equalator
	 * @return the amount of replacements that has been executed by the call of this method.
	 */
	public int replace(E oldElement, E newElement, int skip, Integer limit, Equalator<E> equalator);



	//ignores null values in multiples
	
	/**
	 * 
	 * @param replacementMapping
	 * @return the amount of replacements that has been executed by the call of this method.
	 */
	public int replaceAll(Map<E, E> replacementMapping);
	
	public int replaceAll(E[] oldElements, E newElement);
	public int replaceAll(E[] oldElements, E newElement, Equalator<E> equalator);
	public int replaceAll(XGettingCollection<E> oldElements, E newElement);
	public int replaceAll(XGettingCollection<E> oldElements, E newElement, Equalator<E> equalator);
	
	public int replaceAll(E[] oldElements, E newElement, int skip, Integer limit);
	public int replaceAll(E[] oldElements, E newElement, int skip, Integer limit, Equalator<E> equalator);
	public int replaceAll(XGettingCollection<E> oldElements, E newElement, int skip, Integer limit);
	public int replaceAll(XGettingCollection<E> oldElements, E newElement, int skip, Integer limit, Equalator<E> equalator);

	public int replaceOne( Predicate<E> predicate, E newElement);
	public int replaceOne(TPredicate<E> predicate, E newElement);

	public int replace( Predicate<E> predicate, E newElement);
	public int replace(TPredicate<E> predicate, E newElement);
	public int replace( Predicate<E> predicate, E newElement, int skip, Integer limit);
	public int replace(TPredicate<E> predicate, E newElement, int skip, Integer limit);
}
