/**
 * 
 */
package net.jadoth.collections;

/**
 * @author Thomas Muenz
 *
 */
public class ListView<E> //implements XGettingList<E>
{
// (01.10.2010)TODO ListView
}
