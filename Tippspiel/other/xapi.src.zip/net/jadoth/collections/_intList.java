/**
 *
 */
package net.jadoth.collections;

/**
 * @author Thomas Muenz
 *
 */
public class _intList
{
	// (02.09.2010 TM)TODO: _intList (copy from GrowList when completed)

}
