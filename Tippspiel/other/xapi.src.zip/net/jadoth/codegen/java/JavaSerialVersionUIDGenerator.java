/**
 * 
 */
package net.jadoth.codegen.java;

/**
 * @author Thomas Muenz
 *
 */
public class JavaSerialVersionUIDGenerator
{

}
