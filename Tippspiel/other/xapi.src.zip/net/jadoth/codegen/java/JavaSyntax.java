/*
 * Copyright (c) 2008-2010, Thomas M�nz
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package net.jadoth.codegen.java;

import static net.jadoth.Jadoth.appendArray;
import static net.jadoth.Jadoth.appendArraySeperated;
import static net.jadoth.codegen.Punctuation._;
import static net.jadoth.codegen.Punctuation.apo;
import static net.jadoth.codegen.Punctuation.comma_;
import static net.jadoth.codegen.Punctuation.dot;
import static net.jadoth.codegen.Punctuation.par;
import static net.jadoth.codegen.Punctuation.rap;
import static net.jadoth.codegen.java.Java.Lang.$class;
import static net.jadoth.codegen.java.Java.Lang.$extends;
import static net.jadoth.codegen.java.Java.Lang.$implements;
import static net.jadoth.codegen.java.Java.Lang.$new;
import static net.jadoth.codegen.java.Java.Punctuation.genericsEnd;
import static net.jadoth.codegen.java.Java.Punctuation.genericsStart;

import java.util.HashMap;
import java.util.HashSet;

import net.jadoth.codegen.AbstractSyntax;
import net.jadoth.lang.reflection.JaReflect;

// TODO: Auto-generated Javadoc
/**
 * The Class JavaSyntax.
 * 
 * @author Thomas M�nz
 */
public class JavaSyntax extends AbstractSyntax 
{	
	
	/** The Constant directBoxable. */
	static final HashSet<Class<?>> directBoxable = new HashSet<Class<?>>();
	
	/** The Constant boxable. */
	static final HashSet<Class<?>> boxable = new HashSet<Class<?>>();
	
	/** The Constant singleton. */
	private static final JavaSyntax singleton = new JavaSyntax();
	
	static {
		directBoxable.add(boolean.class);
		directBoxable.add(byte.class);
		directBoxable.add(short.class);
		directBoxable.add(int.class);
		directBoxable.add(long.class);
		directBoxable.add(float.class);
		directBoxable.add(double.class);
		
		directBoxable.add(Boolean.class);
		directBoxable.add(Byte.class);
		directBoxable.add(Short.class);
		directBoxable.add(Integer.class);
		directBoxable.add(Long.class);
		directBoxable.add(Float.class);
		directBoxable.add(Double.class);
		
		boxable.addAll(directBoxable);
		boxable.add(char.class);
		boxable.add(Character.class);
		boxable.add(String.class);		
	}
	
	
	/**
	 * Quote.
	 * 
	 * @param s the s
	 * @return the string
	 */
	public static String quote(String s){
		return singleton.$quote(s);
	}
	
	/**
	 * Instantiate.
	 * 
	 * @param type the type
	 * @param value the value
	 * @return the string
	 */
	public static String instantiate(Class<?> type, String value){
		if(value == null) return null;
		
		if(directBoxable.contains(type)){
			return value;
		}
		if(type == Character.class || type == Character.TYPE){			
			return new StringBuilder(3).append(apo).append(value).append(apo).toString();
		}
		else if(type == String.class){
			return singleton.$quote(value);
		}
		else {
			return new StringBuilder(64) 
			.append($new).append(_).append(type.getSimpleName()).append(par).append(value).append(rap)
			.toString();
		}		
	}
	

	
	///////////////////////////////////////////////////////////////////////////
	// constructors //
	/////////////////
	/**
	 * Instantiates a new java syntax.
	 */
	public JavaSyntax(){
		super();
	}
	
	

	///////////////////////////////////////////////////////////////////////////
	// declared methods //
	/////////////////////
	/**
	 * _class.
	 * 
	 * @param sb the sb
	 * @param className the class name
	 * @param genericBounds the generic bounds
	 * @param superClass the super class
	 * @param superClassParams the super class params
	 * @param superClassEnclosingClassParams the super class enclosing class params
	 * @param interfaces the interfaces
	 * @return the string builder
	 */
	public StringBuilder _class(
			StringBuilder sb, 
			final String className, 
			final String genericBounds, 
			final Class<?> superClass, 
			final String superClassParams,
			final String superClassEnclosingClassParams,
			final String... interfaces
	){
		if(sb == null){
			sb = new StringBuilder(128);
		}
		sb.append($class).append(_).append(className);
		if(genericBounds != null && genericBounds.length() > 0){
			sb.append(_).append(genericsStart).append(genericBounds).append(genericsEnd);
		}
		if(superClass != null){			
			HashMap<Class<?>, String> params = null;
			if(superClass.getEnclosingClass() != null){
				params = new HashMap<Class<?>, String>(1);
				params.put(superClass.getEnclosingClass(), superClassEnclosingClassParams);
			}
			
			sb.append(_).append($extends).append(_);
			sb.append(JaReflect.getFullClassName(superClass, params));
		}
		if(superClassParams != null && superClassParams.length() > 0){
			sb.append(genericsStart).append(superClassParams).append(genericsEnd);
		}
		if(interfaces != null && interfaces.length > 0){
			sb.append(_).append($implements).append(_);
			appendArray(sb, comma_, interfaces);
		}
		
		return sb;
	}
	
	/**
	 * $class.
	 * 
	 * @param className the class name
	 * @param genericBounds the generic bounds
	 * @param superClass the super class
	 * @param superClassParameterisation the super class parameterisation
	 * @param superClassEnclosingClassParams the super class enclosing class params
	 * @param implementedInterfaces the implemented interfaces
	 * @return the string
	 */
	public String $class(
		final String className, 
		final String genericBounds, 
		final Class<?> superClass, 
		final String superClassParameterisation,
		final String superClassEnclosingClassParams,
		final String... implementedInterfaces
	){
		return _class(
			null, 
			className, 
			genericBounds, 
			superClass, 
			superClassParameterisation, 
			superClassEnclosingClassParams, 
			implementedInterfaces
		).toString();
	}
	
	
	/**
	 * Call method.
	 * 
	 * @param methodName the method name
	 * @return the string
	 */
	public static String callMethod(final String methodName){
		return callMethod(null, methodName, (Object[])null);
	}
	
	/**
	 * Call method.
	 * 
	 * @param owner the owner
	 * @param methodName the method name
	 * @return the string
	 */
	public static String callMethod(final String owner, final String methodName){
		return callMethod(owner, methodName, (Object[])null);
	}		
	
	/**
	 * Call method.
	 * 
	 * @param owner the owner
	 * @param methodName the method name
	 * @param paramterStrings the paramter strings
	 * @return the string
	 */
	public static String callMethod(final String owner, final String methodName, final Object... paramterStrings){
		final StringBuilder sb = new StringBuilder(512);
		if(owner != null){
			sb.append(owner).append(dot);
		}
		sb.append(methodName).append(par);
		appendArraySeperated(sb, ", ", paramterStrings);
		sb.append(rap);
		return sb.toString();
	}
	
	
	
}
