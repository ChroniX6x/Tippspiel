/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import java.util.ArrayList;

import net.jadoth.lang.functional.Operation;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaPrimitiveType extends JavaTypeDescription
{
	
	
	public Class<?> getPrimitiveClass();
	
	
	public class Implementation extends JavaCompilationObject.Implementation implements JavaPrimitiveType
	{
		///////////////////////////////////////////////////////////////////////////
		// instance fields  //
		/////////////////////
		
		private final Class<?> primitiveClass;
		
		
		
		Implementation(final Class<?> primitiveClass)
		{
			super(null);
			this.primitiveClass = primitiveClass;
		}

		@Override
		public Class<?> getPrimitiveClass()
		{
			return primitiveClass;
		}

		@Override
		public String getClassSignature()
		{
			// TODO Auto-generated method stub
			return null;
		}


		/**
		 * @return
		 */
		@Override
		public Iterable<JavaTypeMemberDescription> iterateMembers()
		{
			// (16.06.2010 TM)TODO: TM Auto-generated method stub
			return null;
		}


		/**
		 * @return
		 */
		@Override
		public Iterable<JavaInterfaceDescription> iterateSuperInterfaces()
		{
			// (16.06.2010 TM)TODO: TM Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 */
		@Override
		public Iterable<JavaGenericParameter> iterateGenericParameters()
		{
			// (16.06.2010 TM)TODO: TM Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 */
		@Override
		public int getModifiers()
		{
			// (16.06.2010 TM)TODO: TM Auto-generated method stub
			return 0;
		}

		/**
		 * @return
		 */
		@Override
		public String getName()
		{
			// (16.06.2010 TM)TODO: TM Auto-generated method stub
			return null;
		}

		/**
		 * @param memberProcessor
		 */
		@Override
		public void processMembers(final Operation<JavaTypeMemberDescription> memberProcessor)
		{
			
		}

		/**
		 * @return
		 */
		@Override
		public Iterable<JavaFieldDescription> iterateFields()
		{
			return new ArrayList<JavaFieldDescription>(0);
		}

		/**
		 * @return
		 */
		@Override
		public Iterable<JavaMethodDescription> iterateMethods()
		{
			return new ArrayList<JavaMethodDescription>(0);
		}

		/**
		 * @return
		 */
		@Override
		public Iterable<JavaClassDescription> iterateNestedClasses()
		{
			return new ArrayList<JavaClassDescription>(0);
		}

		/**
		 * @return
		 */
		@Override
		public Iterable<JavaInterfaceDescription> iterateNestedInterfaces()
		{
			return new ArrayList<JavaInterfaceDescription>(0);
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDescription#getOwnerType()
		 */
		@Override
		public JavaTypeDescription getOwnerType()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassMemberDescription#getOwnerClass()
		 */
		@Override
		public JavaClassDefinition getOwnerClass()
		{
			// TODO Auto-generated method stub
			return null;
		}
		
		
		/**
		 * @return always <tt>null</tt>
		 * @see java.lang.reflect.Member#getDeclaringClass()
		 */
		@Override
		public Class<?> getDeclaringClass()
		{
			return null;
		}

		/**
		 * @return always <tt>false</tt>
		 * @see java.lang.reflect.Member#isSynthetic()
		 */
		@Override
		public boolean isSynthetic()
		{
			return false;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeDescription#getCanonicalName()
		 */
		@Override
		public String getCanonicalName()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeDescription#getSimpleName()
		 */
		@Override
		public String getSimpleName()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 */
		@Override
		public int getNestingLevel()
		{
			// (30.06.2010 TM)TODO: TM Auto-generated method stub
			return 0;
		}
		
		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaKeywordOwner#getKeyword()
		 */
		@Override
		public String getKeyword()
		{
			return null;
		}
		
	}

}
