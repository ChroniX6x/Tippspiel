/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import net.jadoth.util.strings.Nameable;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaCompilationObject extends Nameable
{	
	
	public class Implementation implements JavaCompilationObject
	{
		///////////////////////////////////////////////////////////////////////////
		// instance fields  //
		/////////////////////
		
		private String name;

		
		
		///////////////////////////////////////////////////////////////////////////
		// constructors     //
		/////////////////////
		
		Implementation(final String name)
		{
			super();
			this.name = name;
		}

		
		
		///////////////////////////////////////////////////////////////////////////
		// getters          //
		/////////////////////
		
		/**
		 * @return
		 * @see net.jadoth.util.strings.Named#getName()
		 */
		@Override
		public String getName()
		{
			return this.name;
		}

		
		
		///////////////////////////////////////////////////////////////////////////
		// setters          //
		/////////////////////
		
		public JavaCompilationObject setName(final String name)
		{
			this.name = name;
			return this;
		}



			
		
	}
	
}
