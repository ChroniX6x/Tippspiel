/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaCodeHolder extends JavaClassMemberDefinition
{
	public JavaBlock getCodeBlock();
	
	public JavaCodeHolder code(CharSequence... code);
	
}
