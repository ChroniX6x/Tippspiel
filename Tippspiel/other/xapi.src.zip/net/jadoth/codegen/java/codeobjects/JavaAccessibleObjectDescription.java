/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;



/**
 * Represents an AccessibleObject (super class of Field, Method and Constructor)
 * @author Thomas Muenz
 *
 */
public interface JavaAccessibleObjectDescription 
extends JavaClassMemberDescription, JavaAnnotatedElementDescription
{
	
}
