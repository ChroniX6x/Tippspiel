/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import java.lang.reflect.Type;

import net.jadoth.codegen.java.Java;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaImportDefinition extends JavaCompilationUnitMember, JavaKeywordOwner
{
	public JavaTypeDescription getImportedType();
	
	
	public class Implementation extends JavaCompilationObject.Implementation implements JavaImportDefinition
	{
		///////////////////////////////////////////////////////////////////////////
		// instance fields  //
		/////////////////////
		
		private final JavaTypeDescription importedType;
		private JavaCompilationUnit owner;
		
		
		
		///////////////////////////////////////////////////////////////////////////
		// constructors     //
		/////////////////////
		
		Implementation(final JavaTypeDescription importedType)
		{
			super(null);
			this.importedType = importedType;
		}
		Implementation(final Type type)
		{
			this(JavaTypeDescription.Implementation.wrap(type));
		}
		
		
		
		///////////////////////////////////////////////////////////////////////////
		// override methods //
		/////////////////////
		
		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaImportDefinition#getImportedType()
		 */
		@Override
		public JavaTypeDescription getImportedType()
		{
			return this.importedType;
		}

		

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#getOwnerCompilationUnit()
		 */
		@Override
		public JavaCompilationUnit getOwnerCompilationUnit()
		{
			return this.owner;
		}

		/**
		 * @param compilationUnit
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#registerAtOwner(JavaCompilationUnit)
		 */
		@Override
		public JavaCompilationUnitMember registerAtOwner(final JavaCompilationUnit compilationUnit)
		{
			compilationUnit.add(this);
			return this;
		}

		/**
		 * @param owner
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#setOwner(JavaCompilationUnit)
		 */
		@Override
		public void setOwner(final JavaCompilationUnit owner)
		{
			this.owner = owner;			
		}
		
		/**
		 * @param codeGenerator
		 * @see net.jadoth.codegen.java.codeobjects.JavaCodeAssembable#assemble(StringBuilder, net.jadoth.codegen.java.codeobjects.JavaCodeGenerator)
		 */
		@Override
		public void assemble(final StringBuilder sb, final JavaCodeGenerator codeGenerator)
		{
			codeGenerator.assembleJavaImportDefinition(sb, this);			
		}



		/**
		 * @return
		 * @see net.jadoth.util.strings.Named#getName()
		 */
		@Override
		public String getName()
		{
			return Java.Lang.$import;
		}



		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#getAssociatedComment()
		 */
		@Override
		public JavaCommentBlock getAssociatedComment()
		{
			// TODO Auto-generated method stub
			return null;
		}



		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#getJavaDoc()
		 */
		@Override
		public JavaDocBlock getJavaDoc()
		{
			// TODO Auto-generated method stub
			return null;
		}
		
		
		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaKeywordOwner#getKeyword()
		 */
		@Override
		public String getKeyword()
		{
			return Java.Lang.$import;
		}
		
		
	}

}
