/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaCommentLine extends JavaComment
{
	public class Implementation extends JavaComment.Implementation implements JavaCommentLine
	{

		public Implementation(final String commentString)
		{
			super(commentString);
		}
		
	}
	
}
