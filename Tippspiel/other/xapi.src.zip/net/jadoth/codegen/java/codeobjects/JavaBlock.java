/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaBlock extends JavaCompilationObject
{
	public JavaCodeHolder getOwner();
}
