/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaTypeWrapper extends JavaTypeDescription
{
	public Class<?> getWrappedType();
	
	
	
	public class Implementation extends JavaTypeDescription.Implementation implements JavaTypeWrapper
	{
		private final Class<?> wrappedType;

		public Implementation(final Class<?> wrappedType)
		{
			super(wrappedType.getModifiers(), wrappedType.getSimpleName());
			this.wrappedType = wrappedType;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeWrapper#getWrappedType()
		 */
		@Override
		public Class<?> getWrappedType()
		{
			return this.wrappedType;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaKeywordOwner#getKeyword()
		 */
		@Override
		public String getKeyword()
		{
			return null;
		}

		@Override
		public String getCanonicalName()
		{
			return this.wrappedType.getCanonicalName();
		}
		
		
		
		
		
		
	}
}
