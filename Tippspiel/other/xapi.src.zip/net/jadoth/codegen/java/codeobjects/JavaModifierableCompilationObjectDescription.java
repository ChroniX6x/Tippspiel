/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaModifierableCompilationObjectDescription extends JavaCompilationObject
{	
	public int getModifiers();
	
	
	public abstract class Implementation extends JavaCompilationObject.Implementation 
	implements JavaModifierableCompilationObjectDescription
	{
		///////////////////////////////////////////////////////////////////////////
		// instance fields  //
		/////////////////////
		
		private int modifiers = 0;
		
		
		
		///////////////////////////////////////////////////////////////////////////
		// constructors     //
		/////////////////////
		
		/**
		 * @param name
		 */
		Implementation(final int modifier, final String name)
		{
			super(name);
			this.modifiers = modifier;			
		}

		
		protected JavaModifierableCompilationObjectDescription setModifiers(final int modifiers)
		{
			this.modifiers = modifiers;
			return this;
		}


		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaModifierableCompilationObjectDescription#getModifiers()
		 */
		@Override
		public int getModifiers()
		{
			return this.modifiers;
		}
		
		
		
		protected abstract boolean isValidModifier(final int modifier);

		
	}
	
}
