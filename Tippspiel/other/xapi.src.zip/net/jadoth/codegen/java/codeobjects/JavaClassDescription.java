/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import java.util.LinkedHashSet;

import net.jadoth.codegen.java.Java;



/**
 * Represents a Java class.
 * 
 * @author Thomas Muenz
 *
 */
public interface JavaClassDescription extends JavaTypeDescription
{
	public Iterable<? extends JavaClassMemberDescription> iterateClassMembers();
	
	public Iterable<? extends JavaConstructorDescription> iterateConstructors();
	
	public Iterable<? extends JavaInitializer> iterateInitializers();
	
	
			
	
	public class Implementation extends JavaTypeDescription.Implementation implements JavaClassDescription
	{
		///////////////////////////////////////////////////////////////////////////
		// instance fields  //
		/////////////////////	
		
		private Class<?> wrappedClass = null;
		private transient JavaClassDescription superClassDescription = null;
		
		private final LinkedHashSet<JavaClassMemberDefinition> classMembers = new LinkedHashSet<JavaClassMemberDefinition>();
		
		
		
		///////////////////////////////////////////////////////////////////////////
		// constructors //
		/////////////////
		
		/**
		 * @param modifiers
		 * @param name
		 */
		Implementation(final int modifiers, final String name)
		{
			super(modifiers, name);
		}
		
		Implementation(final Class<?> wrappedClass)
		{
			super(wrappedClass.getModifiers(), wrappedClass.getSimpleName());
		}
		
		
		
		///////////////////////////////////////////////////////////////////////////
		// getters          //
		/////////////////////
		
		/**
		 * @return the superClass
		 */
		public JavaClassDescription getSuperClassDescription()
		{
			if(superClassDescription == null && this.wrappedClass != null){
				final Class<?> wrapperClassSuperClass = this.wrappedClass.getSuperclass();
				if(wrapperClassSuperClass != null && wrapperClassSuperClass != Object.class){
					this.superClassDescription = new JavaClassDescription.Implementation(wrapperClassSuperClass);
				}
			}
			return this.superClassDescription;
		}
		
		
		
		///////////////////////////////////////////////////////////////////////////
		// setters          //
		/////////////////////
		
		/**
		 * @param javaClass
		 * @return
		 */
		protected void setSuperClassDescription(final JavaClassDescription javaClass)
		{
			this.superClassDescription = javaClass;
		}
		
		
		
		///////////////////////////////////////////////////////////////////////////
		// override methods //
		/////////////////////
		
		@Override
		public Iterable<JavaClassMemberDefinition> iterateClassMembers()
		{
			return this.classMembers;
		}

		/**
		 * @return
		 */
		@Override
		public Iterable<? extends JavaConstructorDescription> iterateConstructors()
		{
			// (16.06.2010 TM)TODO: TM Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 */
		@Override
		public Iterable<? extends JavaInitializer> iterateInitializers()
		{
			// (16.06.2010 TM)TODO: TM Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaKeywordOwner#getKeyword()
		 */
		@Override
		public String getKeyword()
		{
			return Java.Lang.$class;
		}
		
	}
	
}
