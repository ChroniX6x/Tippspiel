/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import java.lang.reflect.Modifier;

/**
 * @author Thomas Muenz
 *
 */
public class JavaModifier
{
	
	public static final int DEFAULT = 1<<30;
	public static final int PRIVATE = Modifier.PRIVATE;
	public static final int PROTECTED = Modifier.PROTECTED;
	public static final int PUBLIC = Modifier.PUBLIC;
	
	public static final int STATIC = Modifier.STATIC;
	
	public static final int FINAL = Modifier.FINAL;
	
	public static final int ABSTRACT = Modifier.ABSTRACT;
	
	public static final int TRANSIENT = Modifier.TRANSIENT;
	
	public static final int VOLATILE = Modifier.VOLATILE;
	
	public static final int SYNCHRONIZED = Modifier.SYNCHRONIZED;
	
	public static final int NATIVE = Modifier.NATIVE;
	
	

	
	public static final int VISIBILITY = DEFAULT|PRIVATE|PROTECTED|PUBLIC;

	
	
	private final int modifiers;






	JavaModifier(final int modifiers)
	{
		super();
		this.modifiers = modifiers;
	}
	
	
	
	
	public int getModifiers()
	{
		return this.modifiers;
	}
	
}
