/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaDocBlock extends JavaComment
{
	public class Implementation extends JavaComment.Implementation implements JavaDocBlock
	{
		///////////////////////////////////////////////////////////////////////////
		// constructors     //
		/////////////////////
		
		public Implementation(final String javaDocString)
		{
			super(javaDocString);
		}
		
	}
	
}
