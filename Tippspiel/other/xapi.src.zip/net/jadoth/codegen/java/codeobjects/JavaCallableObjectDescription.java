/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * Method, Constructor
 * @author Thomas Muenz
 *
 */
public interface JavaCallableObjectDescription 
extends JavaAccessibleObjectDescription, JavaClassMemberDescription
{
	public Iterable<JavaParameter> iterateParameters();
	public Iterable<JavaThrowableType> iterateDeclaredThrowables();
}
