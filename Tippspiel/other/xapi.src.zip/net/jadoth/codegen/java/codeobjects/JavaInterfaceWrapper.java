/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import net.jadoth.lang.wrapperexceptions.InvalidClassRuntimeException;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaInterfaceWrapper extends JavaTypeWrapper, JavaInterfaceDescription
{

	
	public class Implementation extends JavaTypeWrapper.Implementation implements JavaInterfaceWrapper
	{
		private static final Class<?> validateWrappedType(final Class<?> wrappedType)
		{
			if(!wrappedType.isInterface()){
				throw new InvalidClassRuntimeException(wrappedType.getName());
			}
			return wrappedType;
		}
		
		/**
		 * @param wrappedType
		 */
		public Implementation(final Class<?> wrappedType)
		{
			super(validateWrappedType(wrappedType));
		}
		
	}
}
