/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaConstructorDescription extends JavaAccessibleObjectDescription, JavaCallableObjectDescription
{

}
