/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;



/**
 * Represents a Java class. Note that "class in this  
 * 
 * @author Thomas Muenz
 *
 */
public interface JavaInterfaceDefinition extends JavaInterfaceDescription, JavaTypeDefinition
{
	public static final int VALID_MODIFIERS = JavaModifier.VISIBILITY;
	
	
	public JavaInterfaceDefinition extendS(JavaInterfaceDescription... superInterfaces);
}
