/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * Method, Constructor
 * @author Thomas Muenz
 *
 */
public interface JavaCallableObjectDefinition 
extends JavaCallableObjectDescription, JavaClassMemberDefinition, JavaCodeHolder
{
	public JavaCallableObjectDefinition throwS(JavaThrowableType... throwables);
	
	public JavaCallableObjectDefinition throwS(Class<? extends Throwable>... throwables);
	
	
}
