/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import net.jadoth.codegen.java.Java;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaPackageDefinition extends JavaCompilationUnitMember, JavaKeywordOwner
{
	public String getPackage();
	public JavaPackageDefinition setPackage(String packageString);
	
	
	public class Implementation extends JavaCompilationObject.Implementation implements JavaPackageDefinition
	{
		private String packageString;

		Implementation(final String packageString)
		{
			super(null);
			this.packageString = packageString;
		}

		public String getPackage()
		{
			return packageString;
		}

		public JavaPackageDefinition setPackage(final String packageString)
		{
			this.packageString = packageString;
			return this;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#getOwnerCompilationUnit()
		 */
		@Override
		public JavaCompilationUnit getOwnerCompilationUnit()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @param compilationUnit
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#registerAtOwner(net.jadoth.codegen.java.codeobjects.JavaCompilationUnit)
		 */
		@Override
		public JavaCompilationUnitMember registerAtOwner(final JavaCompilationUnit compilationUnit)
		{
			compilationUnit.setPackageDefinition(this);
			return this;
		}

		/**
		 * @param owner
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#setOwner(net.jadoth.codegen.java.codeobjects.JavaCompilationUnit)
		 */
		@Override
		public void setOwner(final JavaCompilationUnit owner)
		{
			// TODO Auto-generated method stub
			
		}
		
		/**
		 * @param codeGenerator
		 * @see net.jadoth.codegen.java.codeobjects.JavaCodeAssembable#assemble(StringBuilder, net.jadoth.codegen.java.codeobjects.JavaCodeGenerator)
		 */
		@Override
		public void assemble(final StringBuilder sb, final JavaCodeGenerator codeGenerator)
		{
			codeGenerator.assembleJavaPackageDefinition(sb, this);			
		}


		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#getAssociatedComment()
		 */
		@Override
		public JavaCommentBlock getAssociatedComment()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#getJavaDoc()
		 */
		@Override
		public JavaDocBlock getJavaDoc()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaKeywordOwner#getKeyword()
		 */
		@Override
		public String getKeyword()
		{
			return Java.Lang.$package;
		}
		
		
	}
}
