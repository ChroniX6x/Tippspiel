/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import java.lang.reflect.Field;
import java.lang.reflect.Member;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Collection;

import net.jadoth.codegen.java.Java;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaImportStaticDefinition extends JavaCompilationUnitMember, JavaKeywordOwner
{
	public JavaTypeMemberDescription getStaticImportedMember();
	
	
	
	public class Implementation extends JavaCompilationObject.Implementation implements JavaImportStaticDefinition
	{
		private static final String import_static = Java.Lang.$import+' '+Java.Lang.$static;
		
		private static void validateMember(final Member member)
		{
			if(!(member instanceof JavaTypeMemberDescription 
				||   member instanceof Field || member instanceof Method)
			){
				throw new IllegalArgumentException("Cannot statically import "+member);					
			}
			
			if(!Modifier.isStatic(member.getModifiers())){
				throw new IllegalArgumentException("Cannot statically import non-static member: "+member);
			}
		}
		
		
		public static void addMembers(final Collection<JavaImportStaticDefinition> staticImports, final Member... staticMember)
		{
			//check-loop
			for(final Member member : staticMember) {
				JavaImportStaticDefinition.Implementation.validateMember(member);
			}
			
			//add-loop
			for(final Member member : staticMember) {
				staticImports.add(new JavaImportStaticDefinition.Implementation(member));
			}
		}
		
		
		///////////////////////////////////////////////////////////////////////////
		// constructors     //
		/////////////////////
		
		Implementation(final Member member)
		{
			super(null);
		}

		
		
		///////////////////////////////////////////////////////////////////////////
		// override methods //
		/////////////////////
		
		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaImportStaticDefinition#getStaticImportedMember()
		 */
		@Override
		public JavaTypeMemberDescription getStaticImportedMember()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#getOwnerCompilationUnit()
		 */
		@Override
		public JavaCompilationUnit getOwnerCompilationUnit()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @param compilationUnit
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#registerAtOwner(net.jadoth.codegen.java.codeobjects.JavaCompilationUnit)
		 */
		@Override
		public JavaCompilationUnitMember registerAtOwner(final JavaCompilationUnit compilationUnit)
		{
			// TODO Auto-generated method stub
			return this;
		}

		/**
		 * @param owner
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#setOwner(net.jadoth.codegen.java.codeobjects.JavaCompilationUnit)
		 */
		@Override
		public void setOwner(final JavaCompilationUnit owner)
		{
			// TODO Auto-generated method stub
			
		}
		
		/**
		 * @param codeGenerator
		 * @see net.jadoth.codegen.java.codeobjects.JavaCodeAssembable#assemble(StringBuilder, net.jadoth.codegen.java.codeobjects.JavaCodeGenerator)
		 */
		@Override
		public void assemble(final StringBuilder sb, final JavaCodeGenerator codeGenerator)
		{
			codeGenerator.assembleJavaImportStaticDefinition(sb, this);			
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#getAssociatedComment()
		 */
		@Override
		public JavaCommentBlock getAssociatedComment()
		{
			// TODO Auto-generated method stub
			return null;
		}


		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#getJavaDoc()
		 */
		@Override
		public JavaDocBlock getJavaDoc()
		{
			// TODO Auto-generated method stub
			return null;
		}
	
		
		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaKeywordOwner#getKeyword()
		 */
		@Override
		public String getKeyword()
		{
			return Java.Lang.$import;
		}
		
	}
}
