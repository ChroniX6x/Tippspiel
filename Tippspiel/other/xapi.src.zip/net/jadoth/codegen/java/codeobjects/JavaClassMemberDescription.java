/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * Represents a Java member. A member is a {@link JavaCompilationObject} that belongs to a {@link JavaCompilationUnit}.
 * 
 * @author Thomas Muenz
 *
 */
public interface JavaClassMemberDescription extends JavaCompilationObject
{
	public JavaClassDefinition getOwnerClass();
}
