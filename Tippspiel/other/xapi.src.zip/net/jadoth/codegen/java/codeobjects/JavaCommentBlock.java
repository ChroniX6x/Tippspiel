/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaCommentBlock extends JavaComment
{
	public class Implementation extends JavaComment.Implementation implements JavaCommentBlock
	{
		///////////////////////////////////////////////////////////////////////////
		// constructors     //
		/////////////////////
		
		public Implementation(final String commentString)
		{
			super(commentString);
		}
		
	}
	
}
