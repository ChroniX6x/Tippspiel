/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import static net.jadoth.codegen.java.codeobjects.JavaModifier.FINAL;
import static net.jadoth.codegen.java.codeobjects.JavaModifier.STATIC;
import static net.jadoth.codegen.java.codeobjects.JavaModifier.TRANSIENT;
import static net.jadoth.codegen.java.codeobjects.JavaModifier.VISIBILITY;
import static net.jadoth.codegen.java.codeobjects.JavaModifier.VOLATILE;



/**
 * @author Thomas Muenz
 *
 */
public interface JavaFieldDefinition 
extends JavaFieldDescription, JavaAccessibleObjectDefinition, JavaTypeMemberDefinition
{
	public static final int VALID_MODIFIERS = VISIBILITY|STATIC|FINAL|TRANSIENT|VOLATILE;
	
	public JavaFieldDefinition set(JavaExpression initialExpression);
	
	
	public class Implemenatation extends JavaModifierableCompilationObjectDefinition.Implementation
	implements JavaFieldDefinition
	{		
		///////////////////////////////////////////////////////////////////////////
		// instance fields  //
		/////////////////////
		
		private JavaTypeDefinition owner = null;
		private boolean ownerIsClass = false;
		
		private JavaExpression initialExpression;
		private JavaTypeDescription type;

		
		
		///////////////////////////////////////////////////////////////////////////
		// constructors     //
		/////////////////////
		
		Implemenatation(
			final int modifiers, 
			final JavaTypeDescription type, 
			final String name, 
			final JavaExpression initialExpression
		)
		{
			super(modifiers, name);
			this.type = type;
			this.initialExpression = initialExpression;
		}

		
		
		///////////////////////////////////////////////////////////////////////////
		// getters          //
		/////////////////////
	
		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaFieldDefinition#getInitialExpression()
		 */
		@Override
		public JavaExpression getInitialExpression()
		{
			return this.initialExpression;
		}
		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassMemberDefinition#getOwnerClass()
		 */
		@Override
		public JavaClassDefinition getOwnerClass()
		{
			return this.ownerIsClass ?(JavaClassDefinition)this.owner :null;
		}
		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDefinition#getOwnerType()
		 */
		@Override
		public JavaTypeDefinition getOwnerType()
		{
			return this.owner;
		}
		/**
		 * @return the type
		 */
		public JavaTypeDescription getType()
		{
			return type;
		}	

		
		///////////////////////////////////////////////////////////////////////////
		// setters          //
		/////////////////////
		
		@Override
		public void setOwner(final JavaTypeDefinition owner)
		{
			this.owner = owner;
			this.ownerIsClass = owner instanceof JavaClassDefinition;	
		}
	
		/**
		 * @param compilationUnit
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDefinition#setOwner(net.jadoth.codegen.java.codeobjects.JavaCompilationUnit)
		 */
		@Override
		public void registerAtOwner(final JavaTypeDefinition owner)
		{	
			owner.add(this);
		}
		/**
		 * @param initialExpression
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaFieldDefinition#setInitialExpression(net.jadoth.codegen.java.codeobjects.JavaExpression)
		 */
		@Override
		public JavaFieldDefinition set(final JavaExpression initialExpression)
		{
			this.initialExpression = initialExpression;
			return this;
		}
		/**
		 * @param type the type to set
		 */
		public void setType(final JavaTypeDescription type)
		{
			this.type = type;
		}



		/**
		 * @param modifier
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaModifierableCompilationObjectDefinition.Implementation#isValidModifier(int)
		 */
		@Override
		protected boolean isValidModifier(final int modifier)
		{
			// TODO Auto-generated method stub
			return false;
		}



		/**
		 * @param javaClass
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassMemberDefinition#setOwner(net.jadoth.codegen.java.codeobjects.JavaClassDefinition)
		 */
		@Override
		public boolean setOwner(final JavaClassDefinition javaClass)
		{
			// TODO Auto-generated method stub
			return false;
		}





		/**
		 * @return always <tt>null</tt>
		 * @see java.lang.reflect.Member#getDeclaringClass()
		 */
		@Override
		public Class<?> getDeclaringClass()
		{
			return null;
		}

		/**
		 * @return always <tt>false</tt>
		 * @see java.lang.reflect.Member#isSynthetic()
		 */
		@Override
		public boolean isSynthetic()
		{
			return false;
		}



		/**
		 * @param sb
		 * @param codeGenerator
		 * @see net.jadoth.codegen.java.codeobjects.JavaCodeAssembable#assemble(java.lang.StringBuilder, net.jadoth.codegen.java.codeobjects.JavaCodeGenerator)
		 */
		@Override
		public void assemble(final StringBuilder sb, final JavaCodeGenerator codeGenerator)
		{
			codeGenerator.assembleJavaFieldDefinition(sb, this);			
		}



		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDefinition#getNestingLevel()
		 */
		@Override
		public int getNestingLevel()
		{
			// TODO Auto-generated method stub
			return 0;
		}
			
		
	}
	
}
