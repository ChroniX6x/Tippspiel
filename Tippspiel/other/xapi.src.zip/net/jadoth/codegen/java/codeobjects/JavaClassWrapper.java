/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import net.jadoth.lang.wrapperexceptions.InvalidClassRuntimeException;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaClassWrapper extends JavaTypeWrapper, JavaClassDescription
{

	
	public class Implementation extends JavaTypeWrapper.Implementation implements JavaClassWrapper
	{
		private static final Class<?> validateWrappedType(final Class<?> wrappedType)
		{
			if(wrappedType.isInterface() || wrappedType.isAnnotation() || wrappedType.isEnum()){
				throw new InvalidClassRuntimeException(wrappedType.getName());
			}
			return wrappedType;
		}
		
		/**
		 * @param wrappedType
		 */
		public Implementation(final Class<?> wrappedType)
		{
			super(validateWrappedType(wrappedType));
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassDescription#iterateClassMembers()
		 */
		@Override
		public Iterable<? extends JavaClassMemberDescription> iterateClassMembers()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassDescription#iterateConstructors()
		 */
		@Override
		public Iterable<? extends JavaConstructorDescription> iterateConstructors()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassDescription#iterateInitializers()
		 */
		@Override
		public Iterable<? extends JavaInitializer> iterateInitializers()
		{
			// TODO Auto-generated method stub
			return null;
		}
		
	}
}
