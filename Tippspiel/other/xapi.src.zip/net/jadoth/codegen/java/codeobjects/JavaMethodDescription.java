/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;


/**
 * @author Thomas Muenz
 *
 */
public interface JavaMethodDescription 
extends JavaCallableObjectDescription, JavaTypedCodeObject, JavaGenericParametrizableObject, JavaTypeMemberDescription
{
	
}
