/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaArrayType extends JavaTypeDescription
{
	public JavaTypeDescription getComponentType();
}
