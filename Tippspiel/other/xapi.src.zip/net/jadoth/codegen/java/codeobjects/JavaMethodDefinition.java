/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import static net.jadoth.codegen.java.codeobjects.JavaModifier.ABSTRACT;
import static net.jadoth.codegen.java.codeobjects.JavaModifier.FINAL;
import static net.jadoth.codegen.java.codeobjects.JavaModifier.STATIC;
import static net.jadoth.codegen.java.codeobjects.JavaModifier.SYNCHRONIZED;
import static net.jadoth.codegen.java.codeobjects.JavaModifier.VISIBILITY;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaMethodDefinition 
extends JavaMethodDescription, JavaCallableObjectDefinition, JavaTypeMemberDefinition
{
	public static final int VALID_MODIFIERS = VISIBILITY|STATIC|FINAL|ABSTRACT|SYNCHRONIZED;
	
	
	
	public class Implementation extends JavaModifierableCompilationObjectDefinition.Implementation
	implements JavaMethodDefinition
	{
		///////////////////////////////////////////////////////////////////////////
		// instance fields  //
		/////////////////////
		
		private JavaTypeDescription type;
		
		
		///////////////////////////////////////////////////////////////////////////
		// constructors     //
		/////////////////////
		
		Implementation(
			final int modifiers, 
			final JavaTypeDescription type, 
			final String name
		)
		{
			super(modifiers, name);
			this.type = type;
		}
		

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCallableObjectDescription#iterateDeclaredThrowables()
		 */
		@Override
		public Iterable<JavaThrowableType> iterateDeclaredThrowables()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCallableObjectDescription#iterateParameters()
		 */
		@Override
		public Iterable<JavaParameter> iterateParameters()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassMemberDescription#getOwnerClass()
		 */
		@Override
		public JavaClassDefinition getOwnerClass()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.util.strings.Named#getName()
		 */
		@Override
		public String getName()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypedCodeObject#getType()
		 */
		@Override
		public JavaTypeDescription getType()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @param modifier
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaModifierableCompilationObjectDefinition#addModifier(int)
		 */
		@Override
		public JavaModifierableCompilationObjectDefinition addModifier(final int modifier)
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @param modifier
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaModifierableCompilationObjectDefinition#removeModifier(int)
		 */
		@Override
		public JavaModifierableCompilationObjectDefinition removeModifier(final int modifier)
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @param modifier
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaModifierableCompilationObjectDefinition#setModifiers(int)
		 */
		@Override
		public JavaModifierableCompilationObjectDefinition setModifiers(final int modifier)
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaModifierableCompilationObjectDescription#getModifiers()
		 */
		@Override
		public int getModifiers()
		{
			// TODO Auto-generated method stub
			return 0;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaGenericParametrizableObject#iterateGenericParameters()
		 */
		@Override
		public Iterable<JavaGenericParameter> iterateGenericParameters()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDescription#getNestingLevel()
		 */
		@Override
		public int getNestingLevel()
		{
			// TODO Auto-generated method stub
			return 0;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDescription#getOwnerType()
		 */
		@Override
		public JavaTypeDescription getOwnerType()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see java.lang.reflect.Member#getDeclaringClass()
		 */
		@Override
		public Class<?> getDeclaringClass()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see java.lang.reflect.Member#isSynthetic()
		 */
		@Override
		public boolean isSynthetic()
		{
			// TODO Auto-generated method stub
			return false;
		}

		/**
		 * @param throwables
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCallableObjectDefinition#throwS(net.jadoth.codegen.java.codeobjects.JavaThrowableType[])
		 */
		@Override
		public JavaCallableObjectDefinition throwS(final JavaThrowableType... throwables)
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @param throwables
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCallableObjectDefinition#throwS(java.lang.Class<? extends java.lang.Throwable>[])
		 */
		@Override
		public JavaCallableObjectDefinition throwS(final Class<? extends Throwable>... throwables)
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @param javaClass
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassMemberDefinition#setOwner(net.jadoth.codegen.java.codeobjects.JavaClassDefinition)
		 */
		@Override
		public boolean setOwner(final JavaClassDefinition javaClass)
		{
			// TODO Auto-generated method stub
			return false;
		}

		/**
		 * @param sb
		 * @param codeGenerator
		 * @see net.jadoth.codegen.java.codeobjects.JavaCodeAssembable#assemble(java.lang.StringBuilder, net.jadoth.codegen.java.codeobjects.JavaCodeGenerator)
		 */
		@Override
		public void assemble(final StringBuilder sb, final JavaCodeGenerator codeGenerator)
		{
			// TODO Auto-generated method stub
			
		}

		/**
		 * @param code
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCodeHolder#code(java.lang.CharSequence[])
		 */
		@Override
		public JavaCodeHolder code(final CharSequence... code)
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCodeHolder#getCodeBlock()
		 */
		@Override
		public JavaBlock getCodeBlock()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @param javaClass
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDefinition#registerAtOwner(net.jadoth.codegen.java.codeobjects.JavaTypeDefinition)
		 */
		@Override
		public void registerAtOwner(final JavaTypeDefinition javaClass)
		{
			// TODO Auto-generated method stub
			
		}

		/**
		 * @param javaClass
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDefinition#setOwner(net.jadoth.codegen.java.codeobjects.JavaTypeDefinition)
		 */
		@Override
		public void setOwner(final JavaTypeDefinition javaClass)
		{
			// TODO Auto-generated method stub
			
		}


		/**
		 * @param modifier
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaModifierableCompilationObjectDefinition.Implementation#isValidModifier(int)
		 */
		@Override
		protected boolean isValidModifier(final int modifier)
		{
			// TODO Auto-generated method stub
			return false;
		}
		
	}
}
