/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaObjectType extends JavaTypeDescription, JavaGenericParametrizableObject
{

}
