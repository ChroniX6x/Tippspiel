/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.LinkedHashSet;

import net.jadoth.lang.functional.Operation;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaTypeDescription 
extends JavaModifierableCompilationObjectDescription, JavaGenericParametrizableObject, 
JavaTypeMemberDescription, JavaClassMemberDescription, JavaKeywordOwner, Type
{	
	public String getClassSignature();
	
	public Iterable<? extends JavaInterfaceDescription> iterateSuperInterfaces();
	
	public Iterable<? extends JavaTypeMemberDescription> iterateMembers();
	
	public Iterable<? extends JavaFieldDescription> iterateFields();
	public Iterable<? extends JavaMethodDescription> iterateMethods();
	
	public Iterable<? extends JavaClassDescription> iterateNestedClasses();	
	public Iterable<? extends JavaInterfaceDescription> iterateNestedInterfaces();
	
	public void processMembers(Operation<JavaTypeMemberDescription> memberProcessor);
	
//	public Iterable<? extends JavaMemberDescription> processMembers(Predicate<JavaMemberDescription> predicate);
	
	public String getSimpleName();	
	public String getName();
	public String getCanonicalName();
		
	
	
	public abstract class Implementation extends JavaModifierableCompilationObjectDescription.Implementation
	implements JavaTypeDescription
	{	
		///////////////////////////////////////////////////////////////////////////
		// static methods   //
		/////////////////////
		
		public static JavaTypeDescription wrap(final Type type)
		{
			if(type instanceof JavaTypeDescription){
				return (JavaTypeDescription)type;
			}
			
			final Class<?> c = (Class<?>)type;
			if(c.isInterface()){
				return new JavaInterfaceWrapper.Implementation(c);
			}
			if(c.isEnum()){
				// (11.07.2010)FIXME: enum
			}
			if(c.isAnnotation()){
				// (11.07.2010)FIXME: annotation
			}
			return new JavaClassWrapper.Implementation(c);
		}
		
		///////////////////////////////////////////////////////////////////////////
		// instance fields  //
		/////////////////////
		
		private final LinkedHashSet<JavaTypeMemberDescription> members = new LinkedHashSet<JavaTypeMemberDescription>();

		/**
		 * @param modifier
		 * @param name
		 */
		Implementation(final int modifier, final String name)
		{
			super(modifier, name);
		}
				
		
		/**
		 * @param modifier
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaModifierableCompilationObjectDescription.Implementation#isValidModifier(int)
		 */
		@Override
		protected boolean isValidModifier(final int modifier)
		{
			// TODO Auto-generated method stub
			return false;
		}

//		/**
//		 * @return
//		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitDescription#iterateFields()
//		 */
//		@Override
//		public Iterable<JavaFieldDescription> iterateFields()
//		{
//			// TODO Auto-generated method stub
//			return null;
//		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitDescription#iterateAllMembers()
		 */
		@Override
		public Iterable<JavaTypeMemberDescription> iterateMembers()
		{
			// TODO Auto-generated method stub
			return null;
		}

//		/**
//		 * @return
//		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitDescription#iterateMethods()
//		 */
//		@Override
//		public Iterable<JavaMethodDescription> iterateMethods()
//		{
//			// TODO Auto-generated method stub
//			return null;
//		}

//		/**
//		 * @return
//		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitDescription#iterateNestedTypes()
//		 */
//		@Override
//		public Iterable<JavaTypeDescription> iterateNestedTypes()
//		{
//			// TODO Auto-generated method stub
//			return null;
//		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitDescription#iterateSuperInterfaces()
		 */
		@Override
		public Iterable<JavaInterfaceDescription> iterateSuperInterfaces()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaGenericParametrizableObject#iterateGenericParameters()
		 */
		@Override
		public Iterable<JavaGenericParameter> iterateGenericParameters()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeDescription#getClassSignature()
		 */
		@Override
		public String getClassSignature()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @param memberProcessor
		 */
		@Override
		public void processMembers(final Operation<JavaTypeMemberDescription> memberProcessor)
		{
			for(final JavaTypeMemberDescription member : this.members) {
				memberProcessor.execute(member);
			}			
		}

		/**
		 * @return
		 */
		@Override
		public Iterable<JavaFieldDescription> iterateFields()
		{
			final ArrayList<JavaFieldDescription> fields = new ArrayList<JavaFieldDescription>(this.members.size());
			for(final JavaTypeMemberDescription member : this.members) {
				if(member instanceof JavaFieldDescription){
					fields.add((JavaFieldDescription)member);
				}
			}
			return fields;
		}

		/**
		 * @return
		 */
		@Override
		public Iterable<JavaMethodDescription> iterateMethods()
		{
			final ArrayList<JavaMethodDescription> methods = new ArrayList<JavaMethodDescription>(this.members.size());
			for(final JavaTypeMemberDescription member : this.members) {
				if(member instanceof JavaMethodDescription){
					methods.add((JavaMethodDescription)member);
				}
			}
			return methods;
		}

		/**
		 * @return
		 */
		@Override
		public Iterable<JavaClassDescription> iterateNestedClasses()
		{
			final ArrayList<JavaClassDescription> classes = new ArrayList<JavaClassDescription>(this.members.size());
			for(final JavaTypeMemberDescription member : this.members) {
				if(member instanceof JavaClassDescription){
					classes.add((JavaClassDescription)member);
				}
			}
			return classes;
		}

		/**
		 * @return
		 */
		@Override
		public Iterable<JavaInterfaceDescription> iterateNestedInterfaces()
		{
			final ArrayList<JavaInterfaceDescription> interfaces = new ArrayList<JavaInterfaceDescription>(this.members.size());
			for(final JavaTypeMemberDescription member : this.members) {
				if(member instanceof JavaInterfaceDescription){
					interfaces.add((JavaInterfaceDescription)member);
				}
			}
			return interfaces;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDescription#getOwnerType()
		 */
		@Override
		public JavaTypeDescription getOwnerType()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassMemberDescription#getOwnerClass()
		 */
		@Override
		public JavaClassDefinition getOwnerClass()
		{
			// TODO Auto-generated method stub
			return null;
		}
		
		
		/**
		 * @return always <tt>null</tt>
		 * @see java.lang.reflect.Member#getDeclaringClass()
		 */
		@Override
		public Class<?> getDeclaringClass()
		{
			return null;
		}

		/**
		 * @return always <tt>false</tt>
		 * @see java.lang.reflect.Member#isSynthetic()
		 */
		@Override
		public boolean isSynthetic()
		{
			return false;
		}


		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeDescription#getCanonicalName()
		 */
		@Override
		public String getCanonicalName()
		{
			// TODO Auto-generated method stub
			return null;
		}


		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeDescription#getSimpleName()
		 */
		@Override
		public String getSimpleName()
		{
			// TODO Auto-generated method stub
			return null;
		}
		
		/**
		 * @return
		 */
		@Override
		public int getNestingLevel()
		{
			// (30.06.2010 TM)TODO: JavaTypeDesciption.Implementation.getNestingLevel()
//			if(this.owner == null) return 0;			
//			return this.owner.getNestingLevel()+1;
			return 0;
		}


				
	}
	
}
