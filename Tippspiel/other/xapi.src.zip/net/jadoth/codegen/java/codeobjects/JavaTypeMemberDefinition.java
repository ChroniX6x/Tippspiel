/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaTypeMemberDefinition extends JavaTypeMemberDescription, JavaCodeAssembable
{
	public void registerAtOwner(JavaTypeDefinition javaClass);
	public void setOwner(JavaTypeDefinition javaClass);
	
}
