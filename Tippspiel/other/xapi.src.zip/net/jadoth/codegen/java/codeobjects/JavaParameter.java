/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaParameter extends JavaTypedValue
{
	public JavaMethodDefinition getOwner();
}
