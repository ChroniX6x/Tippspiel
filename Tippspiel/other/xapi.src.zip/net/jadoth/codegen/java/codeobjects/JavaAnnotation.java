/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * Represents an Annotation
 * @author Thomas Muenz
 *
 */
public interface JavaAnnotation extends JavaCompilationObject, JavaCodeObjectAttachment
{

}
