/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import static net.jadoth.codegen.java.codeobjects.JavaSourceCodeFactory.Code.Constructor;
import static net.jadoth.codegen.java.codeobjects.JavaSourceCodeFactory.Code.clinit;
import static net.jadoth.codegen.java.codeobjects.JavaSourceCodeFactory.Code.exp;
import static net.jadoth.codegen.java.codeobjects.JavaSourceCodeFactory.Code.init;

import java.io.IOException;
import java.io.Serializable;
import java.sql.Date;


/**
 * @author Thomas Muenz
 *
 */
//@SuppressWarnings("unused")
public abstract class ATest implements JavaSourceCodeFactory
{

	
	/**
	 * @param args
	 */
	@SuppressWarnings("unchecked")
	public static void main(final String[] args)
	{		
		pubLic.Class("MyClass").extendS(Date.class).implementS(Serializable.class)
		.add(
			clinit(
				"System.out.println(\"loading class...\");"
			),
			init(
				"System.out.println(\"instantiating...\");"
			),
			public_final.Field(int$, "myVal"),
			public_final.Field(int$, "myVal2").set(exp(5)),
			
			Constructor(null, null),
			pubLic.Constructor(null, null).throwS(IllegalArgumentException.class)
			.code(
				"super();"
			),
			
			public_static_final.Method(int$, "bla", null, null),
			public_static_final.Method(int$, "bla").throwS(IOException.class, null, null)
			.code(
				"return 0;"
			),
			
			
			
			pubLic.Interface("inti").extendS(null, null, null),
			
			public_static.Class("Nesterl")
						
		)
		;
		
		

	}

}
