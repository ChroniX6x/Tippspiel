/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * Members, comments, blank lines, etc
 * @author Thomas Muenz
 *
 */
public interface JavaCompilationUnitMember extends JavaCompilationObject, JavaCodeAssembable
{
	public JavaCompilationUnit getOwnerCompilationUnit();
	
	public JavaCompilationUnitMember registerAtOwner(JavaCompilationUnit compilationUnit);
	public void setOwner(JavaCompilationUnit owner);
	
	public JavaDocBlock getJavaDoc();
	public JavaCommentBlock getAssociatedComment();
	
	
}
