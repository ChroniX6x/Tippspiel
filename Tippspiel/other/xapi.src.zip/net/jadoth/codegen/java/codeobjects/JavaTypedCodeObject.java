/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * (Variable,) Field, Parameter, Method
 * @author Thomas Muenz
 *
 */
public interface JavaTypedCodeObject extends JavaModifierableCompilationObjectDefinition
{
	public JavaTypeDescription getType();
}
