/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaModifierableCompilationObjectDefinition extends JavaModifierableCompilationObjectDescription
{
	public JavaModifierableCompilationObjectDefinition setModifiers(int modifier);
	public JavaModifierableCompilationObjectDefinition addModifier(int modifier);
	public JavaModifierableCompilationObjectDefinition removeModifier(int modifier);
	
	
	
	public abstract class Implementation extends JavaModifierableCompilationObjectDescription.Implementation 
	implements JavaModifierableCompilationObjectDefinition
	{
		///////////////////////////////////////////////////////////////////////////
		// constructors     //
		/////////////////////
		
		/**
		 * @param name
		 */
		Implementation(final int modifiers, final String name)
		{
			super(modifiers, name);
		}

		
		
		///////////////////////////////////////////////////////////////////////////
		// getters          //
		/////////////////////
		

		
		///////////////////////////////////////////////////////////////////////////
		// setters          //
		/////////////////////
		
		@Override
		public JavaModifierableCompilationObjectDefinition setModifiers(final int modifiers)
		{
			super.setModifiers(modifiers);
			return this;
		}



		///////////////////////////////////////////////////////////////////////////
		// override methods //
		/////////////////////
		
		/**
		 * @param modifier
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaModifierableCompilationObjectDefinition#addModifier(int)
		 */
		@Override
		public JavaModifierableCompilationObjectDefinition addModifier(final int modifier)
		{				
			super.setModifiers(this.getModifiers() | modifier);
			return this;
		}
		
		/**
		 * @param modifier
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaModifierableCompilationObjectDefinition#removeModifier(int)
		 */
		@Override
		public JavaModifierableCompilationObjectDefinition removeModifier(final int modifier)
		{
			super.setModifiers(this.getModifiers() & ~modifier);
			return this;
		}	
		
		
		@Override
		protected abstract boolean isValidModifier(final int modifier);
		
	}
	
}
