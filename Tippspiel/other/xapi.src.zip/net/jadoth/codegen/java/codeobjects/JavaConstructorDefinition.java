/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaConstructorDefinition 
extends JavaConstructorDescription, JavaAccessibleObjectDefinition, JavaCallableObjectDefinition
{

}
