/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import java.util.Iterator;

import net.jadoth.Jadoth;

/**
 * @author Thomas Muenz
 *
 */
public interface JavaCommentLineGroup extends JavaComment, Iterable<JavaCommentLine>
{
	public class Implementation implements JavaCommentLineGroup
	{		
		///////////////////////////////////////////////////////////////////////////
		// instance fields  //
		/////////////////////
		
		private final String[] commentStrings;
		
		

		///////////////////////////////////////////////////////////////////////////
		// constructors     //
		/////////////////////
		
		public Implementation(final String... commentStrings)
		{
			super();
			this.commentStrings = commentStrings;
		}

		
		
		///////////////////////////////////////////////////////////////////////////
		// override methods //
		/////////////////////
		
		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaComment#getCommentString()
		 */
		@Override
		public String getCommentString()
		{
			return Jadoth.concat('\n', (Object[])this.commentStrings);
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#getAssociatedComment()
		 */
		@Override
		public JavaCommentBlock getAssociatedComment()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#getJavaDoc()
		 */
		@Override
		public JavaDocBlock getJavaDoc()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#getOwnerCompilationUnit()
		 */
		@Override
		public JavaCompilationUnit getOwnerCompilationUnit()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @param compilationUnit
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#registerAtOwner(net.jadoth.codegen.java.codeobjects.JavaCompilationUnit)
		 */
		@Override
		public JavaCompilationUnitMember registerAtOwner(final JavaCompilationUnit compilationUnit)
		{
			// TODO Auto-generated method stub
			return this;
		}

		/**
		 * @param owner
		 * @see net.jadoth.codegen.java.codeobjects.JavaCompilationUnitMember#setOwner(net.jadoth.codegen.java.codeobjects.JavaCompilationUnit)
		 */
		@Override
		public void setOwner(final JavaCompilationUnit owner)
		{
			// TODO Auto-generated method stub
			
		}

		/**
		 * @return
		 * @see net.jadoth.util.strings.Named#getName()
		 */
		@Override
		public String getName()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @param sb
		 * @param codeGenerator
		 * @see net.jadoth.codegen.java.codeobjects.JavaCodeAssembable#assemble(java.lang.StringBuilder, net.jadoth.codegen.java.codeobjects.JavaCodeGenerator)
		 */
		@Override
		public void assemble(final StringBuilder sb, final JavaCodeGenerator codeGenerator)
		{
			// TODO Auto-generated method stub
			
		}

		/**
		 * @param javaClass
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDefinition#registerAtOwner(net.jadoth.codegen.java.codeobjects.JavaTypeDefinition)
		 */
		@Override
		public void registerAtOwner(final JavaTypeDefinition javaClass)
		{
			// TODO Auto-generated method stub
		}

		/**
		 * @param javaClass
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDefinition#setOwner(net.jadoth.codegen.java.codeobjects.JavaTypeDefinition)
		 */
		@Override
		public void setOwner(final JavaTypeDefinition javaClass)
		{
			// TODO Auto-generated method stub
			
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDescription#getNestingLevel()
		 */
		@Override
		public int getNestingLevel()
		{
			// TODO Auto-generated method stub
			return 0;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDescription#getOwnerType()
		 */
		@Override
		public JavaTypeDescription getOwnerType()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaModifierableCompilationObjectDescription#getModifiers()
		 */
		@Override
		public int getModifiers()
		{
			// TODO Auto-generated method stub
			return 0;
		}

		/**
		 * @return
		 * @see java.lang.reflect.Member#getDeclaringClass()
		 */
		@Override
		public Class<?> getDeclaringClass()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see java.lang.reflect.Member#isSynthetic()
		 */
		@Override
		public boolean isSynthetic()
		{
			// TODO Auto-generated method stub
			return false;
		}

		/**
		 * @param javaClass
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassMemberDefinition#setOwner(net.jadoth.codegen.java.codeobjects.JavaClassDefinition)
		 */
		@Override
		public boolean setOwner(final JavaClassDefinition javaClass)
		{
			// TODO Auto-generated method stub
			return false;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassMemberDescription#getOwnerClass()
		 */
		@Override
		public JavaClassDefinition getOwnerClass()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see java.lang.Iterable#iterator()
		 */
		@Override
		public Iterator<JavaCommentLine> iterator()
		{
			// TODO Auto-generated method stub
			return null;
		}
		
		/**
		 * @param name
		 * @return
		 * @see net.jadoth.util.strings.Nameable#setName(java.lang.String)
		 */
		@Override
		public Implementation setName(final String name)
		{
			// TODO Auto-generated method stub
			return null;
		}
		
	}
}
