/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;


/**
 * @author Thomas Muenz
 *
 */
public interface JavaInitializer extends JavaCodeHolder, JavaClassMemberDefinition
{
	
	
	
	public class Implementation extends JavaCompilationObject.Implementation implements JavaInitializer
	{

		Implementation()
		{
			super(null);
		}
		
		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCodeHolder#getCodeBlock()
		 */
		@Override
		public JavaBlock getCodeBlock()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @param javaClass
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassMemberDefinition#setOwner(net.jadoth.codegen.java.codeobjects.JavaClassDefinition)
		 */
		@Override
		public boolean setOwner(final JavaClassDefinition javaClass)
		{
			// TODO Auto-generated method stub
			return false;
		}

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassMemberDescription#getOwnerClass()
		 */
		@Override
		public JavaClassDefinition getOwnerClass()
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @return
		 * @see net.jadoth.util.strings.Named#getName()
		 */
		@Override
		public String getName()
		{
			// TODO Auto-generated method stub
			return null;
		}


		/**
		 * @param code
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaCodeHolder#code(java.lang.CharSequence[])
		 */
		@Override
		public JavaInitializer.Implementation code(final CharSequence... code)
		{
			// TODO Auto-generated method stub
			return null;
		}

		/**
		 * @param sb
		 * @param codeGenerator
		 * @see net.jadoth.codegen.java.codeobjects.JavaCodeAssembable#assemble(java.lang.StringBuilder, net.jadoth.codegen.java.codeobjects.JavaCodeGenerator)
		 */
		@Override
		public void assemble(final StringBuilder sb, final JavaCodeGenerator codeGenerator)
		{
			codeGenerator.assembleJavaInitializer(sb, this);			
		}


		
	}
}
