/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import net.jadoth.codegen.java.Java;



/**
 * Represents a Java class. Note that "class in this  
 * 
 * @author Thomas Muenz
 *
 */
public interface JavaInterfaceDescription extends JavaTypeDescription
{
	
	public class Implementation extends JavaTypeDescription.Implementation implements JavaInterfaceDescription
	{
		/**
		 * @param modifier
		 * @param name
		 */
		Implementation(final int modifier, final String name)
		{
			super(modifier, name);
		}
		

		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaKeywordOwner#getKeyword()
		 */
		@Override
		public String getKeyword()
		{
			return Java.Lang.$interface;
		}
	}
}
