/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;




/**
 * @author Thomas Muenz
 *
 */
public interface JavaFieldDescription extends JavaAccessibleObjectDescription, JavaTypeMemberDescription
{	
	public JavaExpression getInitialExpression();
	
	
	public class Implemenatation extends JavaModifierableCompilationObjectDescription.Implementation 
	implements JavaFieldDescription
	{		
		///////////////////////////////////////////////////////////////////////////
		// instance fields  //
		/////////////////////
		
		private JavaTypeDefinition owner = null;
		private boolean ownerIsClass = false;
		
		private JavaExpression initialExpression;
		private JavaTypeDescription type;

		
		
		///////////////////////////////////////////////////////////////////////////
		// constructors     //
		/////////////////////
		
		Implemenatation(
			final int modifiers, 
			final JavaTypeDescription type, 
			final String name, 
			final JavaExpression initialExpression
		)
		{
			super(modifiers, name);
			this.type = type;
			this.initialExpression = initialExpression;
		}

		
		
		///////////////////////////////////////////////////////////////////////////
		// getters          //
		/////////////////////
	
		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaFieldDescription#getInitialExpression()
		 */
		@Override
		public JavaExpression getInitialExpression()
		{
			return this.initialExpression;
		}
		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaClassMemberDefinition#getOwnerClass()
		 */
		@Override
		public JavaClassDefinition getOwnerClass()
		{
			return this.ownerIsClass ?(JavaClassDefinition)this.owner :null;
		}
		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaTypeMemberDefinition#getOwnerType()
		 */
		@Override
		public JavaTypeDefinition getOwnerType()
		{
			return this.owner;
		}
		/**
		 * @return the type
		 */
		public JavaTypeDescription getType()
		{
			return type;
		}	

		
		///////////////////////////////////////////////////////////////////////////
		// setters          //
		/////////////////////
		
		/**
		 * @param initialExpression
		 * @return
		 * @see net.jadoth.codegeneration.java.codeobjects.JavaFieldDescription#setInitialExpression(net.jadoth.codegeneration.java.codeobjects.JavaExpression)
		 */
		/**
		 * @param type the type to set
		 */
		public void setType(final JavaTypeDescription type)
		{
			this.type = type;
		}



		/**
		 * @param modifier
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaModifierableCompilationObjectDefinition.Implementation#isValidModifier(int)
		 */
		@Override
		protected boolean isValidModifier(final int modifier)
		{
			// TODO Auto-generated method stub
			return false;
		}



		/**
		 * @return
		 * @see net.jadoth.util.strings.Named#getName()
		 */
		@Override
		public String getName()
		{
			// TODO Auto-generated method stub
			return null;
		}



		/**
		 * @return
		 * @see net.jadoth.codegen.java.codeobjects.JavaModifierableCompilationObjectDescription#getModifiers()
		 */
		@Override
		public int getModifiers()
		{
			// TODO Auto-generated method stub
			return 0;
		}

		
		
		/**
		 * @return always <tt>null</tt>
		 * @see java.lang.reflect.Member#getDeclaringClass()
		 */
		@Override
		public Class<?> getDeclaringClass()
		{
			// (17.06.2010)XXX maybe JavaFieldDescription.getDeclaringClass() makes sense?
			return null;
		}

		/**
		 * @return always <tt>false</tt>
		 * @see java.lang.reflect.Member#isSynthetic()
		 */
		@Override
		public boolean isSynthetic()
		{
			return false;
		}



		/**
		 * @return
		 */
		@Override
		public int getNestingLevel()
		{
			if(this.owner == null) return 0;			
			return this.owner.getNestingLevel()+1;
		}


			
		
	}
	
}
