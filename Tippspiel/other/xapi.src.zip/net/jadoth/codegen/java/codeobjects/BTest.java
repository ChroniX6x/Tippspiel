/**
 * 
 */
package net.jadoth.codegen.java.codeobjects;

import static net.jadoth.codegen.java.codeobjects.JavaSourceCodeFactory.Code.imporT;
import static net.jadoth.codegen.java.codeobjects.JavaSourceCodeFactory.Code.pacKage;

/**
 * @author Thomas Muenz
 *
 */
public class BTest implements JavaSourceCodeFactory
{
	
	static final void print(final JavaCompilationUnit compilationUnit)
	{
		System.out.println(compilationUnit.generateSourceCode(new JavaCodeGenerator.Implementation()));
	}

	/**
	 * @param args
	 */
	public static void main(final String[] args)
	{
		final JavaCompilationUnit jcu = Code.CompilationUnit(
			pacKage("bla.blub"),
			
			imporT(java.math.BigInteger.class),
			imporT(java.math.BigDecimal.class),
			
			pubLic.Class("MyClass")
		);
		
		for(final JavaCompilationUnitMember member : jcu) {
			System.out.println(member);
		}
		System.out.println("----\noutput:\n");
		print(jcu);
		
	}

}
