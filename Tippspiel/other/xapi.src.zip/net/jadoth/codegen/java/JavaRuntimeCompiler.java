/*
 * Copyright (c) 2008-2010, Thomas M�nz
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package net.jadoth.codegen.java;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

import javax.tools.JavaCompiler;
import javax.tools.ToolProvider;

import net.jadoth.Jadoth;


// TODO: Auto-generated Javadoc
/**
 * The Class JavaRuntimeCompiler.
 */
public class JavaRuntimeCompiler {

	/** The javac. */
	private final JavaCompiler javac;

	/** The src folder. */
	private File srcFolder;

	/** The bin folder. */
	private File binFolder;

	/** The file suffix. */
	private String fileSuffix = "java";


	/**
	 * Gets the file suffix.
	 *
	 * @return the fileSuffix
	 */
	public String getFileSuffix() {
		return this.fileSuffix;
	}


	/**
	 * Sets the file suffix.
	 *
	 * @param fileSuffix the fileSuffix to set
	 */
	public void setFileSuffix(final String fileSuffix) {
		this.fileSuffix = fileSuffix;
	}


	/**
	 * Instantiates a new java runtime compiler.
	 */
	public JavaRuntimeCompiler(){
		this.javac = ToolProvider.getSystemJavaCompiler();
		if(this.javac == null) {
			throw new NullPointerException("System Java Compiler not found. Check for JDK and build path.");
		}
		this.srcFolder = null;
		this.binFolder = null;
	}


	/**
	 * Gets the src folder.
	 *
	 * @return the src folder
	 */
	public File getSrcFolder() {
		return this.srcFolder;
	}


	/**
	 * Sets the src folder.
	 *
	 * @param srcFolder the new src folder
	 */
	public void setSrcFolder(final String srcFolder) {
		File newFile;
		try {
			newFile = new File(srcFolder);
		} catch (final Exception e) {
			this.srcFolder = null;
			return;
		}

		if(newFile.isAbsolute()) {
			this.srcFolder = newFile;
		}
	}


	/**
	 * Gets the bin folder.
	 *
	 * @return the bin folder
	 */
	public File getBinFolder() {
		return this.binFolder;
	}


	/**
	 * Sets the bin folder.
	 *
	 * @param binFolder the new bin folder
	 */
	public void setBinFolder(final String binFolder) {
		File newFile;
		try {
			newFile = new File(binFolder);
		} catch (final Exception e) {
			this.binFolder = null;
			return;
		}

		if(newFile.isAbsolute()) {
			this.binFolder = newFile;
		}
	}



	/**
	 * Write class file.
	 *
	 * @param code the code
	 * @param filename the filename
	 * @param compile the compile
	 * @return the compiler status code
	 */
	public final CompilerStatusCode writeClassFile(final String code, final String filename, final boolean compile)
	{
		if(this.srcFolder == null) {
			throw new RuntimeException("Error: no valid src folder given.");
		}
		if(compile && this.binFolder == null) {
			throw new RuntimeException("Error: no valid bin folder given.");
		}

		Jadoth.ensureFolder(this.srcFolder);
		if(compile){
			Jadoth.ensureFolder(this.binFolder);
		}
		final File sourceFile = Jadoth.ensureWritableFile(this.srcFolder, filename + '.'+this.fileSuffix);
		final String sourceFileString = sourceFile.getAbsolutePath();

		if(!this.writeSourceFile(code, sourceFile)) {
			throw new RuntimeException("Error: Could not write file "+sourceFile);
		}

		if(!compile || !this.fileSuffix.toLowerCase().equals("java")){
			return new CompilerStatusCode("File "+sourceFileString+" written successfully (uncompiled).");
		}

		final File classFolder = Jadoth.ensureFolder(this.binFolder);
		final String classFolderString = classFolder.getAbsolutePath();

		if(classFolder == null) {
			throw new RuntimeException("Error: Could not reach folder "+classFolderString);
		}

		final ByteArrayOutputStream errorOutput = new ByteArrayOutputStream();


		final int returnCode = this.javac.run(null, null, errorOutput, "-d", this.binFolder.getAbsolutePath(), sourceFileString);
		boolean success = false;
		if(returnCode == 0){
			success = true;
		}

		if(success){
			return new CompilerStatusCode(returnCode, "File "+sourceFileString+" compiled successfully.");
		}
		sourceFile.delete();
		classFolder.delete();
		return new CompilerStatusCode(returnCode, "Error: \n"+errorOutput.toString());
	}


	/**
	 * Compile.
	 *
	 * @param code the code
	 * @param filename the filename
	 * @return the compiler status code
	 */
	public final CompilerStatusCode compile(final String code, final String filename){
		return this.writeClassFile(code, filename, true);
	}




	/**
	 * Write source file.
	 *
	 * @param code the code
	 * @param sourceFile the source file
	 * @return true, if successful
	 */
	protected boolean writeSourceFile(final String code, final File sourceFile){
		try {
			sourceFile.createNewFile();
		} catch (final Exception e) {
			return false;
		}

		if(sourceFile.canWrite()){
			FileWriter sourceWriter = null;
			try {
				sourceWriter = new FileWriter(sourceFile);
				sourceWriter.write(code);
				sourceWriter.close();
			} catch (final IOException e) {
				sourceFile.delete();
				return false;
			}
		}
		else {
			return false;
		}
		return true;
	}


	/**
	 * The Class CompilerStatusCode.
	 */
	public static class CompilerStatusCode
	{

		/** The return code. */
		final private int returnCode;

		/** The message. */
		final private String message;

		/** The success. */
		final private boolean success;

		/**
		 * Instantiates a new compiler status code.
		 *
		 * @param message the message
		 */
		private CompilerStatusCode(final String message) {
			this(0, message);
		}

		/**
		 * Instantiates a new compiler status code.
		 *
		 * @param returnCode the return code
		 * @param message the message
		 */
		private CompilerStatusCode(final int returnCode, final String message) {
			super();
			this.returnCode = returnCode;
			this.message = message;
			this.success = returnCode == 0; //javac returns 0 for success
		}

		/**
		 * Gets the return code.
		 *
		 * @return the returnCode
		 */
		public Integer getReturnCode() {
			return this.returnCode;
		}

		/**
		 * Gets the message.
		 *
		 * @return the message
		 */
		public String getMessage() {
			return this.message;
		}

		/**
		 * Checks if is success.
		 *
		 * @return the success
		 */
		public boolean isSuccess() {
			return this.success;
		}

		/**
		 * To string.
		 *
		 * @return the string
		 * @return
		 */
		@Override
		public String toString() {
			return "Code("+this.returnCode+"): "+this.message;
		}


	}


}
