/*
 * Copyright (c) 2008-2010, Thomas M�nz
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package net.jadoth.codegen;

// TODO: Auto-generated Javadoc
/**
 * The Interface Punctuation.
 * 
 * @author Thomas M�nz
 */
public interface Punctuation {
	
	/** The Constant n. */
	public static final char n = '\n';
	
	/** The Constant t. */
	public static final char t = '\t';
	
	/** The Constant qt. */
	public static final char qt = '"';
	
	/** The Constant apo. */
	public static final char apo = '\'';
	
	/** The Constant at. */
	public static final char at = '@';
	
	/** The Constant cma. */
	public static final char cma = ',';
	
	/** The Constant str. */
	public static final char str = '*';
	
	/** The Constant d. */
	public static final char d = '.';
	
	/** The Constant qM. */
	public static final char qM = '?';

	/** The Constant _. */
	public static final char _ = ' ';
	
	/** The Constant NEW_LINE. */
	public static final String NEW_LINE = ""+n;
	
	/** The Constant TAB. */
	public static final String TAB = ""+t;
	
	/** The Constant quote. */
	public static final String quote = ""+qt;
	
	/** The Constant scol. */
	public static final String scol = ";";

	
	/** The Constant par. */
	public static final String par = "(";
	
	/** The Constant rap. */
	public static final String rap = ")";
	
	/** The Constant comma. */
	public static final String comma = ""+cma;
	
	/** The Constant dot. */
	public static final String dot = ""+d;
	
	/** The Constant star. */
	public static final String star = ""+str;
	
	/** The Constant qMark. */
	public static final String qMark = ""+qM;


	//comparators
	/** The Constant is. */
	public static final String is = "=";
	
	/** The Constant ne1. */
	public static final String ne1 = "!=";
	
	/** The Constant ne2. */
	public static final String ne2 = "<>";
	
	/** The Constant gt. */
	public static final String gt = ">";
	
	/** The Constant lt. */
	public static final String lt = "<";
	
	/** The Constant gte. */
	public static final String gte = ">=";
	
	/** The Constant lte. */
	public static final String lte = "<=";
	
	/** The Constant comma_. */
	public static final String comma_ = cma+""+_;
}
