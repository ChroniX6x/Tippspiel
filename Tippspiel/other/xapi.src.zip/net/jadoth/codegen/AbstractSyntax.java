/*
 * Copyright (c) 2008-2010, Thomas M�nz
 * All rights reserved.
 * 
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in the
 *       documentation and/or other materials provided with the distribution.
 *     * Neither the name of the <organization> nor the
 *       names of its contributors may be used to endorse or promote products
 *       derived from this software without specific prior written permission.
 * 
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL <COPYRIGHT HOLDER> BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
package net.jadoth.codegen;

import static net.jadoth.Jadoth.appendArraySeperated;
import static net.jadoth.codegen.Punctuation.is;
import static net.jadoth.codegen.Punctuation.par;
import static net.jadoth.codegen.Punctuation.quote;
import static net.jadoth.codegen.Punctuation.rap;
import static net.jadoth.codegen.java.Java.Lang.$else;
import static net.jadoth.codegen.java.Java.Lang.$if;
import static net.jadoth.codegen.java.Java.Lang.blockEnd;
import static net.jadoth.codegen.java.Java.Lang.blockStart;

// TODO: Auto-generated Javadoc
/**
 * The Class AbstractSyntax.
 * 
 * @author Thomas M�nz
 */
public abstract class AbstractSyntax 
{
	
	
	/**
	 * Gets the quote.
	 * 
	 * @return the quote
	 */
	public String getQuote(){
		return quote;
	}
	
	/**
	 * Gets the assign operator.
	 * 
	 * @return the assign operator
	 */
	public String getAssignOperator(){
		return is;
	}
	
	
	/**
	 * _if.
	 * 
	 * @param sb the sb
	 * @param condition the condition
	 * @return the string builder
	 */
	public StringBuilder _if(StringBuilder sb, final String condition){
		if(sb == null){
			sb = new StringBuilder(128);
		}		
		return sb.append($if).append(par).append(condition).append(rap);
	}
	
	/**
	 * $if.
	 * 
	 * @param condition the condition
	 * @return the string
	 */
	public String $if(final String condition){
		return this._if(null, condition).toString();
	}
	
	
	
	/**
	 * _else.
	 * 
	 * @param sb the sb
	 * @return the string builder
	 */
	public StringBuilder _else(StringBuilder sb){
		if(sb == null){
			sb = new StringBuilder(128);
		}		
		return sb.append($else);
	}
	
	/**
	 * $else.
	 * 
	 * @return the string
	 */
	public String $else(){
		return this._else(null).toString();
	}
	
	
	
	/**
	 * _block start.
	 * 
	 * @param sb the sb
	 * @return the string builder
	 */
	public StringBuilder _blockStart(StringBuilder sb){
		if(sb == null){
			sb = new StringBuilder(128);
		}		
		return sb.append(blockStart);
	}
	
	/**
	 * $block start.
	 * 
	 * @return the string
	 */
	public String $blockStart(){
		return this._blockStart(null).toString();
	}
	
	
	/**
	 * _block end.
	 * 
	 * @param sb the sb
	 * @return the string builder
	 */
	public StringBuilder _blockEnd(StringBuilder sb){
		if(sb == null){
			sb = new StringBuilder(128);
		}		
		return sb.append(blockEnd);
	}
	
	/**
	 * $block end.
	 * 
	 * @return the string
	 */
	public String $blockEnd(){
		return this._blockEnd(null).toString();
	}
	

	
	/**
	 * _quote.
	 * 
	 * @param sb the sb
	 * @param s the s
	 * @return the string builder
	 */
	public StringBuilder _quote(StringBuilder sb, final String s){
		if(sb == null){
			sb = new StringBuilder(128);
		}		
		return sb.append(this.getQuote()).append(s).append(this.getQuote());
	}
	
	/**
	 * $quote.
	 * 
	 * @param s the s
	 * @return the string
	 */
	public String $quote(final String s){
		return this._quote(null, s).toString();
	}
	
	
	/**
	 * _modifier.
	 * 
	 * @param sb the sb
	 * @param modifiers the modifiers
	 * @return the string builder
	 */
	public StringBuilder _modifier(StringBuilder sb, final String... modifiers){
		if(sb == null){
			sb = new StringBuilder(128);
		}		
		return appendArraySeperated(sb, ' ', (Object[])modifiers);
	}
	
	/**
	 * $modifier.
	 * 
	 * @param modifiers the modifiers
	 * @return the string
	 */
	public String $modifier(final String... modifiers){
		return this._modifier(null, modifiers).toString();
	}
	
	

}
