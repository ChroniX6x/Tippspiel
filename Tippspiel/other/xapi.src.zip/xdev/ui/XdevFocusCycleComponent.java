/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


/**
 * 
 * 
 * Interface XdevFocusCycleComponent enables components to participate in
 * XdevFocusCycle. All components that participate in the XdevFocusCycle must
 * implement this interface.
 * 
 * @see XdevFocusCycleRoot
 * @see XdevFocusCycleController
 * @see XdevFocusTraversalPolicy
 * 
 * 
 * 
 * @author XDEV Software
 * 
 */
public interface XdevFocusCycleComponent
{
	/**
	 * The property name used by the implementing beans to fire property change
	 * events.
	 */
	public final static String	TAB_INDEX_PROPERTY	= "tabIndex";


	/**
	 * Returns the tabindex assigned to this component. The tabindex defines the
	 * position of the component in the focus cycle.
	 * 
	 * @return tabindex of this component
	 */
	public int getTabIndex();


	/**
	 * Sets the tabindex of this component. The tabindex defines the position of
	 * the component in the focus cycle.
	 * <p>
	 * To exclude this component from the focus cycle set tabindex to -1.
	 * 
	 * @param tabIndex
	 *            to be set
	 */
	public void setTabIndex(int tabIndex);
}
