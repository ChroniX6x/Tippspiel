/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.Dimension;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextField;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;

import xdev.util.Settings;
import xdev.vt.VirtualTable;


/**
 * The standard text field in XDEV. Based on {@link JTextField}.
 * 
 * @see JTextField
 * @see ClientProperties
 * @see XdevFocusCycleComponent
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevTextField extends JTextField implements ClientProperties,
		FormularComponent<XdevTextField>, XdevFocusCycleComponent
{
	private String	savedValue	= "";
	/**
	 * tabIndex is used to store the index for {@link XdevFocusCycleComponent}
	 * functionality.
	 */
	private int		tabIndex	= -1;


	private static class Support extends FormularComponentSupport<XdevTextField, XdevTextField>
	{
		private Support(XdevTextField component)
		{
			super(component,component);
		}
	}

	private final Support	support	= new Support(this);


	/**
	 * Constructor for creating a new instance of a {@link XdevTextField}.
	 */
	public XdevTextField()
	{
		this("");
	}


	/**
	 * Constructor for creating a new instance of a {@link XdevTextField}.
	 * 
	 * @param text
	 *            the text to be displayed, <code>null</code> if none
	 */
	public XdevTextField(String text)
	{
		this(text,1000);
	}


	/**
	 * Constructor for creating a new instance of a {@link XdevTextField}.
	 * 
	 * @param maxSigns
	 *            a <code>int</code> to determine the max signs of the
	 *            {@link MaxSignDocument}
	 */
	public XdevTextField(int maxSigns)
	{
		this("",maxSigns);
	}


	/**
	 * Constructs a new {@link XdevTextField} that uses the given text storage
	 * model and the given number to create a {@link MaxSignDocument}.<br>
	 * This is the constructor through which the other constructors feed.
	 * 
	 * 
	 * @param text
	 *            the text to be displayed, <code>null</code> if none
	 * 
	 * @param maxSigns
	 *            a <code>int</code> to determine the max signs of the
	 *            {@link MaxSignDocument}
	 * 
	 * @throws IllegalArgumentException
	 *             if the <code>maxSigns</code> is <= 0
	 */
	public XdevTextField(String text, int maxSigns) throws IllegalArgumentException
	{
		super();

		setDocument(new MaxSignDocument(maxSigns));
		setText(text);

		addFocusListener(new FocusListener()
		{
			public void focusGained(FocusEvent e)
			{
				if(Settings.checkUserSetting(System.getProperty("xdev.selectAllOnFocus","")))
				{
					selectAll();
				}
			}


			public void focusLost(FocusEvent e)
			{
				select(0,0);
			}
		});
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public Dimension getPreferredSize()
	{
		// Hack because JTextField doesn't honor the set preferred size
		if(isPreferredSizeSet())
		{
			try
			{
				return UIUtils.getPrefSizeFieldValue(this);
			}
			catch(Exception e)
			{
				// Shouldn't happen
				e.printStackTrace();
			}
		}

		return super.getPreferredSize();
	}


	/**
	 * Registers the given {@link DocumentListener} to begin receiving
	 * notifications when changes are made to the document.
	 * 
	 * @param listener
	 *            the {@link DocumentListener} to register
	 * 
	 */
	public void addDocumentListener(DocumentListener listener)
	{
		getDocument().addDocumentListener(listener);
	}


	/**
	 * Returns the max sign count of this {@link XdevTextField}.
	 * 
	 * 
	 * @return the max sign count of this {@link XdevTextField}, -1 if the
	 *         {@link Document} is not an instance of {@link MaxSignDocument}.
	 * 
	 * @see MaxSignDocument
	 */
	public int getMaxSignCount()
	{
		Document doc = getDocument();
		if(doc instanceof MaxSignDocument)
		{
			return ((MaxSignDocument)doc).getMaxSignCount();
		}

		return -1;
	}


	/**
	 * Sets the max sign count of this {@link XdevTextField}.
	 * 
	 * @param maxSignCount
	 *            the max sign count of this {@link XdevTextField}
	 */
	public void setMaxSignCount(int maxSignCount)
	{
		Document doc = getDocument();
		if(doc instanceof MaxSignDocument)
		{
			MaxSignDocument msDoc = (MaxSignDocument)doc;
			int oldValue = msDoc.getMaxSignCount();
			if(oldValue != maxSignCount)
			{
				msDoc.setMaxSignCount(maxSignCount);
				firePropertyChange(MaxSignDocument.MAX_SIGNS_PROPERTY,oldValue,maxSignCount);
			}
		}
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getFormularName()
	{
		return support.getFormularName();
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		String str;
		if(vt != null)
		{
			str = vt.formatValue(value,col);
		}
		else
		{
			str = value != null ? value.toString() : "";
		}
		setText(str);
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object getFormularValue()
	{
		return getText();
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void saveState()
	{
		savedValue = getText();
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void restoreState()
	{
		setText(savedValue);
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isMultiSelect()
	{
		return false;
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean verify()
	{
		return support.verify();
	}


	/**
	 * Returns the selected text contained in this {@link XdevTextField}. If the
	 * selection is <code>null</code> or the document empty, returns a empty
	 * {@link String}.
	 * 
	 * @return the selected text, or a empty {@link String}
	 * 
	 * @throws IllegalArgumentException
	 *             if the selection doesn't have a valid mapping into the
	 *             document for some reason
	 */
	@Override
	public String getSelectedText() throws IllegalArgumentException
	{
		String st = super.getSelectedText();
		if(st == null)
		{
			st = "";
		}

		return st;
	}


	/**
	 * Inserts a {@link String} into this {@link XdevTextField}.
	 * 
	 * @param text
	 *            the {@link String} to insert
	 * 
	 * @see Document#insertString(int, String, javax.swing.text.AttributeSet)
	 */
	public void insertText(String text)
	{
		try
		{
			getDocument().insertString(getCaretPosition(),text,null);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() throws NullPointerException
	{
		return getText();
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getTabIndex()
	{
		return tabIndex;
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTabIndex(int tabIndex)
	{
		if(this.tabIndex != tabIndex)
		{
			int oldValue = this.tabIndex;
			this.tabIndex = tabIndex;
			firePropertyChange(TAB_INDEX_PROPERTY,oldValue,tabIndex);
		}
	}
}
