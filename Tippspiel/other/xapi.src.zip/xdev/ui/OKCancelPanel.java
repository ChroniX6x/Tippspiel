/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class OKCancelPanel extends JPanel
{
	public JButton	cmdOK, cmdCancel;
	

	public OKCancelPanel(ActionListener al)
	{
		super(new BorderLayout());
		
		cmdOK = new JButton(UIManager.getString("OptionPane.okButtonText"));
		cmdOK.addActionListener(al);
		
		cmdCancel = new JButton(UIManager.getString("OptionPane.cancelButtonText"));
		cmdCancel.addActionListener(al);
		
		JPanel pnlCmd = new JPanel(new GridLayout(1,2,10,0));
		pnlCmd.add(cmdOK);
		pnlCmd.add(cmdCancel);
		
		add(new JPanel(),BorderLayout.CENTER);
		add(pnlCmd,BorderLayout.EAST);
	}
}
