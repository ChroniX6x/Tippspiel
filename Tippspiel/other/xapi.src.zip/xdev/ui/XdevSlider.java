/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import javax.swing.BoundedRangeModel;
import javax.swing.DefaultBoundedRangeModel;
import javax.swing.JSlider;

import xdev.vt.VirtualTable;


@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevSlider extends JSlider implements FormularComponent<XdevSlider>,
		XdevFocusCycleComponent
{
	private int	savedValue	= 0;
	/**
	 * tabIndex is used to store the index for {@link XdevFocusCycleComponent}
	 * functionality.
	 */
	private int	tabIndex	= -1;
	


	private static class Support extends FormularComponentSupport<XdevSlider, XdevSlider>
	{
		private Support(XdevSlider component)
		{
			super(component,component);
		}
	}
	
	private final Support	support	= new Support(this);
	

	/**
	 * Creates a horizontal <code>XdevSlider</code> with the range
	 * <code>0</code> to <code>100</code> and an initial value of 50.
	 */
	public XdevSlider()
	{
		super();
	}
	

	/**
	 * Creates a horizontal <code>XdevSlider</code> using the specified
	 * BoundedRangeModel.
	 * 
	 * @param brm
	 *            the new, {@code non-null} <code>BoundedRangeModel</code> to
	 *            use
	 * 
	 * @see BoundedRangeModel
	 */
	public XdevSlider(BoundedRangeModel brm)
	{
		super(brm);
	}
	

	/**
	 * Creates a <code>XdevSlider</code> using the specified orientation with
	 * the range <code>0</code> to <code>100</code> and an initial value of
	 * <code>50</code>. The orientation can be either
	 * <code>SwingConstants.VERTICAL</code> or
	 * <code>SwingConstants.HORIZONTAL</code>.
	 * 
	 * @param orientation
	 *            the orientation of the slider
	 * 
	 * @throws IllegalArgumentException
	 *             if orientation is not one of <code>VERTICAL</code>,
	 *             <code>HORIZONTAL</code>
	 * 
	 * @see #setOrientation
	 */
	public XdevSlider(int orientation) throws IllegalArgumentException
	{
		super(orientation);
	}
	

	/**
	 * Creates a horizontal <code>XdevSlider</code> using the specified min and
	 * max with an initial value equal to the average of the min plus max.
	 * <p>
	 * The <code>BoundedRangeModel</code> that holds the slider's data handles
	 * any issues that may arise from improperly setting the minimum and maximum
	 * values on the slider. See the <code>BoundedRangeModel</code>
	 * documentation for details.
	 * 
	 * @param min
	 *            the minimum value of the slider
	 * @param max
	 *            the maximum value of the slider
	 * 
	 * @see BoundedRangeModel
	 * @see #setMinimum
	 * @see #setMaximum
	 */
	public XdevSlider(int min, int max)
	{
		super(min,max);
	}
	

	/**
	 * Creates a horizontal <code>XdevSlider</code> using the specified min, max
	 * and value.
	 * <p>
	 * The <code>BoundedRangeModel</code> that holds the slider's data handles
	 * any issues that may arise from improperly setting the minimum, initial,
	 * and maximum values on the slider. See the {@code BoundedRangeModel}
	 * documentation for details.
	 * 
	 * @param min
	 *            the minimum value of the XdevSlider
	 * @param max
	 *            the maximum value of the XdevSlider
	 * @param value
	 *            the initial value of the XdevSlider
	 * 
	 * @see BoundedRangeModel
	 * @see #setMinimum
	 * @see #setMaximum
	 * @see #setValue
	 */
	public XdevSlider(int min, int max, int value)
	{
		super(min,max,value);
	}
	

	/**
	 * Creates a <code>XdevSlider</code> with the specified orientation and the
	 * specified minimum, maximum, and initial values. The orientation can be
	 * either <code>SwingConstants.VERTICAL</code> or
	 * <code>SwingConstants.HORIZONTAL</code>.
	 * <p>
	 * The <code>BoundedRangeModel</code> that holds the slider's data handles
	 * any issues that may arise from improperly setting the minimum, initial,
	 * and maximum values on the slider. See the {@code BoundedRangeModel}
	 * documentation for details.
	 * 
	 * @param orientation
	 *            the orientation of the XdevSlider
	 * @param min
	 *            the minimum value of the XdevSlider
	 * @param max
	 *            the maximum value of the XdevSlider
	 * @param value
	 *            the initial value of the XdevSlider
	 * 
	 * @throws IllegalArgumentException
	 *             if orientation is not one of {@code VERTICAL},
	 *             {@code HORIZONTAL}
	 * 
	 * @see BoundedRangeModel
	 * @see #setOrientation
	 * @see #setMinimum
	 * @see #setMaximum
	 * @see #setValue
	 */
	public XdevSlider(int orientation, int min, int max, int value) throws IllegalArgumentException
	{
		super(orientation,min,max,value);
	}
	

	public void setValues(int min, int max, int value)
	{
		setModel(new DefaultBoundedRangeModel(value,0,min,max));
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getFormularName()
	{
		return support.getFormularName();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		if(value != null)
		{
			try
			{
				setValue(Integer.parseInt(value.toString()));
			}
			catch(NumberFormatException e)
			{
				e.printStackTrace();
			}
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object getFormularValue()
	{
		return new Integer(getValue());
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void saveState()
	{
		savedValue = getValue();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void restoreState()
	{
		setValue(savedValue);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isMultiSelect()
	{
		return false;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean verify()
	{
		return support.verify();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		return String.valueOf(getValue());
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getTabIndex()
	{
		return tabIndex;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTabIndex(int tabIndex)
	{
		if(this.tabIndex != tabIndex)
		{
			int oldValue = this.tabIndex;
			this.tabIndex = tabIndex;
			firePropertyChange(TAB_INDEX_PROPERTY,oldValue,tabIndex);
		}
	}
}
