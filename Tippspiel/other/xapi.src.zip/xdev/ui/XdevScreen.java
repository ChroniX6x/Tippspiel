/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.ui;


import java.awt.Component;
import java.awt.HeadlessException;
import java.awt.Window;

import javax.swing.JWindow;
import javax.swing.SwingUtilities;


/**
 * The {@link XdevScreen} is a top-level window with no borders and no menubar
 * in XDEV. Based on {@link JWindow}.
 * 
 * 
 * @see JWindow
 * @see XdevRootPaneContainer
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
public class XdevScreen extends JWindow implements XdevRootPaneContainer
{
	protected Window		owner;
	protected XdevWindow	window;
	protected boolean		modal;
	

	/**
	 * Creates a window with the specified owner window. This window will not be
	 * focusable unless its owner is showing on the screen. If
	 * <code>owner</code> is <code>null</code>, the shared owner will be used
	 * and this window will not be focusable.
	 * <p>
	 * This constructor sets the component's locale property to the value
	 * returned by <code>JComponent.getDefaultLocale</code>.
	 * 
	 * @param owner
	 *            component to get Window ancestor of
	 * 
	 * @param modal
	 *            specifies whether window blocks user input to other top-level
	 *            windows when shown.
	 * 
	 * @param window
	 *            the content of this screen
	 * 
	 * @throws HeadlessException
	 *             if <code>GraphicsEnvironment.isHeadless()</code> returns
	 *             true.
	 * 
	 */
	public XdevScreen(Component owner, boolean modal, XdevWindow window)
			throws HeadlessException
	{
		this(XdevDialog.getWindowFor(owner),modal,window);
	}
	

	/**
	 * Creates a window with the specified owner window. This window will not be
	 * focusable unless its owner is showing on the screen. If
	 * <code>owner</code> is <code>null</code>, the shared owner will be used
	 * and this window will not be focusable.
	 * <p>
	 * This constructor sets the component's locale property to the value
	 * returned by <code>JComponent.getDefaultLocale</code>.
	 * 
	 * @param owner
	 *            the window from which the window is displayed
	 * 
	 * @param modal
	 *            specifies whether window blocks user input to other top-level
	 *            windows when shown.
	 * 
	 * @param window
	 *            the content of this screen
	 * 
	 * @throws HeadlessException
	 *             if <code>GraphicsEnvironment.isHeadless()</code> returns
	 *             true.
	 * 
	 */
	public XdevScreen(Window owner, boolean modal, XdevWindow window) throws HeadlessException
	{
		super(owner);
		
		init(owner,modal);
		
		setXdevWindow(window);
	}
	

	/**
	 * Creates a window with the specified owner window. This window will not be
	 * focusable unless its owner is showing on the screen. If
	 * <code>owner</code> is <code>null</code>, the shared owner will be used
	 * and this window will not be focusable.
	 * <p>
	 * This constructor sets the component's locale property to the value
	 * returned by <code>JComponent.getDefaultLocale</code>.
	 * 
	 * @param owner
	 *            component to get Window ancestor of
	 * 
	 * @param modal
	 *            specifies whether window blocks user input to other top-level
	 *            windows when shown.
	 * 
	 * @throws HeadlessException
	 *             if <code>GraphicsEnvironment.isHeadless()</code> returns
	 *             true.
	 * 
	 */
	public XdevScreen(Component owner, boolean modal) throws HeadlessException
	{
		this(owner != null ? SwingUtilities.getWindowAncestor(owner) : null,modal);
	}
	

	/**
	 * Creates a window with the specified owner window. This window will not be
	 * focusable unless its owner is showing on the screen. If
	 * <code>owner</code> is <code>null</code>, the shared owner will be used
	 * and this window will not be focusable.
	 * <p>
	 * This constructor sets the component's locale property to the value
	 * returned by <code>JComponent.getDefaultLocale</code>.
	 * 
	 * @param owner
	 *            the window from which the window is displayed
	 * 
	 * @param modal
	 *            specifies whether window blocks user input to other top-level
	 *            windows when shown.
	 * 
	 * @throws HeadlessException
	 *             if <code>GraphicsEnvironment.isHeadless()</code> returns
	 *             true.
	 * 
	 */
	public XdevScreen(Window owner, boolean modal) throws HeadlessException
	{
		super(owner);
		
		init(owner,modal);
	}
	

	private void init(Window owner, boolean modal)
	{
		this.owner = owner;
		this.modal = modal;
		
		setFocusTraversalPolicy(new XdevFocusTraversalPolicy(this));
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setXdevWindow(XdevWindow window)
	{
		clean();
		
		this.window = window;
		window.setOwner(this);
		
		setTitle(window.getTitle());
		setBounds(window.getX(),window.getY(),window.getWidth(),
				window.getHeight());
		getRootPane().setDefaultButton(window.getDefaultButton());
		
		setContentPane(Util.createContainer(this,window));
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public XdevWindow getXdevWindow()
	{
		return window;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Window getWindow()
	{
		return this;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTitle(String s)
	{
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setResizable(boolean b)
	{
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setVisible(boolean b)
	{
		if(b)
		{
			// XdevRootPaneContainer.Util.containers.put(id,this);
			
			if(modal)
			{
				owner.setEnabled(false);
			}
		}
		
		super.setVisible(b);
		
		if(!b)
		{
			SwingUtilities.invokeLater(new Runnable()
			{
				public void run()
				{
					clean();
					// XdevRootPaneContainer.Util.containers.remove(id);
				}
			});
			
			if(modal)
			{
				owner.setEnabled(true);
			}
			
			owner.toFront();
		}
	}
	

	protected void clean()
	{
		try
		{
			if(window != null)
			{
				window.cleanUp();
				window = null;
			}
		}
		catch(Exception e)
		{
		}
	}
}
