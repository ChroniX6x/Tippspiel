/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import javax.swing.*;

import xdev.ui.persistence.Persistable;


/**
 * The standard InternalFrame in XDEV. Based on {@link JInternalFrame}.
 * 
 * @see XdevInternalFrame
 * @see JInternalFrame
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(acceptChildren = true, autoPreview = true, useXdevCustomizer = true)
public class XdevInternalFrame extends JInternalFrame implements DistinctChild, Persistable
{
	/**
	 * 
	 */
	private static final long	serialVersionUID	= -2733653851513845056L;
	
	/**
	 * Should the gui state be persisted? Defaults to {@code true}.
	 */
	private boolean persistenceEnabled = true;
	
	/**
	 * Creates a {@link XdevInternalFrame} with default values.
	 * 
	 */
	public XdevInternalFrame()
	{
		this("",null,true,true,true,true);
	}
	

	/**
	 * Creates a {@link XdevInternalFrame} with the specified title, icon,
	 * resizability, closability, maximizability, and iconifiability. All
	 * <code>XdevInternalFrame</code> constructors use this one.
	 * 
	 * @param title
	 *            the <code>String</code> to display in the title bar
	 * 
	 * @param icon
	 *            the <code>Icon</code> to display in the title bar
	 * 
	 * @param resizable
	 *            if <code>true</code>, the internal frame can be resized
	 * 
	 * @param closable
	 *            if <code>true</code>, the internal frame can be closed
	 * 
	 * @param maximizable
	 *            if <code>true</code>, the internal frame can be maximized
	 * 
	 * @param iconifiable
	 *            if <code>true</code>, the internal frame can be iconified
	 */
	public XdevInternalFrame(String title, Icon icon, boolean resizable, boolean closable,
			boolean maximizable, boolean iconifiable)
	{
		super(title,resizable,closable,maximizable,iconifiable);
		setLayout(null);
		setFrameIcon(icon);
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		setVisible(true);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		String toString = UIUtils.toString(this);
		if(toString != null)
		{
			return toString;
		}
		
		return super.toString();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void loadPersistentState(String persistentState)
	{
		String[] persistentValues = persistentState.split(Persistable.VALUE_SEPARATOR);
		int index = 0;
		try {
			int width = Integer.parseInt(persistentValues[index++]);
			int height = Integer.parseInt(persistentValues[index++]);
			int x = Integer.parseInt(persistentValues[index++]);
			int y = Integer.parseInt(persistentValues[index++]);
			this.setBounds(x,y,width,height);
			int zOrder = Integer.parseInt(persistentValues[index++]);
			this.getDesktopPane().setComponentZOrder(this,zOrder);
			this.setIcon(Boolean.parseBoolean(persistentValues[index++]));
		} catch (Exception e) {
			// do nothing her, if persistent value can't be retrieved...
		}
	}


	/**
	 * Persists attributes in the order: width, height, x, y, layer.
	 * {@inheritDoc}
	 */
	@Override
	public String savePersistentState()
	{
		StringBuilder persistentState = new StringBuilder();
		persistentState.append(Integer.toString(this.getWidth()));
		persistentState.append(Persistable.VALUE_SEPARATOR);
		persistentState.append(Integer.toString(this.getHeight()));
		persistentState.append(Persistable.VALUE_SEPARATOR);
		persistentState.append(Integer.toString(this.getX()));
		persistentState.append(Persistable.VALUE_SEPARATOR);
		persistentState.append(Integer.toString(this.getY()));
		persistentState.append(Persistable.VALUE_SEPARATOR);
		int zOrder=this.getDesktopPane().getComponentZOrder(this);
		persistentState.append(Integer.toString(zOrder));
		persistentState.append(Persistable.VALUE_SEPARATOR);
		persistentState.append(Boolean.toString(this.isIcon()));
		return persistentState.toString();
	}


	/**
	 * Uses the name of the component as a persistent id.
	 * <p>
	 * If no name is specified the name of the class will be used. This will work only for one persistent instance of the class!
	 * </p>
	 * {@inheritDoc}
	 */
	@Override
	public String getPersistentId()
	{
		return (this.getName() != null) ? this.getName() : this.getClass().getSimpleName();
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isPersistenceEnabled()
	{
		return persistenceEnabled;
	}


	/**
	 * {@inheritDoc}
	 */
	public void setPersistenceEnabled(boolean persistenceEnabled)
	{
		this.persistenceEnabled = persistenceEnabled;
	}
}
