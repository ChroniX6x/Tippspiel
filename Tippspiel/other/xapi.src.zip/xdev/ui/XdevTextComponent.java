/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.*;

import xdev.ui.text.*;


public interface XdevTextComponent
{
	public Component getCpn();
	

	public void repaint();
	

	public XdevDocument getDocument();
	

	public Color getForeground();
	

	public Font getFont();
	

	public boolean getUnderline();
	

	public Dimension getOriginalSize();
	

	public Dimension getSize();
	

	public void setSize(Dimension d);
	

	public Dimension getPreferredSize();
	

	public void setPreferredSize(Dimension d);
	

	public boolean paintAsImage();
	

	public void setPaintText();
	

	public int getHorizontalAlign();
	

	public boolean isVertical();
	

	public int getVerticalAlign();
	

	public Insets getBorderInsets(boolean withTextBorder);
	

	public Insets getTextInsets();
	

	public void setTextInsets(Insets i);
	

	@Deprecated
	public int getTextColumnCount();
	

	@Deprecated
	public void setTextColumnCount(int i);
	

	@Deprecated
	public int getTextColumnGap();
	

	@Deprecated
	public void setTextColumnGap(int textColumnGap);
}
