/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.text.MessageFormat;
import java.util.*;


class UIResourceBundle
{
	private static ResourceBundle	resourceBundle;


	private static ResourceBundle getBundle()
	{
		if(resourceBundle == null)
		{
			resourceBundle = ResourceBundle.getBundle("xdev.ui.ui");
		}

		return resourceBundle;
	}


	public static String getString(String key, Object... args)
	{
		String str = getBundle().getString(key);

		if(args != null && args.length > 0)
		{
			str = MessageFormat.format(str,args);
		}

		return str;
	}
}
