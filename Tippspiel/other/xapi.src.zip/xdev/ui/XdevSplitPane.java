/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.*;
import javax.swing.*;

import xdev.ui.persistence.Persistable;


/**
 * The standard split pane in XDEV. Based on {@link JSplitPane}.
 * 
 * @see JSplitPane
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(acceptChildren = true, autoPreview = true, useXdevCustomizer = true)
public class XdevSplitPane extends JSplitPane implements Persistable
{
	/**
	 * 
	 */
	private static final long	serialVersionUID	= 491725401915117145L;
	
	/**
	 * Should the gui state be persisted? Defaults to {@code true}.
	 */
	private boolean persistenceEnabled = true;
	

	/**
	 * Creates a new {@link XdevSplitPane} with the default orientation
	 * {@link JSplitPane#HORIZONTAL_SPLIT}.
	 */
	public XdevSplitPane()
	{
		this(HORIZONTAL_SPLIT);
	}
	

	/**
	 * Creates a new {@link XdevSplitPane} with the specified orientation.
	 * 
	 * @param orientation
	 *            <code>JSplitPane.HORIZONTAL_SPLIT</code> or
	 *            <code>JSplitPane.VERTICAL_SPLIT</code>
	 * 
	 * @throws IllegalArgumentException
	 *             if <code>orientation</code> is not one of HORIZONTAL_SPLIT or
	 *             VERTICAL_SPLIT
	 */
	public XdevSplitPane(int orientation) throws IllegalArgumentException
	{
		this(orientation,UIManager.getBoolean("SplitPane.continuousLayout"));
	}
	

	/**
	 * Creates a new {@link XdevSplitPane} with the specified orientation and
	 * redrawing style.
	 * 
	 * @param newOrientation
	 *            <code>JSplitPane.HORIZONTAL_SPLIT</code> or
	 *            <code>JSplitPane.VERTICAL_SPLIT</code>
	 * 
	 * @param newContinuousLayout
	 *            a boolean, <code>true</code> for the components to redraw
	 *            continuously as the divider changes position,
	 *            <code>false</code> to wait until the divider position stops
	 *            changing to redraw
	 * 
	 * @throws IllegalArgumentException
	 *             if <code>orientation</code> is not one of HORIZONTAL_SPLIT or
	 *             VERTICAL_SPLIT
	 */
	public XdevSplitPane(int newOrientation, boolean newContinuousLayout)
			throws IllegalArgumentException
	{
		this(newOrientation,newContinuousLayout,null,null);
	}
	

	/**
	 * Creates a new {@link XdevSplitPane} with the specified orientation and
	 * components.
	 * 
	 * @param newOrientation
	 *            <code>JSplitPane.HORIZONTAL_SPLIT</code> or
	 *            <code>JSplitPane.VERTICAL_SPLIT</code>
	 * 
	 * @param newLeftComponent
	 *            the <code>Component</code> that will appear on the left of a
	 *            horizontally-split pane, or at the top of a vertically-split
	 *            pane
	 * 
	 * @param newRightComponent
	 *            the <code>Component</code> that will appear on the right of a
	 *            horizontally-split pane, or at the bottom of a
	 *            vertically-split pane
	 * 
	 * @throws IllegalArgumentException
	 *             if <code>orientation</code> is not one of HORIZONTAL_SPLIT or
	 *             VERTICAL_SPLIT
	 */
	public XdevSplitPane(int newOrientation, Component newLeftComponent, Component newRightComponent)
			throws IllegalArgumentException
	{
		this(newOrientation,UIManager.getBoolean("SplitPane.continuousLayout"),newLeftComponent,
				newRightComponent);
	}
	

	/**
	 * Creates a new {@link XdevSplitPane} with the specified orientation and
	 * redrawing style, and with the specified components.
	 * 
	 * @param newOrientation
	 *            <code>JSplitPane.HORIZONTAL_SPLIT</code> or
	 *            <code>JSplitPane.VERTICAL_SPLIT</code>
	 * 
	 * @param newContinuousLayout
	 *            a boolean, <code>true</code> for the components to redraw
	 *            continuously as the divider changes position,
	 *            <code>false</code> to wait until the divider position stops
	 *            changing to redraw
	 * 
	 * @param newLeftComponent
	 *            the <code>Component</code> that will appear on the left of a
	 *            horizontally-split pane, or at the top of a vertically-split
	 *            pane
	 * 
	 * @param newRightComponent
	 *            the <code>Component</code> that will appear on the right of a
	 *            horizontally-split pane, or at the bottom of a
	 *            vertically-split pane
	 * 
	 * @throws IllegalArgumentException
	 *             if <code>orientation</code> is not one of HORIZONTAL_SPLIT or
	 *             VERTICAL_SPLIT
	 */
	public XdevSplitPane(int newOrientation, boolean newContinuousLayout,
			Component newLeftComponent, Component newRightComponent)
			throws IllegalArgumentException
	{
		super(newOrientation,newContinuousLayout,newLeftComponent,newRightComponent);
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		String toString = UIUtils.toString(this);
		if(toString != null)
		{
			return toString;
		}
		
		return super.toString();
	}
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void loadPersistentState(String persistentState)
	{
		this.setDividerLocation(Integer.parseInt(persistentState));
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public String savePersistentState()
	{
		return Integer.toString(this.getDividerLocation());
	}


	/**
	 * Uses the name of the component as a persistent id.
	 * <p>
	 * If no name is specified the name of the class will be used. This will work only for one persistent instance of the class!
	 * </p>
	 * {@inheritDoc}
	 */
	@Override
	public String getPersistentId()
	{
		return (this.getName() != null) ? this.getName() : this.getClass().getSimpleName();
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isPersistenceEnabled()
	{
		return persistenceEnabled;
	}


	/**
	 * {@inheritDoc}
	 */
	public void setPersistenceEnabled(boolean persistenceEnabled)
	{
		this.persistenceEnabled = persistenceEnabled;
	}

}
