/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.ui;


import java.awt.Component;
import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;

import xdev.Application;
import xdev.io.IOUtils;


public class XdevFullScreen extends XdevScreen implements XdevApplicationContainer
{
	public XdevFullScreen()
	{
		super(JOptionPane.getRootFrame(),false);
		
		addWindowListener(new WindowAdapter()
		{
			@Override
			public void windowClosing(WindowEvent e)
			{
				Application.exit(XdevFullScreen.this);
			}
		});
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setXdevWindow(XdevWindow window)
	{
		getGraphicsConfiguration().getDevice().setFullScreenWindow(null);
		setVisible(false);
		
		clean();
		
		this.window = window;
		window.setOwner(this);
		
		setTitle(window.getTitle());
		
		setContentPane(window);
		
		SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				getGraphicsConfiguration().getDevice().setFullScreenWindow(XdevFullScreen.this);
				setVisible(true);
			}
		});
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setIconImage(Image img)
	{
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void pack()
	{
		invalidate();
		validate();
		repaint();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setLocationRelativeTo(Component arg0)
	{
		// do nothing
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public URL getCodeBase()
	{
		URL url = null;
		try
		{
			url = new File("./").getAbsoluteFile().toURI().toURL();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return url;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Image getImage(URL url)
	{
		return getToolkit().getImage(url);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void showDocument(URL url)
	{
		try
		{
			IOUtils.launchBrowser(url.toExternalForm());
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void showDocument(URL url, String target)
	{
		try
		{
			IOUtils.launchBrowser(url.toExternalForm());
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}
