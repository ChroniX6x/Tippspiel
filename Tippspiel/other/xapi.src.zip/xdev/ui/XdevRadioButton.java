/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.ui;


import java.util.Enumeration;
import java.util.StringTokenizer;

import javax.swing.Action;
import javax.swing.ButtonGroup;
import javax.swing.ButtonModel;
import javax.swing.DefaultButtonModel;
import javax.swing.Icon;
import javax.swing.JRadioButton;

import xdev.vt.VirtualTable;


/**
 * The radio button in XDEV. Based on {@link JRadioButton}.
 * 
 * @see JRadioButton
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevRadioButton extends JRadioButton implements FormularComponent<XdevRadioButton>,
		XdevFocusCycleComponent
{
	private String	radioGroup;
	private boolean	savedValue			= false;
	private String	returnValue			= "";
	private String	formularValueList	= "";
	/**
	 * tabIndex is used to store the index for {@link XdevFocusCycleComponent}
	 * functionality.
	 */
	private int		tabIndex			= -1;
	


	private static class Support extends FormularComponentSupport<XdevRadioButton, XdevRadioButton>
	{
		private Support(XdevRadioButton component)
		{
			super(component,component);
		}
	}
	
	private final Support	support	= new Support(this);
	

	public XdevRadioButton()
	{
		super();
	}
	

	public XdevRadioButton(Action a)
	{
		super(a);
	}
	

	public XdevRadioButton(Icon icon, boolean selected)
	{
		super(icon,selected);
	}
	

	public XdevRadioButton(Icon icon)
	{
		super(icon);
	}
	

	public XdevRadioButton(String text, boolean selected)
	{
		super(text,selected);
	}
	

	public XdevRadioButton(String text, Icon icon, boolean selected)
	{
		super(text,icon,selected);
	}
	

	public XdevRadioButton(String text, Icon icon)
	{
		super(text,icon);
	}
	

	public XdevRadioButton(String text)
	{
		super(text);
	}
	

	public void setRadioGroup(String radioGroup)
	{
		this.radioGroup = radioGroup;
		
		putClientProperty(ClientProperties.DATA_FIELD,radioGroup);
	}
	

	public String getRadioGroup()
	{
		return radioGroup;
	}
	

	/**
	 * Returns the group that the button belongs to.
	 * 
	 * @return the group that the button belongs to
	 */
	public ButtonGroup getButtonGroup()
	{
		ButtonModel model = getModel();
		if(model instanceof DefaultButtonModel)
		{
			return ((DefaultButtonModel)model).getGroup();
		}
		
		return null;
	}
	

	/**
	 * {@inheritDoc}
	 */
	public String getFormularName()
	{
		return radioGroup;
	}
	

	/**
	 * 
	 * @param formularValueList
	 *            comma separated values e.g. "true,1,yes"
	 */
	
	public void setFormularValueList(String formularValueList)
	{
		this.formularValueList = formularValueList;
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		boolean b = false;
		
		if(value != null)
		{
			String str = value.toString();
			
			if(formularValueList != null && formularValueList.length() > 0)
			{
				b = contains(formularValueList,",",str);
			}
			else
			{
				if(returnValue != null && returnValue.length() > 0)
				{
					b = returnValue.equalsIgnoreCase(str);
				}
				else
				{
					b = Boolean.valueOf(str);
				}
			}
		}
		
		setSelected(b);
	}
	

	private boolean contains(String list, String separator, String val)
	{
		StringTokenizer st = new StringTokenizer(list,separator);
		while(st.hasMoreTokens())
		{
			if(st.nextToken().equalsIgnoreCase(val))
			{
				return true;
			}
		}
		
		return false;
	}
	

	/**
	 * {@inheritDoc}
	 */
	public Object getFormularValue()
	{
		return getSelectedRadioButtonValue();
	}
	

	private Object getFormularValue0()
	{
		return returnValue;
	}
	

	public String getReturnValue()
	{
		return returnValue;
	}
	

	public void setReturnValue(String returnValue)
	{
		this.returnValue = returnValue;
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void saveState()
	{
		savedValue = isSelected();
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void restoreState()
	{
		setSelected(savedValue);
	}
	

	/**
	 * {@inheritDoc}
	 */
	public boolean isMultiSelect()
	{
		return false;
	}
	

	/**
	 * {@inheritDoc}
	 */
	public boolean verify()
	{
		return support.verify();
	}
	

	public void selectRadioButtonInGroup(Object value)
	{
		ButtonGroup buttonGroup = getButtonGroup();
		if(buttonGroup != null)
		{
			Enumeration e = buttonGroup.getElements();
			while(e.hasMoreElements())
			{
				Object o = e.nextElement();
				if(o instanceof XdevRadioButton)
				{
					XdevRadioButton radio = (XdevRadioButton)o;
					if(value.equals(radio.getFormularValue0()))
					{
						radio.setSelected(true);
						break;
					}
				}
			}
		}
	}
	

	public XdevRadioButton getSelectedRadioButtonInGroup()
	{
		ButtonGroup buttonGroup = getButtonGroup();
		if(buttonGroup != null)
		{
			Enumeration e = buttonGroup.getElements();
			while(e.hasMoreElements())
			{
				Object o = e.nextElement();
				if(o instanceof XdevRadioButton)
				{
					XdevRadioButton button = (XdevRadioButton)o;
					if(button.isSelected())
					{
						return button;
					}
				}
			}
		}
		
		return null;
	}
	

	public Object getSelectedRadioButtonValue()
	{
		XdevRadioButton button = getSelectedRadioButtonInGroup();
		if(button != null)
		{
			return button.getFormularValue0();
		}
		
		return null;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		if(returnValue != null && returnValue.length() > 0)
		{
			return returnValue;
		}
		
		return UIUtils.toString(this);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getTabIndex()
	{
		return tabIndex;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTabIndex(int tabIndex)
	{
		if(this.tabIndex != tabIndex)
		{
			int oldValue = this.tabIndex;
			this.tabIndex = tabIndex;
			firePropertyChange(TAB_INDEX_PROPERTY,oldValue,tabIndex);
		}
	}
}
