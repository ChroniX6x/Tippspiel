/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.ui;


import java.lang.annotation.*;


/**
 * Marker annotation for beans to mark all fields as no bean property.
 * <p>
 * All fields of a bean with appropriate getters and setters are bean properties
 * per default, except the bean is annotated with <code>NoBeanProperties</code>.
 * <p>
 * To use single fields of a NoBeanProperties-bean as properties they have to be
 * annotated with {@link BeanProperty}.
 * 
 * 
 * @author XDEV Software
 * @since 3.0
 * 
 * @see BeanProperty
 * @see NoBeanProperty
 * @see AllBeanProperties
 * @see BeanSettings
 */
@Target(ElementType.TYPE)
public @interface NoBeanProperties
{
}
