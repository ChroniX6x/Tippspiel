/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.Image;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.net.URL;

import javax.swing.JFrame;
import javax.swing.WindowConstants;

import xdev.Application;
import xdev.io.IOUtils;


/**
 * The {@link XdevMainFrame} is a top-level Frame. The XdevMainFrame is always
 * called as first frame. Based on {@link XdevFrame}.
 * 
 * 
 * @see JFrame
 * @see XdevRootPaneContainer
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
public class XdevMainFrame extends XdevFrame implements XdevApplicationContainer
{
	/**
	 * Creates a new, initially invisible XdevMainFrame.
	 * 
	 * @see XdevFrame
	 */
	public XdevMainFrame()
	{
		super("",(Image)null);
		
		setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
		addWindowListener(new WindowAdapter()
		{
			@Override
			public void windowClosing(WindowEvent e)
			{
				Application.exit(XdevMainFrame.this);
			}
		});
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public URL getCodeBase()
	{
		URL url = null;
		try
		{
			url = new File("./").getAbsoluteFile().toURI().toURL();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return url;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Image getImage(URL url)
	{
		return getToolkit().getImage(url);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void showDocument(URL url)
	{
		try
		{
			IOUtils.launchBrowser(url.toExternalForm());
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void showDocument(URL url, String target)
	{
		try
		{
			IOUtils.launchBrowser(url.toExternalForm());
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}
}
