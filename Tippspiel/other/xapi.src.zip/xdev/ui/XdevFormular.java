/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.ui;


import java.awt.Component;
import java.awt.LayoutManager;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JComponent;

import xdev.db.DBConnection;
import xdev.db.DBException;
import xdev.db.DBUtils;
import xdev.db.Transaction;
import xdev.db.sql.Condition;
import xdev.db.sql.WHERE;
import xdev.io.IOUtils;
import xdev.lang.cmd.Query;
import xdev.ui.FormularUtils.FormularValue;
import xdev.ui.FormularUtils.ParameterContainer;
import xdev.ui.event.FormularEvent;
import xdev.ui.event.FormularListener;
import xdev.vt.KeyValues;
import xdev.vt.VirtualTable;
import xdev.vt.VirtualTable.VirtualTableRow;
import xdev.vt.VirtualTableException;


/**
 * The {@link XdevFormular} is a GUI container component.
 * 
 * <p>
 * The {@link XdevFormular} can be used to display a row of a
 * {@link VirtualTable}. Therefore the {@link XdevFormular} must contain
 * {@link FormularComponent}s that are mapped to the columns of the
 * {@link VirtualTable} you want to display. This can be done by the XDEV IDE or
 * manually.
 * </p>
 * 
 * <p>
 * The {@link XdevFormular} also manages n:m-relations. Therefore
 * {@link ManyToManyComponent}s can be added into this container.
 * </p>
 * 
 * <p>
 * The {@link XdevFormular} provides methods to:
 * <ul>
 * <li>display {@link VirtualTableRow}s like {@link #setData(int, VirtualTable)}
 * </li>
 * <li>insert {@link VirtualTableRow}s like {@link #insert(boolean)}</li>
 * <li>update (before loaded) {@link VirtualTableRow}s like
 * {@link #update(boolean)}</li>
 * <li>delete (before loaded) {@link VirtualTableRow}s like
 * {@link #delete(boolean)}</li>
 * </ul>
 * </p>
 * 
 * @author XDEV Software
 * 
 * @see FormularListener
 * @see FormularComponent
 * @see MasterDetailComponent
 * @see ManyToManyComponent
 * 
 * @since 2.0
 */
public class XdevFormular extends XdevContainer
{
	
	/**
	 * JavaDoc omitted for private field.
	 */
	private VirtualTableRow		virtualTableRow							= null;
	
	/**
	 * Identifies a change in the saveStateAfterModelUpdate property.
	 */
	public final static String	SAVE_STATE_AFTER_MODEL_UPDATE_PROPERTY	= "saveStateAfterModelUpdate";
	
	private boolean				saveStateAfterModelUpdate				= true;
	

	/**
	 * Create a new {@link XdevFormular} with no layout manager.
	 * 
	 * <p>
	 * Alias for <code>XdevFormular(null)</code>
	 * </p>
	 * 
	 * @see #XdevFormular(LayoutManager)
	 * 
	 */
	public XdevFormular()
	{
		super();
	}
	

	/**
	 * Create a new {@link XdevFormular} with the specified layout manager.
	 * 
	 * @param layout
	 *            the LayoutManager to use
	 */
	public XdevFormular(LayoutManager layout)
	{
		super(layout);
	}
	

	/**
	 * Registers a {@link FormularListener} so that it will receive formular
	 * events.
	 * 
	 * @param l
	 *            the listener to register
	 */
	public void addFormularListener(FormularListener l)
	{
		listenerList.add(FormularListener.class,l);
	}
	

	/**
	 * Removes the listener from the listener list of this formular.
	 * 
	 * @param l
	 *            the listener to remove
	 */
	public void removeFormularListener(FormularListener l)
	{
		listenerList.remove(FormularListener.class,l);
	}
	

	protected void fireModelChanged()
	{
		FormularListener[] listeners = listenerList.getListeners(FormularListener.class);
		if(listeners != null && listeners.length > 0)
		{
			FormularEvent event = new FormularEvent(this);
			for(FormularListener listener : listeners)
			{
				listener.formularModelChanged(event);
			}
		}
	}
	

	protected void fireSavePerformed()
	{
		FormularListener[] listeners = listenerList.getListeners(FormularListener.class);
		if(listeners != null && listeners.length > 0)
		{
			FormularEvent event = new FormularEvent(this);
			for(FormularListener listener : listeners)
			{
				listener.formularSavePerformed(event);
			}
		}
	}
	

	/**
	 * Determines of the {@link FormularComponent} <code>formCpn</code> should
	 * be used in this formular's actions.
	 * 
	 * @param formCpn
	 *            the {@link FormularComponent} to check
	 * @return <code>true</code> if <code>formCpn</code> should be used,
	 *         <code>false</code> otherwise
	 */
	protected boolean use(FormularComponent formCpn)
	{
		return true;
	}
	

	<T> T lookupComponentTree(final ComponentTreeVisitor<T, Component> visitor)
	{
		return UIUtils.lookupComponentTree(this,new ComponentTreeVisitor<T, Component>()
		{
			@Override
			public T visit(Component cpn)
			{
				T ret = null;
				
				if(!(cpn instanceof FormularComponent && !use((FormularComponent)cpn)))
				{
					ret = visitor.visit(cpn);
				}
				
				return ret;
			}
		});
	}
	

	/**
	 * Saves the state of all {@link FormularComponent}s in this formular.
	 * 
	 * @see #reset()
	 * @see FormularComponent#saveState()
	 */
	public void saveState()
	{
		lookupComponentTree(new ComponentTreeVisitor<Object, Component>()
		{
			public Object visit(Component cpn)
			{
				if(cpn instanceof FormularComponent)
				{
					((FormularComponent)cpn).saveState();
				}
				
				return null;
			}
		});
	}
	

	/**
	 * Resets this {@link XdevFormular} / the mapped components in the
	 * {@link XdevFormular} to the default values of the components.
	 * <p>
	 * This method is a synonym for {@link #reset()}
	 * 
	 * @see #saveState()
	 * @see FormularComponent#restoreState()
	 */
	public void restoreState()
	{
		lookupComponentTree(new ComponentTreeVisitor<Object, Component>()
		{
			public Object visit(Component cpn)
			{
				if(cpn instanceof FormularComponent)
				{
					((FormularComponent)cpn).restoreState();
				}
				
				return null;
			}
		});
	}
	

	/**
	 * Resets this {@link XdevFormular} / the mapped components in the
	 * {@link XdevFormular} to the default values of the components.
	 * <p>
	 * This method is a synonym for {@link #restoreState()}
	 * 
	 * @see #saveState()
	 * @see FormularComponent#restoreState()
	 */
	public void reset()
	{
		restoreState();
	}
	

	/**
	 * Resets this {@link XdevFormular} / the mapped components in the
	 * {@link XdevFormular} to the default values of the specified
	 * {@link VirtualTable} <code>vt</code>.
	 * 
	 * <p>
	 * Alias for <code>setData(vt.createRow(),vt)</code>
	 * </p>
	 * 
	 * @param vt
	 *            {@link VirtualTable} to reset on.
	 * 
	 */
	public void setModel(VirtualTable vt)
	{
		reset(vt);
	}
	

	/**
	 * Resets this {@link XdevFormular} / the mapped components in the
	 * {@link XdevFormular} to the default values of the specified
	 * {@link VirtualTable} <code>vt</code>.
	 * 
	 * <p>
	 * Alias for <code>setModel(vt.createRow())</code>
	 * </p>
	 * 
	 * @param vt
	 *            {@link VirtualTable} to reset on.
	 * 
	 */
	public void reset(VirtualTable vt)
	{
		setModel(vt.createRow());
	}
	

	/**
	 * @deprecated use {@link #setModel(VirtualTable.VirtualTableRow)} instead
	 */
	// @Deprecated
	// public void fillFromVT(int row, VirtualTable vt)
	// {
	// setModel(vt.getVTRow(row));
	// }
	
	/**
	 * @deprecated use {@link #setModel(VirtualTable.VirtualTableRow)} instead
	 */
	// @Deprecated
	// public void setData(int row, VirtualTable vt)
	// {
	// setModel(vt.getVTRow(row));
	// }
	
	/**
	 * @deprecated use {@link #setModel(VirtualTable.VirtualTableRow)} instead
	 */
	// @Deprecated
	// public void setData(VirtualTableRow virtualTableRow, VirtualTable vt)
	// {
	// setModel(virtualTableRow);
	// }
	
	/**
	 * Fills this {@link XdevFormular} / the mapped components in the
	 * {@link XdevFormular} with the values provided by the specified
	 * <code>row</code> in the {@link VirtualTable} <code>vt</code>.
	 * 
	 * @param row
	 *            the row index of the {@link VirtualTable}
	 * @param vt
	 *            {@link VirtualTable} to take the data from.
	 * 
	 * @see VirtualTableRow
	 * @see #setModel(VirtualTable.VirtualTableRow)
	 */
	public void setModel(int row, VirtualTable vt)
	{
		setModel(vt.getRow(row));
	}
	

	/**
	 * Fills this {@link XdevFormular} / the mapped components in the
	 * {@link XdevFormular} with the values provided by the specified
	 * <code>row</code>.
	 * 
	 * @param virtualTableRow
	 *            {@link VirtualTableRow} to take the data from.
	 * 
	 * @see VirtualTableRow
	 * @see #setModel(int, VirtualTable)
	 */
	public void setModel(final VirtualTableRow virtualTableRow)
	{
		this.virtualTableRow = virtualTableRow;
		
		final VirtualTable vt = virtualTableRow.getVirtualTable();
		lookupComponentTree(new ComponentTreeVisitor()
		{
			public Object visit(Component cpn)
			{
				if(cpn instanceof ManyToManyComponent)
				{
					ManyToManyComponent nmComponent = (ManyToManyComponent)cpn;
					nmComponent.refresh(virtualTableRow);
					List<FormularListener> formularListeners = Arrays
							.asList(XdevFormular.this.listenerList
									.getListeners(FormularListener.class));
					if(!formularListeners.contains(nmComponent))
					{
						XdevFormular.this.addFormularListener(nmComponent);
					}
				}
				else if(cpn instanceof FormularComponent && cpn instanceof JComponent)
				{
					JComponent jc = (JComponent)cpn;
					Object dataField = jc.getClientProperty(DATA_FIELD);
					String name = dataField != null ? dataField.toString() : jc.getName();
					if(name != null)
					{
						int col = vt.getColumnIndex(name);
						if(col >= 0)
						{
							FormularComponent fc = (FormularComponent)cpn;
							fc.setFormularValue(vt,col,virtualTableRow.get(col));
							return null;
						}
					}
				}
				
				return null;
			}
		});
		
		if(saveStateAfterModelUpdate)
		{
			saveState();
		}
		
		fireModelChanged();
	}
	

	/**
	 * Sets if the formular should save its state after an update of the model.
	 * 
	 * @param saveStateAfterModelUpdate
	 *            <code>true</code> if the state should be saved,
	 *            <code>false</code> otherwise
	 * 
	 * @see #setModel(VirtualTable.VirtualTableRow)
	 * @see #saveState()
	 */
	public void setSaveStateAfterModelUpdate(boolean saveStateAfterModelUpdate)
	{
		if(this.saveStateAfterModelUpdate != saveStateAfterModelUpdate)
		{
			boolean oldValue = this.saveStateAfterModelUpdate;
			this.saveStateAfterModelUpdate = saveStateAfterModelUpdate;
			firePropertyChange(SAVE_STATE_AFTER_MODEL_UPDATE_PROPERTY,oldValue,
					saveStateAfterModelUpdate);
		}
	}
	

	/**
	 * Determines if the formular saves its state after an update of the model.
	 * 
	 * @return <code>true</code> if the state is saved, <code>false</code>
	 *         otherwise
	 * 
	 * @see #setModel(VirtualTable.VirtualTableRow)
	 * @see #saveState()
	 */
	public boolean getSaveStateAfterModelUpdate()
	{
		return saveStateAfterModelUpdate;
	}
	

	/**
	 * Returns a {@link Map} containing all values of this {@link XdevFormular}
	 * / the mapped components in the {@link XdevFormular}. The key of the
	 * {@link Map} is the component name; the value is the value of that
	 * component.
	 * 
	 * @param withNulls
	 *            <code>true</code> if null values should be returned; otherwise
	 *            <code>false</code>
	 * @return a {@link Map} containing all values of this {@link XdevFormular}
	 *         / the mapped components in the {@link XdevFormular}.
	 */
	public Map<String, Object> getData(boolean withNulls)
	{
		Map<String, Object> map = new HashMap<String, Object>();
		
		FormularUtils.addData(this,map,withNulls);
		
		return map;
	}
	

	private List<ManyToManyComponent> getManyToManyComponents()
	{
		final List<ManyToManyComponent> list = new ArrayList();
		
		UIUtils.lookupComponentTree(this,new ComponentTreeVisitor<Object, Component>()
		{
			@Override
			public Object visit(Component cpn)
			{
				if(cpn instanceof ManyToManyComponent)
				{
					list.add((ManyToManyComponent)cpn);
				}
				
				return null;
			}
		});
		
		return list;
	}
	

	/**
	 * JavaDoc omitted for private method.
	 */
	private void checkVirtualTableRow() throws VirtualTableException
	{
		if(virtualTableRow == null)
		{
			throw new VirtualTableException("No data from a VirtualTable assigned");
		}
	}
	

	/**
	 * Returns the current assigned {@link VirtualTableRow}.
	 * 
	 * @return The current assigned {@link VirtualTableRow}
	 * 
	 * @see #setModel(VirtualTable)
	 * @see #setModel(VirtualTable.VirtualTableRow)
	 */
	public VirtualTableRow getVirtualTableRow()
	{
		return virtualTableRow;
	}
	

	/**
	 * Returns the assigned {@link VirtualTable} of this {@link XdevFormular}.
	 * 
	 * @return The current assigned {@link VirtualTable}
	 * 
	 */
	public VirtualTable getVirtualTable()
	{
		if(virtualTableRow != null)
		{
			return virtualTableRow.getVirtualTable();
		}
		
		return lookupVT();
	}
	

	/**
	 * <p>
	 * Alias for <code>save(true).</code>
	 * </p>
	 * 
	 * @throws VirtualTableException
	 *             if the new row can't be set to the {@link VirtualTable}.
	 * @throws DBException
	 *             if the new row can't be propagated to the underling database.
	 * 
	 * @see #save(boolean)
	 */
	public void save() throws VirtualTableException, DBException
	{
		save(true);
	}
	

	/**
	 * <p>
	 * Propagates the values of this {@link XdevFormular} / the mapped
	 * components in the {@link XdevFormular} to the set {@link VirtualTable} as
	 * new row if the row is new to the {@link VirtualTable}, otherwise an
	 * update is performed.
	 * </p>
	 * 
	 * 
	 * @param synchronizeDB
	 *            <code>true</code> if the new row should be propagated to the
	 *            underling database as well; otherwise <code>false</code>.
	 * @throws VirtualTableException
	 *             if the new row can't be set to the {@link VirtualTable}.
	 * @throws DBException
	 *             if the new row can't be propagated to the underling database.
	 * 
	 */
	public void save(final boolean synchronizeDB) throws VirtualTableException, DBException
	{
		if(virtualTableRow != null)
		{
			if(virtualTableRow.isNew())
			{
				insert(synchronizeDB);
			}
			else
			{
				update(synchronizeDB);
			}
		}
		else
		{
			VirtualTable vt = lookupVT();
			if(vt == null)
			{
				throw new NullPointerException("No VirtualTable found for Formular '" + getName()
						+ "'");
			}
			
			vt.addRow(getData(true),synchronizeDB);
			
			fireSavePerformed();
		}
	}
	

	/**
	 * Alias for <code>update(true)</code>.
	 * 
	 * @throws VirtualTableException
	 *             if the values can't be set to the {@link VirtualTable}.
	 * @throws DBException
	 *             if the values can't be propagated to the underling database.
	 * 
	 * @see #update(boolean)
	 */
	public void update() throws VirtualTableException, DBException
	{
		update(true);
	}
	

	/**
	 * <p>
	 * Propagates the values of this {@link XdevFormular} / the mapped
	 * components in the {@link XdevFormular} to the set {@link VirtualTable} /
	 * the set {@link VirtualTableRow}.
	 * </p>
	 * 
	 * <p>
	 * <strong>Warning:</strong> In order to be able to update a row, you need
	 * to set a {@link VirtualTableRow} for this {@link XdevFormular}. You can
	 * do this by calling {@link #setModel(int, VirtualTable)} or
	 * {@link #setModel(VirtualTable.VirtualTableRow)}.
	 * </p>
	 * 
	 * @param synchronizeDB
	 *            <code>true</code> if the changes should be propagated to the
	 *            underling database as well; otherwise <code>false</code>.
	 * @throws VirtualTableException
	 *             if the values can't be set to the {@link VirtualTable}.
	 * @throws DBException
	 *             if the values can't be propagated to the underling database.
	 * 
	 * @see #setModel(VirtualTable.VirtualTableRow)
	 */
	public void update(final boolean synchronizeDB) throws VirtualTableException, DBException
	{
		checkVirtualTableRow();
		
		final Map<String, Object> data = getData(true);
		final List<ManyToManyComponent> nmCpns = getManyToManyComponents();
		
		if(nmCpns.size() > 0)
		{
			if(synchronizeDB)
			{
				new Transaction()
				{
					@Override
					protected void write(DBConnection<?> connection) throws DBException
					{
						virtualTableRow.update(data,synchronizeDB,connection);
						for(ManyToManyComponent nmCpn : nmCpns)
						{
							nmCpn.save(synchronizeDB,connection);
						}
					}
				}.execute();
			}
			else
			{
				virtualTableRow.update(data,synchronizeDB);
				for(ManyToManyComponent nmCpn : nmCpns)
				{
					nmCpn.save(synchronizeDB,null);
				}
			}
		}
		else
		{
			virtualTableRow.update(data,synchronizeDB);
		}
		
		fireSavePerformed();
	}
	

	/**
	 * <p>
	 * Propagates the values of this {@link XdevFormular} / the mapped
	 * components in the {@link XdevFormular} to the specified
	 * {@link VirtualTable} <code>vt</code>, to the row that matches the given
	 * value <code>val</code> in the column with the given name
	 * <code>colName</code>.
	 * </p>
	 * 
	 * 
	 * 
	 * @param vt
	 *            {@link VirtualTable} to propagate the changes to
	 * @param colName
	 *            name of the column to look for the given value
	 *            <code>val</code>
	 * @param val
	 *            value to search for in the column with the given column name
	 *            <code>colName</code>
	 * @param synchronizeDB
	 *            <code>true</code> if the changes should be propagated to the
	 *            underling database as well; otherwise <code>false</code>.
	 * @throws VirtualTableException
	 *             if the values can't be set to {@link VirtualTable}.
	 * @throws DBException
	 *             if the values can't be propagated to underling database.
	 * @deprecated use {@link #updateRowsInVT(VirtualTable, KeyValues, boolean)}
	 *             instead
	 */
	// @Deprecated
	// public void updateRowInVT(VirtualTable vt, String colName, Object val,
	// boolean synchronizeDB)
	// throws VirtualTableException, DBException
	// {
	// vt.updateRows(getData(true),colName,val,synchronizeDB);
	// }
	
	/**
	 * <p>
	 * Propagates the values of this {@link XdevFormular} / the mapped
	 * components in the {@link XdevFormular} to the specified
	 * {@link VirtualTable} <code>vt</code>, to the rows which matches the given
	 * {@link KeyValues} <code>pkv</code>.
	 * </p>
	 * 
	 * 
	 * 
	 * @param vt
	 *            {@link VirtualTable} to propagate the changes to
	 * @param keyValues
	 *            The values which identify the rows to update
	 * @param synchronizeDB
	 *            <code>true</code> if the changes should be propagated to the
	 *            underling database as well; otherwise <code>false</code>.
	 * @throws VirtualTableException
	 *             if the values can't be set to the {@link VirtualTable}.
	 * @throws DBException
	 *             if the values can't be propagated to the underling database.
	 */
	public void updateRowsInVT(VirtualTable vt, KeyValues keyValues, boolean synchronizeDB)
			throws VirtualTableException, DBException
	{
		vt.updateRows(getData(true),keyValues,synchronizeDB);
	}
	

	/**
	 * <p>
	 * Propagates the values of this {@link XdevFormular} / the mapped
	 * components in the {@link XdevFormular} to the set {@link VirtualTable} as
	 * new row.
	 * </p>
	 * 
	 * 
	 * @param vt
	 *            {@link VirtualTable} to propagate the new row to
	 * 
	 * @param synchronizeDB
	 *            <code>true</code> if the changes should be propagated to the
	 *            underling database as well; otherwise <code>false</code>.
	 * @throws VirtualTableException
	 *             if the values can't be set to the {@link VirtualTable}.
	 * @throws DBException
	 *             if the values can't be propagated to the underling database.
	 */
	public void insertRowInVT(VirtualTable vt, boolean synchronizeDB) throws VirtualTableException,
			DBException
	{
		vt.addRow(getData(true),synchronizeDB);
	}
	

	/**
	 * <p>
	 * Alias for <code>insert(true).</code>
	 * </p>
	 * 
	 * @throws VirtualTableException
	 *             if the new row can't be set to {@link VirtualTable}.
	 * @throws DBException
	 *             if the new row can't be propagated to underling database.
	 * 
	 * @see #insert(boolean)
	 */
	public void insert() throws VirtualTableException, DBException
	{
		insert(true);
	}
	

	/**
	 * <p>
	 * Propagates the values of this {@link XdevFormular} / the mapped
	 * components in the {@link XdevFormular} to the set {@link VirtualTable} as
	 * new row.
	 * </p>
	 * 
	 * @param synchronizeDB
	 *            <code>true</code> if the new row should be propagated to the
	 *            underling database as well; otherwise <code>false</code>.
	 * @throws VirtualTableException
	 *             if the new row can't be set to {@link VirtualTable}.
	 * @throws DBException
	 *             if the new row can't be propagated to underling database.
	 */
	public void insert(final boolean synchronizeDB) throws VirtualTableException, DBException
	{
		if(virtualTableRow != null)
		{
			final Map<String, Object> data = getData(true);
			final List<ManyToManyComponent> nmCpns = getManyToManyComponents();
			
			if(nmCpns.size() > 0)
			{
				if(synchronizeDB)
				{
					final DBConnection connection = DBUtils.getCurrentDataSource().openConnection();
					
					try
					{
						new Transaction()
						{
							@Override
							protected DBConnection<?> getConnection() throws DBException
							{
								return connection;
							}
							

							@Override
							protected void write(DBConnection<?> connection) throws DBException
							{
								// insert master record first to get the
								// generated ids
								virtualTableRow.insert(data,synchronizeDB,connection);
								
								for(ManyToManyComponent nmCpn : nmCpns)
								{
									nmCpn.save(synchronizeDB,connection);
								}
							}
						}.execute();
					}
					finally
					{
						connection.close();
					}
				}
				else
				{
					virtualTableRow.insert(data,synchronizeDB);
					for(ManyToManyComponent nmCpn : nmCpns)
					{
						nmCpn.save(synchronizeDB,null);
					}
				}
			}
			else
			{
				virtualTableRow.insert(data,synchronizeDB);
			}
		}
		else
		{
			VirtualTable vt = lookupVT();
			if(vt == null)
			{
				throw new NullPointerException("No VirtualTable found for Formular '" + getName()
						+ "'");
			}
			
			vt.addRow(getData(true),synchronizeDB);
		}
		
		fireSavePerformed();
	}
	

	/**
	 * <p>
	 * Alias for <code>delete(true).</code>
	 * </p>
	 * 
	 * @throws VirtualTableException
	 *             if row can't be deleted from {@link VirtualTable}.
	 * @throws DBException
	 *             if the row can't be deleted from the underling database.
	 * 
	 * @see #delete(boolean)
	 */
	public void delete() throws VirtualTableException, DBException
	{
		delete(true);
	}
	

	/**
	 * <p>
	 * Deletes the {@link VirtualTableRow} represented by this
	 * {@link XdevFormular} from the set {@link VirtualTable}.
	 * </p>
	 * 
	 * <p>
	 * <strong>Warning:</strong> In order to be able to delete a row, you need
	 * to set a {@link VirtualTableRow} for this {@link XdevFormular}. You can
	 * do this by calling {@link #setModel(VirtualTable.VirtualTableRow)} or
	 * {@link #setModel(int, VirtualTable)}.
	 * </p>
	 * 
	 * @param synchronizeDB
	 *            <code>true</code> if the row should also be deleted from the
	 *            underling database as well; otherwise <code>false</code>.
	 * @throws VirtualTableException
	 *             if row can't be deleted from {@link VirtualTable}.
	 * @throws DBException
	 *             if the row can't be deleted from the underling database.
	 * 
	 */
	public void delete(boolean synchronizeDB) throws VirtualTableException, DBException
	{
		checkVirtualTableRow();
		
		virtualTableRow.delete(synchronizeDB);
	}
	

	/**
	 * JavaDoc omitted for private method.
	 */
	private VirtualTable lookupVT()
	{
		return UIUtils.lookupComponentTree(this,
				new ComponentTreeVisitor<VirtualTable, JComponent>()
				{
					public VirtualTable visit(JComponent cpn)
					{
						return FormularUtils.getConnectedVT(cpn);
					}
				},JComponent.class);
	}
	

	/**
	 * Returns <code>ture</code> if all values of all {@link FormularComponent}s
	 * of this {@link XdevFormular} could be verified, <code>false</code>
	 * otherwise.
	 * 
	 * @return <code>true</code> if all values of all {@link FormularComponent}s
	 *         of this {@link XdevFormular} could be verified,
	 *         <code>false</code> otherwise.
	 */
	public boolean verifyFormularComponents()
	{
		return FormularUtils.verifyFormularComponents(this);
	}
	

	/**
	 * Submits the contents of this {@link XdevFormular} to the given
	 * <code>url</code>.
	 * 
	 * @param url
	 *            url to send the contents to
	 * @param target
	 *            HTML target (<code>_blank</code>, <code>_parent</code> etc.)
	 * @throws IOException
	 *             if the submit fails
	 */
	public void submit(String url, String target) throws IOException
	{
		IOUtils.showDocument(url + getURLAdd(),target);
	}
	

	/**
	 * Returns a parameter list consisting of key value pairs containing all
	 * components of this {@link XdevFormular} and their values.
	 * 
	 * e.g. ?txtFirstname=John&txtLastname=Doe
	 * 
	 * @return a parameter list consisting of key value pairs containing all
	 *         components of this {@link XdevFormular} and their values.
	 */
	public String getURLAdd()
	{
		final StringBuffer urlAdd = new StringBuffer();
		final Vector<XdevRadioButton> usedRadioButtons = new Vector<XdevRadioButton>();
		
		lookupComponentTree(new ComponentTreeVisitor<Object, Component>()
		{
			public Object visit(Component cpn)
			{
				if(!(cpn instanceof XdevRadioButton && usedRadioButtons.contains(cpn)))
				{
					Object value = UIUtils.getValue(cpn);
					if(value != null)
					{
						urlAdd.append(urlAdd.length() == 0 ? '?' : '&');
						urlAdd.append(UIUtils.getFormularName(cpn));
						
						if(cpn instanceof XdevRadioButton)
						{
							XdevRadioButton radio = (XdevRadioButton)cpn;
							ButtonGroup buttonGroup = radio.getButtonGroup();
							if(buttonGroup != null)
							{
								Enumeration<AbstractButton> e = buttonGroup.getElements();
								while(e.hasMoreElements())
								{
									Object o = e.nextElement();
									if(o instanceof XdevRadioButton)
									{
										radio = (XdevRadioButton)o;
										if(radio.isSelected())
										{
											value = UIUtils.getValue(radio);
										}
										usedRadioButtons.add(radio);
									}
								}
							}
						}
						
						urlAdd.append('=');
						urlAdd.append(value.toString());
					}
				}
				
				return null;
			}
		});
		
		return urlAdd.toString();
	}
	

	/**
	 * <p>
	 * Alias for <code>createCondition(connector,null)</code>.
	 * </p>
	 * 
	 * @param connector
	 *            "AND" or "OR"
	 * 
	 * @return The {@link WHERE} condition depending on the input component's
	 *         values
	 * 
	 * @throws IllegalArgumentException
	 *             if connector != "AND" resp. "OR"
	 * 
	 * @see #createCondition(String, Query)
	 */
	public Condition createCondition(String connector) throws IllegalArgumentException
	{
		return createCondition(connector,null);
	}
	

	/**
	 * Creates a {@link Condition} depending on the input component's values and
	 * their conditional settings.
	 * 
	 * @param connector
	 *            "AND" or "OR"
	 * @param query
	 *            The {@link Query} to create this {@link WHERE} condition for
	 *            (optional)
	 * @return The {@link WHERE} condition depending on the input component's
	 *         values
	 * @throws IllegalArgumentException
	 *             if connector != "AND" resp. "OR"
	 */
	public Condition createCondition(String connector, final Query query)
			throws IllegalArgumentException
	{
		Map<String, List<FormularValue>> map = new HashMap<String, List<FormularValue>>();
		FormularUtils.collectFormularValues(this,map,false);
		
		ParameterContainer paramContainer = new ParameterContainer()
		{
			@Override
			public void addParameters(Object... params)
			{
				if(query != null)
				{
					query.addParameters(params);
				}
			}
		};
		
		return FormularUtils.createWhereCondition(connector,paramContainer,map);
	}
	

	/**
	 * Updates the model of the {@link VirtualTableOwner} target.
	 * <p>
	 * First a {@link Condition} depending on the input component's values and
	 * their conditional settings is created and then handed over to
	 * {@link VirtualTableOwner#updateModel(Condition, Object...)} of
	 * <code>target</code>.
	 * 
	 * @param connector
	 *            "AND" or "OR"
	 * @param target
	 *            the component to update
	 * @throws IllegalArgumentException
	 *             if connector != "AND" resp. "OR"
	 * 
	 * @see #createCondition(String)
	 */
	public void search(String connector, VirtualTableOwner target) throws IllegalArgumentException
	{
		Map<String, List<FormularValue>> map = new HashMap<String, List<FormularValue>>();
		FormularUtils.collectFormularValues(this,map,false);
		
		final List paramList = new ArrayList();
		ParameterContainer paramContainer = new ParameterContainer()
		{
			@Override
			public void addParameters(Object... params)
			{
				Collections.addAll(paramList,params);
			}
		};
		
		Condition condition = FormularUtils.createWhereCondition(connector,paramContainer,map);
		target.updateModel(condition,paramList.toArray());
	}
}
