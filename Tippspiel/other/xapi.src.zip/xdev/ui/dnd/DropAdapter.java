/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui.dnd;


import java.awt.*;
import java.awt.datatransfer.*;
import java.awt.dnd.*;


public class DropAdapter
{
	public DropAdapter(Component cpn)
	{
		new DropTarget(cpn,new DropTargetListener()
		{
			public void drop(DropTargetDropEvent dtde)
			{
				try
				{
					dtde.acceptDrop(DnDConstants.ACTION_COPY);
					Object data = getTransferData(dtde.getTransferable());
					dtde.dropComplete(true);
					DropAdapter.this.drop(new DropEvent(dtde.getSource(),data,dtde.getLocation()));
				}
				catch(Exception e)
				{
					e.printStackTrace();
				}
			}
			

			public void dragEnter(DropTargetDragEvent dtde)
			{
			}
			

			public void dragOver(DropTargetDragEvent dtde)
			{
			}
			

			public void dragExit(DropTargetEvent dte)
			{
			}
			

			public void dropActionChanged(DropTargetDragEvent dtde)
			{
			}
			

			Object getTransferData(Transferable t)
			{
				try
				{
					return t.getTransferData(LocalTransferable.DATA_FLAVOR);
				}
				catch(Exception e)
				{
					try
					{
						if(t.isDataFlavorSupported(DataFlavor.javaFileListFlavor))
						{
							return t.getTransferData(DataFlavor.javaFileListFlavor);
						}
						else if(t.isDataFlavorSupported(DataFlavor.imageFlavor))
						{
							return t.getTransferData(DataFlavor.imageFlavor);
						}
						else if(t.isDataFlavorSupported(DataFlavor.stringFlavor))
						{
							return t.getTransferData(DataFlavor.stringFlavor);
						}
						
						return "";
					}
					catch(Exception e2)
					{
						e2.printStackTrace();
						return "";
					}
				}
			}
		});
	}
	

	public void drop(DropEvent event)
	{
	}
}
