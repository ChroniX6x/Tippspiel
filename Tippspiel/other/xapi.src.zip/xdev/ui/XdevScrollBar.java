/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import javax.swing.*;
import java.awt.event.*;


public class XdevScrollBar extends JScrollBar implements AdjustmentListener
{
	public final static int			AS_NEEDED	= 0;
	public final static int			ALWAYS		= 1;
	
	private XdevScrollBarListener	listener;
	private double					pvis;
	private int						max;
	

	public XdevScrollBar(int orientation, int min, int max, double pvis, int scrollAmount,
			XdevScrollBarListener listener)
	{
		super(orientation);
		setValues(min,max,pvis,min);
		setScrollAmount(scrollAmount);
		this.listener = listener;
		addAdjustmentListener(this);
	}
	

	public void refresh()
	{
		setValues(getMinimum(),max,pvis,getValue());
	}
	

	public void setValues(int min, int max, double pvis, int val)
	{
		this.pvis = pvis;
		this.max = max;
		int extend = Math.max(1,(int)Math.round(((getOrientation() == HORIZONTAL ? getWidth()
				: getHeight()))
				* pvis));
		super.setValues(val,extend,min,max + extend);
	}
	

	public void setScrollAmount(int sa)
	{
		setUnitIncrement(sa);
		setBlockIncrement((int)Math.round((max - getMinimum()) * pvis));
	}
	

	public void adjustmentValueChanged(AdjustmentEvent e)
	{
		listener.scrollBarValueChanged();
	}
	

	public int getMax()
	{
		return max;
	}
	

	public int getVal()
	{
		return getValue();
	}
	

	public void setVal(int i)
	{
		setValue(i);
	}
}
