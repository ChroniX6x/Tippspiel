/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.Component;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.GrayFilter;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JComponent;


public class XdevDateDropDownButton extends JComponent
{
	private final static Image	calendarImage;
	private final static Image	disabledCalendarImage;
	public final static Icon	calendarIcon;
	static
	{
		calendarImage = GraphicUtils.loadResIcon("calendar.png").getImage();
		disabledCalendarImage = GrayFilter.createDisabledImage(calendarImage);
		calendarIcon = new ImageIcon(calendarImage);
	}


	public static void paintCalendarDropDownButton(Component c, Graphics g)
	{
		Image img = c.isEnabled() ? calendarImage : disabledCalendarImage;
		g.drawImage(img,0,0,c.getWidth(),c.getHeight(),c);
	}

	private XdevDateTextField	txt;


	public XdevDateDropDownButton(final XdevDateTextField txt)
	{
		super();

		this.txt = txt;

		addMouseListener(new MouseAdapter()
		{
			public void mousePressed(MouseEvent e)
			{
				if(txt.isEnabled() && txt.isEditable())
				{
					txt.requestFocus();
					txt.setDatePopupVisible(txt.datePopup == null);
				}
			}
		});
	}


	@Override
	public Dimension getPreferredSize()
	{
		int s = txt.getPreferredSize().height;
		return new Dimension(s,s);
	}


	@Override
	public void paint(Graphics g)
	{
		paintCalendarDropDownButton(this,g);
	}
}
