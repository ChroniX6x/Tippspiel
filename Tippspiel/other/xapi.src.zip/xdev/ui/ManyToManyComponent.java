/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import xdev.db.DBConnection;
import xdev.db.DBException;
import xdev.ui.event.FormularListener;
import xdev.vt.VirtualTable;
import xdev.vt.VirtualTableException;
import xdev.vt.VirtualTable.VirtualTableRow;


/**
 * Component which manages many to many relations of a specific record.
 * <p>
 * Many-to-many components are used inside a {@link XdevFormular}.
 * </p>
 * 
 * @author XDEV Software
 * @see XdevFormular
 */
public interface ManyToManyComponent extends FormularListener
{
	/**
	 * Returns the associated {@link VirtualTable} of this component.
	 * 
	 * @return the associated {@link VirtualTable} of this component
	 */
	public VirtualTable getVirtualTable();
	

	/**
	 * Called by the {@link XdevFormular} when the master record changes.
	 * 
	 * @param masterRecord
	 *            the new record to diplay the detail records for
	 */
	public void refresh(VirtualTableRow masterRecord);
	

	/**
	 * Deletes removed, inserts added and updates changed records of the
	 * associated detail table.
	 * 
	 * @param synchronizeDB
	 *            if set to <code>true</code>, changes will be propagated to the
	 *            underlying data source.
	 * @param connection
	 *            the connection used by the transaction
	 * @throws DBException
	 *             if a database error occurs
	 *             
	 * @throws VirtualTableException
	 * 
	 * @see XdevFormular#save
	 */
	public void save(boolean synchronizeDB, DBConnection connection) throws DBException,
			VirtualTableException;
}
