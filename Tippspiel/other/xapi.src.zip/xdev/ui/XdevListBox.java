/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.BorderFactory;
import javax.swing.DefaultListCellRenderer;
import javax.swing.DefaultListSelectionModel;
import javax.swing.Icon;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import javax.swing.ListModel;
import javax.swing.ListSelectionModel;
import javax.swing.SwingUtilities;
import javax.swing.event.ListDataEvent;
import javax.swing.event.ListDataListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import xdev.Application;
import xdev.db.sql.Condition;
import xdev.ui.ItemList.Entry;
import xdev.util.ObjectUtils;
import xdev.util.XdevList;
import xdev.vt.VirtualTable;
import xdev.vt.VirtualTable.VirtualTableRow;


/**
 * The standard label in XDEV. Based on {@link JLabel}.
 * 
 * @see JLabel
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevListBox extends JList implements ItemListOwner, XdevFocusCycleComponent,
		MasterDetailComponent<XdevListBox>
{
	public final static String	CHECKBOX_LIST_PROPERTY		= "checkBoxList";
	public final static String	EVEN_BACKGROUND_PROPERTY	= "evenBackground";
	public final static String	ODD_BACKGROUND_PROPERTY		= "oddBackground";
	
	ItemList					itemList;
	private boolean				checkBoxList				= false;
	private Color				evenBackground				= getBackground();
	private Color				oddBackground				= getBackground();
	/**
	 * tabIndex is used to store the index for {@link XdevFocusCycleComponent}
	 * functionality.
	 */
	private int					tabIndex					= -1;
	


	private static class Support extends ListBoxSupport<XdevListBox, XdevListBox>
	{
		private Support(XdevListBox list)
		{
			super(list,list,list);
		}
	}
	
	private final Support	support	= new Support(this);
	

	/**
	 * Constructs a {@link XdevListBox} that is initialized with a default
	 * {@link ListCellRenderer}.
	 * 
	 * 
	 * @see #setCheckBoxList(boolean)
	 * @see #setItemList(ItemList)
	 */
	public XdevListBox()
	{
		this(false);
	}
	

	/**
	 * Constructs a {@link XdevListBox} that is initialized with a default
	 * {@link ListCellRenderer}.
	 * 
	 * 
	 * @param checkable
	 *            if <code>true</code> the {@link XdevListBox} items are
	 *            initialized with a checkbox style
	 * 
	 * @see #setItemList(ItemList)
	 * @see #setCheckBoxList(boolean)
	 */
	public XdevListBox(boolean checkable)
	{
		this(new ItemList(),checkable);
	}
	

	/**
	 * Constructs a {@link XdevListBox} that is initialized with the
	 * <code>il</code> and a default {@link ListCellRenderer}.
	 * 
	 * 
	 * @param il
	 *            represents the contents or "value" of this {@link XdevListBox}
	 * 
	 * @see #setItemList(ItemList)
	 * @see #setCheckBoxList(boolean)
	 */
	public XdevListBox(ItemList il)
	{
		this(il,false);
	}
	

	/**
	 * Constructs a {@link XdevListBox} that is initialized with the
	 * <code>model</code> and a default {@link ListCellRenderer}.
	 * 
	 * 
	 * @param model
	 *            the {@link ListModel} for this {@link XdevListBox}
	 * 
	 * @see #setModel(ListModel)
	 * @see #setCheckBoxList(boolean)
	 */
	public XdevListBox(ListModel model)
	{
		this(model,false);
	}
	

	/**
	 * Constructs a {@link XdevListBox} that is initialized with the
	 * <code>il</code> and a default {@link ListCellRenderer}.
	 * 
	 * 
	 * @param il
	 *            represents the contents or "value" of this {@link XdevListBox}
	 * 
	 * @param checkable
	 *            if <code>true</code> the {@link XdevListBox} items are
	 *            initialized with a checkbox style
	 * 
	 * @see #setCheckBoxList(boolean)
	 * @see #setItemList(ItemList)
	 */
	public XdevListBox(ItemList il, boolean checkable)
	{
		super();
		setSelectionModel(createListSelectionModel());
		setItemList(il);
		setCheckBoxList0(checkable,true);
	}
	

	/**
	 * Constructs a {@link XdevListBox} that is initialized with the
	 * <code>model</code> and a default {@link ListCellRenderer}.
	 * 
	 * 
	 * @param model
	 *            the {@link ListModel} for this {@link XdevListBox}
	 * 
	 * @param checkable
	 *            if <code>true</code> the {@link XdevListBox} items are
	 *            initialized with a checkbox style
	 * 
	 * @see #setCheckBoxList(boolean)
	 * @see #setModel(ListModel)
	 */
	public XdevListBox(ListModel model, boolean checkable)
	{
		super();
		setSelectionModel(createListSelectionModel());
		setModel(model);
		setCheckBoxList0(checkable,true);
	}
	

	protected boolean isElementSelectable(Object item)
	{
		if(item instanceof Entry)
		{
			return ((Entry)item).isEnabled();
		}
		
		return true;
	}
	

	// TODO javadoc
	public void setCheckBoxList(boolean checkBoxList)
	{
		setCheckBoxList0(checkBoxList,false);
	}
	

	private void setCheckBoxList0(boolean checkBoxList, boolean force)
	{
		if(this.checkBoxList != checkBoxList || force)
		{
			boolean oldValue = this.checkBoxList;
			this.checkBoxList = checkBoxList;
			
			UIUtils.removeMouseListener(this,CheckableHandler.class);
			UIUtils.removeMouseMotionListener(this,CheckableHandler.class);
			
			if(checkBoxList)
			{
				setCellRenderer(createCheckBoxListCellRenderer());
				
				CheckableHandler checkableHandler = new CheckableHandler();
				UIUtils.insertMouseListener(this,checkableHandler,0);
				UIUtils.insertMouseMotionListener(this,checkableHandler,0);
			}
			else
			{
				setCellRenderer(createDefaultListCellRenderer());
			}
			
			firePropertyChange(CHECKBOX_LIST_PROPERTY,oldValue,checkBoxList);
		}
	}
	

	protected ListSelectionModel createListSelectionModel()
	{
		return new XdevListSelectionModel();
	}
	

	protected ListCellRenderer createDefaultListCellRenderer()
	{
		return new XdevListCellRenderer();
	}
	

	protected ListCellRenderer createCheckBoxListCellRenderer()
	{
		return new XdevCheckBoxListCellRenderer();
	}
	

	/**
	 * Returns <code>true</code> if the <code>items</code> of this
	 * {@link XdevListBox} were drawn with a checkbox style.
	 * 
	 * @return <code>true</code> if the <code>items</code> of this
	 *         {@link XdevListBox} were drawn with a checkbox style, otherwise
	 *         <code>false</code>.
	 */
	public boolean isCheckBoxList()
	{
		return checkBoxList;
	}
	

	/**
	 * Returns the {@link ItemList}, that include the <code>item</code> and
	 * <code>data</code>.
	 * 
	 * @return the {@link ItemList} of this {@link XdevListBox}
	 */
	public ItemList getItemList()
	{
		return itemList;
	}
	

	/**
	 * Sets the {@link ItemList} that represents the contents or "value" of the
	 * {@link XdevListBox} and then clears the list's selection.
	 * 
	 * @param il
	 *            {@link ItemList} include the <code>item</code> and
	 *            <code>data</code>
	 * 
	 * @see #setModel(ListModel)
	 */
	public void setItemList(ItemList il)
	{
		itemList = il;
		setModel(new ItemListModelWrapper(il));
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setModel(ListModel model)
	{
		if(itemList == null)
		{
			itemList = modelToItemList(model);
			super.setModel(new ItemListModelWrapper(itemList));
		}
		else
		{
			super.setModel(model);
		}
	}
	

	/**
	 * 
	 * Create a new {@link ItemList} based on the provided <code>model</code>.
	 * The data are the model's values and the item's are the model's values as
	 * {@link String}.
	 * 
	 * @param model
	 *            The {@link ListModel}
	 * 
	 * @return the new {@link ItemList}
	 */
	public ItemList modelToItemList(ListModel model)
	{
		return new ItemList(model);
	}
	

	/**
	 * Shortcut for <code>setModel(vt,itemCol,dataCol,false)</code>.
	 */
	// TODO javadoc
	public void setModel(VirtualTable vt, String itemCol, String dataCol)
	{
		setModel(vt,itemCol,dataCol,false);
	}
	

	// TODO javadoc
	public void setModel(VirtualTable vt, String itemCol, String dataCol, boolean queryData)
	{
		if(itemList != null)
		{
			try
			{
				itemList.setModel(vt,itemCol,dataCol,queryData);
			}
			catch(Exception e)
			{
				Application.getLogger().error(e);
			}
			clearSelection();
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void refresh()
	{
		support.refresh();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void updateModel(Condition condition, Object... params)
	{
		support.updateModel(condition,params);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void clearModel()
	{
		support.clearModel();
	}
	

	/**
	 * Sets the background {@link Color} of even rows.
	 * 
	 * @param evenBackground
	 *            The background of even rows as type {@link Color}.
	 */
	public void setEvenBackground(Color evenBackground)
	{
		if(!ObjectUtils.equals(this.evenBackground,evenBackground))
		{
			Object oldValue = this.evenBackground;
			this.evenBackground = evenBackground;
			firePropertyChange(EVEN_BACKGROUND_PROPERTY,oldValue,evenBackground);
		}
	}
	

	/**
	 * Returns the background {@link Color} of even rows.
	 * 
	 * @return The background of even rows as type {@link Color}.
	 */
	public Color getEvenBackground()
	{
		return evenBackground;
	}
	

	/**
	 * Sets the background {@link Color} of odd rows.
	 * 
	 * @param oddBackground
	 *            The background of odd rows as type {@link Color}.
	 */
	public void setOddBackground(Color oddBackground)
	{
		if(!ObjectUtils.equals(this.oddBackground,oddBackground))
		{
			Object oldValue = this.oddBackground;
			this.oddBackground = oddBackground;
			firePropertyChange(ODD_BACKGROUND_PROPERTY,oldValue,oddBackground);
		}
	}
	

	/**
	 * Returns the background {@link Color} of odd rows.
	 * 
	 * @return The background of odd rows as type {@link Color}.
	 */
	public Color getOddBackground()
	{
		return oddBackground;
	}
	

	/**
	 * Select all items in the {@link XdevListBox}.
	 * 
	 * @see ListSelectionModel#clearSelection()
	 * @see ListSelectionModel#setSelectionInterval(int, int)
	 */
	public void selectAll()
	{
		int size = getModel().getSize();
		if(size > 0)
		{
			getSelectionModel().clearSelection();
			getSelectionModel().setSelectionInterval(0,size);
		}
	}
	

	/**
	 * Verify if a item is selected.
	 * 
	 * @return <code>true</code> if a item is selected, otherwise
	 *         <code>false</code>.
	 */
	public boolean isSomethingSelected()
	{
		return getSelectedIndex() >= 0;
	}
	

	/**
	 * Changes the selection to be the set of indices specified by the given
	 * {@link XdevList}. Indices greater than or equal to the model size are
	 * ignored. This is a convenience method that clears the selection and then
	 * uses {@code addSelectionInterval} on the selection model to add the
	 * indices. Refer to the documentation of the selection model class being
	 * used for details on how values less than {@code 0} are handled.
	 * 
	 * @param indices
	 *            an {@link XdevList} of the indices of the cells to select,
	 *            {@code non-null}
	 * 
	 * @see #setSelectedIndices(int[])
	 */
	public void setSelectedIndices(java.util.List<Integer> indices)
	{
		int c = indices.size();
		int[] ind = new int[c];
		for(int i = 0; i < c; i++)
		{
			ind[i] = indices.get(i).intValue();
		}
		
		setSelectedIndices(ind);
	}
	

	/**
	 * Returns a {@link XdevList} of all of the selected indices, in increasing
	 * order.
	 * 
	 * @return all of the selected indices, in increasing order, or an empty
	 *         {@link XdevList} if nothing is selected
	 * 
	 */
	public XdevList<Integer> getSelectedIndicesAsList()
	{
		XdevList<Integer> list = new XdevList<Integer>();
		
		int[] si = getSelectedIndices();
		for(int i = 0; i < si.length; i++)
		{
			list.add(si[i]);
		}
		
		return list;
	}
	

	/**
	 * Returns the item for the selected value from {@link ItemList}.
	 * 
	 * @return the item for the selected value from {@link ItemList}
	 */
	public Object getSelectedItem()
	{
		return getSelectedValue();
	}
	

	/**
	 * Selects the specified item from the {@link XdevList}. The
	 * {@link XdevListBox} scroll to the selected item.
	 * 
	 * @param o
	 *            the item to select
	 * 
	 * @see #setSelectedValue(Object, boolean)
	 */
	public void setSelectedItem(Object o)
	{
		setSelectedValue(o,true);
	}
	

	/**
	 * Returns the data for the selected value from {@link ItemList}.
	 * 
	 * @return the data for the selected value from {@link ItemList}
	 */
	public Object getSelectedData()
	{
		int si = getSelectedIndex();
		return si >= 0 ? itemList.getData(si) : null;
	}
	

	/**
	 * Selects the specified data from the {@link XdevList}. If the
	 * <code>o</code> not exist at the {@link ItemList} the selection is
	 * canceled.
	 * 
	 * @param o
	 *            the data to select
	 * 
	 * @see #setSelectedIndex(int)
	 */
	public void setSelectedData(Object o)
	{
		setSelectedIndex(o == null ? -1 : itemList.indexOfData(o));
	}
	

	/**
	 * {@inheritDoc}
	 */
	public String getFormularName()
	{
		return support.getFormularName();
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void setFormularValue(VirtualTable vtRow, int col, Object value)
	{
		support.setFormularValue(vtRow,col,value);
	}
	

	/**
	 * {@inheritDoc}
	 */
	public Object getFormularValue()
	{
		return support.getFormularValue();
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void saveState()
	{
		support.saveState();
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void restoreState()
	{
		support.restoreState();
	}
	

	/**
	 * {@inheritDoc}
	 */
	public boolean isMultiSelect()
	{
		return support.isMultiSelect();
	}
	

	/**
	 * {@inheritDoc}
	 */
	public boolean verify()
	{
		return support.verify();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public VirtualTable getVirtualTable()
	{
		return itemList != null ? itemList.getVirtualTable() : null;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public VirtualTableRow getSelectedVirtualTableRow()
	{
		return support.getSelectedVirtualTableRow();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void addValueChangeListener(ValueChangeListener l)
	{
		support.addValueChangeListener(l);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setDetailHandler(DetailHandler detailHandler)
	{
		support.setDetailHandler(detailHandler);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Dimension getPreferredSize()
	{
		Dimension d = super.getPreferredSize();
		
		if(d.width < 50)
		{
			d.width = 150;
		}
		
		return d;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Dimension getPreferredScrollableViewportSize()
	{
		if(getLayoutOrientation() == JList.VERTICAL
				&& (getFixedCellWidth() <= 0 || getFixedCellHeight() <= 0)
				&& getModel().getSize() == 0)
		{
			return new Dimension(150,16 * getVisibleRowCount());
		}
		
		return super.getPreferredScrollableViewportSize();
	}
	

	/**
	 * This method is a alias for {@link #getRowAtPoint(Point)}.
	 * 
	 * @param x
	 *            the X coordinate of the row
	 * @param y
	 *            the Y coordinate of the row
	 * 
	 * @return the row index closest to the given location, or {@code -1}
	 * 
	 * 
	 * @see #locationToIndex(Point)
	 */
	public int getRowAtPoint(int x, int y)
	{
		return getRowAtPoint(new Point(x,y));
	}
	

	/**
	 * Returns the row index closest to the given location in the list's
	 * coordinate system. To determine if the row actually contains the
	 * specified location, compare the point against the cell's bounds, as
	 * provided by {@code getCellBounds}. This method returns {@code -1} if the
	 * model is empty
	 * <p>
	 * This is a cover method that delegates to the method of the same name in
	 * the list's {@code ListUI}. It returns {@code -1} if the list has no
	 * {@code ListUI}.
	 * 
	 * @param location
	 *            the coordinates of the point
	 * 
	 * @return the row index closest to the given location, or {@code -1}
	 * 
	 * @see #locationToIndex(Point)
	 */
	public int getRowAtPoint(Point location)
	{
		return locationToIndex(location);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		Object o = getSelectedItem();
		if(o != null)
		{
			return String.valueOf(o);
		}
		
		return UIUtils.toString(this);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getTabIndex()
	{
		return tabIndex;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTabIndex(int tabIndex)
	{
		if(this.tabIndex != tabIndex)
		{
			int oldValue = this.tabIndex;
			this.tabIndex = tabIndex;
			firePropertyChange(TAB_INDEX_PROPERTY,oldValue,tabIndex);
		}
	}
	


	public static class ItemListModelWrapper implements ListModel
	{
		private ItemList	itemList;
		

		public ItemListModelWrapper(ItemList itemList)
		{
			this.itemList = itemList;
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public int getSize()
		{
			return itemList.size();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Object getElementAt(int index)
		{
			return itemList.get(index);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void addListDataListener(ListDataListener l)
		{
			itemList.addListDataListener(l);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void removeListDataListener(ListDataListener l)
		{
			itemList.removeListDataListener(l);
		}
	}
	


	protected class XdevListSelectionModel extends DefaultListSelectionModel
	{
		public XdevListSelectionModel()
		{
			final ListDataListener listDataListener = new ListDataListener()
			{
				/**
				 * {@inheritDoc}
				 */
				@Override
				public void contentsChanged(ListDataEvent e)
				{
					listDataChanged();
				}
				

				/**
				 * {@inheritDoc}
				 */
				@Override
				public void intervalAdded(ListDataEvent e)
				{
					listDataChanged();
				}
				

				/**
				 * {@inheritDoc}
				 */
				@Override
				public void intervalRemoved(ListDataEvent e)
				{
					listDataChanged();
				}
				

				void listDataChanged()
				{
					try
					{
						setValueIsAdjusting(true);
						checkSelection();
					}
					finally
					{
						setValueIsAdjusting(false);
					}
				}
			};
			
			ListModel model = getModel();
			if(model != null)
			{
				model.addListDataListener(listDataListener);
			}
			
			addPropertyChangeListener("model",new PropertyChangeListener()
			{
				@Override
				public void propertyChange(PropertyChangeEvent evt)
				{
					Object o = evt.getOldValue();
					if(o instanceof ListModel)
					{
						((ListModel)o).removeListDataListener(listDataListener);
					}
					o = evt.getNewValue();
					if(o instanceof ListModel)
					{
						((ListModel)o).addListDataListener(listDataListener);
					}
				}
			});
			
			addListSelectionListener(new ListSelectionListener()
			{
				@Override
				public void valueChanged(ListSelectionEvent e)
				{
					checkSelection();
				}
			});
		}
		

		protected void checkSelection()
		{
			int[] si = getSelectedIndices();
			for(int i = si.length; --i >= 0;)
			{
				int index = si[i];
				if(!isElementSelectable(getModel().getElementAt(index)))
				{
					removeSelectionInterval(index,index);
				}
			}
		}
	}
	


	protected class XdevListCellRenderer extends DefaultListCellRenderer
	{
		/**
		 * {@inheritDoc}
		 */
		@Override
		public Component getListCellRendererComponent(JList list, Object value, int index,
				boolean isSelected, boolean cellHasFocus)
		{
			boolean selectable = isElementSelectable(value);
			if(isSelected && !selectable)
			{
				isSelected = false;
			}
			
			Icon icon = null;
			if(value instanceof Entry)
			{
				Entry entry = (Entry)value;
				value = entry.getItem();
				icon = entry.getIcon();
			}
			
			super.getListCellRendererComponent(list,value,index,isSelected,cellHasFocus);
			
			setIcon(icon);
			
			if(!isSelected)
			{
				setBackground(index % 2 == 0 ? getEvenBackground() : getOddBackground());
			}
			setOpaque(list.isOpaque());
			setEnabled(list.isEnabled() && selectable);
			
			return this;
		}
	}
	


	protected class XdevCheckBoxListCellRenderer extends JCheckBox implements ListCellRenderer
	{
		public XdevCheckBoxListCellRenderer()
		{
			super();
			setBorder(BorderFactory.createEmptyBorder(1,1,1,1));
			setOpaque(true);
		}
		

		public Component getListCellRendererComponent(JList list, Object value, int index,
				boolean isSelected, boolean cellHasFocus)
		{
			boolean selectable = isElementSelectable(value);
			if(isSelected && !selectable)
			{
				isSelected = false;
			}
			
			String text;
			Icon icon = null;
			if(value instanceof Entry)
			{
				Entry entry = (Entry)value;
				text = entry.toString();
				icon = entry.getIcon();
			}
			else if(value instanceof Icon)
			{
				text = "";
				icon = (Icon)value;
			}
			else
			{
				text = value == null ? "" : value.toString();
			}
			
			setText(text);
			setIcon(icon);
			
			setComponentOrientation(list.getComponentOrientation());
			setBackground(index % 2 == 0 ? getEvenBackground() : getOddBackground());
			setForeground(list.getForeground());
			setSelected(isSelected);
			setEnabled(list.isEnabled() && selectable);
			setFont(list.getFont());
			setOpaque(list.isOpaque());
			
			return this;
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public boolean isOpaque()
		{
			Color back = getBackground();
			Component p = getParent();
			if(p != null)
			{
				p = p.getParent();
			}
			
			boolean colorMatch = (back != null) && (p != null) && back.equals(p.getBackground())
					&& p.isOpaque();
			return !colorMatch && super.isOpaque();
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void validate()
		{
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void invalidate()
		{
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void repaint()
		{
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void revalidate()
		{
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void repaint(long tm, int x, int y, int width, int height)
		{
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void repaint(Rectangle r)
		{
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		protected void firePropertyChange(String propertyName, Object oldValue, Object newValue)
		{
			if(propertyName == "text"
					|| ((propertyName == "font" || propertyName == "foreground")
							&& oldValue != newValue && getClientProperty(javax.swing.plaf.basic.BasicHTML.propertyKey) != null))
			{
				super.firePropertyChange(propertyName,oldValue,newValue);
			}
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void firePropertyChange(String propertyName, byte oldValue, byte newValue)
		{
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void firePropertyChange(String propertyName, char oldValue, char newValue)
		{
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void firePropertyChange(String propertyName, short oldValue, short newValue)
		{
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void firePropertyChange(String propertyName, int oldValue, int newValue)
		{
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void firePropertyChange(String propertyName, long oldValue, long newValue)
		{
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void firePropertyChange(String propertyName, float oldValue, float newValue)
		{
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void firePropertyChange(String propertyName, double oldValue, double newValue)
		{
		}
		

		/**
		 * Overridden for performance reasons.
		 */
		@Override
		public void firePropertyChange(String propertyName, boolean oldValue, boolean newValue)
		{
		}
	}
	


	private class CheckableHandler extends MouseAdapter
	{
		@Override
		public void mousePressed(MouseEvent e)
		{
			if(SwingUtilities.isLeftMouseButton(e) && XdevListBox.this.isEnabled())
			{
				int index = locationToIndex(e.getPoint());
				if(index >= 0)
				{
					int selectedIndex = getSelectedIndex();
					
					if(e.isShiftDown() && selectedIndex >= 0)
					{
						if(isSelectedIndex(index))
						{
							removeSelectionInterval(Math.min(index,selectedIndex),Math.max(index,
									selectedIndex));
							
						}
						else
						{
							addSelectionInterval(Math.min(index,selectedIndex),Math.max(index,
									selectedIndex));
						}
					}
					else
					{
						if(isSelectedIndex(index))
						{
							removeSelectionInterval(index,index);
						}
						else
						{
							addSelectionInterval(index,index);
						}
					}
					
					XdevListBox.this.requestFocus();
					
					e.consume();
				}
			}
			
		}
		

		@Override
		public void mouseDragged(MouseEvent e)
		{
			e.consume();
		}
	}
}
