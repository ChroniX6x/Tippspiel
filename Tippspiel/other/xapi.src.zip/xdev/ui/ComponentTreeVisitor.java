/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.*;


/**
 * 
 * @author XDEV Software Corp.
 * 
 * @param <T>
 *            The return type
 * @param <C>
 *            The component type to visit
 */

public interface ComponentTreeVisitor<T extends Object, C extends Component>
{
	/**
	 * This method is invoked for every visitable component in the component
	 * tree hierarchy which fits the type C.
	 * 
	 * 
	 * @param cpn
	 *            The current visited component
	 * 
	 * @return a value != <code>null</code> means the visit should be ended,
	 *         <code>null</code> means the visit continues
	 */

	public T visit(C cpn);
}
