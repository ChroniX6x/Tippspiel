/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.*;
import java.awt.event.HierarchyEvent;
import java.awt.event.HierarchyListener;

import javax.swing.*;


/**
 * The standard label in XDEV. Based on {@link JLabel}.
 * 
 * @see JLabel
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevLabel extends JLabel
{
	/**
	 * 
	 */
	private static final long	serialVersionUID	= 7702329628022922856L;


	/**
	 * Creates a {@link XdevLabel} instance with no image and with an empty
	 * string for the title. The {@link XdevLabel} is centered vertically in its
	 * display area. The label's contents, once set, will be displayed on the
	 * leading edge of the label's display area.
	 */
	public XdevLabel()
	{
		super();
	}


	/**
	 * Creates a {@link XdevLabel} instance with the specified text. The
	 * {@link XdevLabel} is aligned against the leading edge of its display
	 * area, and centered vertically.
	 * 
	 * @param text
	 *            The text to be displayed by the label.
	 */
	public XdevLabel(String text)
	{
		super(text);
	}


	/**
	 * Creates a {@link XdevLabel} instance with the specified text and
	 * horizontal alignment. The {@link XdevLabel} is centered vertically in its
	 * display area.
	 * 
	 * @param text
	 *            The text to be displayed by the label.
	 * @param horizontalAlignment
	 *            One of the following constants defined in
	 *            <code>SwingConstants</code>: <code>LEFT</code>,
	 *            <code>CENTER</code>, <code>RIGHT</code>, <code>LEADING</code>
	 *            or <code>TRAILING</code>.
	 */
	public XdevLabel(String text, int horizontalAlignment)
	{
		super(text,horizontalAlignment);
	}


	/**
	 * Creates a {@link XdevLabel} instance with the specified text and icon.
	 * The {@link XdevLabel} is aligned against the leading edge of its display
	 * area, and centered vertically.
	 * 
	 * @param text
	 *            The text to be displayed by the label.
	 * 
	 * @param icon
	 *            The {@link Icon} to be displayed by the label.
	 */
	public XdevLabel(String text, Icon icon)
	{
		super(text);
		setIcon(icon);
	}


	/**
	 * Creates a {@link XdevLabel} instance with the specified image. The
	 * {@link XdevLabel} is centered vertically and horizontally in its display
	 * area.
	 * 
	 * @param image
	 *            The image to be displayed by the label.
	 */
	public XdevLabel(Icon image)
	{
		super(image);
	}


	/**
	 * Creates a {@link XdevLabel} instance with the specified image and
	 * horizontal alignment. The {@link XdevLabel} is centered vertically in its
	 * display area.
	 * 
	 * @param image
	 *            The {@link Icon} to be displayed by the label.
	 * 
	 * @param horizontalAlignment
	 *            One of the following constants defined in
	 *            <code>SwingConstants</code>: <code>LEFT</code>,
	 *            <code>CENTER</code>, <code>RIGHT</code>, <code>LEADING</code>
	 *            or <code>TRAILING</code>.
	 */
	public XdevLabel(Icon image, int horizontalAlignment)
	{
		super(image,horizontalAlignment);
	}


	/**
	 * Creates a {@link XdevLabel} instance with the specified text, image, and
	 * horizontal alignment. The {@link XdevLabel} is centered vertically in its
	 * display area. The text is on the trailing edge of the image.
	 * 
	 * @param text
	 *            The text to be displayed by the label.
	 * 
	 * @param icon
	 *            The {@link Icon} to be displayed by the label.
	 * 
	 * @param horizontalAlignment
	 *            One of the following constants defined in
	 *            <code>SwingConstants</code>: <code>LEFT</code>,
	 *            <code>CENTER</code>, <code>RIGHT</code>, <code>LEADING</code>
	 *            or <code>TRAILING</code>.
	 */
	public XdevLabel(String text, Icon icon, int horizontalAlignment)
	{
		super(text,icon,horizontalAlignment);
	}

	{
		addHierarchyListener(new HierarchyListener()
		{
			@Override
			public void hierarchyChanged(HierarchyEvent e)
			{
				Container parent = getParent();
				if(parent != null)
				{
					removeHierarchyListener(this);
					if(parent.getLayout() == null)
					{
						setSize(getPreferredSize());
					}
				}
			}
		});
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setText(String text)
	{
		super.setText(text);

		SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				Container parent = getParent();
				if(parent != null && parent.getLayout() == null)
				{
					setSize(getPreferredSize());
				}
			}
		});
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		return getText();
	}
}
