/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.*;


/**
 * @deprecated Old layout component cell, use {@link GridBagLayout} instead
 * 
 * 
 * @author XDEV Software
 * 
 */
@Deprecated
@BeanSettings(acceptChildren = true, autoPreview = true, useXdevCustomizer = true)
public class XdevLayoutCell extends XdevTextPane
{
	public final static int	FILL_NONE		= 0;
	public final static int	FILL_HORIZONTAL	= 1;
	public final static int	FILL_VERTICAL	= 2;
	public final static int	FILL_BOTH		= 3;
	
	private Insets			insets;
	private Insets			padding;
	private int				anchor			= GBC.CENTER;
	private int				fill			= FILL_BOTH;
	private int				row				= 0;
	private int				col				= 0;
	private int				rowSpan			= 1;
	private int				colSpan			= 1;
	private int				weightX			= 1;
	private int				weightY			= 1;
	Rectangle				cellRect;
	

	public XdevLayoutCell()
	{
		super();
		
		insets = new Insets(0,0,0,0);
		padding = new Insets(0,0,0,0);
		
		setLayout(new CellLayout());
	}
	

	public XdevLayoutCell(Rectangle cellRect, int row, int col, int rowSpan, int colSpan,
			int weightX, int weightY)
	{
		this();
		
		this.cellRect = cellRect;
		this.row = row;
		this.col = col;
		this.rowSpan = rowSpan;
		this.colSpan = colSpan;
		this.weightX = weightX;
		this.weightY = weightY;
	}
	

	public void setInsets(Insets insets)
	{
		this.insets = insets;
	}
	

	public void setPadding(Insets padding)
	{
		this.padding = padding;
	}
	

	public Insets getPadding()
	{
		return padding;
	}
	

	public void setAnchor(int anchor)
	{
		this.anchor = anchor;
	}
	

	public void setFill(int fill)
	{
		this.fill = fill;
	}
	

	public int getRow()
	{
		return row;
	}
	

	public int getCol()
	{
		return col;
	}
	

	public int getRowSpan()
	{
		return rowSpan;
	}
	

	public int getColSpan()
	{
		return colSpan;
	}
	

	public int getWeightX()
	{
		return weightX;
	}
	

	public int getWeightY()
	{
		return weightY;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Dimension getPreferredSize()
	{
		Dimension d = getChildPreferredSize();
		
		if(isPreferredSizeSet())
		{
			Dimension ps = super.getPreferredSize();
			if(ps.width == 0)
			{
				ps.width = d.width;
			}
			if(ps.height == 0)
			{
				ps.height = d.height;
			}
			
			d = ps;
		}
		
		d.width += insets.left + insets.right;
		d.height += insets.top + insets.bottom;
		
		d.width += padding.left + padding.right;
		d.height += padding.top + padding.bottom;
		
		return d;
	}
	
	private final static Dimension	minPrefSize	= new Dimension(10,10);
	

	public Dimension getChildPreferredSize()
	{
		Component[] children = getComponents();
		if(children.length == 1)
		{
			return children[0].getPreferredSize();
		}
		else
		{
			return minPrefSize.getSize();
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Dimension getMinimumSize()
	{
		return minPrefSize.getSize();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Dimension getMaximumSize()
	{
		return getPreferredSize();
	}
	


	private class CellLayout implements LayoutManager2
	{
		/**
		 * {@inheritDoc}
		 */
		@Override
		public void layoutContainer(Container parent)
		{
			synchronized(getTreeLock())
			{
				Dimension size = getSize();
				Rectangle place = new Rectangle(insets.left,insets.top,size.width - insets.left
						- insets.right,size.height - insets.top - insets.bottom);
				
				int c = getComponentCount();
				for(int i = 0; i < c; i++)
				{
					Component child = getComponent(i);
					Rectangle r = child.getBounds();
					Dimension ps = child.getPreferredSize();
					
					switch(fill)
					{
						case FILL_NONE:
							r.setSize(ps);
						break;
						
						case FILL_HORIZONTAL:
							r.width = Math.max(1,place.width);
							r.height = Math.min(place.height,ps.height);
						break;
						
						case FILL_VERTICAL:
							r.width = Math.min(place.width,ps.width);
							r.height = Math.max(1,place.height);
						break;
						
						case FILL_BOTH:
							r.width = Math.max(1,place.width);
							r.height = Math.max(1,place.height);
						break;
					}
					
					switch(anchor)
					{
						case GBC.CENTER:
							r.setLocation(place.x + (place.width - r.width) / 2,place.y
									+ (place.height - r.height) / 2);
						break;
						
						case GBC.NORTHEAST:
							r.setLocation(place.x + place.width - r.width,place.y);
						break;
						
						case GBC.NORTH:
							r.setLocation(place.x + (place.width - r.width) / 2,place.y);
						break;
						
						case GBC.NORTHWEST:
							r.setLocation(place.x,place.y);
						break;
						
						case GBC.EAST:
							r.setLocation(place.x + place.width - r.width,place.y
									+ (place.height - r.height) / 2);
						break;
						
						case GBC.SOUTHEAST:
							r.setLocation(place.x + place.width - r.width,place.y + place.height
									- r.height);
						break;
						
						case GBC.SOUTH:
							r.setLocation(place.x + (place.width - r.width) / 2,place.y
									+ place.height - r.height);
						break;
						
						case GBC.SOUTHWEST:
							r.setLocation(place.x,place.y + place.height - r.height);
						break;
						
						case GBC.WEST:
							r.setLocation(place.x,place.y + (place.height - r.height) / 2);
						break;
					}
					
					child.setBounds(r);
				}
			}
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void addLayoutComponent(String name, Component comp)
		{
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void addLayoutComponent(Component comp, Object constraints)
		{
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void removeLayoutComponent(Component comp)
		{
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Dimension preferredLayoutSize(Container parent)
		{
			return getPreferredSize();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Dimension minimumLayoutSize(Container parent)
		{
			int iw = insets.left + insets.right, ih = insets.top + insets.bottom;
			Dimension d = new Dimension(iw,ih);
			
			int c = getComponentCount();
			for(int i = 0; i < c; i++)
			{
				Component child = getComponent(i);
				Dimension ms = child.getMinimumSize();
				if(ms != null)
				{
					d.width = Math.max(d.width,iw + ms.width);
					d.height = Math.max(d.height,ih + ms.height);
				}
			}
			
			return d;
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Dimension maximumLayoutSize(Container target)
		{
			return null;
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void invalidateLayout(Container target)
		{
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public float getLayoutAlignmentX(Container target)
		{
			return 0.5f;
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public float getLayoutAlignmentY(Container target)
		{
			return 0.5f;
		}
	}
	
	// @Override
	// public String toString()
	// {
	// return super.toString() + "[col=" + col + ", row=" + row + ", colSpan=" +
	// colSpan
	// + ", rowSpan=" + rowSpan + "]";
	// }
}
