/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.ui;


import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.ComboBoxModel;
import javax.swing.DefaultListCellRenderer;
import javax.swing.Icon;
import javax.swing.JComboBox;
import javax.swing.JList;
import javax.swing.ListCellRenderer;
import javax.swing.MutableComboBoxModel;
import javax.swing.event.ListDataListener;

import xdev.Application;
import xdev.db.sql.Condition;
import xdev.ui.ItemList.Entry;
import xdev.util.ObjectUtils;
import xdev.vt.VirtualTable;
import xdev.vt.VirtualTable.VirtualTableRow;


/**
 * The standard combobox in XDEV. Based on {@link JComboBox}.
 * 
 * @see JComboBox
 * @see FormularComponent
 * @see ItemListOwner
 * @see XdevFocusCycleComponent
 * @see MasterDetailComponent
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevComboBox extends JComboBox implements ItemListOwner, XdevFocusCycleComponent,
		MasterDetailComponent<XdevComboBox>
{
	private ItemList		itemList;
	private String			preSelectionValue					= null;
	private Color			evenBackground						= Color.white;
	private Color			oddBackground						= Color.white;
	/**
	 * tabIndex is used to store the index for {@link XdevFocusCycleComponent}
	 * functionality.
	 */
	private int				tabIndex							= -1;
	private XdevFormular	connectedFormular;
	private boolean			connectedFormularHandlerRegistered	= false;
	


	private static class Support extends ComboBoxSupport<XdevComboBox, XdevComboBox>
	{
		private Support(XdevComboBox combo)
		{
			super(combo,combo,combo);
		}
	}
	
	private final Support	support	= new Support(this);
	

	/**
	 * Constructs a new {@link XdevComboBox}.
	 * 
	 * 
	 * @see #XdevComboBox(ItemList)
	 */
	public XdevComboBox()
	{
		this(new ItemList());
	}
	

	/**
	 * Constructs a {@link XdevComboBox} that is initialized with
	 * {@link ItemList} as the data model.<br>
	 * 
	 * @param il
	 *            the {@link ItemList} that provides the displayed and data
	 *            items
	 * 
	 * @see #setItemList(ItemList)
	 * @see #setRenderer(javax.swing.ListCellRenderer)
	 */
	public XdevComboBox(ItemList il)
	{
		super();
		setItemList(il);
		setRenderer(createListCellRenderer());
	}
	

	/**
	 * Constructs a {@link XdevComboBox} that is initialized with
	 * {@link ComboBoxModel} as the data model.<br>
	 * 
	 * @param model
	 *            the {@link ComboBoxModel} with data
	 * 
	 * @see #setModel(ComboBoxModel)
	 * @see #setRenderer(javax.swing.ListCellRenderer)
	 */
	public XdevComboBox(ComboBoxModel model)
	{
		super();
		setModel(model);
		setRenderer(createListCellRenderer());
	}
	
	{
		addItemListener(new ItemListener()
		{
			Object	oldItem	= getSelectedItem();
			

			@Override
			public void itemStateChanged(ItemEvent e)
			{
				if(e.getStateChange() == ItemEvent.SELECTED)
				{
					Object item = e.getItem();
					if(isElementSelectable(item))
					{
						oldItem = item;
					}
					else
					{
						setSelectedItem(oldItem);
					}
				}
			}
		});
	}
	

	protected boolean isElementSelectable(Object item)
	{
		if(item instanceof Entry)
		{
			return ((Entry)item).isEnabled();
		}
		
		return true;
	}
	

	protected ListCellRenderer createListCellRenderer()
	{
		return new XdevComboBoxListCellRenderer();
	}
	

	// TODO check the javadoc for accuracy
	public void setConnectedFormular(XdevFormular connectedFormular)
	{
		this.connectedFormular = connectedFormular;
		
		if(!connectedFormularHandlerRegistered)
		{
			connectedFormularHandlerRegistered = true;
			
			addActionListener(new ActionListener()
			{
				@Override
				public void actionPerformed(ActionEvent e)
				{
					if(XdevComboBox.this.connectedFormular != null)
					{
						int index = getSelectedIndex();
						VirtualTable vt = getVirtualTable();
						if(index != -1 && vt != null)
						{
							XdevComboBox.this.connectedFormular.setModel(vt.getRow(index));
						}
					}
				}
			});
		}
	}
	

	/**
	 * Returns the {@link ItemList} of this {@link XdevComboBox}.
	 * 
	 * @return the {@link ItemList}
	 */
	public ItemList getItemList()
	{
		return itemList;
	}
	

	/**
	 * Sets the {@link ItemList} and create a data model that this
	 * {@link XdevComboBox} uses to obtain the list of items.
	 * 
	 * @param il
	 *            the {@link ItemList} that provides the displayed and data
	 *            items
	 * 
	 * @see #setModel(ComboBoxModel)
	 * @see ItemListModelWrapper
	 */
	public void setItemList(ItemList il)
	{
		itemList = il;
		setModel(new ItemListModelWrapper(itemList));
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setModel(ComboBoxModel model)
	{
		if(itemList == null)
		{
			itemList = modelToItemList(model);
			super.setModel(new ItemListModelWrapper(itemList));
		}
		else
		{
			super.setModel(model);
		}
	}
	

	/**
	 * Create a new {@link ItemList} based on the provided {@link ComboBoxModel}
	 * .
	 * 
	 * @param model
	 *            The data model
	 * 
	 * @return a {@link ItemList}, the data are the model's values and the
	 *         item's are the model's values as {@link String}.
	 */
	public ItemList modelToItemList(ComboBoxModel model)
	{
		return new ItemList(model);
	}
	

	/**
	 * This method is a alias for #setModel(VirtualTable, String, String,
	 * false).
	 * 
	 */
	// TODO javadoc
	public void setModel(VirtualTable vt, String itemCol, String dataCol)
	{
		setModel(vt,itemCol,dataCol,false);
	}
	

	// TODO javadoc
	public void setModel(VirtualTable vt, String itemCol, String dataCol, boolean queryData)
	{
		if(itemList != null)
		{
			try
			{
				itemList.setModel(vt,itemCol,dataCol,queryData);
			}
			catch(Exception e)
			{
				Application.getLogger().error(e);
			}
			setSelectedItem(null);
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void refresh()
	{
		support.refresh();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void updateModel(Condition condition, Object... params)
	{
		support.updateModel(condition,params);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void clearModel()
	{
		support.clearModel();
	}
	

	/**
	 * 
	 * @param s
	 *            the {@link String} to display in this {@link XdevComboBox}
	 */
	public void setPreSelectionValue(String s)
	{
		preSelectionValue = s;
		repaint();
	}
	

	/**
	 * Sets the background {@link Color} of even rows.
	 * 
	 * @param evenBackground
	 *            the background of even rows as {@link Color}.
	 */
	public void setEvenBackground(Color evenBackground)
	{
		this.evenBackground = evenBackground;
	}
	

	/**
	 * Returns the background {@link Color} of even rows.
	 * 
	 * @return the background of even rows as {@link Color}.
	 */
	public Color getEvenBackground()
	{
		return evenBackground;
	}
	

	/**
	 * Sets the background {@link Color} of odd rows.
	 * 
	 * @param oddBackground
	 *            the background of odd rows as {@link Color}.
	 */
	public void setOddBackground(Color oddBackground)
	{
		this.oddBackground = oddBackground;
	}
	

	/**
	 * Returns the background {@link Color} of odd rows.
	 * 
	 * @return the background of odd rows as {@link Color}.
	 */
	public Color getOddBackground()
	{
		return oddBackground;
	}
	

	/**
	 * Verify if a item is selected.
	 * 
	 * @return <code>true</code> if a item is selected, otherwise
	 *         <code>false</code>.
	 */
	public boolean isSomethingSelected()
	{
		return getSelectedItem() != null;
	}
	

	/**
	 * Returns the selected data.
	 * 
	 * @return the selected data, if no data is selected <code>null</code>
	 */
	public Object getSelectedData()
	{
		int si = getSelectedIndex();
		return si >= 0 ? itemList.getData(si) : null;
	}
	

	/**
	 * Select the index of the first occurrence of the specified <code>o</code>
	 * in this list. If the {@link ItemList} of this {@link XdevComboBox} does
	 * not contain the <code>o</code>, the selection is canceled.
	 * 
	 * @param o
	 *            the {@link Object} to select
	 */
	public void setSelectedData(Object o)
	{
		setSelectedIndex(o == null ? -1 : itemList.indexOfData(o));
	}
	

	@Override
	public void setSelectedItem(Object anObject)
	{
		if(anObject == null || anObject instanceof Entry)
		{
			super.setSelectedItem(anObject);
		}
		else
		{
			int index = itemList.indexOfItem(anObject);
			if(index == -1)
			{
				super.setSelectedItem(null);
			}
			else
			{
				super.setSelectedItem(itemList.get(index));
			}
		}
	}
	

	/**
	 * Returns the selected {@link ItemList}-{@link Entry}.
	 * 
	 * @return the selected {@link ItemList}-{@link Entry}
	 */
	public Entry getSelectedEntry()
	{
		return (Entry)getSelectedItem();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getFormularName()
	{
		return support.getFormularName();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		support.setFormularValue(vt,col,value);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object getFormularValue()
	{
		return support.getFormularValue();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void saveState()
	{
		support.saveState();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void restoreState() throws IllegalArgumentException
	{
		support.restoreState();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isMultiSelect()
	{
		return support.isMultiSelect();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean verify()
	{
		return support.verify();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public VirtualTable getVirtualTable()
	{
		return itemList != null ? itemList.getVirtualTable() : null;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public VirtualTableRow getSelectedVirtualTableRow()
	{
		return support.getSelectedVirtualTableRow();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void addValueChangeListener(final ValueChangeListener l)
	{
		support.addValueChangeListener(l);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setDetailHandler(DetailHandler detailHandler)
	{
		support.setDetailHandler(detailHandler);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Dimension getPreferredSize()
	{
		Dimension d = super.getPreferredSize();
		
		if(d.width < 50)
		{
			d.width = 150;
		}
		
		return d;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		Object o = getSelectedItem();
		if(o != null)
		{
			return String.valueOf(o);
		}
		
		return UIUtils.toString(this);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getTabIndex()
	{
		return tabIndex;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTabIndex(int tabIndex)
	{
		if(this.tabIndex != tabIndex)
		{
			int oldValue = this.tabIndex;
			this.tabIndex = tabIndex;
			firePropertyChange(TAB_INDEX_PROPERTY,oldValue,tabIndex);
		}
	}
	


	public static class ItemListModelWrapper implements MutableComboBoxModel
	{
		private ItemList	itemList;
		private Object		selectedItem;
		

		public ItemListModelWrapper(final ItemList itemList)
		{
			this.itemList = itemList;
			
			if(itemList.size() > 0)
			{
				selectedItem = itemList.getItem(0);
			}
		}
		

		public void setSelectedItem(Object o)
		{
			if(!ObjectUtils.equals(selectedItem,o))
			{
				selectedItem = o;
				itemList.fireContentsChanged(-1,-1);
			}
		}
		

		public Object getSelectedItem()
		{
			return selectedItem;
		}
		

		public int getSize()
		{
			return itemList.size();
		}
		

		public Object getElementAt(int index)
		{
			return itemList.get(index);
		}
		

		public void addElement(Object obj)
		{
			itemList.add(String.valueOf(obj),obj);
		}
		

		public void insertElementAt(Object obj, int index)
		{
			itemList.add(index,String.valueOf(obj),obj);
		}
		

		public void removeElement(Object obj)
		{
			int index = itemList.indexOfItem(obj);
			if(index >= 0)
			{
				itemList.remove(index);
			}
		}
		

		public void removeElementAt(int index)
		{
			itemList.remove(index);
		}
		

		@Override
		public void addListDataListener(ListDataListener l)
		{
			itemList.addListDataListener(l);
		}
		

		@Override
		public void removeListDataListener(ListDataListener l)
		{
			itemList.removeListDataListener(l);
		}
	}
	


	protected class XdevComboBoxListCellRenderer extends DefaultListCellRenderer
	{
		@Override
		public Component getListCellRendererComponent(JList list, Object value, int index,
				boolean isSelected, boolean cellHasFocus)
		{
			boolean selectable = isElementSelectable(value);
			if(isSelected && !selectable)
			{
				isSelected = false;
			}
			
			Icon icon = null;
			if(index == -1 && getSelectedItem() == null && preSelectionValue != null)
			{
				value = preSelectionValue;
			}
			else if(value instanceof Entry)
			{
				Entry entry = (Entry)value;
				value = entry.getItem();
				icon = entry.getIcon();
			}
			
			super.getListCellRendererComponent(list,value,index,isSelected,cellHasFocus);
			
			setIcon(icon);
			
			if(!isSelected)
			{
				setBackground(index % 2 == 0 ? getEvenBackground() : getOddBackground());
			}
			
			setEnabled(selectable);
			
			return this;
		}
	}
	
	/**
	 * Workaround for a JDK bug.
	 * 
	 * 
	 * @see <a href="http://issues.xdev-software.de/view.php?id=11041">XDEV
	 *      Issue</a>
	 * @see <a
	 *      href="http://bugs.sun.com/bugdatabase/view_bug.do?bug_id=4618607">SUN
	 *      Issue</a>
	 */
	private boolean	layouting	= false;
	

	/**
	 * {@inheritDoc}
	 */
	public void doLayout()
	{
		try
		{
			layouting = true;
			super.doLayout();
		}
		finally
		{
			layouting = false;
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	public Dimension getSize()
	{
		Dimension d = super.getSize();
		if(!layouting)
		{
			d.width = Math.max(d.width,getPreferredSize().width);
		}
		return d;
	}
}
