/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import javax.swing.BoundedRangeModel;
import javax.swing.DefaultBoundedRangeModel;
import javax.swing.JProgressBar;

import xdev.vt.VirtualTable;


/**
 * The standard progress bar in XDEV. Based on {@link JProgressBar}.
 * 
 * @see FormularComponent
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevProgressBar extends JProgressBar implements FormularComponent<XdevProgressBar>
{
	private int	savedValue	= 0;


	private static class Support extends FormularComponentSupport<XdevProgressBar, XdevProgressBar>
	{
		private Support(XdevProgressBar component)
		{
			super(component,component);
		}
	}

	private final Support	support	= new Support(this);


	/**
	 * Creates a new horizontal {@link XdevProgressBar} that displays a border
	 * but no progress string. The initial and minimum values are 0, and the
	 * maximum is 100.
	 * 
	 * @see #setOrientation
	 * @see #setBorderPainted
	 * @see #setStringPainted
	 * @see #setString
	 * @see #setIndeterminate
	 */
	public XdevProgressBar()
	{
		super();
	}


	/**
	 * Creates a new {@link XdevProgressBar} with the specified orientation,
	 * which can be either {@code SwingConstants.VERTICAL} or {@code
	 * SwingConstants.HORIZONTAL}. By default, a border is painted but a
	 * progress string is not. The initial and minimum values are 0, and the
	 * maximum is 100.
	 * 
	 * @param orientation
	 *            the desired orientation of this {@link XdevProgressBar}
	 * 
	 * @throws IllegalArgumentException
	 *             if {@code orient} is an illegal value
	 * 
	 * @see #setOrientation
	 * @see #setBorderPainted
	 * @see #setStringPainted
	 * @see #setString
	 * @see #setIndeterminate
	 */
	public XdevProgressBar(int orientation) throws IllegalArgumentException
	{
		super(orientation);
	}


	/**
	 * Creates a new horizontal {@link XdevProgressBar} with the specified
	 * minimum and maximum. Sets the initial value of the
	 * {@link XdevProgressBar} to the specified minimum. By default, a border is
	 * painted but a progress string is not.
	 * <p>
	 * The <code>BoundedRangeModel</code> that holds the progress bar's data
	 * handles any issues that may arise from improperly setting the minimum,
	 * initial, and maximum values on the progress bar. See the {@code
	 * BoundedRangeModel} documentation for details.
	 * 
	 * @param min
	 *            the minimum value of this {@link XdevProgressBar}
	 * 
	 * @param max
	 *            the maximum value of this {@link XdevProgressBar}
	 * 
	 * @see BoundedRangeModel
	 * @see #setOrientation
	 * @see #setBorderPainted
	 * @see #setStringPainted
	 * @see #setString
	 * @see #setIndeterminate
	 */
	public XdevProgressBar(int min, int max)
	{
		super(min,max);
	}


	/**
	 * Creates a new {@link XdevProgressBar} using the specified orientation,
	 * minimum, and maximum. By default, a border is painted but a progress
	 * string is not. Sets the initial value of the {@link XdevProgressBar} to
	 * the specified minimum.
	 * <p>
	 * The <code>BoundedRangeModel</code> that holds the progress bar's data
	 * handles any issues that may arise from improperly setting the minimum,
	 * initial, and maximum values on the progress bar. See the {@code
	 * BoundedRangeModel} documentation for details.
	 * 
	 * @param orientation
	 *            the desired orientation of this {@link XdevProgressBar}
	 * 
	 * @param min
	 *            the minimum value of this {@link XdevProgressBar}
	 * 
	 * @param max
	 *            the maximum value of this {@link XdevProgressBar}
	 * 
	 * @throws IllegalArgumentException
	 *             if {@code orient} is an illegal value
	 * 
	 * @see BoundedRangeModel
	 * @see #setOrientation
	 * @see #setBorderPainted
	 * @see #setStringPainted
	 * @see #setString
	 * @see #setIndeterminate
	 */
	public XdevProgressBar(int orientation, int min, int max) throws IllegalArgumentException
	{
		super(orientation,min,max);
	}


	/**
	 * Creates a new horizontal {@link XdevProgressBar} that uses the specified
	 * model to hold the progress bar's data. By default, a border is painted
	 * but a progress string is not.
	 * 
	 * @param newModel
	 *            the data model for this {@link XdevProgressBar}
	 * 
	 * @see #setOrientation
	 * @see #setBorderPainted
	 * @see #setStringPainted
	 * @see #setString
	 * @see #setIndeterminate
	 */
	public XdevProgressBar(BoundedRangeModel newModel)
	{
		super(newModel);
	}


	/**
	 * Sets a new data model ({@link DefaultBoundedRangeModel}) used by the
	 * {@link XdevProgressBar}.
	 * 
	 * @param min
	 *            the {@link XdevProgressBar} minimum
	 * 
	 * @param max
	 *            the {@link XdevProgressBar} maximum
	 * 
	 * @param value
	 *            the {@link XdevProgressBar} current value
	 * 
	 * @see #setModel(BoundedRangeModel)
	 * @see DefaultBoundedRangeModel
	 */
	public void setValues(int min, int max, int value)
	{
		setModel(new DefaultBoundedRangeModel(value,0,min,max));
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getFormularName()
	{
		return support.getFormularName();
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		if(value != null)
		{
			try
			{
				setValue(Integer.parseInt(value.toString()));
			}
			catch(NumberFormatException e)
			{
				e.printStackTrace();
			}
		}
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object getFormularValue()
	{
		return new Integer(getValue());
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void saveState()
	{
		savedValue = getValue();
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void restoreState()
	{
		setValue(savedValue);
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isMultiSelect()
	{
		return false;
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean verify()
	{
		return support.verify();
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		return String.valueOf(getValue());
	}
}
