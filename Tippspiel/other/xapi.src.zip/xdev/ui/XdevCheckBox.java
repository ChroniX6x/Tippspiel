/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.ui;


import java.util.StringTokenizer;

import javax.swing.Action;
import javax.swing.Icon;
import javax.swing.JCheckBox;

import xdev.vt.VirtualTable;


/**
 * The check box in XDEV. Based on {@link JCheckBox}.
 * 
 * @see JCheckBox
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevCheckBox extends JCheckBox implements FormularComponent<XdevCheckBox>,
		XdevFocusCycleComponent
{
	private boolean	savedValue			= false;
	private String	formularValueList	= "";
	private String	trueReturnValue		= "";
	private String	falseReturnValue	= "";
	/**
	 * tabIndex is used to store the index for {@link XdevFocusCycleComponent}
	 * functionality.
	 */
	private int		tabIndex			= -1;
	


	private static class Support extends FormularComponentSupport<XdevCheckBox, XdevCheckBox>
	{
		private Support(XdevCheckBox component)
		{
			super(component,component);
		}
	}
	
	private final Support	support	= new Support(this);
	

	public XdevCheckBox()
	{
		super();
	}
	

	public XdevCheckBox(Action a)
	{
		super(a);
	}
	

	public XdevCheckBox(Icon icon, boolean selected)
	{
		super(icon,selected);
	}
	

	public XdevCheckBox(Icon icon)
	{
		super(icon);
	}
	

	public XdevCheckBox(String text, boolean selected)
	{
		super(text,selected);
	}
	

	public XdevCheckBox(String text, Icon icon, boolean selected)
	{
		super(text,icon,selected);
	}
	

	public XdevCheckBox(String text, Icon icon)
	{
		super(text,icon);
	}
	

	public XdevCheckBox(String text)
	{
		super(text);
	}
	

	/**
	 * {@inheritDoc}
	 */
	public String getFormularName()
	{
		return support.getFormularName();
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		boolean b = false;
		
		if(value != null)
		{
			String str = value.toString();
			
			if(formularValueList != null && formularValueList.length() > 0)
			{
				b = contains(formularValueList,",",str);
			}
			else
			{
				String returnValue = isSelected() ? trueReturnValue : falseReturnValue;
				if(returnValue != null && returnValue.length() > 0)
				{
					b = returnValue.equalsIgnoreCase(str);
				}
				else
				{
					b = Boolean.valueOf(str);
				}
			}
		}
		
		setSelected(b);
	}
	

	/**
	 * {@inheritDoc}
	 */
	public Object getFormularValue()
	{
		if(isSelected())
		{
			if(trueReturnValue != null && trueReturnValue.length() > 0)
			{
				return trueReturnValue;
			}
			else
			{
				return Boolean.TRUE;
			}
		}
		else
		{
			if(falseReturnValue != null && falseReturnValue != null)
			{
				return falseReturnValue;
			}
			else
			{
				return Boolean.FALSE;
			}
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void saveState()
	{
		savedValue = isSelected();
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void restoreState()
	{
		setSelected(savedValue);
	}
	

	/**
	 * {@inheritDoc}
	 */
	public boolean isMultiSelect()
	{
		return false;
	}
	

	/**
	 * {@inheritDoc}
	 */
	public boolean verify()
	{
		return support.verify();
	}
	

	public void setFormularValueList(String formularValueList)
	{
		this.formularValueList = formularValueList;
	}
	

	public String getFormularValueList()
	{
		return formularValueList;
	}
	

	public void setReturnValue(boolean selected, String value)
	{
		if(selected)
		{
			trueReturnValue = value;
		}
		else
		{
			falseReturnValue = value;
		}
	}
	

	public String getReturnValue(boolean selected)
	{
		return selected ? trueReturnValue : falseReturnValue;
	}
	

	private boolean contains(String list, String separator, String val)
	{
		StringTokenizer st = new StringTokenizer(list,separator);
		while(st.hasMoreTokens())
		{
			if(st.nextToken().equalsIgnoreCase(val))
			{
				return true;
			}
		}
		
		return false;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		Object value = getFormularValue();
		if(value != null)
		{
			String str = value.toString();
			if(str.length() > 0)
			{
				return str;
			}
		}
		
		return UIUtils.toString(this);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getTabIndex()
	{
		return tabIndex;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTabIndex(int tabIndex)
	{
		if(this.tabIndex != tabIndex)
		{
			int oldValue = this.tabIndex;
			this.tabIndex = tabIndex;
			firePropertyChange(TAB_INDEX_PROPERTY,oldValue,tabIndex);
		}
	}
}
