/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.ui;


import java.awt.Component;
import java.awt.Image;
import java.awt.Window;

import javax.swing.Icon;
import javax.swing.JFrame;
import javax.swing.WindowConstants;

import xdev.Application;


/**
 * The {@link XdevFrame} is a top-level window with a title and a border in
 * XDEV. Based on {@link JFrame}.
 * 
 * 
 * @see JFrame
 * @see XdevRootPaneContainer
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
public class XdevFrame extends JFrame implements XdevRootPaneContainer
{
	protected XdevWindow	window;
	

	/**
	 * Creates a new, initially invisible Frame.
	 * 
	 * <p>
	 * Alias for <code>XdevFrame(String title, Icon icon, String id)</code>
	 * </p>
	 * 
	 * @param window
	 *            the {@link XdevWindow} for this {@link XdevFrame}
	 * 
	 */
	public XdevFrame(XdevWindow window)
	{
		this(window.getTitle(),window.getIcon());
		
		setXdevWindow(window);
	}
	

	/**
	 * Creates a new, initially invisible Frame with the specified
	 * <code>title</code>, <code>icon</code> and <code>id</code>.
	 * 
	 * <p>
	 * Alias for <code>XdevFrame(String title, Image icon, String id)</code>
	 * </p>
	 * 
	 * @param title
	 *            the title for the frame
	 * 
	 * @param icon
	 *            the icon to be displayed as the icon for this frame
	 */
	public XdevFrame(String title, Icon icon)
	{
		this(title,icon == null ? null : GraphicUtils.createImageFromIcon(icon));
	}
	

	/**
	 * Creates a new, initially invisible Frame with the specified
	 * <code>title</code>, <code>icon</code> and <code>id</code>.
	 * 
	 * <p>
	 * This constructor sets the default close operation to
	 * {@link WindowConstants#DO_NOTHING_ON_CLOSE}.
	 * </p>
	 * 
	 * @param title
	 *            the title for the frame
	 * 
	 * @param icon
	 *            the image to be displayed as the icon for this frame
	 * 
	 */
	public XdevFrame(String title, Image icon)
	{
		super(title);
		
		if(icon == null)
		{
			setIconImage(Application.getIconImage());
		}
		else
		{
			setIconImage(icon);
		}
		
		setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
		
		setFocusTraversalPolicy(new XdevFocusTraversalPolicy(this));
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public final void setXdevWindow(XdevWindow window)
	{
		clean();
		
		this.window = window;
		window.setOwner(this);
		
		if(!isMaximized())
		{
			setBounds(window.getX(),window.getY(),window.getWidth(),window.getHeight());
		}
		
		setResizable(window.isResizable());
		setTitle(window.getTitle());
		setIconImages(Util.createImageList(window));
		setJMenuBar(window.getJMenuBar());
		getRootPane().setDefaultButton(window.getDefaultButton());
		
		setContentPane(Util.createContainer(this,window));
		
		if(window.isMinimumSizeSet())
		{
			try
			{
				setMinimumSize(window.getMinimumSize());
			}
			catch(Throwable t)
			{
			}
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public XdevWindow getXdevWindow()
	{
		return window;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Window getWindow()
	{
		return this;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setVisible(boolean b)
	{
		super.setVisible(b);
		
		if(b)
		{
			// XdevRootPaneContainer.Util.containers.put(id,this);
		}
		else
		{
			clean();
			
			// XdevRootPaneContainer.Util.containers.remove(id);
		}
	}
	

	private void clean()
	{
		try
		{
			if(window != null)
			{
				window.cleanUp();
			}
		}
		catch(Exception e)
		{
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void pack()
	{
		if(isMaximized())
		{
			invalidate();
			validate();
		}
		else
		{
			super.pack();
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setLocationRelativeTo(Component c)
	{
		if(!isMaximized())
		{
			super.setLocationRelativeTo(c);
		}
	}
	

	/**
	 * Returns <code>true</code> if this frame is maximized.
	 * 
	 * @return <code>true</code> if this frame is maximized, otherwise
	 *         <code>false</code>
	 */
	public boolean isMaximized()
	{
		switch(getExtendedState())
		{
			case MAXIMIZED_BOTH:
			case MAXIMIZED_HORIZ:
			case MAXIMIZED_VERT:
				return true;
				
			default:
				return false;
		}
	}
}
