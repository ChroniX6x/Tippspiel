/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JComboBox;

import xdev.db.sql.Condition;
import xdev.ui.MasterDetailComponent.DetailHandler;
import xdev.ui.MasterDetailComponent.ValueChangeListener;
import xdev.vt.VirtualTable;
import xdev.vt.VirtualTable.VirtualTableRow;


class ComboBoxSupport<C extends JComboBox, MDC extends MasterDetailComponent<C>> extends
		FormularComponentSupport<C, MDC>
{
	protected final C				comboBox;
	protected final MDC				masterDetailComponent;
	protected final ItemListOwner	itemListOwner;

	protected Object				savedValue	= null;
	protected DetailHandler			detailHandler;


	protected ComboBoxSupport(C comboBox, MDC masterDetailComponent, ItemListOwner itemListOwner)
	{
		super(comboBox,masterDetailComponent);

		this.comboBox = comboBox;
		this.masterDetailComponent = masterDetailComponent;
		this.itemListOwner = itemListOwner;
	}


	// *****************************************************
	// FormularComponent Support
	// *****************************************************

	public boolean isMultiSelect()
	{
		return false;
	}


	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		int index = getFormularValueIndex(value);
		if(index == -1 && detailHandler != null)
		{
			detailHandler.checkDetailView(value);
			index = getFormularValueIndex(value);
		}

		comboBox.setSelectedIndex(index);
	}


	private int getFormularValueIndex(Object value)
	{
		ItemList itemList = itemListOwner.getItemList();
		if(itemList != null && value != null)
		{
			String str = value.toString();
			for(int i = 0; i < itemList.size(); i++)
			{
				if(String.valueOf(itemList.getData(i)).equalsIgnoreCase(str))
				{
					return i;
				}
			}
		}

		return -1;
	}


	public Object getFormularValue()
	{
		ItemList itemList = itemListOwner.getItemList();
		if(itemList != null)
		{
			int i = comboBox.getSelectedIndex();
			if(i >= 0)
			{
				return itemList.getData(i);
			}
		}

		return comboBox.getSelectedItem();
	}


	public void saveState()
	{
		savedValue = comboBox.getSelectedItem();
	}


	public void restoreState()
	{
		comboBox.setSelectedItem(savedValue);
	}


	// *****************************************************
	// MasterDetailComponent Support
	// *****************************************************

	public VirtualTableRow getSelectedVirtualTableRow()
	{
		VirtualTable vt = masterDetailComponent.getVirtualTable();
		if(vt != null)
		{
			int index = comboBox.getSelectedIndex();
			if(index >= 0)
			{
				return vt.getRow(index);
			}
		}

		return null;
	}


	public void refresh()
	{
		ItemList itemList = itemListOwner.getItemList();
		if(itemList != null)
		{
			itemList.refresh();
		}
	}


	public void updateModel(Condition condition, Object... params)
	{
		component.setSelectedIndex(-1);
		ItemList itemList = itemListOwner.getItemList();
		if(itemList != null)
		{
			itemList.updateModel(condition,params);
		}
	}


	public void clearModel()
	{
		ItemList itemList = itemListOwner.getItemList();
		if(itemList != null)
		{
			itemList.clear();
		}
	}


	public void addValueChangeListener(final ValueChangeListener l)
	{
		comboBox.addActionListener(new ActionListener()
		{
			@Override
			public void actionPerformed(ActionEvent e)
			{
				l.valueChanged();
			}
		});
	}
	

	public void setDetailHandler(DetailHandler detailHandler)
	{
		this.detailHandler = detailHandler;
	}
}
