/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.Dimension;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextArea;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent;

import xdev.vt.VirtualTable;


/**
 * The standard formatted textfield in XDEV. Based on {@link JTextArea}.
 * 
 * @see ClientProperties
 * @see FormularComponent
 * @see XdevFocusCycleComponent
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevTextArea extends JTextArea implements ClientProperties,
		FormularComponent<XdevTextArea>, XdevFocusCycleComponent
{
	/**
	 * 
	 */
	private static final long	serialVersionUID	= 2915603711086126974L;

	private String				savedValue			= "";
	/**
	 * tabIndex is used to store the index for {@link XdevFocusCycleComponent}
	 * functionality.
	 */
	private int					tabIndex			= -1;


	private static class Support extends FormularComponentSupport<XdevTextArea, XdevTextArea>
	{
		private Support(XdevTextArea component)
		{
			super(component,component);
		}
	}

	private final Support	support	= new Support(this);


	/**
	 * Constructor for creating a new instance of a {@link XdevTextArea}.
	 * 
	 */
	public XdevTextArea()
	{
		this("");
	}


	/**
	 * Constructor for creating a new instance of a {@link XdevTextArea}.
	 * 
	 * @param text
	 *            the text to be displayed, <code>null</code> if none
	 * 
	 */
	public XdevTextArea(String text)
	{
		this(text,10000);
	}


	/**
	 * Constructor for creating a new instance of a {@link XdevTextArea}.
	 * 
	 * 
	 * @param maxSigns
	 *            a <code>int</code> to determine the max signs of the
	 *            {@link MaxSignDocument}
	 * 
	 * @throws IllegalArgumentException
	 *             if the <code>maxSigns</code> is <= 0
	 */
	public XdevTextArea(int maxSigns) throws IllegalArgumentException
	{
		this("",maxSigns);
	}


	/**
	 * Constructor for creating a new instance of a {@link XdevTextArea}.
	 * 
	 * @param text
	 *            the text to be displayed, <code>null</code> if none
	 * 
	 * @param maxSigns
	 *            a <code>int</code> to determine the max signs of the
	 *            {@link MaxSignDocument}
	 * 
	 * @throws IllegalArgumentException
	 *             if the <code>maxSigns</code> is <= 0
	 */
	public XdevTextArea(String text, int maxSigns) throws IllegalArgumentException
	{
		super();

		setWrapStyleWord(true);
		setLineWrap(true);

		setDocument(new MaxSignDocument(maxSigns));
		setText(text);

		addFocusListener(new FocusListener()
		{
			public void focusGained(FocusEvent e)
			{
				if(System.getProperty("xdev.selectAllOnFocus","").equals("true"))
				{
					selectAll();
				}
			}


			public void focusLost(FocusEvent e)
			{
				select(0,0);
			}
		});
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public Dimension getPreferredSize()
	{
		// Hack because JTextArea doesn't honor the set preferred size
		if(isPreferredSizeSet())
		{
			try
			{
				return UIUtils.getPrefSizeFieldValue(this);
			}
			catch(Exception e)
			{
				// Shouldn't happen
				e.printStackTrace();
			}
		}

		return super.getPreferredSize();
	}


	/**
	 * Registers the given {@link DocumentListener} to begin receiving
	 * notifications when changes are made to the document.
	 * 
	 * @param listener
	 *            the {@link DocumentListener} to register
	 * 
	 * @see Document#addDocumentListener(DocumentListener)
	 */
	public void addDocumentListener(DocumentListener listener)
	{
		getDocument().addDocumentListener(listener);
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getFormularName()
	{
		return support.getFormularName();
	}


	/**
	 * Returns the max sign count of this {@link XdevTextArea}.
	 * 
	 * 
	 * @return the max sign count of this {@link XdevTextArea}, -1 if the
	 *         {@link Document} is not an instance of {@link MaxSignDocument}.
	 * 
	 * @see MaxSignDocument
	 */
	public int getMaxSignCount()
	{
		Document doc = getDocument();
		if(doc instanceof MaxSignDocument)
		{
			return ((MaxSignDocument)doc).getMaxSignCount();
		}

		return -1;
	}


	/**
	 * Sets the max sign count of this {@link XdevTextArea}.
	 * 
	 * @param maxSignCount
	 *            the max sign count of this {@link XdevTextArea}
	 */
	public void setMaxSignCount(int maxSignCount)
	{
		Document doc = getDocument();
		if(doc instanceof MaxSignDocument)
		{
			MaxSignDocument msDoc = (MaxSignDocument)doc;
			int oldValue = msDoc.getMaxSignCount();
			if(oldValue != maxSignCount)
			{
				msDoc.setMaxSignCount(maxSignCount);
				firePropertyChange(MaxSignDocument.MAX_SIGNS_PROPERTY,oldValue,maxSignCount);
			}
		}
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		String str;
		if(vt != null)
		{
			str = vt.formatValue(value,col);
		}
		else
		{
			str = value != null ? value.toString() : "";
		}
		setText(str);
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object getFormularValue()
	{
		return getText();
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void saveState()
	{
		savedValue = getText();
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void restoreState()
	{
		setText(savedValue);
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isMultiSelect()
	{
		return false;
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean verify()
	{
		return support.verify();
	}


	/**
	 * Returns the selected text contained in this {@link XdevTextArea}. If the
	 * selection is <code>null</code> or the document empty, returns a empty
	 * {@link String}.
	 * 
	 * @return the selected text, or a empty {@link String}
	 * 
	 * @throws IllegalArgumentException
	 *             if the selection doesn't have a valid mapping into the
	 *             document for some reason
	 * 
	 * @see #setText
	 * @see JTextComponent#getSelectedText()
	 */
	@Override
	public String getSelectedText() throws IllegalArgumentException
	{
		String st = super.getSelectedText();
		if(st == null)
		{
			st = "";
		}

		return st;
	}


	/**
	 * Inserts a {@link String} into this {@link XdevTextArea}.
	 * 
	 * @param text
	 *            the {@link String} to insert
	 * 
	 * @throws IllegalArgumentException
	 *             if the caret position is not an valid position in the model
	 * 
	 * @see #getCaretPosition()
	 * @see Document#insertString(int, String, javax.swing.text.AttributeSet)
	 */
	public void insertText(String text) throws IllegalArgumentException
	{
		insert(text,getCaretPosition());
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() throws NullPointerException
	{
		return getText();
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getTabIndex()
	{
		return tabIndex;
	}


	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTabIndex(int tabIndex)
	{
		if(this.tabIndex != tabIndex)
		{
			int oldValue = this.tabIndex;
			this.tabIndex = tabIndex;
			firePropertyChange(TAB_INDEX_PROPERTY,oldValue,tabIndex);
		}
	}
}
