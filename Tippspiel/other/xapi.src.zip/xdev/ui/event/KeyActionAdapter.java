/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui.event;


import java.awt.event.*;


/**
 * Simplification of the {@link KeyListener} interface.
 * <p>
 * In this key listener adapter it is only necessary to handle one method:
 * {@link #keyActionPerformed(KeyEvent)}.
 * 
 * @author XDEV Software
 */
public abstract class KeyActionAdapter implements KeyListener
{
	private boolean	letterOrDigit	= false;
	private int		keyCode			= 0;
	

	/**
	 * {@inheritDoc}
	 */
	public void keyPressed(KeyEvent e)
	{
		if(Character.isLetterOrDigit(e.getKeyChar()))
		{
			keyCode = e.getKeyCode();
			letterOrDigit = true;
		}
		else
		{
			letterOrDigit = false;
			keyActionPerformed(e);
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void keyReleased(KeyEvent e)
	{
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void keyTyped(KeyEvent e)
	{
		if(letterOrDigit)
		{
			e.setKeyCode(keyCode);
			keyActionPerformed(e);
		}
	}
	

	/**
	 * Invoked only once when a key has been pressed or typed.
	 * 
	 * @param e
	 *            the event object
	 */
	public abstract void keyActionPerformed(KeyEvent e);
}
