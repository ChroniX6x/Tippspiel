/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import javax.swing.JComponent;

import xdev.vt.VirtualTable;


/**
 * Enables a {@link JComponent} to be used as a {@link FormularComponent}. A
 * {@link FormularComponent} provides methods that allows the
 * {@link XdevFormular} to set and read values from the component automatically.
 * 
 * @param <C>
 *            type of the implementing {@link JComponent}
 */
public interface FormularComponent<C extends JComponent>
{
	/**
	 * Returns the name of the component in the formular context.
	 * 
	 * @return the name of the component in the formular context.
	 */
	public String getFormularName();


	/**
	 * Sets the value of the component according to the provided value
	 * <code>value</code>. The value is formatted using the column format of the
	 * provided {@link VirtualTable} and <code>columnIndex</code>.
	 * 
	 * @param vt
	 *            {@link VirtualTable} to use the format from
	 * @param columnIndex
	 *            of the column to use the format from
	 * @param value
	 *            value to set
	 */
	public void setFormularValue(VirtualTable vt, int columnIndex, Object value);


	/**
	 * Returns the value of the component.
	 * 
	 * @return the value of the component.
	 */
	public Object getFormularValue();


	/**
	 * Saves the state of the component internally.
	 * <p>
	 * A saved state can be restored using {@link #restoreState()}.
	 * </p>
	 */
	public void saveState();


	/**
	 * Restores the internally saved state of the component.
	 * <p>
	 * The state of the component can be saved using {@link #saveState()}.
	 * </p>
	 */
	public void restoreState();


	/**
	 * Returns whether the component supports <i>multi selection</i> or not.
	 * 
	 * <p>
	 * A component that supports <i>multi selection</i> can have more than one
	 * selected item / value.
	 * </p>
	 * 
	 * @return <code>true</code> if the component supports <i>multi
	 *         selection</i>, <code>false</code> otherwise.
	 */
	public boolean isMultiSelect();


	/**
	 * Returns whether the component's value adheres all set constraints.
	 * 
	 * @return <code>true</code> if the value of the component adheres all set
	 *         constraints; otherwise <code>false</code>.
	 */
	public boolean verify();


	/**
	 * Determines whether this component is visible or not.
	 * 
	 * @return <code>true</code> if the component is visible, <code>false</code>
	 *         otherwise
	 */
	public boolean isVisible();


	/**
	 * Determines whether this component is enabled or not.
	 * 
	 * @return <code>true</code> if the component is enabled, <code>false</code>
	 *         otherwise
	 */
	public boolean isEnabled();
}
