/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.util.ArrayList;
import java.util.List;

import xdev.Application;
import xdev.db.DBConnection;
import xdev.db.DBException;
import xdev.db.sql.Condition;
import xdev.ui.ManyToMany.State;
import xdev.ui.event.FormularEvent;
import xdev.vt.KeyValues;
import xdev.vt.VirtualTable;
import xdev.vt.VirtualTableException;
import xdev.vt.VirtualTable.VirtualTableRow;


public class XdevNmListBox extends XdevListBox implements ManyToManyComponent
{
	private State			state;
	private VirtualTable	savedState;
	
	private VirtualTableRow masterRecord;

	public XdevNmListBox()
	{
		super(true);
	}
	

	@Override
	public void setModel(VirtualTable vt, String itemCol, String dataCol, boolean queryData)
	{
		/*
		 * Dont't use unique indices in this VT because most of the values are
		 * not used, default values will be added and
		 * UniqueIndexDoubleValuesException are thrown
		 */
		vt = vt.clone(!queryData);
		vt.setCheckUniqueIndexDoubleValues(false);
		
		super.setModel(vt,itemCol,dataCol,false);
		
		/*
		 * Don't query all the data of the nm-table, use the refresh method
		 * instead to get a reasonable result.
		 */
		if(queryData)
		{
			XdevFormular formular = UIUtils.getParentOfClass(XdevFormular.class,this);
			if(formular != null)
			{
				VirtualTable masterVT = formular.getVirtualTable();
				if(masterVT != null)
				{
					refresh(masterVT.createRow());
				}
			}
		}
	}
	

	@Override
	public void refresh(VirtualTableRow masterRecord)
	{
		try
		{
			this.masterRecord = masterRecord;
			state = new State(masterRecord,getVirtualTable());
			
			List values = new ArrayList();
			Condition condition = state.getForeignKeyValues().getCondition(values);
			updateModel(condition,values.toArray());
			VirtualTable vt = getVirtualTable(); // re-get vt after updateModel
			savedState = vt.clone(true);
			int[] indices = state.fillUpNMTable(vt,savedState);
			itemList.syncWithVT();
			setSelectedIndices(indices);
		}
		catch(Exception e)
		{
			Application.getLogger().error(e);
		}
	}
	

	@Override
	public void save(boolean synchronizeDB, DBConnection connection) throws DBException,
			VirtualTableException
	{
		VirtualTable vt = getVirtualTable();
		KeyValues foreignKeyValues = state.getForeignKeyValues();
		MasterDetail.updateForeignKeys(vt,foreignKeyValues);
		
		List<VirtualTableRow> added = new ArrayList();
		List<VirtualTableRow> changed = new ArrayList();
		List<VirtualTableRow> deleted = new ArrayList();
		
		for(int i : getSelectedIndices())
		{
			added.add(vt.getRow(i));
		}
		
		ManyToMany.getChanges(savedState,added,changed,deleted);
		
		if(synchronizeDB)
		{
			ManyToMany.synchronize(vt,added,changed,deleted,connection);
		}
		
		savedState.clear();
		for(int i : getSelectedIndices())
		{
			// re-get rows with generated keys
			savedState.addRow(vt.getRow(i),false);
		}
		state = new State(state.masterRecord,vt);
	}


	@Override
	public void formularModelChanged(FormularEvent event)
	{
	}


	@Override
	public void formularSavePerformed(FormularEvent event)
	{
		this.refresh(masterRecord);
	}
}
