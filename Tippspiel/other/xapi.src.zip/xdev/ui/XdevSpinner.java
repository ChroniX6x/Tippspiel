/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.Color;
import java.awt.Font;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.swing.JComponent;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerDateModel;
import javax.swing.SpinnerListModel;
import javax.swing.SpinnerModel;
import javax.swing.SpinnerNumberModel;

import xdev.vt.VirtualTable;


/**
 * The standard spinner in XDEV. Based on {@link JSpinner}.
 * 
 * @see JSpinner
 * @see FormularComponent
 * @see XdevFocusCycleComponent
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevSpinner extends JSpinner implements FormularComponent<XdevSpinner>,
		XdevFocusCycleComponent
{
	/**
	 * 
	 */
	private static final long	serialVersionUID	= 4670379761510929176L;
	
	private Object				savedValue			= null;
	/**
	 * tabIndex is used to store the index for {@link XdevFocusCycleComponent}
	 * functionality.
	 */
	private int					tabIndex			= -1;
	


	private static class Support extends FormularComponentSupport<XdevSpinner, XdevSpinner>
	{
		private Support(XdevSpinner component)
		{
			super(component,component);
		}
	}
	
	private final Support	support	= new Support(this);
	

	/**
	 * Constructs a {@link XdevSpinner} with an
	 * <code>Integer {@link SpinnerNumberModel}</code> with initial value 0 and
	 * no minimum or maximum limits.
	 * 
	 * @see #setModel(SpinnerModel)
	 */
	public XdevSpinner()
	{
		super();
	}
	

	/**
	 * Constructs a complete {@link XdevSpinner} with pair of next/previous
	 * buttons and an editor for the {@link SpinnerModel}.
	 * 
	 * @param model
	 *            the new {@link SpinnerModel} for this {@link XdevSpinner}
	 */
	public XdevSpinner(SpinnerModel model)
	{
		super(model);
	}
	

	/**
	 * Returns the component that displays and potentially changes the model's
	 * value.
	 * 
	 * @return the {@link JTextField} that gives the user access to the
	 *         <code>SpinnerDateModel's</code> value. If the editor is not a
	 *         <code>DefaultEditor</code>, null is returned.
	 */
	public JTextField getTextField()
	{
		JComponent editor = getEditor();
		if(editor instanceof DefaultEditor)
		{
			return ((DefaultEditor)editor).getTextField();
		}
		
		return null;
	}
	

	/**
	 * {@inheritDoc}
	 */
	public String getFormularName()
	{
		return support.getFormularName();
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		if(value != null)
		{
			SpinnerModel spinnerModel = getModel();
			if(spinnerModel instanceof SpinnerNumberModel)
			{
				if(value instanceof Number)
				{
					spinnerModel.setValue(value);
				}
				else
				{
					try
					{
						spinnerModel.setValue(Double.valueOf(value.toString()));
					}
					catch(NumberFormatException e)
					{
						e.printStackTrace();
					}
				}
			}
			else if(spinnerModel instanceof SpinnerDateModel)
			{
				if(value instanceof Date)
				{
					spinnerModel.setValue(value);
				}
				else if(value instanceof Calendar)
				{
					Date d = new Date(((Calendar)value).getTimeInMillis());
					spinnerModel.setValue(d);
				}
			}
			else
			{
				spinnerModel.setValue(value);
			}
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	public Object getFormularValue()
	{
		return getValue();
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void saveState()
	{
		savedValue = getValue();
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void restoreState()
	{
		setValue(savedValue);
	}
	

	/**
	 * {@inheritDoc}
	 */
	public boolean isMultiSelect()
	{
		return false;
	}
	

	/**
	 * {@inheritDoc}
	 */
	public boolean verify()
	{
		return support.verify();
	}
	

	/**
	 * Constructs a {@link SpinnerNumberModel} with the specified
	 * <code>value</code>, <code>minimum</code>/<code>maximum</code> bounds, and
	 * <code>stepSize</code> and changes the model that represents the value of
	 * this {@link XdevSpinner}.
	 * 
	 * 
	 * @param value
	 *            the current value of the {@link SpinnerNumberModel}
	 * 
	 * @param minimum
	 *            the first number in the sequence
	 * 
	 * @param maximum
	 *            the last number in the sequence
	 * 
	 * @param stepSize
	 *            the difference between elements of the sequence
	 * 
	 * @throws IllegalArgumentException
	 *             if the following expression is false: minimum <= value <=
	 *             maximum
	 */
	public void setNumberModel(int value, int minimum, int maximum, int stepSize)
			throws IllegalArgumentException
	{
		setModel(new SpinnerNumberModel(value,minimum,maximum,stepSize));
	}
	

	/**
	 * Constructs a {@link SpinnerListModel} whose sequence of values is defined
	 * by the specified {@link List} and changes the model that represents the
	 * value of this {@link XdevSpinner}.
	 * 
	 * @param values
	 *            the values of the {@link SpinnerListModel}
	 * 
	 * @throws IllegalArgumentException
	 *             if model is <code>null</code>
	 * 
	 * @see #getModel
	 * @see #getEditor
	 * @see #setEditor
	 * @see SpinnerListModel
	 */
	public void setListModel(java.util.List values) throws IllegalArgumentException
	{
		setModel(new SpinnerListModel(values));
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setBackground(Color bg)
	{
		super.setBackground(bg);
		
		JComponent editor = getEditor();
		if(editor instanceof DefaultEditor)
		{
			((DefaultEditor)editor).getTextField().setBackground(bg);
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setForeground(Color fg)
	{
		super.setForeground(fg);
		
		JComponent editor = getEditor();
		if(editor instanceof DefaultEditor)
		{
			((DefaultEditor)editor).getTextField().setForeground(fg);
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setFont(Font f)
	{
		super.setFont(f);
		
		JComponent editor = getEditor();
		if(editor != null)
		{
			if(editor instanceof DefaultEditor)
			{
				((DefaultEditor)editor).getTextField().setFont(f);
			}
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setOpaque(boolean b)
	{
		super.setOpaque(b);
		
		JComponent editor = getEditor();
		if(editor != null)
		{
			editor.setOpaque(b);
			
			if(editor instanceof DefaultEditor)
			{
				((DefaultEditor)editor).getTextField().setOpaque(b);
			}
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setEnabled(boolean enabled)
	{
		super.setEnabled(enabled);
		
		JComponent editor = getEditor();
		if(editor instanceof DefaultEditor)
		{
			((DefaultEditor)editor).getTextField().setEnabled(enabled);
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		return String.valueOf(getValue());
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getTabIndex()
	{
		return tabIndex;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTabIndex(int tabIndex)
	{
		if(this.tabIndex != tabIndex)
		{
			int oldValue = this.tabIndex;
			this.tabIndex = tabIndex;
			firePropertyChange(TAB_INDEX_PROPERTY,oldValue,tabIndex);
		}
	}
}
