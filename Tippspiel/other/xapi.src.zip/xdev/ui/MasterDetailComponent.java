/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import javax.swing.JComponent;

import xdev.vt.VirtualTable;
import xdev.vt.VirtualTable.VirtualTableRow;


/**
 * Extended {@link FormularComponent} which is used to display the detail
 * records for a specific master record, or to display master records and
 * control another MasterDetailComponent which displays the details.
 * <p>
 * A MasterDetailComponent can be connected to a {@link XdevFormular}:
 * 
 * <pre>
 * {@link MasterDetail#connect(MasterDetailComponent, XdevFormular)}
 * </pre>
 * 
 * or to another MasterDetailComponent:
 * 
 * <pre>
 * {@link MasterDetail#connect(MasterDetailComponent, MasterDetailComponent)}
 * </pre>
 * 
 * 
 * 
 * @author XDEV Software
 * 
 * @param <C>
 *            The implementor's type
 * 
 * @see MasterDetail
 * @see MasterDetailHandler
 */
public interface MasterDetailComponent<C extends JComponent> extends FormularComponent<C>,
		VirtualTableOwner
{
	/**
	 * Returns the selected {@link VirtualTableRow} of this component, or
	 * <code>null</code> if nothing is selected.
	 * 
	 * @return the selected {@link VirtualTableRow} of this component
	 */
	public VirtualTableRow getSelectedVirtualTableRow();
	

	/**
	 * Reloads the data from the underlying data source with the last executed
	 * resp. default query.
	 */
	public void refresh();
	

	/**
	 * Clears the underlying data model, mostly a {@link VirtualTable}, and the
	 * view.
	 */
	public void clearModel();
	

	/**
	 * Registers a {@link ValueChangeListener}.
	 * 
	 * @param l
	 *            the listener to register
	 */
	public void addValueChangeListener(ValueChangeListener l);
	


	/**
	 * Listener interface which is informed when the selection changes.
	 * 
	 * @see MasterDetailComponent#addValueChangeListener(ValueChangeListener)
	 * @see MasterDetailComponent#getSelectedVirtualTableRow()
	 */
	public static interface ValueChangeListener
	{
		/**
		 * Invoked when the selected of a {@link MasterDetailComponent} has
		 * changed.
		 * 
		 * @see MasterDetailComponent#getSelectedVirtualTableRow()
		 */
		public void valueChanged();
	}
	

	/**
	 * Sets the handler which controls the corporation of two
	 * {@link MasterDetailComponent}s.
	 * 
	 * @param detailHandler
	 *            the new {@link DetailHandler}
	 */
	public void setDetailHandler(DetailHandler detailHandler);
	


	/**
	 * Handles the detail view of a {@link MasterDetailComponent} which is used
	 * as detail of another {@link MasterDetailComponent} which is the master.
	 */
	public static interface DetailHandler
	{
		/**
		 * Adjusts the detail view according to the selected master value.
		 * 
		 * @param value
		 *            the selected primary key value of the master
		 */
		public void checkDetailView(Object value);
	}
}
