/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.ui;


import java.awt.Component;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Graphics2D;
import java.awt.HeadlessException;
import java.awt.LayoutManager;
import java.awt.Window;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.util.Locale;

import javax.swing.Icon;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JRootPane;
import javax.swing.JWindow;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;

import xdev.Application;
import xdev.lang.XDEV;
import xdev.util.res.ResourceUtils;


/**
 * The XdevWindow is a root container which can be added into a
 * {@link XdevRootPaneContainer}.
 * <p>
 * Don't confuse XdevWindow with {@link JWindow}, see {@link XdevScreen}.
 * 
 * 
 * @author XDEV Software
 * 
 * @see XdevComponent
 * @see XdevRootPaneContainer
 * @see XDEV#OpenWindow(xdev.lang.cmd.Show)
 * 
 * @since 3.0
 */
@BeanSettings(acceptChildren = true, autoPreview = true, useXdevCustomizer = true)
public class XdevWindow extends XdevComponent
{
	// private String dialogID = null;
	private String					title						= "";
	private Icon					icon						= null;
	
	private boolean					resizable					= true;
	private int						verticalScrollBarPolicy		= ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER;
	private int						horizontalScrollBarPolicy	= ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER;
	
	private JMenuBar				menuBar						= null;
	private JButton					defaultButton				= null;
	
	private XdevRootPaneContainer	owner;
	
	private Object					parameter					= null;
	private Object					responseValue				= null;
	private boolean					responseState				= false;
	
	private Component				lockPanel;
	

	/**
	 * Create a new {@link XdevWindow} with no layout manager.
	 * 
	 * <p>
	 * Alias for <code>XdevWindow(null)</code>
	 * </p>
	 * 
	 * @see #XdevWindow(LayoutManager)
	 * 
	 */
	public XdevWindow()
	{
		this(null);
	}
	

	/**
	 * Create a new {@link XdevWindow} with the specified layout manager.
	 * 
	 * @param layout
	 *            the LayoutManager to use
	 */
	public XdevWindow(LayoutManager layout)
	{
		super(layout);
	}
	

	/**
	 * Adds the specified window listener to receive window events of this
	 * {@link XdevWindow}.
	 * 
	 * 
	 * @param listener
	 *            the window listener
	 * 
	 */
	public void addWindowListener(WindowListener listener)
	{
		listenerList.add(WindowListener.class,listener);
	}
	

	// TODO javadoc
	public void fireWindowOpened(WindowEvent event)
	{
		for(WindowListener l : listenerList.getListeners(WindowListener.class))
		{
			l.windowOpened(event);
		}
	}
	

	/**
	 * Sets the owner of this window.
	 * 
	 * 
	 * @param owner
	 *            the <code>XdevRootPaneContainer</code> to set as owner
	 * 
	 * @see #getOwner()
	 */
	public void setOwner(XdevRootPaneContainer owner)
	{
		this.owner = owner;
		
		if(owner != null)
		{
			for(WindowListener l : listenerList.getListeners(WindowListener.class))
			{
				owner.addWindowListener(l);
			}
			
			// refresh lock panel
			setEnabled(isEnabled());
		}
	}
	

	/**
	 * Gets the container of this {@link XdevWindow}.
	 * 
	 * @return the owner of this {@link XdevWindow} as
	 *         <code>XdevRootPaneContainer</code>. The owner may be
	 *         <code>null</code>.
	 * 
	 * @see #setOwner(XdevRootPaneContainer)
	 */
	public XdevRootPaneContainer getOwner()
	{
		return owner;
	}
	

	/**
	 * Sets the title of the window.
	 * 
	 * @param title
	 *            the title displayed in the dialog's or frame's border; a null
	 *            value results in an empty title
	 * @see #getTitle()
	 */
	public void setTitle(String title)
	{
		this.title = title;
		
		if(owner != null)
		{
			owner.setTitle(title);
		}
	}
	

	/**
	 * Gets the title of the window. The title is displayed in the dialog's or
	 * frame's border.
	 * 
	 * @return the title of this window. The title may be <code>null</code>.
	 * 
	 * @see #setTitle(String)
	 */
	public String getTitle()
	{
		return title;
	}
	

	/**
	 * Sets the <code>menubar</code> for this window.
	 * 
	 * @param menuBar
	 *            the <code>menubar</code> being placed in the window
	 * 
	 * @see #getJMenuBar()
	 */
	public void setJMenuBar(JMenuBar menuBar)
	{
		this.menuBar = menuBar;
	}
	

	/**
	 * Returns the <code>menubar</code> set on this window.
	 * 
	 * @return the {@link JMenuBar} of this {@link XdevWindow}
	 * 
	 * @see #setJMenuBar(JMenuBar)
	 */
	public JMenuBar getJMenuBar()
	{
		return menuBar;
	}
	

	/**
	 * Sets the <code>defaultButton</code> property, which determines the
	 * current default button for this window. The default button is the button
	 * which will be activated when a UI-defined activation event (typically the
	 * <b>Enter</b> key) occurs in the root pane regardless of whether or not
	 * the button has keyboard focus (unless there is another component within
	 * the window which consumes the activation event, such as a
	 * <code>JTextPane</code>). For default activation to work, the button must
	 * be an enabled descendent of the window when activation occurs. To remove
	 * a default button from this window, set this property to <code>null</code>
	 * .
	 * 
	 * @see JButton#isDefaultButton()
	 * @param defaultButton
	 *            the {@link JButton} which is to be the default button
	 */
	public void setDefaultButton(JButton defaultButton)
	{
		this.defaultButton = defaultButton;
		
		if(owner != null)
		{
			owner.getRootPane().setDefaultButton(defaultButton);
		}
	}
	

	/**
	 * Returns the value of the <code>defaultButton</code> property.
	 * 
	 * @return the {@link JButton} which is currently the default button
	 * @see #setDefaultButton(JButton)
	 */
	public JButton getDefaultButton()
	{
		return defaultButton;
	}
	

	/**
	 * Sets the <code>parameter</code> of the window.
	 * 
	 * @param o
	 *            the <code>Object</code> to set as parameter
	 * 
	 * @see #getParameter()
	 */
	public void setParameter(Object o)
	{
		parameter = o;
	}
	

	/**
	 * Gets the <code>parameter</code> of the window.
	 * 
	 * @return the parameter of this window. The parameter may be
	 *         <code>null</code>.
	 * 
	 * @see #setParameter(Object)
	 */
	public Object getParameter()
	{
		return parameter;
	}
	

	/**
	 * Sets the <code>response value</code> of the window.
	 * 
	 * @param responseValue
	 *            the <code>Object</code> to set as response value
	 * 
	 * @see #getResponseValue()
	 */
	public void setResponseValue(Object responseValue)
	{
		this.responseValue = responseValue;
	}
	

	/**
	 * Gets the <code>response value</code> of the window.
	 * 
	 * @return the response value of this window. The response value may be
	 *         <code>null</code>.
	 * 
	 * @see #setResponseValue(Object)
	 */
	public Object getResponseValue()
	{
		return responseValue;
	}
	

	/**
	 * Sets the <code>response state</code> of the window.
	 * 
	 * @param responseState
	 *            the response state value
	 * 
	 * @see #isResponseOK()
	 */
	public void setResponseState(boolean responseState)
	{
		this.responseState = responseState;
	}
	

	/**
	 * Returns the value of the <code>responseState</code>. The default value is
	 * <code>false</code>
	 * 
	 * @return the value of the <code>responseState</code>
	 * 
	 * @see #setResponseState(boolean)
	 */
	public boolean isResponseOK()
	{
		return responseState;
	}
	

	/**
	 * @deprecated use {@link #setIcon(Icon)} instead
	 */
	// @Deprecated
	// public void setIconPath(String iconPath)
	// {
	// setIcon(UIUtils.loadIcon(iconPath));
	// }
	
	/**
	 * Defines the icon this window's parent (dialog,frame,...) will display. If
	 * the value of icon is null, nothing is displayed.
	 * 
	 * @param icon
	 *            the icon to display
	 */
	public void setIcon(Icon icon)
	{
		this.icon = icon;
	}
	

	/**
	 * Returns this window's icon.
	 * 
	 * @return an icon or <code>null</code>
	 */
	public Icon getIcon()
	{
		return icon;
	}
	

	/**
	 * Sets whether this {@link XdevWindow} is resizable by the user.
	 * 
	 * @param resizable
	 *            <code>true</code> if the user can resize this
	 *            {@link XdevWindow} ; <code>false</code> otherwise.
	 * 
	 * @see #isResizable()
	 */
	public void setResizable(boolean resizable)
	{
		this.resizable = resizable;
		
		if(owner != null)
		{
			owner.setResizable(resizable);
		}
	}
	

	/**
	 * Returns <code>true</code> if this {@link XdevWindow} is resizeable by the
	 * user.
	 * 
	 * @return <code>true</code> if the user can resize this {@link XdevWindow}
	 *         ; <code>false</code> otherwise.
	 * 
	 * @see #setResizable(boolean)
	 */
	public boolean isResizable()
	{
		return resizable;
	}
	

	/**
	 * Determines when the vertical scrollbar appears in the scrollpane. Legal
	 * values are:
	 * <ul>
	 * <li><code>ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED</code>
	 * <li><code>ScrollPaneConstants.VERTICAL_SCROLLBAR_NEVER</code>
	 * <li><code>ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS</code>
	 * </ul>
	 * 
	 * @param verticalScrollBarPolicy
	 *            one of the three values listed above
	 * 
	 * @throws IllegalArgumentException
	 *             if <code>policy</code> is not one of the legal values shown
	 *             above
	 * 
	 * @see #getVerticalScrollBarPolicy
	 */
	public void setVerticalScrollBarPolicy(int verticalScrollBarPolicy)
			throws IllegalArgumentException
	{
		this.verticalScrollBarPolicy = verticalScrollBarPolicy;
	}
	

	/**
	 * Returns the vertical scroll bar policy value.
	 * 
	 * @return the vertical scroll bar policy value
	 * 
	 * @see #setVerticalScrollBarPolicy
	 */
	public int getVerticalScrollBarPolicy()
	{
		return verticalScrollBarPolicy;
	}
	

	/**
	 * Determines when the horizontal scrollbar appears in the scrollpane. The
	 * options are:
	 * <ul>
	 * <li><code>ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED</code>
	 * <li><code>ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER</code>
	 * <li><code>ScrollPaneConstants.HORIZONTAL_SCROLLBAR_ALWAYS</code>
	 * </ul>
	 * 
	 * @param horizontalScrollBarPolicy
	 *            one of the three values listed above
	 * 
	 * @throws IllegalArgumentException
	 *             if <code>policy</code> is not one of the legal values shown
	 *             above
	 * 
	 * @see #getHorizontalScrollBarPolicy
	 */
	public void setHorizontalScrollBarPolicy(int horizontalScrollBarPolicy)
			throws IllegalArgumentException
	{
		this.horizontalScrollBarPolicy = horizontalScrollBarPolicy;
	}
	

	/**
	 * Returns the horizontal scroll bar policy value.
	 * 
	 * @return the horizontal scroll bar policy value
	 * 
	 * @see #setHorizontalScrollBarPolicy
	 */
	public int getHorizontalScrollBarPolicy()
	{
		return horizontalScrollBarPolicy;
	}
	

	/**
	 * This method indicates that the window is fully maximized (that is both
	 * horizontally and vertically).
	 * 
	 * <p>
	 * Note that if the state is not supported on a given platform, nothing will
	 * happen.
	 * </p>
	 * 
	 * @see JFrame#setExtendedState(int)
	 * @see Frame#MAXIMIZED_BOTH
	 */
	public void maximize()
	{
		if(owner instanceof JFrame)
		{
			((JFrame)owner).setExtendedState(Frame.MAXIMIZED_BOTH);
		}
	}
	

	public void pack()
	{
		if(owner != null)
		{
			owner.pack();
		}
	}
	

	/**
	 * Removes all the components from this window. This method also notifies
	 * the layout manager to remove the components from this content pane's
	 * layout via the <code>removeLayoutComponent</code> method.
	 * 
	 * @see #removeAll()
	 * @see Application#gc()
	 */
	public void cleanUp()
	{
		removeAll();
		Application.gc();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void paintImage(Graphics2D g)
	{
		Dimension d = getSize();
		paintBackground(g,0,0,d.width,d.height);
		drawTexture(g,0,0,d.width,d.height);
	}
	

	/**
	 * Returns the localized version of the given {@link String}
	 * <code>str</code>.
	 * 
	 * <P>
	 * This method is an alias for
	 * <code>ResourceUtils#optLocalizeString(str, this)</code>.
	 * <p>
	 * 
	 * @param str
	 *            to localize
	 * 
	 * @return the localized String for the given <code>str</code>.
	 * 
	 * @see Locale
	 * @see ResourceUtils#optLocalizeString(String, Object)
	 * @see ResourceUtils#optLocalizeChar(String, Object)
	 */
	public String localizeString(String str)
	{
		return ResourceUtils.optLocalizeString(str,this);
	}
	

	/**
	 * Returns the localized version of the given {@link String}
	 * <code>str</code> as char if the result is a 1-length String, '\0'
	 * otherwise.
	 * 
	 * <P>
	 * This method is an alias for
	 * <code>ResourceUtils#optLocalizeChar(str,this);</code>.
	 * <p>
	 * 
	 * @param str
	 *            to localize
	 * 
	 * @return the localized char for the given <code>str</code> or '\0'.
	 * 
	 * @see Locale
	 * @see ResourceUtils#optLocalizeString(String, Object)
	 * @see ResourceUtils#optLocalizeChar(String, Object)
	 */
	public char localizeChar(String str)
	{
		return ResourceUtils.optLocalizeChar(str,this);
	}
	

	/**
	 * Open the window in the current window.
	 * 
	 * 
	 * @param window
	 *            the {@link XdevWindow} to open
	 * 
	 */
	public void openInCurrentWindow(XdevWindow window)
	{
		XdevRootPaneContainer container = UIUtils
				.getParentOfClass(XdevRootPaneContainer.class,this);
		if(container != null)
		{
			container.setXdevWindow(window);
			container.pack();
			container.setLocationRelativeTo(null);
		}
	}
	

	/**
	 * Open the <code>window</code> in a new {@link XdevDialog}. <br>
	 * This {@link XdevWindow} is used as <code>owner</code>.
	 * 
	 * <P>
	 * This method is an alias for <code>openInDialog(window,modal,this);</code>.
	 * <p>
	 * 
	 * 
	 * @param window
	 *            the {@link XdevWindow} to open
	 * 
	 * @param modal
	 *            specifies whether dialog blocks user input to other top-level
	 *            windows when shown.
	 * 
	 * 
	 * @return the new {@link JDialog}
	 */
	public JDialog openInDialog(XdevWindow window, boolean modal)
	{
		return openInDialog(window,modal,this);
	}
	

	/**
	 * Open the <code>window</code> in a new {@link XdevDialog}.
	 * 
	 * 
	 * @param window
	 *            the {@link XdevWindow} to open
	 * 
	 * @param modal
	 *            specifies whether dialog blocks user input to other top-level
	 *            windows when shown.
	 * 
	 * @param owner
	 *            the <code>Component</code> from which the dialog is displayed
	 *            or <code>null</code> if this dialog has no owner
	 * 
	 * @return the new {@link JDialog}
	 */
	public JDialog openInDialog(XdevWindow window, boolean modal, Component owner)
	{
		XdevDialog dialog = new XdevDialog(owner,modal,window);
		dialog.pack();
		dialog.setLocationRelativeTo(null);
		dialog.setVisible(true);
		return dialog;
	}
	

	/**
	 * Open the <code>window</code> in a new {@link XdevScreen}. <br>
	 * This {@link XdevWindow} is used as <code>owner</code>.
	 * 
	 * <P>
	 * This method is an alias for <code>openInWindow(window,modal,this);</code>.
	 * <p>
	 * 
	 * @param window
	 *            the content of this window
	 * 
	 * @param modal
	 *            specifies whether window blocks user input to other top-level
	 *            windows when shown.
	 * 
	 * 
	 * @throws HeadlessException
	 *             if <code>GraphicsEnvironment.isHeadless()</code> returns
	 *             true.
	 * 
	 * @return the new {@link JWindow}
	 */
	public JWindow openInScreen(XdevWindow window, boolean modal) throws HeadlessException
	{
		return openInScreen(window,modal,this);
	}
	

	/**
	 * Open the <code>window</code> in a new {@link XdevScreen}.
	 * 
	 * @param window
	 *            the content of this window
	 * 
	 * @param modal
	 *            specifies whether window blocks user input to other top-level
	 *            windows when shown.
	 * 
	 * @param owner
	 *            component to get Window ancestor of
	 * 
	 * @throws HeadlessException
	 *             if <code>GraphicsEnvironment.isHeadless()</code> returns
	 *             true.
	 * 
	 * @return the new {@link JWindow}
	 */
	public JWindow openInScreen(XdevWindow window, boolean modal, Component owner)
			throws HeadlessException
	{
		XdevScreen screen = new XdevScreen(owner,modal,window);
		screen.pack();
		screen.setLocationRelativeTo(null);
		screen.setVisible(true);
		return screen;
	}
	

	/**
	 * Open the <code>window</code> in a new {@link XdevFrame}.
	 * 
	 * @param window
	 *            the {@link XdevWindow} to open
	 * 
	 * @return the new {@link JFrame}
	 */
	public JFrame openInFrame(XdevWindow window)
	{
		XdevFrame frame = new XdevFrame(window);
		frame.pack();
		frame.setLocationRelativeTo(null);
		frame.setVisible(true);
		return frame;
	}
	

	/**
	 * Hides this {@link XdevWindow}.
	 * 
	 * @see SwingUtilities#getWindowAncestor(Component)
	 */
	public void close()
	{
		Window w = SwingUtilities.getWindowAncestor(this);
		if(w != null)
		{
			w.setVisible(false);
		}
	}
	

	/**
	 * Gets the lock panel of the window.
	 * 
	 * @return the lock panel as <code>Component</code>
	 */
	public Component getLockPanel()
	{
		if(lockPanel == null)
		{
			lockPanel = createLockPanel();
		}
		
		return lockPanel;
	}
	

	protected Component createLockPanel()
	{
		return new LockPanel();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setEnabled(boolean enabled)
	{
		super.setEnabled(enabled);
		
		JRootPane rootPane = owner != null ? owner.getRootPane() : getRootPane();
		if(rootPane != null)
		{
			if(enabled)
			{
				rootPane.getGlassPane().setVisible(false);
				rootPane.getGlassPane().setEnabled(true);
			}
			else
			{
				rootPane.setGlassPane(getLockPanel());
				rootPane.getGlassPane().setEnabled(false);
				rootPane.getGlassPane().setVisible(true);
			}
		}
	}
}
