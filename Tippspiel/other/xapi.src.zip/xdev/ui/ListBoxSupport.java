/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.util.ArrayList;
import java.util.List;

import javax.swing.JList;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

import xdev.db.sql.Condition;
import xdev.ui.MasterDetailComponent.DetailHandler;
import xdev.ui.MasterDetailComponent.ValueChangeListener;
import xdev.vt.VirtualTable;
import xdev.vt.VirtualTable.VirtualTableRow;


class ListBoxSupport<L extends JList, MDC extends MasterDetailComponent<L>> extends
		FormularComponentSupport<L, MDC>
{
	protected final L				list;
	protected final MDC				masterDetailComponent;
	protected final ItemListOwner	itemListOwner;
	
	protected int[]					savedValue	= new int[0];
	protected DetailHandler			detailHandler;
	

	protected ListBoxSupport(L list, MDC masterDetailComponent, ItemListOwner itemListOwner)
	{
		super(list,masterDetailComponent);
		
		this.list = list;
		this.masterDetailComponent = masterDetailComponent;
		this.itemListOwner = itemListOwner;
	}
	

	// *****************************************************
	// FormularComponent Support
	// *****************************************************
	
	public boolean isMultiSelect()
	{
		return list.getSelectionMode() != ListSelectionModel.SINGLE_SELECTION;
	}
	

	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		list.clearSelection();
		
		selectFormularValue(value);
		
		if(list.isSelectionEmpty() && detailHandler != null)
		{
			detailHandler.checkDetailView(value);
			selectFormularValue(value);
		}
	}
	

	private void selectFormularValue(Object value)
	{
		ItemList itemList = itemListOwner.getItemList();
		if(itemList != null || value != null)
		{
			if(isMultiSelect())
			{
				Object[] values;
				if(value.getClass().isArray())
				{
					values = (Object[])value;
				}
				else
				{
					values = new Object[]{value};
				}
				
				for(int row = 0; row < itemList.size(); row++)
				{
					for(int i = 0; i < values.length; i++)
					{
						if(VirtualTable.equals(itemList.getData(row),values[i]))
						{
							list.addSelectionInterval(row,row);
							break;
						}
					}
				}
			}
			else
			{
				for(int row = 0; row < itemList.size(); row++)
				{
					if(VirtualTable.equals(itemList.getData(row),value))
					{
						list.addSelectionInterval(row,row);
					}
				}
			}
		}
	}
	

	public Object getFormularValue()
	{
		List values = new ArrayList();
		
		ItemList itemList = itemListOwner.getItemList();
		if(itemList != null)
		{
			int[] si = list.getSelectedIndices();
			if(si != null)
			{
				for(int i = 0; i < si.length; i++)
				{
					values.add(itemList.getData(si[i]));
				}
			}
		}
		
		if(values.size() == 0)
		{
			return null;
		}
		else if(values.size() == 1 && !isMultiSelect())
		{
			return values.get(0);
		}
		return values.toArray();
	}
	

	public void saveState()
	{
		savedValue = list.getSelectedIndices();
	}
	

	public void restoreState()
	{
		list.setSelectedIndices(savedValue);
	}
	

	// *****************************************************
	// MasterDetailComponent Support
	// *****************************************************
	
	public VirtualTableRow getSelectedVirtualTableRow()
	{
		VirtualTable vt = masterDetailComponent.getVirtualTable();
		if(vt != null)
		{
			int index = list.getSelectedIndex();
			if(index >= 0)
			{
				return vt.getRow(index);
			}
		}
		
		return null;
	}
	

	public void refresh()
	{
		ItemList itemList = itemListOwner.getItemList();
		if(itemList != null)
		{
			itemList.refresh();
		}
	}
	

	public void updateModel(Condition condition, Object... params)
	{
		component.clearSelection();
		ItemList itemList = itemListOwner.getItemList();
		if(itemList != null)
		{
			itemList.updateModel(condition,params);
		}
	}
	

	public void clearModel()
	{
		ItemList itemList = itemListOwner.getItemList();
		if(itemList != null)
		{
			itemList.clear();
		}
	}
	

	public void addValueChangeListener(final ValueChangeListener l)
	{
		list.addListSelectionListener(new ListSelectionListener()
		{
			@Override
			public void valueChanged(ListSelectionEvent e)
			{
				l.valueChanged();
			}
		});
	}
	

	public void setDetailHandler(DetailHandler detailHandler)
	{
		this.detailHandler = detailHandler;
	}
}
