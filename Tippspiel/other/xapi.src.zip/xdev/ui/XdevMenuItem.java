/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import javax.swing.*;


/**
 * The standard menu item in XDEV. Based on {@link JMenuItem}.
 * 
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
public class XdevMenuItem extends JMenuItem
{
	/**
	 * 
	 */
	private static final long	serialVersionUID	= 1155191658716015657L;
	

	/**
	 * Creates a {@link XdevMenuItem} with no set text or icon.
	 */
	public XdevMenuItem()
	{
		super();
	}
	

	/**
	 * Creates a {@link XdevMenuItem} whose properties are taken from the
	 * specified <code>Action</code>.
	 * 
	 * @param a
	 *            the action of the {@link XdevMenuItem}
	 */
	public XdevMenuItem(Action a)
	{
		super(a);
	}
	

	/**
	 * Creates a {@link XdevMenuItem} with the specified icon.
	 * 
	 * @param icon
	 *            the icon of the {@link XdevMenuItem}
	 */
	public XdevMenuItem(Icon icon)
	{
		super(icon);
	}
	

	/**
	 * Creates a {@link XdevMenuItem} with the specified text and icon.
	 * 
	 * @param text
	 *            the text of the {@link XdevMenuItem}
	 * @param icon
	 *            the icon of the {@link XdevMenuItem}
	 */
	public XdevMenuItem(String text, Icon icon)
	{
		super(text,icon);
	}
	

	/**
	 * Creates a {@link XdevMenuItem} with the specified text and keyboard
	 * mnemonic.
	 * 
	 * @param text
	 *            the text of the {@link XdevMenuItem}
	 * @param mnemonic
	 *            the keyboard mnemonic for the {@link XdevMenuItem}
	 */
	public XdevMenuItem(String text, int mnemonic)
	{
		super(text,mnemonic);
	}
	

	/**
	 * Creates a {@link XdevMenuItem} with the specified text.
	 * 
	 * @param text
	 *            the text of the {@link XdevMenuItem}
	 */
	public XdevMenuItem(String text)
	{
		super(text);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		String toString = UIUtils.toString(this);
		if(toString != null)
		{
			return toString;
		}
		
		return super.toString();
	}
}
