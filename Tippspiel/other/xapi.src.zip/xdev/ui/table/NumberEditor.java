/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui.table;


import java.awt.*;
import java.awt.event.*;
import java.text.*;

import javax.swing.*;
import javax.swing.table.*;
import javax.swing.text.*;

import xdev.vt.*;


public class NumberEditor extends JFormattedTextField implements EditorDelegate, ActionListener
{
	private TableCellEditor	editor;


	public NumberEditor()
	{
		setBorder(XdevTableEditor.DEFAULT_BORDER);
		addActionListener(this);
	}


	public void actionPerformed(ActionEvent e)
	{
		if(editor != null)
		{
			editor.stopCellEditing();
		}
	}


	@Override
	public Component getFocusComponent()
	{
		return this;
	}


	@Override
	public Component getEditorComponent(TableCellEditor editor, JTable table, Object value,
			int row, int column, VirtualTable vt, VirtualTableColumn vtColumn)
	{
		this.editor = editor;

		setFormatterFactory(new DefaultFormatterFactory(new NumberFormatter((NumberFormat)vtColumn
				.getTextFormat().getFormat())));
		try
		{
			setValue(value);
		}
		catch(Exception e)
		{
			try
			{
				setValue(new Integer(0));
			}
			catch(Exception e2)
			{
				setValue(vtColumn.getDefaultValue());
			}
		}

		setHorizontalAlignment(vtColumn != null ? vtColumn.getHorizontalAlignment()
				: SwingConstants.LEADING);

		SwingUtilities.invokeLater(new Runnable()
		{
			public void run()
			{
				selectAll();
			}
		});

		return this;
	}


	@Override
	public Object getEditorValue()
	{
		try
		{
			commitEdit();
		}
		catch(ParseException e)
		{
		}

		return getValue();
	}
	
	
	@Override
	public void editingCanceled()
	{
	}


	@Override
	public void editingStopped()
	{
	}
}
