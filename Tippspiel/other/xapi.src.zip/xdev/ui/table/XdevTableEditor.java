/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui.table;


import java.awt.Component;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.util.Date;
import java.util.EventObject;
import java.util.HashMap;
import java.util.Map;

import javax.swing.AbstractCellEditor;
import javax.swing.JTable;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.table.TableCellEditor;

import xdev.vt.VirtualTable;
import xdev.vt.VirtualTableColumn;
import xdev.vt.XdevBlob;


public class XdevTableEditor extends AbstractCellEditor implements TableCellEditor, KeyListener
{
	public static final Border						DEFAULT_BORDER;
	
	private static EditorDelegate					_defaultDelegate;
	private static EditorDelegate					_detailDelegate;
	private static Map<Class<?>, EditorDelegate>	_delegates;
	
	static
	{
		DEFAULT_BORDER = new EmptyBorder(1,1,1,1);
		
		setPublicDefaultDelegate(new DefaultEditor());
		setPublicDetailDelegate(new DetailEditor());
		
		_delegates = new HashMap();
		setPublicDelegate(Date.class,new DateEditor());
		setPublicDelegate(XdevBlob.class,new BlobEditor());
		
		BooleanEditor booleanEditor = new BooleanEditor();
		setPublicDelegate(boolean.class,booleanEditor);
		setPublicDelegate(Boolean.class,booleanEditor);
		
		NumberEditor numberEditor = new NumberEditor();
		setPublicDelegate(int.class,numberEditor);
		setPublicDelegate(Integer.class,numberEditor);
		setPublicDelegate(double.class,numberEditor);
		setPublicDelegate(Double.class,numberEditor);
	}
	

	public static void setPublicDefaultDelegate(EditorDelegate defaultDelegate)
	{
		_defaultDelegate = defaultDelegate;
	}
	

	public static void setPublicDetailDelegate(EditorDelegate detailDelegate)
	{
		_detailDelegate = detailDelegate;
	}
	

	public static void setPublicDelegate(Class<?> type, EditorDelegate delegate)
	{
		if(delegate == null)
		{
			_delegates.remove(type);
		}
		else
		{
			_delegates.put(type,delegate);
		}
	}
	
	private EditorDelegate					defaultDelegate;
	private EditorDelegate					detailDelegate;
	private Map<Class<?>, EditorDelegate>	delegates;
	private int								clickCountToStart	= 1;
	private EditorDelegate					delegate;
	

	public XdevTableEditor()
	{
		defaultDelegate = _defaultDelegate;
		detailDelegate = _detailDelegate;
		delegates = new HashMap(_delegates);
	}
	

	public void setPrivateDefaultDelegate(EditorDelegate defaultDelegate)
	{
		this.defaultDelegate = defaultDelegate;
	}
	

	public void setPrivateDetailDelegate(EditorDelegate detailDelegate)
	{
		this.detailDelegate = detailDelegate;
	}
	

	public void setPrivateDelegate(Class<?> type, EditorDelegate delegate)
	{
		if(delegate == null)
		{
			delegates.remove(type);
		}
		else
		{
			delegates.put(type,delegate);
		}
	}
	

	public int getClickCountToStart()
	{
		return clickCountToStart;
	}
	

	public void setClickCountToStart(int clickCountToStart)
	{
		this.clickCountToStart = clickCountToStart;
	}
	

	@Override
	public boolean isCellEditable(EventObject anEvent)
	{
		if(anEvent instanceof MouseEvent)
		{
			return ((MouseEvent)anEvent).getClickCount() >= clickCountToStart;
		}
		return true;
	}
	

	public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected,
			int row, int column)
	{
		column = table.convertColumnIndexToModel(column);
		
		VirtualTableColumn vtColumn = TableUtils.getVirtualTableColumn(table,column);
		VirtualTable vt = vtColumn != null ? vtColumn.getVirtualTable() : null;
		
		if(!vtColumn.isPersistent() && vtColumn.getTableColumnLink() != null
				&& detailDelegate != null)
		{
			delegate = detailDelegate;
		}
		else
		{
			Class<?> clazz = table.getModel().getColumnClass(column);
			delegate = delegates.get(clazz);
			if(delegate == null)
			{
				delegate = defaultDelegate;
			}
		}
		
		Component cpn = delegate.getEditorComponent(this,table,value,row,column,vt,vtColumn);
		delegate.getFocusComponent().addKeyListener(this);
		return cpn;
	}
	

	public Object getCellEditorValue()
	{
		return delegate.getEditorValue();
	}
	

	@Override
	public void cancelCellEditing()
	{
		delegate.getFocusComponent().removeKeyListener(this);
		delegate.editingCanceled();
		super.cancelCellEditing();
	}
	

	@Override
	public boolean stopCellEditing()
	{
		delegate.getFocusComponent().removeKeyListener(this);
		delegate.editingStopped();
		return super.stopCellEditing();
	}
	

	public void keyPressed(KeyEvent e)
	{
		if(e.getKeyCode() == KeyEvent.VK_ESCAPE)
		{
			cancelCellEditing();
		}
	}
	

	public void keyTyped(KeyEvent e)
	{
	}
	

	public void keyReleased(KeyEvent e)
	{
	}
}
