/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui.table;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.text.DateFormat;
import java.util.Date;

import javax.swing.JComponent;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.SwingConstants;

import xdev.vt.VirtualTable;
import xdev.vt.VirtualTableColumn;


public class DateRenderer extends JPanel implements RendererDelegate
{
	private JLabel	label;


	// private DropDownButton button;

	public DateRenderer()
	{
		super(new BorderLayout());

		label = new JLabel();
		// button = new DropDownButton();

		add(label,BorderLayout.CENTER);
		// add(button,BorderLayout.LINE_END);
	}


	@Override
	public void setForeground(Color fg)
	{
		if(label != null)
		{
			label.setForeground(fg);
		}
		super.setForeground(fg);
	}


	@Override
	public void setFont(Font font)
	{
		if(label != null)
		{
			label.setFont(font);
		}
		super.setFont(font);
	}


	@Override
	public JComponent getRendererComponent(JTable table, Object value, int row, int column,
			VirtualTable vt, VirtualTableColumn vtColumn, boolean editable)
	{
		if(value instanceof Date)
		{
			if(vtColumn != null)
			{
				label.setText(vtColumn.getTextFormat().format(value));
			}
			else
			{
				label.setText(DateFormat.getDateTimeInstance().format((Date)value));
			}
		}
		else
		{
			label.setText("");
		}

		label.setHorizontalAlignment(vtColumn != null ? vtColumn.getHorizontalAlignment()
				: SwingConstants.LEADING);

		// button.setVisible(editable);

		return this;
	}

	// private static class DropDownButton extends JComponent
	// {
	// @Override
	// public Dimension getPreferredSize()
	// {
	// Dimension d = super.getPreferredSize();
	// d.width = getParent().getHeight();
	// return d;
	// }
	//
	//
	// @Override
	// public void paint(Graphics g)
	// {
	// XdevDateDropDownButton.paintCalendarDropDownButton(this,g);
	// }
	// }
}
