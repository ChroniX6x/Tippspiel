/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui.text;


import java.awt.*;
import java.util.*;


class RowBox
{
	private Vector		words;
	private Rectangle	rect;
	private int			maxDescent	= 0, maxLeading = 0, c = 0;


	public RowBox(Rectangle rect)
	{
		words = new Vector();
		this.rect = rect;
	}


	public void addWord(Word w)
	{
		words.addElement(w);
		maxDescent = Math.max(maxDescent,w.maxDescent);
		maxLeading = Math.max(maxLeading,w.maxLeading);
		c++;
	}


	public Sign layout(int align, int newHeight, int row)
	{
		Sign s = null;

		try
		{
			rect.height = newHeight;

			Word w;
			int x, allwidth;

			if(align == XdevDocument.TRAILING)
			{
				w = (Word)words.elementAt(words.size() - 1);
				if(w.sign[w.sign.length - 1].isBreak())
				{
					align = XdevDocument.LEFT;
				}
			}

			switch(align)
			{
				case XdevDocument.TRAILING:
				case XdevDocument.LEFT:
					x = rect.x;
					for(int i = 0; i < c; i++)
					{
						w = (Word)words.elementAt(i);
						s = w.layout(x,rect,row,maxDescent,maxLeading,0);
						x += w.width;
					}
				break;
				case XdevDocument.RIGHT:
					x = rect.x + rect.width - 1;
					for(int i = c - 1; i >= 0; i--)
					{
						w = (Word)words.elementAt(i);
						x -= w.width;
						s = w.layout(x,rect,row,maxDescent,maxLeading,0);
					}
				break;
				case XdevDocument.CENTER:
					allwidth = 0;
					for(int i = 0; i < c; i++)
					{
						w = (Word)words.elementAt(i);
						allwidth += w.width;
					}
					x = rect.x + (rect.width - allwidth) / 2;
					for(int i = 0; i < c; i++)
					{
						w = (Word)words.elementAt(i);
						s = w.layout(x,rect,row,maxDescent,maxLeading,0);
						x += w.width;
					}
				break;
			}
		}
		catch(Exception e)
		{
		}
		finally
		{
			words.removeAllElements();
			rect = null;
		}

		return s;
	}
}
