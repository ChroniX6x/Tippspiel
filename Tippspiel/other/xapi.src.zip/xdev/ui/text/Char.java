/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui.text;


import java.awt.*;


class Char implements Sign
{
	protected char			c;
	public String			s;
	protected Color			color;
	protected Font			font;
	protected boolean		underline, switchVals;
	protected SignBounds	rect;
	protected int			ascent, descent, leading, underlineY, underlineHeight, drawY;
	protected Link			link;
	

	public Char(char c, Font font, int ascent, int descent, int leading, Color color,
			boolean underline, int underlineY, int underlineHeight)
	{
		this.c = c;
		s = new String(new char[]{c});
		this.ascent = ascent;
		this.descent = descent;
		this.leading = leading;
		this.underline = underline;
		this.underlineY = underlineY;
		this.underlineHeight = underlineHeight;
		this.font = font;
		this.color = color;
		rect = new SignBounds();
	}
	

	public boolean isTab()
	{
		return c == '\t';
	}
	

	public boolean isBreak()
	{
		return c == '\n';
	}
	

	public boolean isSpace()
	{
		return c == ' ';
	}
	

	public int getLeading()
	{
		return leading;
	}
	

	public int getDescent()
	{
		return descent;
	}
	

	public int getDrawY()
	{
		return drawY;
	}
	

	public void setDrawY(int i)
	{
		drawY = i;
	}
	

	public SignBounds getBounds()
	{
		return rect;
	}
	

	public void setLink(Link l)
	{
		link = l;
	}
	

	public Link getLink()
	{
		return link;
	}
	

	public boolean canBreak()
	{
		return c == '-' || Character.isWhitespace(c);
	}
	

	@Override
	public String toString()
	{
		return s;
	}
	

	public void addBounds(SignBounds r)
	{
		int x1 = Math.min(rect.x,r.x);
		float x2 = Math.max(rect.x + rect.width,r.x + r.width);
		int y1 = Math.min(rect.y,r.y);
		int y2 = Math.max(rect.y + rect.height,r.y + r.height);
		r.x = x1;
		r.y = y1;
		r.width = x2 - x1;
		r.height = y2 - y1;
	}
	

	public boolean equalsStyleAndRow(Sign _s)
	{
		if(_s instanceof Char)
		{
			Char s = (Char)_s;
			try
			{
				return s.font.equals(font) && s.color.equals(color) && s.underline == underline
						&& s.drawY == drawY;
			}
			catch(Exception e)
			{
				return false;
			}
		}
		
		return false;
	}
	

	public boolean equalsRow(Sign _s)
	{
		if(_s instanceof Char)
		{
			Char s = (Char)_s;
			try
			{
				return s.drawY == drawY;
			}
			catch(Exception e)
			{
				return false;
			}
		}
		
		return false;
	}
	

	public void addYdiff(int diff)
	{
		drawY += diff;
		underlineY += diff;
		rect.y += diff;
	}
}
