/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui.text;


import java.awt.*;


class SignBounds
{
	public int		x, y, height;
	public float	width;
	

	public SignBounds()
	{
		this(0,0,0,0);
	}
	

	public SignBounds(int x, int y, float width, int height)
	{
		setBounds(x,y,width,height);
	}
	

	public void setBounds(SignBounds sb)
	{
		setBounds(sb.x,sb.y,sb.width,sb.height);
	}
	

	public void setBounds(int x, int y, float width, int height)
	{
		this.x = x;
		this.y = y;
		this.width = width;
		this.height = height;
	}
	

	public Rectangle getBounds()
	{
		return new Rectangle(x,y,Math.round(width),height);
	}
}
