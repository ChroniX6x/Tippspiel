/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui.text;


import java.awt.*;


class TextImage implements Sign
{
	protected SignBounds	rect;
	protected Link			link;
	protected Image			img;
	protected String		str;
	

	public TextImage(Image img, String str)
	{
		this.img = img;
		rect = new SignBounds(0,0,img.getWidth(null),img.getHeight(null));
	}
	

	public boolean isTab()
	{
		return false;
	}
	

	public boolean isBreak()
	{
		return false;
	}
	

	public boolean canBreak()
	{
		return true;
	}
	

	public boolean isSpace()
	{
		return false;
	}
	

	public int getDrawY()
	{
		return 0;
	}
	

	public void setDrawY(int i)
	{
	}
	

	public void paint(Graphics g)
	{
		g.drawImage(img,rect.x,rect.y,null);
	}
	

	public int getDescent()
	{
		return 0;
	}
	

	public Link getLink()
	{
		return link;
	}
	

	public void setLink(Link l)
	{
		link = l;
	}
	

	public int getLeading()
	{
		return 0;
	}
	

	public SignBounds getBounds()
	{
		return rect;
	}
	

	@Override
	public String toString()
	{
		return str;
	}
	

	public boolean equalsStyleAndRow(Sign s)
	{
		return false;
	}
	

	public boolean equalsRow(Sign s)
	{
		return false;
	}
	

	public void addYdiff(int diff)
	{
		rect.y += diff;
	}
}
