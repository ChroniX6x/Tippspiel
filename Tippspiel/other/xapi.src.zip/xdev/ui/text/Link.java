/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui.text;


import java.awt.*;
import java.io.*;

import xdev.io.*;
import xdev.ui.*;


public class Link
{
	public final static int	NONE		= 0;
	public final static int	PAGELINK	= 1;
	public final static int	HYPERLILNK	= 2;
	public final static int	EMAIL		= 3;
	public final static int	FORM_SUBMIT	= 4;
	public final static int	FORM_RESET	= 5;
	
	public int				type;
	public String			page, hyperURL, hyperTarget, formURL, formTarget, mailReceiver,
			mailSubject, mailCC, mailBCC, mailText;
	

	public Link(String page)
	{
		type = PAGELINK;
		this.page = page;
	}
	

	public Link(String url, String target)
	{
		type = HYPERLILNK;
		hyperURL = url;
		hyperTarget = target;
	}
	

	public Link(String receiver, String subject, String cc, String bcc, String text)
	{
		type = EMAIL;
		mailReceiver = receiver;
		mailSubject = subject;
		mailCC = cc;
		mailBCC = bcc;
		mailText = text;
	}
	

	public Link(int type)
	{
		if(!(type == NONE || type == FORM_SUBMIT || type == FORM_RESET))
		{
			throw new IllegalArgumentException(
					"Type has to be FORM_SUBMIT, FORM_RESET or NONE, for other types use other consturctors");
		}
		
		this.type = type;
	}
	

	public void execute(Component source) throws IOException
	{
		switch(type)
		{
			case PAGELINK:
			{
				// TODO
//				UIUtils.showWindow(page);
			}
				break;
			
			case HYPERLILNK:
			{
				IOUtils.showDocument(hyperURL,hyperTarget);
			}
				break;
			
			case EMAIL:
			{
				StringBuffer mailOpt = new StringBuffer("?");
				if(mailCC.trim().length() > 0)
				{
					mailOpt.append("cc=" + mailCC + "&");
				}
				if(mailBCC.trim().length() > 0)
				{
					mailOpt.append("bcc=" + mailBCC + "&");
				}
				if(mailSubject.trim().length() > 0)
				{
					mailOpt.append("subject=" + mailSubject + "&");
				}
				if(mailText.trim().length() > 0)
				{
					mailOpt.append("body=" + mailText + "&");
				}
				mailOpt.setLength(mailOpt.length() - 1);
				StringBuffer mailStr = new StringBuffer("mailto:" + mailReceiver);
				if(mailOpt.length() > 0)
				{
					mailStr.append(mailOpt.toString());
				}
				
				IOUtils.showDocument(mailStr.toString(),null);
			}
				break;
			
			case FORM_SUBMIT:
			{
				XdevFormular formular = getFormular(source);
				if(formular != null)
				{
					formular.submit(formURL,formTarget);
				}
			}
				break;
			
			case FORM_RESET:
			{
				XdevFormular formular = getFormular(source);
				if(formular != null)
				{
					formular.reset();
				}
			}
				break;
		}
	}
	

	private XdevFormular getFormular(Component cpn)
	{
		while(cpn != null)
		{
			if(cpn instanceof XdevFormular)
			{
				return (XdevFormular)cpn;
			}
			
			cpn = cpn.getParent();
		}
		
		return null;
	}
}
