/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.Vector;

import javax.swing.DefaultRowSorter;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.ListSelectionModel;
import javax.swing.RowSorter;
import javax.swing.RowSorter.SortKey;
import javax.swing.SortOrder;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;

import xdev.db.sql.Condition;
import xdev.db.sql.SELECT;
import xdev.ui.persistence.Persistable;
import xdev.ui.table.EditorDelegate;
import xdev.ui.table.ExtendedTable;
import xdev.ui.table.XdevTableEditor;
import xdev.ui.table.XdevTableHeaderRenderer;
import xdev.ui.table.XdevTableRenderer;
import xdev.util.ObjectUtils;
import xdev.vt.VirtualTable;
import xdev.vt.VirtualTable.VirtualTableRow;
import xdev.vt.VirtualTableModel;
import xdev.vt.VirtualTableWrapper;


/**
 * The standard table in XDEV. Based on {@link JTable}.
 * 
 * @see JTable
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevTable extends JTable implements XdevFocusCycleComponent,
		MasterDetailComponent<XdevTable>, VirtualTableEditor, ExtendedTable, Persistable
{
	private static final long	serialVersionUID			= -5259133447843483181L;
	
	public final static String	VISIBLE_ROWS_PROPERTY		= "visibleRows";
	public final static String	EVEN_BACKGROUND_PROPERTY	= "evenBackground";
	public final static String	ODD_BACKGROUND_PROPERTY		= "oddBackground";
	
	public static final String	PERSISTENT_COLUMN_SEPARATOR	= "#";
	
	private boolean				editable					= true;
	private int					visibleRows					= -1;
	private Color				evenBackground				= null;
	private Color				oddBackground				= null;
	
	/**
	 * tabIndex is used to store the index for {@link XdevFocusCycleComponent}
	 * functionality.
	 */
	private int					tabIndex					= -1;
	
	/**
	 * Should the gui state be persisted? Defaults to {@code true}.
	 */
	private boolean				persistenceEnabled			= true;
	


	protected static class Support extends TableSupport<XdevTable, XdevTable>
	{
		private Support(XdevTable table)
		{
			super(table,table);
		}
	}
	
	protected final Support	support	= new Support(this);
	

	/**
	 * Constructs a default {@link XdevTable} that is initialized with a default
	 * data model, a default column model, and a default selection model.
	 * 
	 * @see JTable
	 */
	public XdevTable()
	{
		super();
		init();
	}
	

	/**
	 * Constructs a {@link XdevTable} that is initialized with
	 * {@link DefaultTableModel} as the data model, a default column model, and
	 * a default selection model. <br>
	 * The first index in the <code>Object[][]</code> array is the row index and
	 * the second is the column index.
	 * 
	 * @param data
	 *            the data of the table
	 * 
	 * @param columnNames
	 *            the names of the columns
	 * 
	 * @see JTable
	 */
	public XdevTable(Object[][] data, Object[] columnNames)
	{
		this(new DefaultTableModel(data,columnNames));
	}
	

	/**
	 * Constructs a {@link XdevTable} that is initialized with
	 * {@link DefaultTableModel} as the data model, a default column model, and
	 * a default selection model. <br>
	 * 
	 * @param data
	 *            the data of the table, a <code>Vector</code> of
	 *            <code>Vector</code>s of <code>Object</code> values
	 * 
	 * @param columnNames
	 *            <code>vector</code> containing the names of the new columns
	 */
	public XdevTable(Vector data, Vector columnNames)
	{
		this(new DefaultTableModel(data,columnNames));
	}
	

	/**
	 * Constructs a {@link XdevTable} that is initialized with
	 * <code>model</code> as the data model, a default column model, and a
	 * default selection model.
	 * 
	 * @param model
	 *            the data model for the table
	 * 
	 * @see JTable
	 */
	public XdevTable(TableModel model)
	{
		super(model);
		init();
	}
	

	private void init()
	{
		getTableHeader().setReorderingAllowed(true);
		// getSelectionModel().addListSelectionListener(this);
		
		putClientProperty("terminateEditOnFocusLost",Boolean.TRUE);
		
		JTableHeader header = getTableHeader();
		if(header != null)
		{
			header.setDefaultRenderer(new XdevTableHeaderRenderer(this));
		}
		
		setDefaultRenderer(new XdevTableRenderer());
		setDefaultEditor(new XdevTableEditor());
	}
	

	/**
	 * Sets the <code>data</code> and <code>columnNames</code> for this
	 * {@link XdevTable}.
	 * 
	 * @param data
	 *            the data of the table. <b>NOTE:</b> The first index in the
	 *            Object[][] array is the row index and the second is the column
	 *            index.
	 * 
	 * @param columnNames
	 *            the names of the columns
	 */
	public void setData(Object[][] data, Object[] columnNames)
	{
		setModel(new DefaultTableModel(data,columnNames));
	}
	

	/**
	 * Sets the <code>data</code> and <code>columnNames</code> for this
	 * {@link XdevTable}.
	 * 
	 * @param data
	 *            the data of the table, a <code>Vector</code> of
	 *            <code>Vector</code>s of <code>Object</code> values
	 * @param columnNames
	 *            <code>vector</code> containing the names of the new columns
	 */
	public void setData(Vector data, Vector columnNames)
	{
		setModel(new DefaultTableModel(data,columnNames));
	}
	

	/**
	 * @deprecated use {@link #setModel(TableModel)} instead
	 */
	// @Deprecated
	// public void setData(VirtualTable vt)
	// {
	// setModel(vt);
	// }
	
	/**
	 * @deprecated use {@link #setModel(VirtualTable)} instead
	 */
	// @Deprecated
	// public void fillFrom(VirtualTable vt)
	// {
	// setModel(vt);
	// }
	
	/**
	 * Add a {@link ListSelectionListener} to the list that's notified each time
	 * a change to the selection occurs.
	 * 
	 * @param listener
	 *            the ListSelectionListener
	 * 
	 * @see #removeListSelectionListener(ListSelectionListener)
	 */
	public void addListSelectionListener(ListSelectionListener listener)
	{
		getSelectionModel().addListSelectionListener(listener);
	}
	

	/**
	 * Remove a listener from the {@link ListSelectionModel} that's notified
	 * each time a change to the selection occurs.
	 * 
	 * @param listener
	 *            the {@link ListSelectionListener}
	 * 
	 * @see #addListSelectionListener(ListSelectionListener)
	 */
	public void removeListSelectionListener(ListSelectionListener listener)
	{
		getSelectionModel().removeListSelectionListener(listener);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setModel(VirtualTable vt)
	{
		support.setModel(vt);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setModel(VirtualTable vt, String columns, boolean queryData)
	{
		support.setModel(vt,columns,queryData);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setModel(VirtualTable vt, String columns, SELECT select, Object... params)
	{
		support.setModel(vt,columns,select,params);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void refresh()
	{
		support.refresh();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void updateModel(Condition condition, Object... params)
	{
		support.updateModel(condition,params);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void clearModel()
	{
		support.clearModel();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setVisibleRowCount(int visibleRows)
	{
		if(this.visibleRows != visibleRows)
		{
			int oldValue = this.visibleRows;
			this.visibleRows = visibleRows;
			firePropertyChange(VISIBLE_ROWS_PROPERTY,oldValue,visibleRows);
			revalidate();
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getVisibleRowCount()
	{
		return visibleRows;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setEvenBackground(Color evenBackground)
	{
		if(!ObjectUtils.equals(this.evenBackground,evenBackground))
		{
			Object oldValue = this.evenBackground;
			this.evenBackground = evenBackground;
			firePropertyChange(EVEN_BACKGROUND_PROPERTY,oldValue,evenBackground);
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Color getEvenBackground()
	{
		return evenBackground;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setOddBackground(Color oddBackground)
	{
		if(!ObjectUtils.equals(this.oddBackground,oddBackground))
		{
			Object oldValue = this.oddBackground;
			this.oddBackground = oddBackground;
			firePropertyChange(ODD_BACKGROUND_PROPERTY,oldValue,oddBackground);
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Color getOddBackground()
	{
		return oddBackground;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getTabIndex()
	{
		return tabIndex;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTabIndex(int tabIndex)
	{
		if(this.tabIndex != tabIndex)
		{
			int oldValue = this.tabIndex;
			this.tabIndex = tabIndex;
			firePropertyChange(TAB_INDEX_PROPERTY,oldValue,tabIndex);
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void exportCSV(Writer writer) throws IOException
	{
		support.exportCSV(writer);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void exportCSV(Writer writer, char delimiter) throws IOException
	{
		support.exportCSV(writer,delimiter);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public synchronized void exportCSV(Writer writer, char delimiter, boolean withColumnNames)
			throws IOException
	{
		support.exportCSV(writer,delimiter,withColumnNames);
	}
	

	protected String exportCSV_getColumnName(TableColumn column)
	{
		return support.exportCSV_getColumnName(column);
	}
	

	protected String exportCSV_getValue(Object value, int row, int col)
	{
		return support.exportCSV_getValue(value,row,col);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getFormularName()
	{
		return support.getFormularName();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		support.setFormularValue(vt,col,value);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object getFormularValue()
	{
		return support.getFormularValue();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void saveState()
	{
		support.saveState();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void restoreState()
	{
		support.restoreState();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isMultiSelect()
	{
		return support.isMultiSelect();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean verify()
	{
		return support.verify();
	}
	

	/**
	 * Returns the {@link VirtualTable} that provides the data displayed by this
	 * {@link XdevTable}.
	 * 
	 * @return a {@link VirtualTable} that provides the data of this
	 *         {@link XdevTable}.<br>
	 *         If the {@link TableModel} isn�t a {@link VirtualTableWrapper}
	 *         <code>null</code> is returned.
	 */
	@Override
	public VirtualTable getVirtualTable()
	{
		VirtualTableWrapper wrapper = getVirtualTableWrapper();
		if(wrapper != null)
		{
			return wrapper.getVirtualTable();
		}
		
		return null;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public VirtualTableWrapper getVirtualTableWrapper()
	{
		TableModel model = getModel();
		if(model instanceof VirtualTableWrapper)
		{
			return (VirtualTableWrapper)model;
		}
		
		return null;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void addValueChangeListener(ValueChangeListener l)
	{
		support.addValueChangeListener(l);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setDetailHandler(DetailHandler detailHandler)
	{
		support.setDetailHandler(detailHandler);
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void clear()
	{
		setModel(new DefaultTableModel());
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isEditable()
	{
		return editable;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setEditable(boolean editable)
	{
		if(this.editable != editable)
		{
			boolean oldValue = this.editable;
			this.editable = editable;
			firePropertyChange(EDITABLE_PROPERTY,oldValue,editable);
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isCellEditable(int row, int column)
	{
		return isEditable() && super.isCellEditable(row,column);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	protected void addImpl(Component comp, Object constraints, int index)
	{
		super.addImpl(comp,constraints,index);
		
		if(comp instanceof EditorDelegate)
		{
			((EditorDelegate)comp).getFocusComponent().requestFocus();
		}
	}
	

	/**
	 * {@inheritDoc}
	 * 
	 */
	@Override
	public void setModel(TableModel dataModel)
	{
		super.setModel(dataModel);
		
		setRowSorter(new TableRowSorter<TableModel>(dataModel));
		
		checkColumnProperties();
	}
	

	protected void checkColumnProperties()
	{
		VirtualTableWrapper wrapper = getVirtualTableWrapper();
		if(wrapper != null)
		{
			VirtualTable vt = wrapper.getVirtualTable();
			if(vt != null)
			{
				TableModel model = getModel();
				int cc = model.getColumnCount();
				for(int c = 0; c < cc; c++)
				{
					TableColumn column = getColumnModel().getColumn(c);
					int width = vt.getPreferredColWidth(wrapper.viewToModelColumn(c),
							getTableHeader(),c);
					column.setPreferredWidth(width);
					column.setWidth(width);
				}
			}
		}
	}
	

	/**
	 * Clears all previous set renderers and registers <code>renderer</code> as
	 * default renderer for <code>Object.class</code>, which makes it the
	 * default renderer as long as no other renderer is set for a specific
	 * column class.
	 * 
	 * @param renderer
	 *            the new default renderer
	 * @see #setDefaultRenderer(Class, TableCellRenderer)
	 * @see TableColumn#setCellRenderer(TableCellRenderer)
	 */
	public void setDefaultRenderer(TableCellRenderer renderer)
	{
		defaultRenderersByColumnClass.clear();
		setDefaultRenderer(Object.class,renderer);
	}
	

	/**
	 * Clears all previous set editors and registers <code>editor</code> as
	 * default editor for <code>Object.class</code>, which makes it the default
	 * editor as long as no other editor is set for a specific column class.
	 * 
	 * @param editor
	 *            the new default editor
	 * @see #setDefaultEditor(Class, TableCellEditor)
	 * @see TableColumn#setCellEditor(TableCellEditor)
	 */
	public void setDefaultEditor(TableCellEditor editor)
	{
		defaultEditorsByColumnClass.clear();
		setDefaultEditor(Object.class,editor);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isSomethingSelected()
	{
		return support.isSomethingSelected();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getSelectedModelRow() throws IndexOutOfBoundsException
	{
		return support.getSelectedModelRow();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int[] getSelectedModelRows() throws IndexOutOfBoundsException
	{
		return support.getSelectedModelRows();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public VirtualTableRow getSelectedVirtualTableRow()
	{
		return support.getSelectedVirtualTableRow();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public VirtualTableRow[] getSelectedVirtualTableRows()
	{
		return support.getSelectedVirtualTableRows();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setSelectedModelRow(int row) throws IndexOutOfBoundsException,
			IllegalArgumentException
	{
		support.setSelectedModelRow(row);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setSelectedModelRows(int[] rows) throws IndexOutOfBoundsException,
			IllegalArgumentException
	{
		support.setSelectedModelRows(rows);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setSelectedModelRows(int start, int end)
	{
		support.setSelectedModelRows(start,end);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setSelectedRows(int[] indices)
	{
		support.setSelectedRows(indices);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getRowAtPoint(int x, int y) throws IndexOutOfBoundsException
	{
		return support.getRowAtPoint(x,y);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getRowAtPoint(Point location) throws IndexOutOfBoundsException
	{
		return support.getRowAtPoint(location);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getColumnAtPoint(int x, int y)
	{
		return support.getColumnAtPoint(x,y);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getColumnAtPoint(Point location)
	{
		return support.getColumnAtPoint(location);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setColumnWidth(int index, int width)
	{
		support.setColumnWidth(index,width);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setColumnTitle(int index, String title)
	{
		support.setColumnTitle(index,title);
	}
	

	/**
	 * {@inheritDoc}
	 */
	public boolean getScrollableTracksViewportHeight()
	{
		if(getParent() instanceof JViewport)
		{
			return getParent().getHeight() > getPreferredSize().height;
		}
		return false;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Dimension getPreferredScrollableViewportSize()
	{
		Dimension d = super.getPreferredScrollableViewportSize();
		if(visibleRows > 0)
		{
			d.height = visibleRows * getRowHeight();
		}
		
		return d;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		String toString = UIUtils.toString(this);
		if(toString != null)
		{
			return toString;
		}
		
		return super.toString();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void loadPersistentState(String persistentState)
	{
		String[] persistentColumns = persistentState.split(PERSISTENT_COLUMN_SEPARATOR);
		String[][] persistentColumnValues = new String[persistentColumns.length][];
		for(int i = 0; i < persistentColumns.length; i++)
		{
			String[] persistentValues = persistentColumns[i].split(Persistable.VALUE_SEPARATOR);
			persistentColumnValues[i] = persistentValues;
		}
		
		TableColumnModel columnModel = this.getColumnModel();
		for(int i = 0; i < persistentColumnValues.length; i++)
		{
			String[] persistentValues = persistentColumnValues[i];
			for(int j = 0; j < columnModel.getColumnCount(); j++)
			{
				TableColumn column = columnModel.getColumn(j);
				Object identifier = column.getIdentifier();
				if(identifier.equals(persistentValues[0]))
				{
					
					column.setPreferredWidth(Integer.parseInt(persistentValues[1]));
					
					int currentIndex = columnModel.getColumnIndex(column.getIdentifier());
					int newIndex = Integer.parseInt(persistentValues[2]);
					columnModel.moveColumn(currentIndex,newIndex);
					
					if(persistentValues.length > 3)
					{
						int sortOrderOrdinal = Integer.parseInt(persistentValues[3]);
						SortOrder sortOrder = SortOrder.values()[sortOrderOrdinal];
						int modelIndex = column.getModelIndex();
						DefaultRowSorter<?, ?> sorter = ((DefaultRowSorter<?, ?>)this
								.getRowSorter());
						List<SortKey> sortKeys = new ArrayList<SortKey>();
						sortKeys.add(new SortKey(modelIndex,sortOrder));
						sorter.setSortKeys(sortKeys);
						sorter.sort();
					}
					break;
				}
			}
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String savePersistentState()
	{
		StringBuilder persistentState = new StringBuilder();
		
		TableColumnModel columnModel = this.getColumnModel();
		
		for(int i = 0; i < columnModel.getColumnCount(); i++)
		{
			if(i != 0)
			{
				persistentState.append(PERSISTENT_COLUMN_SEPARATOR);
			}
			TableColumn column = columnModel.getColumn(i);
			persistentState.append(column.getIdentifier()); // position 0 for
															// identifier
			persistentState.append(Persistable.VALUE_SEPARATOR);
			persistentState.append(column.getWidth()); // position 1 for width
			persistentState.append(Persistable.VALUE_SEPARATOR);
			persistentState.append(columnModel.getColumnIndex(column.getIdentifier())); // position
																						// 2
																						// for
																						// index
			
			int modelIndex = column.getModelIndex();
			RowSorter<?> rowSorter = this.getRowSorter();
			List<?> sortKeys = rowSorter.getSortKeys();
			
			if(!sortKeys.isEmpty())
			{
				SortKey sortKey = (SortKey)sortKeys.get(0);
				if(sortKey.getColumn() == modelIndex)
				{
					persistentState.append(Persistable.VALUE_SEPARATOR);
					persistentState.append("" + sortKey.getSortOrder().ordinal()); // position
																					// 3
																					// for
																					// sortorder
				}
			}
		}
		
		return persistentState.toString();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getPersistentId()
	{
		return this.getName();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isPersistenceEnabled()
	{
		return persistenceEnabled;
	}
	

	/**
	 * Sets the persistenceEnabled flag.
	 * 
	 * @param persistenceEnabled
	 *            the state for this instance
	 */
	public void setPersistenceEnabled(boolean persistenceEnabled)
	{
		this.persistenceEnabled = persistenceEnabled;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void ensureCellIsVisible(int rowIndex, int columnIndex)
	{
		this.support.ensureCellIsVisible(rowIndex,columnIndex);
		
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void ensureRowIsVisible(int rowIndex)
	{
		this.support.ensureRowIsVisible(rowIndex);
		
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void ensureColumnIsVisible(int columnIndex)
	{
		this.ensureColumnIsVisible(columnIndex);
		
	}
	

	/**
	 * Creates a Virtual Table from the currently displayed values of this
	 * supported table.
	 * <p>
	 * The generated Virtual Table has the same order of columns and rows as
	 * currently displayed in the view.
	 * </p>
	 * <p>
	 * The supported table must have a referenced VirtualTable
	 * {@link VirtualTableModel} for this method to work)
	 * </p>
	 * 
	 * @return a {@link VirtualTable} representing the currently displayed
	 *         results of the table
	 * @throws IllegalStateException
	 *             if the supported table is not based on a VirtualTableModel or
	 *             if a new VirtualTable could not be created.
	 */
	public VirtualTable createSubsettedVirtualTable()
	{
		return support.createSubsettedVirtualTable();
	}
}
