/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

import javax.swing.JTextField;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent;

import xdev.ui.text.TextFormat;
import xdev.util.DateFormatException;
import xdev.util.Settings;
import xdev.util.XdevDate;
import xdev.vt.VirtualTable;


/**
 * The standard date textfield in XDEV. Based on {@link JTextField}.
 * 
 * @see JTextField
 * @see ClientProperties
 * @see FormattedFormularComponent
 * @see XdevFocusCycleComponent
 * @see DatePopupOwner
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevDateTextField extends JTextField implements ClientProperties,
		FormattedFormularComponent<XdevDateTextField>, DatePopupOwner, XdevFocusCycleComponent
{
	DatePopup						datePopup;
	private DatePopupCustomizer		datePopupCustomizer;
	private TextFormat				textFormat;
	private XdevDateDropDownButton	dropDownButton;
	private boolean					dropDownButtonVisible	= true;
	private String					savedValue				= "";
	/**
	 * tabIndex is used to store the index for {@link XdevFocusCycleComponent}
	 * functionality.
	 */
	private int						tabIndex				= -1;
	


	private static class Support extends
			FormularComponentSupport<XdevDateTextField, XdevDateTextField>
	{
		private Support(XdevDateTextField component)
		{
			super(component,component);
		}
	}
	
	private final Support	support	= new Support(this);
	

	/**
	 * Constructor for creating a new instance of a {@link XdevDateTextField}.
	 * Initialized with default {@link TextFormat}.
	 */
	public XdevDateTextField()
	{
		this(TextFormat.getDateInstance());
	}
	

	/**
	 * Constructor for creating a new instance of a {@link XdevDateTextField}.
	 * Initialized with the specified <code>textFormat</code>.
	 * 
	 * @param textFormat
	 *            the {@link TextFormat} to format the display value,
	 *            <code>null</code> if none
	 */
	public XdevDateTextField(TextFormat textFormat)
	{
		this("",textFormat);
	}
	

	/**
	 * Constructor for creating a new instance of a {@link XdevDateTextField}.
	 * Initialized with the specified <code>text</code>, <code>textFormat</code>
	 * and the default <code>maxSigns</code> of <code>100</code>.
	 * 
	 * @param text
	 *            the text to be displayed, <code>null</code> if none
	 * 
	 * @param textFormat
	 *            the {@link TextFormat} to format the display value,
	 *            <code>null</code> if none
	 * 
	 */
	public XdevDateTextField(String text, TextFormat textFormat)
	{
		this(text,100,textFormat);
	}
	

	/**
	 * Constructor for creating a new instance of a {@link XdevDateTextField}.
	 * Initialized with the specified <code>maxSigns</code> and
	 * <code>textFormat</code>.
	 * 
	 * 
	 * @param maxSigns
	 *            a <code>int</code> to determine the max signs of the
	 *            {@link MaxSignDocument}
	 * 
	 * @param textFormat
	 *            the {@link TextFormat} to format the display value,
	 *            <code>null</code> if none
	 * 
	 * @throws IllegalArgumentException
	 *             if the <code>maxSigns</code> is <= 0
	 */
	public XdevDateTextField(int maxSigns, TextFormat textFormat) throws IllegalArgumentException
	{
		this("",maxSigns,textFormat);
	}
	

	/**
	 * Constructor for creating a new instance of a {@link XdevDateTextField}.
	 * Initialized with the specified <code>text</code>, <code>maxSigns</code>
	 * and <code>textFormat</code>.
	 * 
	 * @param text
	 *            the text to be displayed, <code>null</code> if none
	 * 
	 * @param maxSigns
	 *            a <code>int</code> to determine the max signs of the
	 *            {@link MaxSignDocument}
	 * 
	 * @param textFormat
	 *            the {@link TextFormat} to format the display value,
	 *            <code>null</code> if none
	 * 
	 * @throws IllegalArgumentException
	 *             if the <code>maxSigns</code> is <= 0
	 */
	public XdevDateTextField(String text, int maxSigns, TextFormat textFormat)
			throws IllegalArgumentException
	{
		super();
		
		setTextFormat(textFormat);
		
		setDocument(new MaxSignDocument(maxSigns));
		setText(text);
		
		init();
	}
	

	// TODO javadoc
	public XdevDateTextField(XdevDate value, TextFormat textFormat)
	{
		this(value,100,textFormat);
	}
	

	// TODO javadoc
	public XdevDateTextField(XdevDate value, int maxSigns, TextFormat textFormat)
			throws IllegalArgumentException
	{
		super();
		
		setTextFormat(textFormat);
		
		setDocument(new MaxSignDocument(maxSigns));
		if(value != null)
		{
			setText(textFormat.format(value));
		}
		
		init();
	}
	

	private void init()
	{
		addFocusListener(new FocusListener()
		{
			public void focusGained(FocusEvent e)
			{
				if(Settings.checkUserSetting(System.getProperty("xdev.selectAllOnFocus","")))
				{
					selectAll();
				}
			}
			

			public void focusLost(FocusEvent e)
			{
				select(0,0);
				
				if(datePopup != null)
				{
					hideDatePopup();
				}
			}
		});
		
		dropDownButton = createDropDownButton();
		
		addKeyListener(new KeyAdapter()
		{
			@Override
			public void keyPressed(KeyEvent e)
			{
				if(e.getKeyCode() == KeyEvent.VK_ESCAPE && datePopup != null)
				{
					hideDatePopup();
				}
			}
		});
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Dimension getPreferredSize()
	{
		// Hack because JTextField doesn't honor the set preferred size
		if(isPreferredSizeSet())
		{
			try
			{
				return UIUtils.getPrefSizeFieldValue(this);
			}
			catch(Exception e)
			{
				// Shouldn't happen
				e.printStackTrace();
			}
		}
		
		return super.getPreferredSize();
	}
	

	// TODO javadoc
	protected XdevDateDropDownButton createDropDownButton()
	{
		XdevDateDropDownButton dropDownButton = new XdevDateDropDownButton(this);
		dropDownButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		dropDownButton.setVisible(isVisible() && dropDownButtonVisible);
		return dropDownButton;
	}
	

	/**
	 * Gets the {@link XdevDateDropDownButton} of this {@link XdevDateTextField}
	 * .
	 * 
	 * @return the {@link XdevDateDropDownButton} of this
	 *         {@link XdevDateTextField}
	 * 
	 */
	public XdevDateDropDownButton getDropDownButton()
	{
		return dropDownButton;
	}
	

	// TODO javadoc
	public void setDropDownButtonVisible(boolean b)
	{
		dropDownButtonVisible = b;
		if(dropDownButton != null)
		{
			dropDownButton.setVisible(b);
		}
	}
	

	// TODO javadoc
	public XComponent createPanel()
	{
		XComponent pnl = new XComponent(new BorderLayout());
		pnl.add(this,BorderLayout.CENTER);
		pnl.add(dropDownButton,BorderLayout.EAST);
		return pnl;
	}
	

	/**
	 * Sets the {@link DatePopupCustomizer} of this {@link XdevDateTextField}.
	 * 
	 * @param datePopupCustomizer
	 *            a {@link DatePopupCustomizer} to be set.
	 * 
	 */
	public void setDatePopupCustomizer(DatePopupCustomizer datePopupCustomizer)
	{
		this.datePopupCustomizer = datePopupCustomizer;
	}
	

	/**
	 * Gets the {@link DatePopupCustomizer} of this {@link XdevDateTextField}.
	 * 
	 * @return the {@link DatePopupCustomizer} of this {@link XdevDateTextField}
	 * 
	 */
	@Override
	public DatePopupCustomizer getDatePopupCustomizer()
	{
		return datePopupCustomizer;
	}
	

	/**
	 * Registers the given {@link DocumentListener} to begin receiving
	 * notifications when changes are made to the document.
	 * 
	 * @param listener
	 *            the {@link DocumentListener} to register
	 * 
	 * @see Document#addDocumentListener(DocumentListener)
	 */
	public void addDocumentListener(DocumentListener listener)
	{
		getDocument().addDocumentListener(listener);
	}
	

	/**
	 * Returns the max sign count of this {@link XdevDateTextField}.
	 * 
	 * 
	 * @return the max sign count of this {@link XdevDateTextField}, -1 if the
	 *         {@link Document} is not an instance of {@link MaxSignDocument}.
	 * 
	 * @see MaxSignDocument
	 */
	public int getMaxSignCount()
	{
		Document doc = getDocument();
		if(doc instanceof MaxSignDocument)
		{
			return ((MaxSignDocument)doc).getMaxSignCount();
		}
		
		return -1;
	}
	

	/**
	 * Sets the max sign count of this {@link XdevDateTextField}.
	 * 
	 * @param maxSignCount
	 *            the max sign count of this {@link XdevDateTextField}
	 */
	public void setMaxSignCount(int maxSignCount)
	{
		Document doc = getDocument();
		if(doc instanceof MaxSignDocument)
		{
			MaxSignDocument msDoc = (MaxSignDocument)doc;
			int oldValue = msDoc.getMaxSignCount();
			if(oldValue != maxSignCount)
			{
				msDoc.setMaxSignCount(maxSignCount);
				firePropertyChange(MaxSignDocument.MAX_SIGNS_PROPERTY,oldValue,maxSignCount);
			}
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getFormularName()
	{
		return support.getFormularName();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		String str = value != null ? value.toString() : "";
		
		boolean useVTFormat = true;
		if(textFormat != null && textFormat.getType() != TextFormat.PLAIN)
		{
			str = textFormat.format(value);
			useVTFormat = false;
		}
		
		if(useVTFormat && vt != null)
		{
			str = vt.formatValue(value,col);
		}
		
		setText(str);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object getFormularValue()
	{
		try
		{
			return getDate();
		}
		catch(DateFormatException e)
		{
			return null;
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void saveState()
	{
		savedValue = getText();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void restoreState()
	{
		setText(savedValue);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isMultiSelect()
	{
		return false;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean verify()
	{
		return support.verify();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setCursor(Cursor c)
	{
		super.setCursor(c);
		
		if(dropDownButton != null)
		{
			dropDownButton.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setVisible(boolean flag)
	{
		if(!flag && datePopup != null)
		{
			hideDatePopup();
		}
		
		if(dropDownButton != null)
		{
			dropDownButton.setVisible(flag);
		}
		
		super.setVisible(flag);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setEnabled(boolean enabled)
	{
		if(!enabled && datePopup != null)
		{
			hideDatePopup();
		}
		
		if(dropDownButton != null)
		{
			dropDownButton.setEnabled(enabled);
		}
		
		super.setEnabled(enabled);
	}
	

	// TODO javadoc
	public void setDatePopupVisible(boolean b)
	{
		if(b)
		{
			datePopup = DatePopup.getInstance(this);
			datePopup.showPopup(this);
		}
		else
		{
			hideDatePopup();
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public TextFormat getTextFormat()
	{
		return textFormat;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTextFormat(TextFormat textFormat)
	{
		this.textFormat = textFormat;
	}
	

	/**
	 * Get this {@link XdevDateTextField}.
	 * 
	 * @return this {@link XdevDateTextField} as {@link Component}
	 * 
	 */
	@Override
	public Component getComponentForDatePopup()
	{
		return this;
	}
	

	/**
	 * {@inheritDoc}
	 */
	public void hideDatePopup()
	{
		datePopup.hidePopup();
		datePopup = null;
	}
	

	/**
	 * Returns the selected text contained in this {@link XdevDateTextField}. If
	 * the selection is <code>null</code> or the document empty, returns a empty
	 * {@link String}.
	 * 
	 * @return the selected text, or a empty {@link String}
	 * 
	 * @throws IllegalArgumentException
	 *             if the selection doesn't have a valid mapping into the
	 *             document for some reason
	 * 
	 * @see #setText
	 * @see JTextComponent#getSelectedText()
	 */
	@Override
	public String getSelectedText() throws IllegalArgumentException
	{
		String st = super.getSelectedText();
		if(st == null)
		{
			st = "";
		}
		
		return st;
	}
	

	/**
	 * Inserts a {@link String} into this {@link XdevDateTextField}.
	 * 
	 * @param text
	 *            the {@link String} to insert
	 * 
	 * @see Document#insertString(int, String, javax.swing.text.AttributeSet)
	 */
	public void insertText(String text)
	{
		try
		{
			getDocument().insertString(getCaretPosition(),text,null);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	

	/**
	 * 
	 * Returns the value of this {@link XdevDateTextField} as {@link XdevDate}.
	 * 
	 * @return the value of this {@link XdevDateTextField} as {@link XdevDate}.
	 * 
	 * @throws DateFormatException
	 *             if the value of this {@link XdevDateTextField} can not be
	 *             converted.
	 * 
	 * @see #getDate(XdevDate)
	 * @see #getText()
	 * @see TextFormat#parseDate(String)
	 */
	public XdevDate getDate() throws DateFormatException
	{
		if(textFormat != null)
		{
			try
			{
				return new XdevDate(textFormat.parseDate(getText()));
			}
			catch(Exception e)
			{
			}
		}
		
		throw new DateFormatException(getText());
	}
	

	/**
	 * Returns the value of this {@link XdevDateTextField} as {@link XdevDate}.
	 * If the internal value can not be converted into a {@link XdevDate}, the
	 * <code>defaultValue</code> is returned.
	 * 
	 * @param defaultValue
	 *            the default {@link XdevDate}
	 * 
	 * @return the value of this {@link XdevDateTextField}. If the internal
	 *         value can not be converted into a {@link XdevDate}, the
	 *         <code>defaultValue</code> is returned.
	 * 
	 * @see #getDate()
	 */
	public XdevDate getDate(XdevDate defaultValue)
	{
		try
		{
			return getDate();
		}
		catch(DateFormatException e)
		{
			return defaultValue;
		}
	}
	

	/**
	 * Same as {@link #setValue(Object)}.
	 * 
	 * @param date
	 *            the value to set
	 */
	public void setDate(XdevDate date)
	{
		setValue(date);
	}
	

	/**
	 * @deprecated use {@link #setValue(Object)()} instead
	 */
//	@Deprecated
//	public void setVal(Object value)
//	{
//		setValue(value);
//	}
	

	/**
	 * Set the <code>value</code> in this {@link XdevDateTextField} as text. If
	 * a {@link TextFormat} exist, the <code>value</code> is formatted.
	 * 
	 * @param value
	 *            the display value
	 * 
	 * @see #setText(String)
	 */
	public void setValue(Object value)
	{
		if(textFormat != null)
		{
			setText(textFormat.format(value));
		}
		else
		{
			setText(String.valueOf(value));
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString() throws NullPointerException
	{
		return getText();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getTabIndex()
	{
		return tabIndex;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTabIndex(int tabIndex)
	{
		if(this.tabIndex != tabIndex)
		{
			int oldValue = this.tabIndex;
			this.tabIndex = tabIndex;
			firePropertyChange(TAB_INDEX_PROPERTY,oldValue,tabIndex);
		}
	}
}
