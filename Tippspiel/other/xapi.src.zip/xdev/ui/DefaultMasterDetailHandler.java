/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.util.ArrayList;
import java.util.List;

import javax.swing.JComponent;

import xdev.Application;
import xdev.db.DBConnection;
import xdev.db.DBDataSource;
import xdev.db.DBException;
import xdev.db.Result;
import xdev.db.sql.Condition;
import xdev.db.sql.SELECT;
import xdev.ui.MasterDetailComponent.DetailHandler;
import xdev.ui.MasterDetailComponent.ValueChangeListener;
import xdev.vt.EntityRelationship;
import xdev.vt.EntityRelationships;
import xdev.vt.KeyValues;
import xdev.vt.VirtualTable;
import xdev.vt.VirtualTableColumn;
import xdev.vt.EntityRelationship.Entity;
import xdev.vt.VirtualTable.VirtualTableRow;


/**
 * Default implementation of {@link MasterDetailHandler}.
 * <p>
 * If you plan to implement your own {@link MasterDetailHandler} this is the
 * best point to start.
 * </p>
 * 
 * @see MasterDetail#setHandler(MasterDetailHandler)
 * @see MasterDetailComponent
 * @author XDEV Software
 */
public class DefaultMasterDetailHandler implements MasterDetailHandler
{
	/**
	 * Client property used to turn off auto-synchronization with the datasource<br>
	 * <code>formular.putClientProperty(OFFLINE,Boolean.TRUE);</code>
	 */
	public final static Object		OFFLINE				= "MasterDetail.offline";
	
	protected final static String	MASTER_COMPONENT	= "MASTER_COMPONENT";
	protected final static String	DETAIL_COMPONENT	= "DETAIL_COMPONENT";
	protected final static String	WORKING				= MasterDetailHandler.class.getName()
																.concat(".working");
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void connect(MasterDetailComponent master, XdevFormular detail)
			throws MasterDetailException
	{
		if(master.isMultiSelect())
		{
			throw new MasterDetailException(master,detail,
					"The master component does support multiple selection");
		}
		
		connectImpl(master,detail);
	}
	

	/**
	 * Called from {@link #connect(MasterDetailComponent, XdevFormular)} after
	 * preconditions are checked successfully.
	 * 
	 * @param master
	 *            the component which operates as master
	 * @param detail
	 *            the {@link XdevFormular} which operates as detail view
	 */
	protected void connectImpl(final MasterDetailComponent master, final XdevFormular detail)
	{
		master.addValueChangeListener(new ValueChangeListener()
		{
			@Override
			public void valueChanged()
			{
				VirtualTableRow row = master.getSelectedVirtualTableRow();
				if(row == null)
				{
					return;
				}
				
				VirtualTable formularVT = detail.getVirtualTable();
				if(formularVT == null)
				{
					return;
				}
				
				KeyValues pkValues = new KeyValues(row);
				row = formularVT.getRow(pkValues);
				try
				{
					if(!Boolean.TRUE.equals(detail.getClientProperty(OFFLINE)))
					{
						if(row != null)
						{
							row.reload();
						}
						else
						{
							if(formularVT.queryAndAppend(pkValues))
							{
								row = formularVT.getLastRow();
							}
						}
					}
					
					if(row != null)
					{
						detail.setModel(row);
					}
				}
				catch(Exception e)
				{
					Application.getLogger().error(e);
				}
			}
		});
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void connect(MasterDetailComponent master, MasterDetailComponent detail)
			throws MasterDetailException
	{
		if(master.isMultiSelect())
		{
			throw new MasterDetailException(master,detail,
					"The master component does support multiple selection");
		}
		
		connectImpl(master,detail);
	}
	

	/**
	 * Called from
	 * {@link #connect(MasterDetailComponent, MasterDetailComponent)} after
	 * preconditions are checked successfully.
	 * 
	 * @param master
	 *            the component which operates as master
	 * @param detail
	 *            the component which operates as detail view
	 */
	protected void connectImpl(MasterDetailComponent master, MasterDetailComponent detail)
	{
		new MasterDetailComponentConnection(master,detail);
	}
	


	/**
	 * Default implementation for the connection of two
	 * {@link MasterDetailComponent}s.
	 */
	protected static class MasterDetailComponentConnection
	{
		/**
		 * The master component of this connection.
		 */
		protected final MasterDetailComponent	master;
		/**
		 * The detail component of this connection.
		 */
		protected final MasterDetailComponent	detail;
		

		protected MasterDetailComponentConnection(MasterDetailComponent master,
				MasterDetailComponent detail)
		{
			this.master = master;
			this.detail = detail;
			
			((JComponent)detail).putClientProperty(MASTER_COMPONENT,master);
			((JComponent)master).putClientProperty(DETAIL_COMPONENT,detail);
			
			master.addValueChangeListener(createMasterHandler());
			detail.setDetailHandler(createDetailHandler());
		}
		

		/**
		 * Factory method for the handler of the master component.
		 * 
		 * @return the handler for the master component
		 */
		protected ValueChangeListener createMasterHandler()
		{
			return new DefaultMasterHandler();
		}
		


		protected class DefaultMasterHandler implements ValueChangeListener
		{
			/**
			 * {@inheritDoc}
			 */
			@Override
			public void valueChanged()
			{
				if(!isWorking(master))
				{
					try
					{
						setWorking(master,true);
						setWorking(detail,true);
						updateDetailComponent();
					}
					catch(MasterDetailException mde)
					{
						Application.getLogger().error(mde);
					}
					finally
					{
						setWorking(master,false);
						setWorking(detail,false);
					}
				}
			}
		}
		

		protected void updateDetailComponent() throws MasterDetailException
		{
			MasterDetailInfo info = new MasterDetailInfo(master,detail);
			List values = new ArrayList();
			values.add(info.getMasterKeyValue());
			Condition condition = info.detailKeyColumn.toSqlColumn().eq("?");
			updateDetailComponent(condition,values,info);
			clearFollowingDetailComponents();
		}
		

		protected void updateDetailComponent(Condition condition, List values, MasterDetailInfo info)
		{
			detail.updateModel(condition,values.toArray());
		}
		

		protected void clearFollowingDetailComponents()
		{
			MasterDetailComponent detail = MasterDetailComponentConnection.this.detail;
			while((detail = getDetail(detail)) != null)
			{
				detail.clearModel();
			}
		}
		

		/**
		 * Factory method for the handler of the detail component.
		 * 
		 * @return the handler for the detail component
		 */
		protected DetailHandler createDetailHandler()
		{
			return new DefaultDetailHandler();
		}
		


		protected class DefaultDetailHandler implements DetailHandler
		{
			/**
			 * {@inheritDoc}
			 */
			@Override
			public void checkDetailView(final Object value)
			{
				if(!isWorking(detail))
				{
					try
					{
						updateMasterComponents(value);
					}
					catch(Exception e)
					{
						Application.getLogger().error(e);
					}
				}
			}
		}
		

		protected void updateMasterComponents(Object detailPrimaryKeyValue)
				throws MasterDetailException, DBException
		{
			List<MasterDetailComponent> stack = new ArrayList();
			MasterDetailComponent c = detail;
			while(c != null)
			{
				stack.add(0,c);
				c = getMaster(c);
			}
			
			DBDataSource<?> dataSource = null;
			
			SELECT select = new SELECT();
			int max = stack.size() - 2;
			MasterDetailInfo[] infos = new MasterDetailInfo[max + 1];
			for(int i = 0; i <= max; i++)
			{
				MasterDetailComponent master = stack.get(i);
				MasterDetailComponent detail = stack.get(i + 1);
				
				MasterDetailInfo info = new MasterDetailInfo(master,detail);
				infos[i] = info;
				select.columns(info.masterKeyColumn.toSqlColumn());
				if(i == 0)
				{
					dataSource = info.masterVT.getDataSource();
					select.FROM(info.masterVT.toSqlTable());
				}
				select.INNER_JOIN(info.detailVT.toSqlTable(),
						info.detailKeyColumn.toSqlColumn().eq(info.masterKeyColumn.toSqlColumn()));
				if(i == max)
				{
					select.WHERE(info.getDetailPrimaryKeyColumn().toSqlColumn().eq("?"));
				}
			}
			
			DBConnection<?> con = dataSource.openConnection();
			try
			{
				Result keys = con.query(select,detailPrimaryKeyValue);
				if(keys.next())
				{
					int col = 0;
					for(MasterDetailInfo info : infos)
					{
						try
						{
							setWorking(master,true);
							setWorking(detail,true);
							
							Object key = keys.getObject(col++);
							info.master.setFormularValue(info.masterVT,
									info.masterVT.getColumnIndex(info.masterKeyColumn),key);
							info.detail.updateModel(info.detailKeyColumn.toSqlColumn().eq("?"),key);
						}
						finally
						{
							setWorking(master,false);
							setWorking(detail,false);
						}
					}
				}
			}
			finally
			{
				if(con != null)
				{
					con.close();
				}
			}
		}
		

		protected boolean isWorking(MasterDetailComponent cpn)
		{
			return Boolean.TRUE.equals(((JComponent)cpn).getClientProperty(WORKING));
		}
		

		protected void setWorking(MasterDetailComponent cpn, boolean working)
		{
			((JComponent)cpn).putClientProperty(WORKING,working ? Boolean.TRUE : null);
		}
		

		protected MasterDetailComponent getDetail(MasterDetailComponent master)
		{
			Object o = ((JComponent)master).getClientProperty(DETAIL_COMPONENT);
			if(o != null && o instanceof MasterDetailComponent)
			{
				return (MasterDetailComponent)o;
			}
			return null;
		}
		

		protected MasterDetailComponent getMaster(MasterDetailComponent detail)
		{
			Object o = ((JComponent)detail).getClientProperty(MASTER_COMPONENT);
			if(o != null && o instanceof MasterDetailComponent)
			{
				return (MasterDetailComponent)o;
			}
			return null;
		}
	}
	


	/**
	 * Holds information of a distinct master detail connection.
	 * 
	 * @see #getMasterKeyValue()
	 * @see #getDetailPrimaryKeyColumn()
	 */
	protected static class MasterDetailInfo
	{
		public final MasterDetailComponent	master;
		public final VirtualTable			masterVT;
		public final VirtualTableColumn		masterKeyColumn;
		
		public final MasterDetailComponent	detail;
		public final VirtualTable			detailVT;
		public final VirtualTableColumn		detailKeyColumn;
		
		public final EntityRelationship		relation;
		public final Entity					detailEntity;
		

		protected MasterDetailInfo(MasterDetailComponent master, MasterDetailComponent detail)
				throws MasterDetailException
		{
			this.master = master;
			this.detail = detail;
			
			masterVT = master.getVirtualTable();
			if(masterVT == null)
			{
				throw new MasterDetailException(master,detail,
						"Master component has no VirtualTable");
			}
			
			VirtualTableColumn[] masterKeys = masterVT.getPrimaryKeyColumns();
			if(masterKeys == null || masterKeys.length == 0)
			{
				throw new MasterDetailException(master,detail,"Master has no primary key");
			}
			else if(masterKeys == null || masterKeys.length != 1)
			{
				throw new MasterDetailException(master,detail,
						"Master's primary key has multiple columns");
			}
			masterKeyColumn = masterKeys[0];
			
			detailVT = detail.getVirtualTable();
			if(detailVT == null)
			{
				throw new MasterDetailException(master,detail,
						"Detail component has no VirtualTable");
			}
			
			relation = EntityRelationships.getModel().getRelationship(masterVT.getName(),
					masterKeyColumn.getName(),detailVT.getName());
			if(relation == null)
			{
				throw new MasterDetailException(master,detail,"No relation found");
			}
			
			detailEntity = relation.getReferrer(detailVT.getName());
			detailKeyColumn = detailVT.getColumn(detailEntity.getColumnName());
			if(detailKeyColumn == null)
			{
				throw new MasterDetailException(master,detail,"Detail column '"
						+ detailEntity.getColumnName() + "' not found in relation");
			}
		}
		

		/**
		 * Determines the current selected key of the master component.
		 * 
		 * @return the current master key value or <code>null</code> if nothing
		 *         is selected
		 * @throws MasterDetailException
		 *             if the column count of the master's primary key != 1
		 */
		protected Object getMasterKeyValue() throws MasterDetailException
		{
			VirtualTableRow selectedRow = master.getSelectedVirtualTableRow();
			if(selectedRow == null)
			{
				return null;
			}
			KeyValues masterKeyValues = new KeyValues(selectedRow);
			if(masterKeyValues.getColumnCount() != 1)
			{
				throw new MasterDetailException(master,detail,
						"Master's primary key has multiple columns");
			}
			return masterKeyValues.getValue(masterKeyColumn.getName());
		}
		

		/**
		 * Determines the primary key column of the detail table.
		 * 
		 * @return the detail's primary key column
		 * @throws MasterDetailException
		 *             if the column count of the detail's primary key != 1
		 */
		protected VirtualTableColumn getDetailPrimaryKeyColumn() throws MasterDetailException
		{
			VirtualTableColumn[] detailKeys = detailVT.getPrimaryKeyColumns();
			if(detailKeys == null || detailKeys.length == 0)
			{
				throw new MasterDetailException(master,detail,"Detail has no primary key");
			}
			else if(detailKeys == null || detailKeys.length != 1)
			{
				throw new MasterDetailException(master,detail,
						"Detail's primary key has multiple columns");
			}
			return detailKeys[0];
		}
	}
}
