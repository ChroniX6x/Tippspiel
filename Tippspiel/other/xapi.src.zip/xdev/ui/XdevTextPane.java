/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Insets;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

import javax.swing.SwingUtilities;

import xdev.ui.text.Link;
import xdev.ui.text.XdevDocument;


//TODO javadoc (class description)
@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevTextPane extends XdevComponent implements XdevTextComponent
{
	private Image			image;
	private String			textImagePath	= null;
	
	private int				horizontalAlign	= XdevDocument.LEFT;
	private boolean			underline		= false;
	private int				textColumnCount	= 1;
	private int				textColumnGap	= 10;
	private Insets			textInsets		= new Insets(0,0,0,0);
	private Dimension		originalSize	= null;
	private XdevDocument	document;
	

	/**
	 * Constructor for creating a new instance of a {@link XdevTextPane}.
	 * 
	 * @see XdevDocument
	 */
	public XdevTextPane()
	{
		super();
		
		LinkListener ll = new LinkListener();
		addMouseListener(ll);
		addMouseMotionListener(ll);
		
		document = new XdevDocument(this);
		
		addComponentListener(new ComponentAdapter()
		{
			@Override
			public void componentResized(ComponentEvent e)
			{
				document.relayout(XdevDocument.FIT_NONE);
			}
		});
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Component getCpn()
	{
		return this;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@SuppressWarnings("deprecation")
	@Override
	public void reshape(int x, int y, int width, int height)
	{
		if(originalSize == null)
		{
			originalSize = new Dimension(width,height);
		}
		
		super.reshape(x,y,width,height);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Dimension getOriginalSize()
	{
		return originalSize;
	}
	

	/**
	 * Sets the new text of this {@link XdevTextPane}.
	 * 
	 * <p>
	 * This is an alias for {@link #setText(String, String)} .
	 * </p>
	 * 
	 * @param str
	 *            the text to be displayed
	 * 
	 * @see #setText(String, String)
	 */
	public void setText(String str)
	{
		setText(str,XdevDocument.CONTENT_TYPE_TEXT_PLAIN);
	}
	

	/**
	 * Sets the new text of this {@link XdevTextPane}.
	 * 
	 * @param str
	 *            the text to be displayed
	 * 
	 * @param contentType
	 *            the constants defined in <code>XdevDocument</code>:
	 *            {@link XdevDocument#CONTENT_TYPE_TEXT_PLAIN}
	 *            {@link XdevDocument#CONTENT_TYPE_TEXT_RTF}
	 * 
	 */
	public void setText(String str, String contentType)
	{
		document.setText(str,contentType);
		repaint();
	}
	

	/**
	 * <p>
	 * This is an alias for {@link #setTextAndPack(String, String)}.
	 * </p>
	 * 
	 * @param str
	 */
	// TODO javaDoc
	public void setTextAndPack(String str)
	{
		setTextAndPack(str,XdevDocument.CONTENT_TYPE_TEXT_PLAIN);
	}
	

	// TODO javaDoc
	public void setTextAndPack(String str, String contentType)
	{
		document.setText(str,contentType,XdevDocument.FIT_STRETCH);
		repaint();
	}
	

	/**
	 * Returns the text of this {@link XdevTextPane}.
	 * 
	 * @return the text of this {@link XdevTextPane}.
	 */
	public String getText()
	{
		return document.toString();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public XdevDocument getDocument()
	{
		return document;
	}
	

	// TODO javaDoc
	public void setTextImagePath(String textImagePath)
	{
		this.textImagePath = textImagePath;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getHorizontalAlign()
	{
		return horizontalAlign;
	}
	

	// TODO javaDoc
	public void setHorizontalAlign(int align)
	{
		this.horizontalAlign = align;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Deprecated
	@Override
	public int getTextColumnCount()
	{
		return textColumnCount;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Deprecated
	@Override
	public void setTextColumnCount(int textColumnCount)
	{
		this.textColumnCount = textColumnCount;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Deprecated
	@Override
	public int getTextColumnGap()
	{
		return textColumnGap;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Deprecated
	@Override
	public void setTextColumnGap(int textColumnGap)
	{
		this.textColumnGap = textColumnGap;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean getUnderline()
	{
		return underline;
	}
	

	public void setUnderline(boolean underline)
	{
		this.underline = underline;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setPaintText()
	{
		textImagePath = null;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isVertical()
	{
		return false;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getVerticalAlign()
	{
		return -1;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean paintAsImage()
	{
		return textImagePath != null;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Insets getTextInsets()
	{
		return textInsets;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTextInsets(Insets i)
	{
		textInsets = i;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Insets getBorderInsets(boolean withTextBorder)
	{
		Insets insets = getBorderInsets();
		if(withTextBorder && textInsets != null)
		{
			insets.top += textInsets.top;
			insets.left += textInsets.left;
			insets.bottom += textInsets.bottom;
			insets.right += textInsets.right;
		}
		
		return insets;
	}
	

	@Override
	protected void paintImage(Graphics2D g)
	{
		Dimension d = getSize();
		paintBackground(g,0,0,d.width,d.height);
		drawTexture(g,0,0,d.width,d.height);
		drawText(g);
	}
	

	// TODO javaDoc
	public void drawText(Graphics2D g)
	{
		if(textImagePath != null)
		{
			if(image == null)
			{
				try
				{
					image = GraphicUtils.loadImage(textImagePath);
				}
				catch(IOException e)
				{
					e.printStackTrace();
				}
			}
			if(image != null)
			{
				g.drawImage(image,0,0,this);
			}
		}
		else if(document != null)
		{
			document.paint(g);
		}
	}
	


	class LinkListener extends MouseAdapter
	{
		private Cursor	defaultCursor	= null;
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void mouseEntered(MouseEvent e)
		{
			if(defaultCursor == null)
			{
				defaultCursor = getCursor();
			}
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void mouseMoved(MouseEvent e)
		{
			if(document != null)
			{
				Link l = document.getSignLinkForPoint(e.getPoint());
				if(l != null && l.type != Link.NONE)
				{
					setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
				}
				else
				{
					setCursor(defaultCursor);
				}
			}
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void mousePressed(MouseEvent e)
		{
			if(document != null && SwingUtilities.isLeftMouseButton(e))
			{
				Link link = document.getSignLinkForPoint(e.getPoint());
				if(link != null && link.type != Link.NONE)
				{
					try
					{
						link.execute(XdevTextPane.this);
					}
					catch(IOException ex)
					{
						ex.printStackTrace();
					}
				}
			}
		}
	}
	
	// private class TextPainter extends JEditorPane
	// {
	// TextPainter()
	// {
	// super("text/plain","");
	// }
	//
	//
	// public Dimension getPreferredSize()
	// {
	// if(originalSize == null)
	// {
	// return super.getPreferredSize();
	// }
	//
	// try
	// {
	//
	// Rectangle start = modelToView(getDocument().getStartPosition());
	// Rectangle end = modelToView(getDocument().getEndPosition());
	// if(start == null || end == null)
	// {
	// return super.getPreferredSize();
	// }
	// int height = end.y + end.height - start.y;
	// Insets insets = getInsets();
	// return new Dimension(originalSize.width,height + insets.top +
	// insets.bottom);
	// }
	// catch(BadLocationException e)
	// {
	// return super.getPreferredSize();
	// }
	// }
	//
	//
	// private Rectangle modelToView(Position p) throws BadLocationException
	// {
	// int offset = p.getOffset();
	// return modelToView(offset > 0 ? offset - 1 : offset);
	// }
	// }
}
