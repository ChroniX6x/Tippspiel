/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.Dimension;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.text.Format;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;

import javax.swing.JFormattedTextField;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;
import javax.swing.text.JTextComponent;

import xdev.ui.text.TextFormat;
import xdev.util.DateFormatException;
import xdev.util.Settings;
import xdev.util.XdevDate;
import xdev.vt.VirtualTable;


/**
 * The standard formatted textfield in XDEV. Based on
 * {@link JFormattedTextField}.
 * 
 * @see JFormattedTextField
 * @see ClientProperties
 * @see FormattedFormularComponent
 * @see XdevFocusCycleComponent
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 */
@BeanSettings(autoPreview = true, useXdevCustomizer = true)
public class XdevFormattedTextField extends JFormattedTextField implements ClientProperties,
		FormattedFormularComponent<XdevFormattedTextField>, XdevFocusCycleComponent
{
	/**
	 * 
	 */
	private static final long	serialVersionUID	= 2643519059601388480L;
	
	private TextFormat			textFormat;
	private Object				savedValue			= null;
	/**
	 * tabIndex is used to store the index for {@link XdevFocusCycleComponent}
	 * functionality.
	 */
	private int					tabIndex			= -1;
	


	private static class Support extends
			FormularComponentSupport<XdevFormattedTextField, XdevFormattedTextField>
	{
		private Support(XdevFormattedTextField component)
		{
			super(component,component);
		}
	}
	
	private final Support	support	= new Support(this);
	

	/**
	 * Constructor for creating a new instance of a
	 * {@link XdevFormattedTextField}.
	 * 
	 */
	public XdevFormattedTextField()
	{
		this(null);
	}
	

	/**
	 * Constructor for creating a new instance of a
	 * {@link XdevFormattedTextField}.
	 * 
	 * @param textFormat
	 *            the {@link TextFormat} to format the display text,
	 *            <code>null</code> if none
	 */
	public XdevFormattedTextField(TextFormat textFormat)
	{
		this("",textFormat);
	}
	

	/**
	 * Constructor for creating a new instance of a
	 * {@link XdevFormattedTextField}.
	 * 
	 * @param text
	 *            the text to be displayed, <code>null</code> if none
	 * 
	 * @param textFormat
	 *            the {@link TextFormat} to format the display text,
	 *            <code>null</code> if none
	 */
	public XdevFormattedTextField(String text, TextFormat textFormat)
	{
		this(text,1000,textFormat);
	}
	

	/**
	 * Constructor for creating a new instance of a
	 * {@link XdevFormattedTextField}.
	 * 
	 * @param maxSigns
	 *            a <code>int</code> to determine the max signs of the
	 *            {@link MaxSignDocument}
	 * 
	 * @param textFormat
	 *            the {@link TextFormat} to format the display text,
	 *            <code>null</code> if none
	 * 
	 * @throws IllegalArgumentException
	 *             if the <code>maxSigns</code> is <= 0
	 */
	public XdevFormattedTextField(int maxSigns, TextFormat textFormat)
			throws IllegalArgumentException
	{
		this("",maxSigns,textFormat);
	}
	

	/**
	 * Constructor for creating a new instance of a
	 * {@link XdevFormattedTextField}.
	 * 
	 * @param text
	 *            the text to be displayed, <code>null</code> if none
	 * 
	 * @param maxSigns
	 *            a <code>int</code> to determine the max signs of the
	 *            {@link MaxSignDocument}
	 * 
	 * @param textFormat
	 *            the {@link TextFormat} to format the display text,
	 *            <code>null</code> if none
	 * 
	 * @throws IllegalArgumentException
	 *             if the <code>maxSigns</code> is <= 0
	 */
	public XdevFormattedTextField(String text, int maxSigns, final TextFormat textFormat)
			throws IllegalArgumentException
	{
		super();
		
		setFocusLostBehavior(JFormattedTextField.COMMIT_OR_REVERT);
		setDocument(new MaxSignDocument(maxSigns));
		
		setTextFormat(textFormat);
		
		if(text != null && text.length() > 0)
		{
			if(textFormat != null)
			{
				setText(textFormat.format(text));
			}
			else
			{
				setText(text);
			}
		}
		
		addFocusListener(new FocusListener()
		{
			public void focusGained(FocusEvent e)
			{
				if(Settings.checkUserSetting(System.getProperty("xdev.selectAllOnFocus","")))
				{
					selectAll();
				}
			}
			

			public void focusLost(FocusEvent e)
			{
				select(0,0);
			}
		});
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Dimension getPreferredSize()
	{
		// Hack because JTextField doesn't honor the set preferred size
		if(isPreferredSizeSet())
		{
			try
			{
				return UIUtils.getPrefSizeFieldValue(this);
			}
			catch(Exception e)
			{
				// Shouldn't happen
				e.printStackTrace();
			}
		}
		
		return super.getPreferredSize();
	}
	

	/**
	 * Registers the given {@link DocumentListener} to begin receiving
	 * notifications when changes are made to the document.
	 * 
	 * @param listener
	 *            the {@link DocumentListener} to register
	 * 
	 * @see Document#addDocumentListener(DocumentListener)
	 */
	public void addDocumentListener(DocumentListener listener)
	{
		getDocument().addDocumentListener(listener);
	}
	

	/**
	 * Returns the max sign count of this {@link XdevFormattedTextField}.
	 * 
	 * 
	 * @return the max sign count of this {@link XdevFormattedTextField}, -1 if
	 *         the {@link Document} is not an instance of
	 *         {@link MaxSignDocument}.
	 * 
	 * @see MaxSignDocument
	 */
	public int getMaxSignCount()
	{
		Document doc = getDocument();
		if(doc instanceof MaxSignDocument)
		{
			return ((MaxSignDocument)doc).getMaxSignCount();
		}
		
		return -1;
	}
	

	/**
	 * Sets the max sign count of this {@link XdevFormattedTextField}.
	 * 
	 * @param maxSignCount
	 *            the max sign count of this {@link XdevFormattedTextField}
	 */
	public void setMaxSignCount(int maxSignCount)
	{
		Document doc = getDocument();
		if(doc instanceof MaxSignDocument)
		{
			MaxSignDocument msDoc = (MaxSignDocument)doc;
			int oldValue = msDoc.getMaxSignCount();
			if(oldValue != maxSignCount)
			{
				msDoc.setMaxSignCount(maxSignCount);
				firePropertyChange(MaxSignDocument.MAX_SIGNS_PROPERTY,oldValue,maxSignCount);
			}
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String getFormularName()
	{
		return support.getFormularName();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		try
		{
			setValue(value);
		}
		catch(Exception e)
		{
			String str = value != null ? value.toString() : "";
			
			boolean useVTFormat = true;
			
			if(textFormat != null && textFormat.getType() != TextFormat.PLAIN)
			{
				str = textFormat.format(value);
				useVTFormat = false;
			}
			
			if(useVTFormat && vt != null)
			{
				str = vt.formatValue(value,col);
			}
			
			setText(str);
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Object getFormularValue()
	{
		Object value = getValue();
		
		if("".equals(value) && textFormat != null && textFormat.getType() != TextFormat.PLAIN)
		{
			value = null;
		}
		
		return value;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public TextFormat getTextFormat()
	{
		return textFormat;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTextFormat(TextFormat format)
	{
		this.textFormat = format;
		
		if(textFormat != null)
		{
			setFormatterFactory(new AbstractFormatterFactory()
			{
				@Override
				public AbstractFormatter getFormatter(JFormattedTextField tf)
				{
					return new AbstractFormatter()
					{
						@Override
						public Object stringToValue(String str) throws ParseException
						{
							return textFormat.parse(str);
						}
						

						@Override
						public String valueToString(Object value) throws ParseException
						{
							return textFormat.format(value);
						}
					};
				}
			});
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void commitEdit() throws ParseException
	{
		try
		{
			super.commitEdit();
		}
		catch(ParseException e)
		{
			if(textFormat == null)
			{
				throw e;
			}
			
			switch(textFormat.getType())
			{
				case TextFormat.CURRENCY:
				{
					Format numberFormat = textFormat.createFormat(TextFormat.NUMBER);
					setValue(numberFormat.parseObject(getText()));
				}
				break;
				
				case TextFormat.PERCENT:
				{
					Format numberFormat = textFormat.createFormat(TextFormat.NUMBER);
					Object value = numberFormat.parseObject(getText());
					if(value instanceof Number)
					{
						double d = ((Number)value).doubleValue();
						value = new Double(d / 100d);
					}
					setValue(value);
				}
				break;
				
				default:
				{
					throw e;
				}
			}
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void saveState()
	{
		savedValue = getValue();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void restoreState()
	{
		setValue(savedValue);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isMultiSelect()
	{
		return false;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean verify()
	{
		return support.verify();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setText(String str)
	{
		try
		{
			if(textFormat != null)
			{
				Object o = textFormat.parse(str);
				if(o != null && textFormat.getSuppressZero() && o instanceof Number
						&& ((Number)o).doubleValue() == 0.0)
				{
					super.setText("");
				}
				else
				{
					super.setText(str);
				}
			}
			else
			{
				super.setText(str);
			}
		}
		catch(Exception e)
		{
			super.setText(str);
		}
	}
	

	/**
	 * Sets the text back to an empty String.<br>
	 * Has the same effect as <code>setValue(null)</code>.
	 */
	public void reset()
	{
		setValue(null);
	}
	

	/**
	 * Returns the selected text contained in this
	 * {@link XdevFormattedTextField}. If the selection is <code>null</code> or
	 * the document empty, returns a empty {@link String}.
	 * 
	 * @return the selected text, or a empty {@link String}
	 * 
	 * @throws IllegalArgumentException
	 *             if the selection doesn't have a valid mapping into the
	 *             document for some reason
	 * 
	 * @see #setText
	 * @see JTextComponent#getSelectedText()
	 */
	@Override
	public String getSelectedText() throws IllegalArgumentException
	{
		String st = super.getSelectedText();
		if(st == null)
		{
			st = "";
		}
		
		return st;
	}
	

	/**
	 * Inserts a {@link String} into this {@link XdevFormattedTextField}.
	 * 
	 * @param text
	 *            the {@link String} to insert
	 * 
	 * @see Document#insertString(int, String, javax.swing.text.AttributeSet)
	 */
	public void insertText(String text)
	{
		try
		{
			getDocument().insertString(getCaretPosition(),text,null);
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	

	/**
	 * 
	 * Returns the value of this {@link XdevFormattedTextField} as
	 * {@link XdevDate}.
	 * 
	 * @return the value of this {@link XdevFormattedTextField} as
	 *         {@link XdevDate}.
	 * 
	 * @throws DateFormatException
	 *             if no {@link TextFormat} is existing or the value of this
	 *             {@link XdevFormattedTextField} can not be converted.
	 * 
	 * @see #getDate(XdevDate)
	 * @see #getInt()
	 * @see #getDouble()
	 */
	public XdevDate getDate() throws DateFormatException
	{
		Object val = getValue();
		if(val instanceof Date)
		{
			return new XdevDate((Date)val);
		}
		else if(val instanceof Calendar)
		{
			return new XdevDate((Calendar)val);
		}
		
		if(textFormat != null && textFormat.getType() == TextFormat.DATETIME)
		{
			try
			{
				return new XdevDate(textFormat.parseDate(getText()));
			}
			catch(Exception e)
			{
			}
		}
		
		throw new DateFormatException(getText());
	}
	

	/**
	 * Returns the value of this {@link XdevFormattedTextField} as
	 * {@link XdevDate}. If the internal value can not be converted into a
	 * {@link XdevDate}, the <code>defaultValue</code> is returned.
	 * 
	 * @param defaultValue
	 *            the default {@link XdevDate}
	 * 
	 * @return the value of this {@link XdevFormattedTextField}. If the internal
	 *         value can not be converted into a {@link XdevDate}, the
	 *         <code>defaultValue</code> is returned.
	 * 
	 * @see #getDate()
	 */
	public XdevDate getDate(XdevDate defaultValue)
	{
		try
		{
			return getDate();
		}
		catch(DateFormatException e)
		{
			return defaultValue;
		}
	}
	

	/**
	 * Returns the value of this {@link XdevFormattedTextField} as
	 * <code>int</code>.
	 * 
	 * @return the value of this {@link XdevFormattedTextField} as
	 *         <code>int</code>.
	 * 
	 * @throws NumberFormatException
	 *             if no {@link TextFormat} is existing or the value of this
	 *             {@link XdevFormattedTextField} can not be converted.
	 * 
	 * @see #getInt(int)
	 * @see #getNumber()
	 * @see #getDate()
	 * @see #getDouble()
	 */
	public int getInt() throws NumberFormatException
	{
		return getNumber().intValue();
	}
	

	/**
	 * Returns the value of this {@link XdevFormattedTextField} as
	 * <code>int</code>. If the internal value can not be converted into a
	 * <code>int</code>, the <code>defaultValue</code> is returned.
	 * 
	 * @param defaultValue
	 *            the default <code>int</code>
	 * 
	 * @return the value of this {@link XdevFormattedTextField}. If the internal
	 *         value can not be converted into a <code>int</code>, the
	 *         <code>defaultValue</code> is returned.
	 * 
	 * @see #getInt()
	 */
	public int getInt(int defaultValue)
	{
		try
		{
			return getInt();
		}
		catch(NumberFormatException e)
		{
			return defaultValue;
		}
	}
	

	/**
	 * Returns the value of this {@link XdevFormattedTextField} as
	 * <code>double</code>.
	 * 
	 * @return the value of this {@link XdevFormattedTextField} as
	 *         <code>double</code>
	 * 
	 * @throws NumberFormatException
	 *             if no {@link TextFormat} is existing or the value of this
	 *             {@link XdevFormattedTextField} can not be converted.
	 * 
	 * @see #getDouble(double)
	 * @see #getNumber()
	 * @see #getDate()
	 * @see #getInt()
	 */
	public double getDouble() throws NumberFormatException
	{
		return getNumber().doubleValue();
	}
	

	/**
	 * Returns the value of this {@link XdevFormattedTextField} as
	 * <code>double</code>. If the internal value can not be converted into a
	 * <code>double</code>, the <code>defaultValue</code> is returned.
	 * 
	 * @param defaultValue
	 *            the default <code>double</code>
	 * 
	 * @return the value of this {@link XdevFormattedTextField}. If the internal
	 *         value can not be converted into a <code>double</code>, the
	 *         <code>defaultValue</code> is returned.
	 * 
	 * @see #getDouble()
	 */
	public double getDouble(double defaultValue)
	{
		try
		{
			return getDouble();
		}
		catch(NumberFormatException e)
		{
			return defaultValue;
		}
	}
	

	/**
	 * Returns the value of this {@link XdevFormattedTextField} as
	 * {@link Number}.
	 * 
	 * @return the value of this {@link XdevFormattedTextField} as
	 *         {@link Number}
	 * 
	 * @throws NumberFormatException
	 *             if no {@link TextFormat} is existing or the value of this
	 *             {@link XdevFormattedTextField} can not be converted.
	 * 
	 * @see #getNumber(Number)
	 * @see #getDouble()
	 * @see #getDate()
	 * @see #getInt()
	 */
	public Number getNumber() throws NumberFormatException
	{
		Object val = getValue();
		if(val instanceof Number)
		{
			return (Number)val;
		}
		
		if(textFormat != null && textFormat.isNumeric())
		{
			try
			{
				val = textFormat.parse(getText());
				if(val instanceof Number)
				{
					return (Number)val;
				}
			}
			catch(Exception e)
			{
			}
		}
		
		throw new NumberFormatException(getText());
	}
	

	/**
	 * Returns the value of this {@link XdevFormattedTextField} as
	 * {@link Number}. If the internal value can not be converted into a
	 * {@link Number}, the <code>defaultValue</code> is returned.
	 * 
	 * @param defaultValue
	 *            the default {@link Number}
	 * 
	 * @return the value of this {@link XdevFormattedTextField}. If the internal
	 *         value can not be converted into a {@link Number}, the
	 *         <code>defaultValue</code> is returned.
	 * 
	 * @see #getDouble()
	 */
	public Number getNumber(Number defaultValue)
	{
		try
		{
			return getNumber();
		}
		catch(NumberFormatException e)
		{
			return defaultValue;
		}
	}
	

	/**
	 * Set the <code>value</code> in this {@link XdevFormattedTextField} as
	 * text. If a {@link TextFormat} exist, the <code>value</code> is formatted.
	 * 
	 * @param value
	 *            the display value
	 * 
	 * @see #setText(String)
	 * @deprecated use {@link #setValue(Object)()} instead
	 */
	// @Deprecated
	// public void setVal(Object value)
	// {
	// if(textFormat != null)
	// {
	// setText(textFormat.format(value));
	// }
	// else
	// {
	// setText(String.valueOf(value));
	// }
	// }
	
	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		if(textFormat != null)
		{
			return textFormat.format(getValue());
		}
		else
		{
			return getText();
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int getTabIndex()
	{
		return tabIndex;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTabIndex(int tabIndex)
	{
		if(this.tabIndex != tabIndex)
		{
			int oldValue = this.tabIndex;
			this.tabIndex = tabIndex;
			firePropertyChange(TAB_INDEX_PROPERTY,oldValue,tabIndex);
		}
	}
}
