/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.ui;


import java.awt.*;
import java.awt.event.*;
import java.beans.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.plaf.*;


public class XScrollPane extends JScrollPane
{
	public XScrollPane(Component view)
	{
		this(view,VERTICAL_SCROLLBAR_AS_NEEDED,HORIZONTAL_SCROLLBAR_AS_NEEDED);
	}


	public XScrollPane(Component view, int vsbPolicy, int hsbPolicy)
	{
		super(view,vsbPolicy,hsbPolicy);

		if(view != null)
		{
			setVisible(view.isVisible());
			view.addComponentListener(new ComponentAdapter()
			{
				@Override
				public void componentShown(ComponentEvent e)
				{
					setVisible(true);
				}


				@Override
				public void componentHidden(ComponentEvent e)
				{
					setVisible(false);
				}
			});

			if(view instanceof JComponent)
			{
				final JComponent jc = (JComponent)view;

				Border border = jc.getBorder();
				if(border != null && !(border instanceof UIResource))
				{
					setBorder(border);
					jc.setBorder(null);
				}

				jc.addPropertyChangeListener("border",new PropertyChangeListener()
				{
					boolean	flag	= true;


					public void propertyChange(PropertyChangeEvent evt)
					{
						if(flag)
						{
							flag = false;

							setBorder((Border)evt.getNewValue());
							jc.setBorder(null);

							flag = true;
						}
					}
				});

				setOpaque(jc.isOpaque());
				getViewport().setOpaque(jc.isOpaque());
				jc.addPropertyChangeListener("opaque",new PropertyChangeListener()
				{
					public void propertyChange(PropertyChangeEvent evt)
					{
						setOpaque(jc.isOpaque());
						getViewport().setOpaque(jc.isOpaque());
					}
				});
			}
		}
	}
}
