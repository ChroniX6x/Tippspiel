/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.ui;


import java.awt.Component;
import java.awt.Point;
import java.awt.Rectangle;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JViewport;
import javax.swing.ListSelectionModel;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;

import xdev.Application;
import xdev.db.QueryInfo;
import xdev.db.sql.Condition;
import xdev.db.sql.SELECT;
import xdev.db.sql.WHERE;
import xdev.io.csv.CSVWriter;
import xdev.ui.MasterDetailComponent.DetailHandler;
import xdev.ui.MasterDetailComponent.ValueChangeListener;
import xdev.util.ArrayUtils;
import xdev.util.IntList;
import xdev.vt.EntityRelationship;
import xdev.vt.EntityRelationship.Entity;
import xdev.vt.EntityRelationships;
import xdev.vt.KeyValues;
import xdev.vt.VirtualTable;
import xdev.vt.VirtualTable.VirtualTableRow;
import xdev.vt.VirtualTableColumn;
import xdev.vt.VirtualTableException;
import xdev.vt.VirtualTableModel;


public class TableSupport<T extends JTable, MDC extends MasterDetailComponent<T>> extends
		FormularComponentSupport<T, MDC>
{
	protected final T		table;
	protected final MDC		masterDetailComponent;
	
	protected int[]			savedValue	= new int[0];
	protected DetailHandler	detailHandler;
	protected String		modelColumns;
	

	protected TableSupport(T table, MDC masterDetailComponent)
	{
		super(table,masterDetailComponent);
		
		this.table = table;
		this.masterDetailComponent = masterDetailComponent;
	}
	

	// *****************************************************
	// Common Support
	// *****************************************************
	
	public void setModel(VirtualTable vt, String columns, SELECT select, Object... params)
	{
		modelColumns = columns;
		
		if(select != null)
		{
			try
			{
				vt.queryAndFill(select,params);
			}
			catch(Exception e)
			{
				Application.getLogger().error(e);
			}
		}
		
		columns = columns.trim();
		if(columns.equals("*"))
		{
			table.setModel(vt.createTableModel());
		}
		else if(columns.length() > 0)
		{
			List<String> columnNames = new ArrayList();
			StringTokenizer st = new StringTokenizer(columns,",");
			while(st.hasMoreTokens())
			{
				columnNames.add(st.nextToken().trim());
			}
			table.setModel(vt.createTableModel(columnNames));
		}
		
		table.clearSelection();
	}
	

	public void setModel(VirtualTable vt)
	{
		setModel(vt,"*",false);
	}
	

	public void setModel(VirtualTable vt, String columns, boolean queryData)
	{
		SELECT select = null;
		if(queryData)
		{
			select = vt.getSelect();
		}
		
		setModel(vt,columns,select);
	}
	

	public int getRowAtPoint(Point location) throws IndexOutOfBoundsException
	{
		int row = table.rowAtPoint(location);
		return table.convertRowIndexToModel(row);
	}
	

	// *****************************************************
	// Selection Support
	// *****************************************************
	
	public int getSelectedModelRow() throws IndexOutOfBoundsException
	{
		int row = table.getSelectedRow();
		if(row != -1)
		{
			row = table.convertRowIndexToModel(row);
		}
		return row;
	}
	

	public int[] getSelectedModelRows() throws IndexOutOfBoundsException
	{
		IntList list = new IntList();
		
		int[] si = table.getSelectedRows();
		if(si != null)
		{
			for(int i = 0; i < si.length; i++)
			{
				si[i] = table.convertRowIndexToModel(si[i]);
				if(si[i] != -1)
				{
					list.add(si[i]);
				}
			}
		}
		
		return list.toArray();
	}
	

	public void setSelectedRows(int[] indices)
	{
		ListSelectionModel sm = table.getSelectionModel();
		sm.clearSelection();
		int size = table.getModel().getRowCount();
		for(int i = 0; i < indices.length; i++)
		{
			if(indices[i] < size)
			{
				sm.addSelectionInterval(indices[i],indices[i]);
			}
		}
	}
	

	public void setSelectedModelRow(int row) throws IndexOutOfBoundsException,
			IllegalArgumentException
	{
		if(row < 0)
		{
			table.clearSelection();
		}
		else
		{
			row = table.convertRowIndexToView(row);
			if(row != -1)
			{
				table.setRowSelectionInterval(row,row);
			}
		}
	}
	

	public void setSelectedModelRows(int[] rows) throws IndexOutOfBoundsException,
			IllegalArgumentException
	{
		if(rows == null)
		{
			table.clearSelection();
		}
		else
		{
			for(int i = 0; i < rows.length; i++)
			{
				int row = table.convertRowIndexToView(rows[i]);
				if(row != -1)
				{
					table.addRowSelectionInterval(row,row);
				}
			}
		}
	}
	

	public void setSelectedModelRows(int start, int end)
	{
		table.getSelectionModel().setSelectionInterval(table.convertRowIndexToView(start),
				table.convertRowIndexToView(end));
	}
	

	// *****************************************************
	// FormularComponent Support
	// *****************************************************
	
	public boolean isMultiSelect()
	{
		return table.getSelectionModel().getSelectionMode() != ListSelectionModel.SINGLE_SELECTION;
	}
	

	public void setFormularValue(VirtualTable vt, int col, Object value)
	{
		table.clearSelection();
		
		if(value == null)
		{
			return;
		}
		
		VirtualTable tableVT = masterDetailComponent.getVirtualTable();
		selectFormularValue(vt,tableVT,col,value);
		if(table.getSelectedRowCount() == 0 && detailHandler != null)
		{
			detailHandler.checkDetailView(value);
			selectFormularValue(vt,tableVT,col,value);
		}
	}
	

	private void selectFormularValue(VirtualTable formularVT, VirtualTable tableVT, int col,
			Object value)
	{
		if(isMultiSelect())
		{
			Object[] values;
			if(value.getClass().isArray())
			{
				values = (Object[])value;
			}
			else
			{
				values = new Object[]{value};
			}
			KeyValues[] keyValues = new KeyValues[values.length];
			for(int i = 0; i < values.length; i++)
			{
				keyValues[i] = getKeyValues(formularVT,tableVT,keyValues);
			}
			int rowCount = table.getModel().getRowCount();
			for(int row = 0; row < rowCount; row++)
			{
				for(int i = 0; i < keyValues.length; i++)
				{
					if(keyValues[i].equals(tableVT.getRow(row)))
					{
						table.getSelectionModel().addSelectionInterval(row,row);
						break;
					}
				}
			}
		}
		else
		{
			KeyValues keyValues = getKeyValues(formularVT,tableVT,value);
			int rowCount = table.getModel().getRowCount();
			for(int row = 0; row < rowCount; row++)
			{
				if(keyValues.equals(tableVT.getRow(row)))
				{
					table.getSelectionModel().addSelectionInterval(row,row);
				}
			}
		}
	}
	

	private KeyValues getKeyValues(VirtualTable formularVT, VirtualTable tableVT, Object value)
			throws MasterDetailException, VirtualTableException
	{
		VirtualTableColumn[] pkColumns = tableVT.getPrimaryKeyColumns();
		if(pkColumns.length == 0)
		{
			throw new MasterDetailException(formularVT,tableVT,"no primary key defined in '"
					+ formularVT.getName() + "'");
		}
		else if(pkColumns.length != 1)
		{
			throw new MasterDetailException(formularVT,tableVT,
					"multi column primary key defined in '" + formularVT.getName() + "'");
		}
		
		VirtualTableColumn keyColumn = pkColumns[0];
		
		if(formularVT.getName().equals(tableVT.getName()))
		{
			return new KeyValues(tableVT,keyColumn.getName(),value);
		}
		
		EntityRelationship relation = EntityRelationships.getModel().getRelationship(
				tableVT.getName(),keyColumn.getName(),formularVT.getName());
		if(relation == null)
		{
			throw new MasterDetailException(formularVT,tableVT,"no foreign key for '"
					+ formularVT.getName() + "." + keyColumn.getName() + "' found in '"
					+ tableVT.getName() + "'");
		}
		
		Entity formularEntity = relation.getReferrer(formularVT.getName());
		Entity tableEntity = relation.getOther(formularEntity);
		VirtualTableColumn tableColumn = tableVT.getColumn(tableEntity.getColumnName());
		if(tableColumn == null)
		{
			VirtualTableException.throwColumnNotFound(tableVT,tableEntity.getColumnName());
		}
		
		return new KeyValues(tableVT,tableColumn.getName(),value);
	}
	

	public Object getFormularValue()
	{
		List list = new ArrayList();
		
		TableModel model = table.getModel();
		if(model instanceof VirtualTableModel)
		{
			VirtualTableModel vtModel = (VirtualTableModel)model;
			VirtualTable modelVT = vtModel.getVirtualTable();
			if(modelVT != null)
			{
				int[] si = table.getSelectedRows();
				if(si != null)
				{
					VirtualTableColumn[] cols = modelVT.getPrimaryKeyColumns();
					if(cols.length == 1)
					{
						for(int i = 0; i < si.length; i++)
						{
							list.add(modelVT.getValueAt(si[i],cols[0]));
						}
					}
				}
			}
		}
		
		if(list.size() == 0)
		{
			return null;
		}
		else if(list.size() == 1 && !isMultiSelect())
		{
			return list.get(0);
		}
		return list.toArray();
	}
	

	public void saveState()
	{
		savedValue = table.getSelectedRows();
	}
	

	public void restoreState()
	{
		setSelectedRows(savedValue);
	}
	

	// *****************************************************
	// MasterDetailComponent Support
	// *****************************************************
	
	public VirtualTableRow getSelectedVirtualTableRow()
	{
		VirtualTable vt = masterDetailComponent.getVirtualTable();
		if(vt != null)
		{
			int index = getSelectedModelRow();
			if(index >= 0)
			{
				return vt.getRow(index);
			}
		}
		
		return null;
	}
	

	public VirtualTableRow[] getSelectedVirtualTableRows()
	{
		VirtualTable vt = masterDetailComponent.getVirtualTable();
		if(vt != null)
		{
			int indices[] = getSelectedModelRows();
			int c = indices.length;
			VirtualTableRow[] rows = new VirtualTableRow[c];
			for(int i = 0; i < c; i++)
			{
				rows[i] = vt.getRow(indices[i]);
			}
			return rows;
		}
		
		return null;
	}
	

	public void refresh()
	{
		VirtualTable vt = masterDetailComponent.getVirtualTable();
		if(vt != null)
		{
			try
			{
				int[] selectedRows = table.getSelectedRows();
				
				vt.reload();
				
				setSelectedRows(selectedRows);
			}
			catch(Exception e)
			{
				Application.getLogger().error(e);
			}
		}
	}
	

	public void updateModel(Condition condition, Object... params)
	{
		component.clearSelection();
		VirtualTable vt = masterDetailComponent.getVirtualTable();
		if(vt != null && modelColumns != null)
		{
			QueryInfo query = vt.getLastQuery();
			QueryInfo queryClone = query != null ? query.clone() : null;
			SELECT select;
			if(query != null)
			{
				select = query.getSelect();
				
				Object[] lastParams = query.getParameters();
				if(lastParams.length > 0)
				{
					params = ArrayUtils.concat(Object.class,lastParams,params);
				}
			}
			else
			{
				select = vt.getSelect();
			}
			
			WHERE where = select.getWhere();
			if(where != null && !where.isEmpty())
			{
				where = new WHERE(where.encloseWithPars().and(condition));
			}
			else
			{
				where = new WHERE(condition);
			}
			
			select.WHERE(where);
			setModel(vt,modelColumns,select,params);
			
			vt.setLastQuery(queryClone);
		}
	}
	

	public void clearModel()
	{
		VirtualTable vt = masterDetailComponent.getVirtualTable();
		if(vt != null)
		{
			vt.clear();
		}
	}
	

	public void addValueChangeListener(final ValueChangeListener l)
	{
		table.getSelectionModel().addListSelectionListener(new ListSelectionListener()
		{
			@Override
			public void valueChanged(ListSelectionEvent e)
			{
				l.valueChanged();
			}
		});
	}
	

	public void setDetailHandler(DetailHandler detailHandler)
	{
		this.detailHandler = detailHandler;
	}
	

	/**
	 * Exports data of this {@link XdevTable} as CSV information to a specified
	 * {@link Writer}.
	 * <p>
	 * This is an alias for {@link #exportCSV(Writer, char)}.
	 * </p>
	 * 
	 * @param writer
	 *            the {@link Writer} to write CSV information to
	 * 
	 * 
	 * @throws IOException
	 *             if CSV file couldn't be written
	 */
	public void exportCSV(Writer writer) throws IOException
	{
		exportCSV(writer,',');
	}
	

	/**
	 * Exports data of this {@link XdevTable} as CSV information to a specified
	 * {@link Writer}.
	 * <p>
	 * This is an alias for {@link #exportCSV(Writer, char, boolean)}.
	 * </p>
	 * 
	 * @param writer
	 *            the {@link Writer} to write CSV information to
	 * 
	 * @param delimiter
	 *            the delimiter to use for separating entries.
	 * 
	 * @throws IOException
	 *             if CSV file couldn't be written
	 */
	public void exportCSV(Writer writer, char delimiter) throws IOException
	{
		exportCSV(writer,delimiter,true);
	}
	

	/**
	 * Exports data of this {@link XdevTable} as CSV information to a specified
	 * {@link Writer}.
	 * 
	 * @param writer
	 *            the {@link Writer} to write CSV information to
	 * 
	 * @param delimiter
	 *            the delimiter to use for separating entries.
	 * 
	 * @param withColumnNames
	 *            a flag to control whether the columns are written
	 * 
	 * @throws IOException
	 *             if CSV file couldn't be written
	 */
	public synchronized void exportCSV(Writer writer, char delimiter, boolean withColumnNames)
			throws IOException
	{
		CSVWriter csvWriter = new CSVWriter(writer,delimiter);
		
		int columnCount = table.getColumnCount();
		int[] viewColumns = new int[columnCount];
		for(int col = 0; col < columnCount; col++)
		{
			viewColumns[col] = col;// convertColumnIndexToView(col);
		}
		String[] line = new String[columnCount];
		
		int rowCount = table.getRowCount();
		
		if(withColumnNames)
		{
			TableColumnModel columnModel = table.getColumnModel();
			for(int col = 0; col < columnCount; col++)
			{
				int viewCol = viewColumns[col];
				line[col] = exportCSV_getColumnName(columnModel.getColumn(viewCol));
			}
			csvWriter.writeNext(line);
		}
		
		for(int row = 0; row < rowCount; row++)
		{
			int viewRow = row;// convertRowIndexToView(row);
			for(int col = 0; col < columnCount; col++)
			{
				int viewCol = viewColumns[col];
				line[col] = exportCSV_getValue(line,viewRow,viewCol);
			}
			csvWriter.writeNext(line);
		}
	}
	

	protected String exportCSV_getColumnName(TableColumn column)
	{
		return String.valueOf(column.getHeaderValue());
	}
	

	protected String exportCSV_getValue(Object value, int row, int col)
	{
		Component cpn = table.getCellRenderer(row,col).getTableCellRendererComponent(table,value,
				false,false,row,col);
		if(cpn instanceof JLabel)
		{
			return ((JLabel)cpn).getText();
		}
		
		return "";
	}
	

	/**
	 * Return <code>true</code> if something is selected, otherwise
	 * <code>false</code>.
	 * 
	 * @return <code>true</code> if something is selected, otherwise
	 *         <code>false</code>
	 */
	public boolean isSomethingSelected()
	{
		return table.getSelectedRow() >= 0;
	}
	

	/**
	 * Sets the column�s <code>preferredWidth</code> and the column�s
	 * <code>width</code>.
	 * 
	 * @param index
	 *            the index of the desired column
	 * @param width
	 *            the value for the column width
	 * 
	 * @see TableColumn#setPreferredWidth(int)
	 * @see TableColumn#setWidth(int)
	 */
	public void setColumnWidth(int index, int width)
	{
		TableColumn tc = table.getColumnModel().getColumn(index);
		tc.setPreferredWidth(width);
		tc.setWidth(width);
	}
	

	/**
	 * Sets the title of the desired column with the <code>index</code>.
	 * 
	 * @param index
	 *            the index of the desired column
	 * @param title
	 *            the value for the column title
	 * 
	 * @see TableColumn#setHeaderValue(Object)
	 */
	public void setColumnTitle(int index, String title)
	{
		TableColumn tc = table.getColumnModel().getColumn(index);
		tc.setHeaderValue(title);
	}
	

	/**
	 * 
	 * Returns the index of the row that x- and y-coordinate lies in. Maps the
	 * index of the row in terms of the view to the underlying
	 * {@link TableModel}.
	 * 
	 * @param x
	 *            the <i>x</i> coordinate of the row
	 * @param y
	 *            the <i>y</i> coordinate of the row
	 * 
	 * @return the index of the corresponding row in the model
	 * 
	 * @throws IndexOutOfBoundsException
	 *             if sorting is enabled and passed an index outside the range
	 *             of the {@link JTable} as determined by the method
	 *             {@link JTable#getRowCount()}
	 * 
	 * @see #getRowAtPoint(Point)
	 * @see JTable#convertRowIndexToModel(int)
	 */
	public int getRowAtPoint(int x, int y) throws IndexOutOfBoundsException
	{
		return getRowAtPoint(new Point(x,y));
	}
	

	/**
	 * Returns the index of the column that x- and y-coordinate lies in or -1 if
	 * the result is not in the range [0, {@link JTable#getColumnCount()} -1].
	 * 
	 * @param x
	 *            the <i>x</i> coordinate of the column
	 * @param y
	 *            the <i>y</i> coordinate of the column
	 * @return the index of the column that x- and y-coordinate lies in or -1 if
	 *         the result is not in the range [0,
	 *         {@link JTable#getColumnCount()} -1]
	 * 
	 * @see #getColumnAtPoint(Point)
	 */
	public int getColumnAtPoint(int x, int y)
	{
		return getColumnAtPoint(new Point(x,y));
	}
	

	/**
	 * This method is a alias for {@link JTable#columnAtPoint(Point)}.
	 * 
	 * @param location
	 *            of interest
	 * 
	 * @return the index of the column that <code>location</code> lies in or -1
	 *         if the result is not in the range [0,
	 *         {@link JTable#getColumnCount()} -1]
	 * 
	 * @see #getColumnAtPoint(int, int)
	 */
	public int getColumnAtPoint(Point location)
	{
		return table.columnAtPoint(location);
	}
	

	/**
	 * Scrolls to the desired cell. After the call the desired cell is visible
	 * in the viewport.
	 * 
	 * <p>
	 * <strong>Note:</strong> Works only if the table is contained in a
	 * {@link JScrollPane}.
	 * </p>
	 * 
	 * @param rowIndex
	 *            index of row to scroll to
	 * @param columnIndex
	 *            index of the column to scroll to
	 */
	public void ensureCellIsVisible(int rowIndex, int columnIndex)
	{
		if(!(table.getParent() instanceof JViewport))
		{
			// no scroller - no scrolling!
			return;
		}
		
		JViewport viewport = (JViewport)this.table.getParent();
		
		// calculate rect that should be displayed
		Rectangle rect = this.table.getCellRect(rowIndex,columnIndex,true);
		Point point = viewport.getViewPosition();
		rect.setLocation(rect.x - point.x,rect.y - point.y);
		
		// scroll!
		viewport.scrollRectToVisible(rect);
	}
	

	/**
	 * Scrolls to the desired row. After the call the desired row is visible in
	 * the viewport. The selected column will be preserved during the process.
	 * 
	 * <p>
	 * <strong>Note:</strong> Works only if the table is contained in a
	 * {@link JScrollPane}.
	 * </p>
	 * 
	 * @param rowIndex
	 *            index of row to scroll to
	 */
	public void ensureRowIsVisible(int rowIndex)
	{
		this.ensureCellIsVisible(rowIndex,this.table.getSelectedColumn());
	}
	

	/**
	 * Scrolls to the desired column. After the call the desired column is
	 * visible in the viewport. The selected row will be preserved during the
	 * process.
	 * 
	 * <p>
	 * <strong>Note:</strong> Works only if the table is contained in a
	 * {@link JScrollPane}.
	 * </p>
	 * 
	 * @param columnIndex
	 *            index of the column to scroll to
	 */
	public void ensureColumnIsVisible(int columnIndex)
	{
		this.ensureCellIsVisible(this.table.getSelectedRow(),columnIndex);
	}
	

	/**
	 * Creates a Virtual Table from the currently displayed values of this
	 * supported table.
	 * <p>
	 * The generated Virtual Table has the same order of columns and rows as
	 * currently displayed in the view.
	 * </p>
	 * <p>
	 * The supported table must have a referenced VirtualTable
	 * {@link VirtualTableModel} for this method to work)
	 * </p>
	 * 
	 * @return a {@link VirtualTable} representing the currently displayed
	 *         results of the table
	 * @throws IllegalStateException
	 *             if the supported table is not based on a VirtualTableModel or
	 *             if a new VirtualTable could not be created.
	 */
	public VirtualTable createSubsettedVirtualTable()
	{
		if(!(table.getModel() instanceof VirtualTableModel))
		{
			throw new IllegalArgumentException("No VirtualTableModel found.");
		}
		
		VirtualTableModel virtualTableModel = (VirtualTableModel)table.getModel();
		if(virtualTableModel == null)
		{
			throw new IllegalStateException("There is no VirtualTableModel for this table.");
		}
		
		final VirtualTable modelVT = virtualTableModel.getVT();
		
		VirtualTable subsettedVt = createSubsettedVT(modelVT);
		
		fillSubsettedVT(modelVT,subsettedVt);
		
		return subsettedVt;
	}
	

	/**
	 * Creates a subsetted Virtual Table.
	 * <p>
	 * A new Virtual Table is created, that contains only those columns that are
	 * currently visible in the table.
	 * </p>
	 * 
	 * @param modelVT
	 *            the Virtual Table representing the model for reading column
	 *            information
	 * @return
	 */
	private VirtualTable createSubsettedVT(final VirtualTable modelVT)
	{
		final int columnCount = table.getColumnCount();
		List<String> visibleColumnNames = getVisibleColumnNames();
		@SuppressWarnings("rawtypes")
		VirtualTableColumn[] vtColumns = new VirtualTableColumn[columnCount];
		
		for(int j = 0; j < columnCount; j++)
		{
			VirtualTableColumn<?> modelColumn = null;
			for(VirtualTableColumn<?> column : modelVT)
			{
				if(column.getName().equals(visibleColumnNames.get(j)))
				{
					modelColumn = column;
					break;
				}
			}
			vtColumns[j] = modelColumn.clone();
		}
		VirtualTable subsettedVt = new VirtualTable(modelVT.getName(),modelVT.getDatabaseAlias(),
				vtColumns);
		return subsettedVt;
	}
	

	/**
	 * Fills the values of the subsetted Virtual Table with values from the
	 * models Virtual Table.
	 * <p>
	 * Only values are filled in that are currently visible in the table. The
	 * order of rows and columns equals the displayed order.
	 * </p>
	 * 
	 * @param modelVT
	 *            the underlying Virtual Table representing the model for
	 *            reading the values
	 * @param subsettedVT
	 *            the subsetted Virtual Table representling the view for writing
	 *            the values
	 */
	private void fillSubsettedVT(final VirtualTable modelVT, VirtualTable subsettedVt)
	{
		int rowCount = table.getModel().getRowCount();
		List<String> visibleColumnNames = getVisibleColumnNames();
		
		for(int row = 0; row < rowCount; row++)
		{
			List<Object> values = new ArrayList<Object>();
			for(int col = 0; col < table.getColumnCount(); col++)
			{
				VirtualTableColumn<?> modelColumn = null;
				for(VirtualTableColumn<?> column : modelVT)
				{
					if(column.getName().equals(visibleColumnNames.get(col)))
					{
						modelColumn = column;
						break;
					}
				}
				
				int modelRow = table.convertRowIndexToModel(row);
				
				Object value = modelVT.getValueAt(modelRow,modelColumn);
				values.add(value);
			}
			try
			{
				subsettedVt.addRow(values,false);
			}
			catch(Exception e)
			{
				throw new IllegalStateException("creation of virtual table failed. ",e);
			}
		}
	}
	

	/**
	 * @return a {@link List} of all currently visible column names ordered from
	 *         left to right
	 */
	protected List<String> getVisibleColumnNames()
	{
		int columnCount = table.getColumnCount();
		List<String> visibibleColumnNames = new ArrayList<String>();
		for(int c = 0; c < columnCount; c++)
		{
			visibibleColumnNames.add(table.getColumnName(c));
		}
		return visibibleColumnNames;
	}
}
