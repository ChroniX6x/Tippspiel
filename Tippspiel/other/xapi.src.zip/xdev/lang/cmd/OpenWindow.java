/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.lang.cmd;


import java.awt.Component;

import javax.swing.FocusManager;

import xdev.Application;
import xdev.ui.UIUtils;
import xdev.ui.XdevDialog;
import xdev.ui.XdevFrame;
import xdev.ui.XdevWindow;
import xdev.ui.XdevRootPaneContainer;
import xdev.ui.XdevScreen;


public abstract class OpenWindow extends XdevCommandObject
{
	public static enum ContainerType
	{
		CURRENT_CONTAINER,

		FRAME,

		DIALOG,

		SCREEN
	}
	
	private XdevWindow		window			= null;
	private ContainerType	containerType	= null;
	private boolean			modal			= false;
	private Component		owner			= null;
	

	public OpenWindow(Object... args)
	{
		super(args);
	}
	

	public void setXdevWindow(XdevWindow window)
	{
		this.window = window;
	}
	

	public void setContainerType(ContainerType containerType)
	{
		this.containerType = containerType;
	}
	

	public void setModal(boolean modal)
	{
		this.modal = modal;
	}
	

	public void setOwner(Component owner)
	{
		this.owner = owner;
	}
	

	@Override
	public void execute()
	{
		if(window == null)
		{
			CommandException.throwMissingParameter("contentPane");
		}
		
		if(containerType == null)
		{
			CommandException.throwMissingParameter("containerType");
		}
		
		if(owner == null)
		{
			FocusManager fm = FocusManager.getCurrentManager();
			owner = fm.getFocusOwner();
			if(owner == null)
			{
				owner = UIUtils.getActiveWindow();
			}
		}
		
		switch(containerType)
		{
			case CURRENT_CONTAINER:
			{
				XdevRootPaneContainer container = UIUtils.getParentOfClass(
						XdevRootPaneContainer.class,owner);
				if(container == null)
				{
					container = Application.getContainer();
				}
				
				container.setXdevWindow(window);
				container.pack();
				container.setLocationRelativeTo(null);
			}
			break;
			
			case FRAME:
			{
				XdevFrame frame = new XdevFrame(window);
				frame.pack();
				frame.setLocationRelativeTo(null);
				frame.setVisible(true);
			}
			break;
			
			case DIALOG:
			{
				XdevDialog dialog = new XdevDialog(owner,modal,window);
				dialog.pack();
				dialog.setLocationRelativeTo(null);
				dialog.setVisible(true);
			}
			break;
			
			case SCREEN:
			{
				XdevScreen screen = new XdevScreen(owner,modal,window);
				screen.pack();
				screen.setLocationRelativeTo(null);
				screen.setVisible(true);
			}
			break;
		}
	}
}
