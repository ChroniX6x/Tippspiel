/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.lang;


import java.lang.annotation.*;


/**
 * A marker annotation for delegate methods of event handlers.
 * <p>
 * This class is used for example by visual user interface designers.
 * </p>
 * Sample:
 * 
 * <pre>
 * ...
 * 
 * JButton cmdOK;
 * 
 * ...
 * 
 * cmdOK.addActionListener(new ActionListener(){
 * 	public void actionPerformed(ActionEvent e){
 * 		cmdOK_actionPerformed(e);
 * 	}
 * });
 * 
 * ...
 * 
 * &#64;EventHandlerDelegate void cmdOK_actionPerformed(ActionEvent e){
 * 	// do stuff
 * }
 * 
 * ...
 * </pre>
 * 
 * 
 * @author XDEV Software Corp.
 */

@Target(ElementType.METHOD)
public @interface EventHandlerDelegate
{
}
