/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.lang;


import xdev.db.DBDataSource;
import xdev.db.DBException;
import xdev.lang.cmd.FillTree;
import xdev.lang.cmd.OpenWindow;
import xdev.lang.cmd.Query;
import xdev.ui.XdevWindow;
import xdev.ui.XdevTree;
import xdev.vt.VirtualTable;
import xdev.vt.VirtualTableException;


/**
 * The XDEV class contains the static XDEV methods which can be parameterized by
 * a wizard in the IDE.
 * 
 * 
 * @author XDEV Software
 */

@LibraryMember
public final class XDEV
{
	/**
	 * No instanciation.
	 */
	private XDEV()
	{
	}
	

	/**
	 * Queries a {@link DBDataSource} with a query and reads the data into a
	 * {@link VirtualTable}.
	 * 
	 * @param query
	 *            The {@link Query} data object
	 * @return the target VirtualTable
	 */
	
	public static VirtualTable Query(Query query) throws DBException, VirtualTableException
	{
		query.prepare();
		query.execute();
		return query.getVirtualTable();
	}
	

	/**
	 * Opens a {@link XdevWindow} in a specific container.
	 * 
	 * @param openWindow
	 *            The {@link OpenWindow} data object
	 */
	
	public static void OpenWindow(OpenWindow openWindow)
	{
		openWindow.prepare();
		openWindow.execute();
	}
	

	/**
	 * Creates a data model for a {@link XdevTree}.
	 */
	public static void FillTree(FillTree fillTree) throws DBException, VirtualTableException
	{
		fillTree.prepare();
		fillTree.execute();
	}
}
