/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.event;


import java.util.EventListener;

import xdev.Application;


/**
 * Listener interface to observe the exit of the XDEV Application Framwork.
 * 
 * @see Application#addExitListener(ApplicationExitListener)
 * @see Application#removeExitListener(ApplicationExitListener)
 * 
 * @author XDEV Software
 * @since 3.0
 */
public interface ApplicationExitListener extends EventListener
{
	/**
	 * Invoked before the application will exit.
	 * <p>
	 * Call {@link ApplicationExitEvent#vetoExit()} to veto the exit process.
	 * 
	 * @param event
	 */
	public void applicationWillExit(ApplicationExitEvent event);
	

	/**
	 * Invoked after {@link #applicationWillExit(ApplicationExitEvent)} returns
	 * with no veto.
	 * 
	 * @param event
	 */
	public void applicationExits(ApplicationExitEvent event);
}
