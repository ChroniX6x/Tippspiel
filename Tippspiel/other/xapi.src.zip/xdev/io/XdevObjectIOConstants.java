/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.io;


public interface XdevObjectIOConstants
{
	public final static byte	OTHER			= -1;
	public final static byte	NULL			= 0;
	public final static byte	BYTE			= 1;
	public final static byte	SHORT			= 2;
	public final static byte	INTEGER			= 3;
	public final static byte	LONG			= 4;
	public final static byte	FLOAT			= 5;
	public final static byte	DOUBLE			= 6;
	public final static byte	BOOLEAN			= 7;
	public final static byte	CHAR			= 8;
	public final static byte	STRING			= 9;
	public final static byte	SQL_DATE		= 10;
	public final static byte	SQL_TIME		= 11;
	public final static byte	SQL_TIMESTAMP	= 12;
	public final static byte	UTIL_DATE		= 13;
	public final static byte	VERSION			= 14;
	public final static byte	BLOB			= 15;
	public final static byte	CLOB			= 16;
}
