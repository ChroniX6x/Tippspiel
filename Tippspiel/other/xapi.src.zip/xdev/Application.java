/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev;


import java.applet.Applet;
import java.applet.AppletStub;
import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.Image;
import java.awt.Window;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.net.URL;
import java.net.URLEncoder;
import java.security.Permission;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import javax.swing.JApplet;
import javax.swing.JComponent;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.event.EventListenerList;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import xdev.event.ApplicationExitEvent;
import xdev.event.ApplicationExitListener;
import xdev.ui.GraphicUtils;
import xdev.ui.XdevApplicationContainer;
import xdev.ui.XdevFocusTraversalPolicy;
import xdev.ui.XdevMainFrame;
import xdev.ui.XdevFullScreen;
import xdev.ui.XdevWindow;
import xdev.ui.laf.LookAndFeel;
import xdev.ui.laf.LookAndFeelManager;
import xdev.ui.laf.SystemLookAndFeel;
import xdev.util.Settings;
import xdev.util.XdevDate;
import xdev.util.logging.XdevLogger;


/**
 * 
 * This is the entry point of the XDEV Application Framework.
 * <p>
 * Desktop and webstart applications are started via the {@link #main(String[])}
 * method, applets per default via {@link #init()} and {@link #start()}.
 * <p>
 * The user application on top of the framework is started afterwards. This is
 * because runtime environment specific init routines of the framwork are
 * performed in this class.
 * <p>
 * The system parameter 'main' is used to define the user application's main
 * class. Ensure that this main class is in a package, not in the default
 * package.
 * <hr>
 * <p>
 * Desktop application:<br>
 * <br>
 * <code>java [vm args] -Dmain=myapp.Start xdev.Application [application args]</code>
 * <hr>
 * <p>
 * Applet:<br>
 * <br>
 * <code>
 * &lt;applet code="xdev.Application.class"&gt;<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;param name="main" value="myapp.Start" /&gt;<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;param...<br>
 * &lt;/applet&gt;
 * </code>
 * <hr>
 * <p>
 * Webstart:<br>
 * <br>
 * <code>
 * &lt;jnlp...<br>
 * ...<br>
 * &lt;resources&gt;<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;property name="application.type" value="webstart" /&gt;<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;property name="main" value="start.Main" /&gt;<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;property...<br>
 * &lt;/resources&gt;<br>
 * ...<br>
 * &lt;application-desc main-class="xdev.Application"&gt;<br>
 * &nbsp;&nbsp;&nbsp;&nbsp;&lt;argument...<br>
 * &lt;/application-desc&gt;<br>
 * ...<br>
 * &lt;/jnlp&gt;
 * </code>
 * <hr>
 * 
 * @see #main(String[])
 * @see #initApplication(String[])
 * @see #startApplication()
 * @see #isApplet()
 * @see #isApplication()
 * @see #isWebstart()
 * 
 * @author XDEV Software
 * @since 3.0
 */

public final class Application extends JApplet implements AppletStub, XdevApplicationContainer
{
	/**
	 * Application type constant.
	 */
	public final static int	APPLICATION	= 0;
	
	/**
	 * Application type constant.
	 */
	public final static int	APPLET		= 1;
	
	/**
	 * Application type constant.
	 */
	public final static int	WEBSTART	= 2;
	
	private static int		type		= APPLICATION;
	

	/**
	 * @return The application's type. Either {@link #APPLICATION},
	 *         {@link #APPLET} or {@link #WEBSTART}
	 */
	
	public static int getType()
	{
		return type;
	}
	

	/**
	 * @return <code>true</code> if this is a desktop application started via
	 *         {@link #main(String[])}, <code>false</code> otherwise
	 */
	
	public static boolean isApplication()
	{
		return type == APPLICATION;
	}
	

	/**
	 * @return <code>true</code> if this is a applet running in a browser or
	 *         another applet container, <code>false</code> otherwise
	 */
	
	public static boolean isApplet()
	{
		return type == APPLET;
	}
	

	/**
	 * @return <code>true</code> if this is a webstart application started via a
	 *         webstart descriptor, <code>false</code> otherwise
	 */
	
	public static boolean isWebstart()
	{
		return type == WEBSTART;
	}
	
	private static String[]					args;
	private static EventListenerList		listenerList	= new EventListenerList();
	private static XdevApplicationContainer	container		= null;
	private static Image					appIcon			= null;
	private static boolean					fullscreen		= false;
	private static long						serverTimeDiff	= 0;
	private static boolean					initialized		= false;
	private static XdevLogger				logger			= null;
	private static Map<String, Extension>	extensions		= new HashMap();
	

	/**
	 * Returns the extension named <code>name</code> or <code>null</code> if not
	 * found.
	 * <p>
	 * Note: The extensions are only available after {@link #init()} has been
	 * called.
	 * 
	 * @param name
	 *            the extension's name
	 * @return the appropriate extension or <code>null</code>
	 */
	public static Extension getExtension(String name)
	{
		return extensions.get(name);
	}
	

	/**
	 * Returns all available extensions.
	 * <p>
	 * Note: The extensions are only available after {@link #init()} has been
	 * called.
	 * 
	 * @return All available extensions.
	 */
	public static Extension[] getExtensions()
	{
		return extensions.values().toArray(new Extension[extensions.size()]);
	}
	

	/**
	 * This is the entry point of the XDEV Application Framwork for desktop and
	 * webstart appications.
	 * <p>
	 * It initializes the framework and starts the application based on the
	 * framework.
	 * <p>
	 * First {@link #initApplication(String[])} is called, then
	 * {@link #startApplication()}.
	 * 
	 * <p>
	 * <strong>Hint:</strong> Can be used to start {@link XdevWindow}s.
	 * Therefore set the VM Argument
	 * <code>-Dmain=FULL_QUALIFIED_CLASSNAME</code>. Where
	 * <code>FULL_QUALIFIED_CLASSNAME</code> is the full qualified classname
	 * like <i>xdev.ui.MyClass</i>.
	 * </p>
	 * 
	 * @param args
	 *            The application's arguments
	 */
	
	public static void main(String[] args)
	{
		initApplication(args);
		startApplication();
	}
	

	/**
	 * Initializes the XDEV Application Framework.
	 * <ul>
	 * <li>Determines whether this is a desktop or a webstart application</li>
	 * <li>Sets the look and feel to the system's default</li>
	 * <li>Evaluates the application's arguments <code>args</code></li>
	 * <li>Initializes the applications top level container: a frame, a
	 * fullscreen window if the system property <code>fullscreen</code> is
	 * <code>true</code> or an applet</li>
	 * </ul>
	 * <p>
	 * This method is called by {@link #main(String[])}.
	 * <p>
	 * If you want to start your application without using
	 * {@link #main(String[])} of this class, call
	 * {@link #initApplication(String[])} at the beginning of your application
	 * to initialize the XDEV Application Framwork properly.
	 * 
	 * @param args
	 *            The application's arguments
	 */
	
	public static void initApplication(String[] args)
	{
		initApplicationImpl(args,"webstart".equalsIgnoreCase(System.getProperty("application.type",
				"")) ? WEBSTART : APPLICATION);
	}
	

	private static void initApplicationImpl(String[] args, int type)
	{
		Application.type = type;
		
		try
		{
			Application.args = args != null ? args : new String[0];
			
			String icon = System.getProperty("icon");
			if(icon != null && icon.length() > 0)
			{
				try
				{
					appIcon = GraphicUtils.loadImagePlain(icon);
				}
				catch(IOException e)
				{
				}
			}
			
			URL url = Application.class.getResource("Extensions");
			if(url != null)
			{
				try
				{
					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
					DocumentBuilder builder = factory.newDocumentBuilder();
					Document doc = builder.parse(url.openStream());
					doc.getDocumentElement().normalize();
					NodeList children = doc.getElementsByTagName("extension");
					for(int i = 0, c = children.getLength(); i < c; i++)
					{
						Element child = (Element)children.item(i);
						String extensionClassName = child.getAttribute("class");
						Extension extension = (Extension)Class.forName(extensionClassName)
								.newInstance();
						Map<String, String> params = new HashMap();
						NodeList paramElements = child.getElementsByTagName("param");
						for(int p = 0, pc = paramElements.getLength(); p < pc; p++)
						{
							Element paramElement = (Element)paramElements.item(i);
							params.put(paramElement.getAttribute("name"),
									paramElement.getAttribute("value"));
						}
						try
						{
							extension.init(params);
						}
						catch(ExtensionInitializationException eie)
						{
							getLogger().error(eie);
						}
					}
				}
				catch(Exception e)
				{
					getLogger().error(e);
				}
			}
			
			LookAndFeel laf = null;
			String lafName = System.getProperty("laf");
			if(lafName != null && lafName.length() > 0)
			{
				laf = (LookAndFeel)Class.forName(lafName).newInstance();
			}
			if(laf == null)
			{
				laf = new SystemLookAndFeel();
			}
			LookAndFeelManager.setLookAndFeel(laf);
		}
		catch(Exception e)
		{
			getLogger().error(e);
		}
		finally
		{
			initialized = true;
		}
		
		if(container == null)
		{
			fullscreen = Settings.checkUserSetting(System.getProperty("fullscreen"));
			if(fullscreen)
			{
				container = new XdevFullScreen();
			}
			else
			{
				container = new XdevMainFrame();
			}
		}
	}
	

	/**
	 * Starts the application after the XDEV application framwork has been
	 * initialized.
	 * <p>
	 * This method is called by {@link #main(String[])} after
	 * {@link #initApplication(String[])}.
	 * <p>
	 * The system property main is used to determine the main class.
	 * <ul>
	 * <li>If the class has a valid main method, it is called with the arguments
	 * handed over in {@link #initApplication(String[])}.</li>
	 * <li>If the class is an instance of {@link XdevWindow} it is initialized
	 * via the default constructor and shown in the application's top level
	 * container.</li>
	 * <li>If the class is an instance of {@link JComponent} it is initialized
	 * via the default constructor, placed in a {@link XdevWindow} and shown in
	 * the application's top level container.</li>
	 * </ul>
	 * 
	 * @throws IllegalStateException
	 *             if the framework has not been initialized via
	 *             {@link #initApplication(String[])}
	 * 
	 * @see #main(String[])
	 * @see #initApplication(String[])
	 */
	
	public static void startApplication() throws IllegalStateException
	{
		startApplicationImpl(System.getProperty("main"));
	}
	

	private static void startApplicationImpl(String main) throws IllegalStateException
	{
		if(!initialized)
		{
			throw new IllegalStateException("XDEV Application Framework has not been initialized "
					+ "(Application.initApplication(String[]");
		}
		
		if(main != null && main.length() > 0)
		{
			try
			{
				Class mainClass = Class.forName(main);
				try
				{
					mainClass.getMethod("main",String[].class).invoke(null,(Object)args);
				}
				catch(NoSuchMethodException nsme)
				{
					try
					{
						mainClass.getDeclaredConstructor(new Class[0]);
					}
					catch(NoSuchMethodException e)
					{
						throw new IllegalArgumentException(main + " has no default constructor");
					}
					
					if(XdevWindow.class.isAssignableFrom(mainClass))
					{
						XdevWindow window = (XdevWindow)mainClass.newInstance();
						container.setXdevWindow(window);
						container.pack();
						container.setLocationRelativeTo(null);
						container.setVisible(true);
					}
					else if(JComponent.class.isAssignableFrom(mainClass))
					{
						JComponent cpn = (JComponent)mainClass.newInstance();
						XdevWindow window = new XdevWindow();
						window.setLayout(new BorderLayout());
						window.add(cpn,BorderLayout.CENTER);
						container.setXdevWindow(window);
						container.pack();
						container.setLocationRelativeTo(null);
						container.setVisible(true);
					}
					else
					{
						throw new IllegalArgumentException(main
								+ " has no main method nor is a bean");
					}
				}
			}
			catch(Exception e)
			{
				Throwable t = e;
				if(e instanceof InvocationTargetException)
				{
					Throwable cause = e.getCause();
					if(cause != null)
					{
						t = cause;
					}
				}
				
				t.printStackTrace();
			}
		}
	}
	

	/**
	 * Return the arguments handed over to the application in
	 * {@link #main(String[])}.
	 * 
	 * @return The application's arguments
	 * @throws IllegalStateException
	 *             if this {@link Application} is an {@link Applet}
	 * @see #getType()
	 */
	
	public static String[] getArguments() throws IllegalStateException
	{
		if(type == APPLET)
		{
			throw new IllegalStateException("application is an applet");
		}
		
		return args;
	}
	

	/**
	 * Returns the value of the named parameter in the HTML tag. For example, if
	 * this applet is specified as
	 * 
	 * <pre>
	 * <applet code="Clock" width=50 height=50>
	 * <param name="Color" value="blue"/>
	 * 
	 * </pre>
	 * 
	 * then a call to getParameter("Color") returns the value "blue".
	 * <p>
	 * The name argument is case insensitive.
	 * </p>
	 * 
	 * @param name
	 *            a parameter name.
	 * @return the value of the named parameter, or null if not set.
	 * @throws IllegalStateException
	 *             if this {@link Application} is not an {@link Applet}
	 * @see #getType()
	 */
	public static String getParam(String name) throws IllegalStateException
	{
		if(type == APPLET && container instanceof Applet)
		{
			return ((Applet)container).getParameter(name);
		}
		
		throw new IllegalStateException("not an applet");
	}
	

	public static Image getIconImage()
	{
		return appIcon;
	}
	

	/**
	 * Returns the applications top level container.
	 * <p>
	 * It is either a frame, a fullscreen window or an applet.
	 * 
	 * @return The application's top level container
	 */
	
	public static XdevApplicationContainer getContainer()
	{
		return container;
	}
	

	/**
	 * Returns the {@link XdevLogger} of this Application which is used to log
	 * messages for the XDEV Application Framework.
	 * 
	 * @return the {@link XdevLogger} of this Application.
	 */
	public static XdevLogger getLogger()
	{
		if(logger == null)
		{
			logger = new XdevLogger();
		}
		
		return logger;
	}
	

	/**
	 * Registers an {@link ApplicationExitListener} to obsorve the exit of this
	 * {@link Application}.
	 * 
	 * @param l
	 *            the listener to add
	 */
	public static void addExitListener(ApplicationExitListener l)
	{
		listenerList.add(ApplicationExitListener.class,l);
	}
	

	/**
	 * Removes the {@link ApplicationExitListener} <code>l</code> from this
	 * {@link Application}.
	 * 
	 * @param l
	 *            the listener to remove
	 */
	public static void removeExitListener(ApplicationExitListener l)
	{
		listenerList.remove(ApplicationExitListener.class,l);
	}
	

	/**
	 * Exits the current running XDEV Application Framwork and Java Virtual
	 * Machine.
	 * <p>
	 * If a registered {@link ApplicationExitListener} vetos the process, the
	 * exit is terminated and the XDEV Application Framework remains running.
	 * 
	 * @param source
	 *            The initiator of the exit process
	 * @see ApplicationExitListener
	 * @see ApplicationExitEvent#vetoExit()
	 */
	public static void exit(Object source)
	{
		ApplicationExitListener[] listeners = listenerList
				.getListeners(ApplicationExitListener.class);
		if(listeners != null && listeners.length > 0)
		{
			ApplicationExitEvent event = new ApplicationExitEvent(source);
			
			for(ApplicationExitListener l : listeners)
			{
				l.applicationWillExit(event);
			}
			
			if(event.hasVeto())
			{
				return;
			}
			
			for(ApplicationExitListener l : listeners)
			{
				l.applicationExits(event);
			}
		}
		
		// HSQL.shutdownIfRunning();
		
		System.exit(0);
	}
	

	/**
	 * Returns the time of the hosting server of this applet / webstart
	 * application.
	 * 
	 * @return The server time of this application.
	 */
	public static XdevDate getServerTime()
	{
		return new XdevDate(System.currentTimeMillis() + serverTimeDiff);
	}
	
	private static Runnable	gc;
	static
	{
		gc = new Runnable()
		{
			public void run()
			{
				System.gc();
			}
		};
	}
	

	/**
	 * Runs the garbage collector.
	 * <p>
	 * Calling the gc method suggests that the Java Virtual Machine expend
	 * effort toward recycling unused objects in order to make the memory they
	 * currently occupy available for quick reuse. When control returns from the
	 * method call, the Java Virtual Machine has made a best effort to reclaim
	 * space from all discarded objects.
	 * </p>
	 */
	public static void gc()
	{
		SwingUtilities.invokeLater(gc);
	}
	

	/**
	 * Returns the default {@link GraphicsConfiguration} associated with the
	 * {@link GraphicsDevice} this application is showing on.
	 * 
	 * @return the default {@link GraphicsConfiguration} of this
	 *         {@link GraphicsDevice}.
	 */
	public static GraphicsConfiguration getLocalGraphicsConfiguration()
	{
		if(container != null)
		{
			return container.getGraphicsConfiguration();
		}
		
		return GraphicsEnvironment.getLocalGraphicsEnvironment().getDefaultScreenDevice()
				.getDefaultConfiguration();
	}
	

	/*
	 * ---------------------------- Applet---------------------------
	 */

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void init()
	{
		try
		{
			System.setSecurityManager(new SecurityManager()
			{
				@Override
				public void checkPermission(Permission perm)
				{
				}
				

				@Override
				public void checkPermission(Permission perm, Object context)
				{
				}
			});
		}
		catch(Throwable t)
		{
		}
		
		getContentPane().setLayout(new BorderLayout());
		
		container = this;
		
		try
		{
			serverTimeDiff = Long.parseLong(getParameter("serverTimeMillis")) * 1000
					- System.currentTimeMillis();
		}
		catch(Exception e)
		{
			serverTimeDiff = 0;
		}
		
		try
		{
			fullscreen = "true".equals(getParameter("fullscreen"));
		}
		catch(Exception e)
		{
			fullscreen = false;
		}
		
		try
		{
			String value = getParameter("suffix");
			if(value != null && value.length() > 0)
			{
				System.setProperty(Settings.SERVER_SIDE_SUFFIX,value);
			}
		}
		catch(Exception e)
		{
			getLogger().error(e);
		}
		
		setFocusTraversalPolicy(new XdevFocusTraversalPolicy(this));
		
		try
		{
			String vmArgs = getParameter("java_args");
			if(vmArgs != null && vmArgs.length() > 0)
			{
				StringTokenizer st = new StringTokenizer(vmArgs," ");
				while(st.hasMoreTokens())
				{
					String token = st.nextToken().trim();
					if(token.startsWith("-D"))
					{
						int index = token.indexOf('=');
						if(index == -1)
						{
							System.setProperty(token.substring(2),"true");
						}
						else
						{
							System.setProperty(token.substring(2,index),token.substring(index + 1));
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			getLogger().error(e);
		}
		
		initApplicationImpl(null,APPLET);
		
		System.out.println("XDEV Application Framework " + API.VERSION.toScreen());
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void start()
	{
		startApplicationImpl(getParameter("main"));
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void destroy()
	{
		System.gc();
		exit(this);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Window getWindow()
	{
		return JOptionPane.getRootFrame();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Image getImage(URL url)
	{
		return getAppletContext().getImage(url);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void showDocument(URL url)
	{
		getAppletContext().showDocument(url);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void showDocument(URL url, String target)
	{
		getAppletContext().showDocument(url,target);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void appletResize(int width, int height)
	{
		resize(width,height);
	}
	
	private XdevWindow	window;
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setXdevWindow(XdevWindow window)
	{
		cleanUp();
		
		this.window = window;
		
		window.setOwner(this);
		
		String width;
		String height;
		if(fullscreen)
		{
			width = height = "\"100%\"";
		}
		else
		{
			Dimension ps = window.getPreferredSize();
			width = "\"" + ps.width + "px\"";
			height = "\"" + ps.height + "px\"";
		}
		
		setJMenuBar(window.getJMenuBar());
		getRootPane().setDefaultButton(window.getDefaultButton());
		getContentPane().add(Util.createContainer(this,window));
		
		jsc("resize","width",width,"height",height);
		
		validate();
		repaint();
		
		window.fireWindowOpened(new WindowEvent(SwingUtilities.getWindowAncestor(this),0));
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public XdevWindow getXdevWindow()
	{
		return window;
	}
	

	private void cleanUp()
	{
		try
		{
			getRootPane().setJMenuBar(null);
			getContentPane().removeAll();
			
			if(window != null)
			{
				window.cleanUp();
				window = null;
			}
		}
		catch(Exception e)
		{
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setTitle(String title)
	{
		jsc("setTitle","title",jsc_escape(title));
	}
	

	private void jsc(String action, String... params)
	{
		try
		{
			StringBuilder sb = new StringBuilder();
			sb.append("jsc.");
			sb.append(Settings.getServerSideSuffix());
			sb.append("?action=");
			sb.append(action);
			for(int i = 0; i < params.length; i += 2)
			{
				sb.append("&");
				sb.append(params[i]);
				sb.append("=");
				sb.append(URLEncoder.encode(params[i + 1],"UTF8"));
			}
			
			showDocument(new URL(Application.getContainer().getCodeBase(),sb.toString()),"jsc");
		}
		catch(Exception e)
		{
			getLogger().error(e);
		}
	}
	

	private String jsc_escape(String str)
	{
		int len = str.length();
		StringBuilder sb = new StringBuilder(len + 2);
		sb.append("'");
		for(int i = 0; i < len; i++)
		{
			char ch = str.charAt(i);
			if(ch == '\'')
			{
				sb.append('\\');
			}
			sb.append(ch);
		}
		sb.append("'");
		return sb.toString();
	}
	

	/**
	 * Implemented with no action for {@link XdevApplicationContainer}.
	 */
	@Override
	public void setIconImage(Image img)
	{
		// no op
	}
	

	/**
	 * Implemented with no action for {@link XdevApplicationContainer}.
	 */
	@Override
	public void pack()
	{
		// no op
	}
	

	/**
	 * Implemented with no action for {@link XdevApplicationContainer}.
	 */
	@Override
	public void setLocationRelativeTo(Component c)
	{
		// no op
	}
	

	/**
	 * Implemented with no action for {@link XdevApplicationContainer}.
	 */
	@Override
	public void setResizable(boolean b)
	{
		// no op
	}
	

	/**
	 * Implemented with no action for {@link XdevApplicationContainer}.
	 */
	@Override
	public void toFront()
	{
		// no op
	}
	

	/**
	 * Implemented with no action for {@link XdevApplicationContainer}.
	 */
	@Override
	public void toBack()
	{
		// no op
	}
	

	/**
	 * Implemented with no action for {@link XdevApplicationContainer}.
	 */
	@Override
	public void addWindowListener(WindowListener listener)
	{
		// no op
	}
}
