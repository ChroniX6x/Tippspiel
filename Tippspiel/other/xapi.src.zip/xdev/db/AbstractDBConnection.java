/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db;


import java.lang.reflect.Field;
import java.util.List;
import java.util.Vector;

import net.jadoth.sqlengine.internal.DatabaseGateway;
import xdev.db.event.DBConnectionEvent;
import xdev.db.event.DBConnectionListener;


/**
 * <P>
 * A abstract class from the <code>DBConnection</code>. A connection (session)
 * with a specific database. SQL statements are executed and results are
 * returned within the context of a connection.
 * </P>
 * 
 * @param <DS>
 *            the generic type
 * 
 * @see DBDataSource
 * @see DBConnection
 * 
 * @author XDEV Software
 * 
 */
public abstract class AbstractDBConnection<DS extends DBDataSource<DS>> implements DBConnection<DS>
{
	protected final DS						dataSource;
	
	protected List<DBConnectionListener>	listeners		= new Vector();
	
	private boolean							storeQueries	= false;
	private final List<Query>				queries			= new Vector();
	

	/**
	 * Constructs a {@link AbstractDBConnection} that is initialized with the
	 * originating data source.
	 * 
	 * @param dataSource
	 *            The originating data source
	 */
	public AbstractDBConnection(DS dataSource)
	{
		this.dataSource = dataSource;
	}
	

	/**
	 * Returns the data source of this {@link AbstractDBConnection}.
	 * 
	 * @return this connection's originating data source
	 */
	public DS getDataSource()
	{
		return dataSource;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void addDBConnectionListener(DBConnectionListener l)
	{
		listeners.add(l);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void removeDBConnectionListener(DBConnectionListener l)
	{
		listeners.remove(l);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DBConnectionListener[] getDBConnectionListeners()
	{
		return listeners.toArray(new DBConnectionListener[listeners.size()]);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void setStoreQueries(boolean store)
	{
		this.storeQueries = store;
		if(!storeQueries)
		{
			queries.clear();
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public Query[] getStoredQueries()
	{
		return queries.toArray(new Query[queries.size()]);
	}
	

	protected void queryPerformed(String statement, Object[] params, DBException exception)
	{
		Query query = new Query(statement,params);
		if(storeQueries)
		{
			queries.add(query);
		}
		
		if(listeners.size() > 0)
		{
			DBConnectionEvent event = new DBConnectionEvent(this);
			event.setQuery(query);
			event.setException(exception);
			for(DBConnectionListener listener : listeners)
			{
				listener.queryPerformed(event);
			}
		}
	}
	

	protected void writePerformed(String statement, Object[] params, DBException exception)
	{
		Query query = new Query(statement,params);
		if(storeQueries)
		{
			queries.add(query);
		}
		
		if(listeners.size() > 0)
		{
			DBConnectionEvent event = new DBConnectionEvent(this);
			event.setQuery(query);
			event.setException(exception);
			for(DBConnectionListener listener : listeners)
			{
				listener.writePerformed(event);
			}
		}
	}
	

	/**
	 * Quick and dirty way to inject the gateway into a xdev.db.sql object
	 */
	protected void decorateDelegate(Object query, DatabaseGateway gateway)
	{
		try
		{
			Field field = query.getClass().getDeclaredField("delegate");
			boolean accessible = field.isAccessible();
			if(!accessible)
			{
				field.setAccessible(true);
			}
			net.jadoth.sqlengine.types.Query _query = (net.jadoth.sqlengine.types.Query)field
					.get(query);
			_query.setDatabaseGateway(gateway);
			if(!accessible)
			{
				field.setAccessible(false);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
