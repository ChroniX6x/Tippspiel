/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db.servlet;


interface ServletServiceConstants
{
	byte[]	HANDSHAKE							= new byte[]{0x11,0x1B,0x07,0x03};
	
	String	SESSIONID_PARAM						= "sid";
	String	KEY_PARAM							= "key";
	String	KEY_FROM_CERT						= "$CERT";
	
	String	SECRET_KEY_ALGORITHM				= "DESede";
	String	KEY_EXCHANGE_ALGORITHM				= "DH";
	String	MAC_ALGORITHM						= "DESede/ECB/PKCS5Padding";
	
	byte	REQUEST_TEST_CONNECTION				= 1;
	
	byte	REQUEST_METADATA					= 10;
	byte	REQUEST_METADATA_TABLE_INFOS		= 11;
	byte	REQUEST_METADATA_TABLE_METADATA		= 12;
	byte	REQUEST_METADATA_STORED_PROCEDURES	= 13;
	byte	REQUEST_METADATA_ERS				= 14;
	byte	REQUEST_METADATA_SYNC				= 15;
	
	byte	REQUEST_QUERY_SQL					= 20;
	byte	REQUEST_GET_QUERY_ROW_COUNT			= 21;
	byte	REQUEST_WRITE_SQL_RGK				= 22;
	byte	REQUEST_WRITE_SQL_COLS				= 23;
	byte	REQUEST_WRITE_SQL					= 24;
	byte	REQUEST_STORED_PROCEDURE			= 25;
	byte	REQUEST_BEGIN_TRANSACTION			= 26;
	byte	REQUEST_SET_SAVEPOINT				= 27;
	byte	REQUEST_SET_SAVEPOINT_NAME			= 28;
	byte	REQUEST_RELEASE_SAVEPOINT			= 29;
	byte	REQUEST_COMMIT						= 30;
	byte	REQUEST_ROLLBACK					= 31;
	byte	REQUEST_ROLLBACK_SAVEPOINT			= 32;
	
	byte	RESPONSE_OK							= 0;
	byte	RESPONSE_EXCEPTION					= 1;
	
	byte	RESPONSE_STORED_PROCEDURE_VOID		= 0;
	byte	RESPONSE_STORED_PROCEDURE_RESULT	= 1;
	byte	RESPONSE_STORED_PROCEDURE_OBJECT	= 2;
}
