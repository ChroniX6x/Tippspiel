/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db.servlet;


import java.util.ArrayList;
import java.util.List;

import xdev.db.ColumnMetaData;
import xdev.db.Result;
import xdev.io.XdevObjectInputStream;
import xdev.io.XdevObjectOutputStream;


public class ServletResult extends Result
{
	public static void write(Result result, XdevObjectOutputStream out) throws Exception
	{
		int colCount = result.getColumnCount();
		out.writeInt(colCount);

		for(int i = 0; i < colCount; i++)
		{
			out.writeObject(result.getMetadata(i));
		}

		while(result.next())
		{
			out.writeBoolean(true);
			for(int col = 0; col < colCount; col++)
			{
				out.writeObject(result.getObject(col));
			}
		}
		out.writeBoolean(false);
	}

	private int					colCount;
	private ColumnMetaData[]	metadata;

	private Object[][]			data;
	private int					currentRow		= -1;
	private int					traversedRows	= 0;


	public ServletResult(XdevObjectInputStream in) throws Exception
	{
		colCount = in.readInt();

		metadata = new ColumnMetaData[colCount];
		for(int i = 0; i < colCount; i++)
		{
			metadata[i] = (ColumnMetaData)in.readObject();
		}

		List<Object[]> list = new ArrayList();
		while(in.readBoolean())
		{
			Object[] rowData = new Object[colCount];
			for(int col = 0; col < colCount; col++)
			{
				rowData[col] = in.readObject();
			}
			list.add(rowData);
		}
		this.data = new Object[list.size()][];
		list.toArray(this.data);
	}


	@Override
	public synchronized boolean next()
	{
		Integer maxRowCount = getMaxRowCount();
		if(maxRowCount != null && traversedRows >= maxRowCount)
		{
			return false;
		}

		if(++currentRow < data.length)
		{
			traversedRows++;
			return true;
		}
		
		return false;
	}


	@Override
	public synchronized int skip(int count)
	{
		currentRow += count;
		return count;
	}


	@Override
	public Object getObject(int col)
	{
		return data[currentRow][col];
	}


	@Override
	public int getColumnCount()
	{
		return colCount;
	}


	@Override
	public ColumnMetaData getMetadata(int col)
	{
		return metadata[col];
	}


	@Override
	public void close()
	{
		metadata = null;
		data = null;
	}
}
