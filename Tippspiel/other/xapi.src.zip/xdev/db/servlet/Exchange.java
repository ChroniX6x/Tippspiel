/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db.servlet;


import java.net.URL;
import java.net.URLConnection;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;

import xdev.io.XdevObjectInputStream;
import xdev.io.XdevObjectOutputStream;


abstract class Exchange<Response> implements ServletServiceConstants
{
	private SessionInfo				info;
	private URLConnection			con;
	private XdevObjectInputStream	in;
	private XdevObjectOutputStream	out;
	

	Exchange(SessionInfo info) throws Exception
	{
		this.info = info;
		
		StringBuilder sb = new StringBuilder(info.getURL());
		sb.append("?");
		sb.append(SESSIONID_PARAM);
		sb.append("=");
		sb.append(info.getSessionID());
		
		con = new URL(sb.toString()).openConnection();
		con.setDoOutput(true);
		
		Cipher cipher = Cipher.getInstance(MAC_ALGORITHM);
		cipher.init(Cipher.ENCRYPT_MODE,info.getSecretKey());
		
		out = new XdevObjectOutputStream(new CipherOutputStream(con.getOutputStream(),cipher));
		out.write(HANDSHAKE);
		out.writeUTF(info.getAuthKey());
	}
	

	final Response exec() throws Exception
	{
		try
		{
			sendRequest(out);
			
			out.close();
			out = null;
			
			Cipher cipher = Cipher.getInstance(MAC_ALGORITHM);
			cipher.init(Cipher.DECRYPT_MODE,info.getSecretKey());
			
			in = new XdevObjectInputStream(new CipherInputStream(con.getInputStream(),cipher),info
					.getDataSource().original);
			
			byte response = in.readByte();
			
			switch(response)
			{
				case RESPONSE_EXCEPTION:
				{
					throw (Exception)in.readObject();
				}
			}
			
			return readResponse(in);
		}
		finally
		{
			try
			{
				if(out != null)
				{
					out.close();
				}
				
				if(in != null)
				{
					in.close();
				}
			}
			catch(Exception e)
			{
			}
		}
	}
	

	abstract void sendRequest(XdevObjectOutputStream out) throws Exception;
	

	abstract Response readResponse(XdevObjectInputStream in) throws Exception;
}
