/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db.servlet;


import java.util.EnumSet;

import xdev.db.AbstractDBMetaData;
import xdev.db.ColumnMetaData;
import xdev.db.DBException;
import xdev.db.DBMetaData;
import xdev.db.StoredProcedure;
import xdev.db.DBConnection.Query;
import xdev.util.ProgressMonitor;
import xdev.vt.EntityRelationshipModel;


public class ServletDBMetaData extends AbstractDBMetaData
{
	private static final long			serialVersionUID	= 1L;
	
	private final ServletDBDataSource	dataSource;
	/**
	 * disconnected original datasource.
	 */
	private final DBMetaData			original;
	

	public ServletDBMetaData(ServletDBDataSource dataSource, DBMetaData original)
	{
		this.dataSource = dataSource;
		this.original = original;
	}
	

	@Override
	public String getName()
	{
		return original.getName();
	}
	

	@Override
	public String getVersion()
	{
		return original.getVersion();
	}
	

	@Override
	public boolean isCaseSensitive() throws DBException
	{
		return original.isCaseSensitive();
	}
	

	@Override
	public TableInfo[] getTableInfos(ProgressMonitor monitor, EnumSet<TableType> types)
			throws DBException
	{
		ServletDBConnection connection = (ServletDBConnection)dataSource.openConnection();
		try
		{
			return connection.getTableInfos(types);
		}
		finally
		{
			connection.close();
		}
	}
	

	@Override
	public TableMetaData[] getTableMetaData(ProgressMonitor monitor, int flags, TableInfo... tables)
			throws DBException
	{
		ServletDBConnection connection = (ServletDBConnection)dataSource.openConnection();
		try
		{
			return connection.getTableMetaData(flags,tables);
		}
		finally
		{
			connection.close();
		}
	}
	

	@Override
	public StoredProcedure[] getStoredProcedures(ProgressMonitor monitor) throws DBException
	{
		ServletDBConnection connection = (ServletDBConnection)dataSource.openConnection();
		try
		{
			return connection.getStoredProcedures();
		}
		finally
		{
			connection.close();
		}
	}
	

	@Override
	public EntityRelationshipModel getEntityRelationshipModel(ProgressMonitor monitor,
			TableInfo... tables) throws DBException
	{
		ServletDBConnection connection = (ServletDBConnection)dataSource.openConnection();
		try
		{
			return connection.getEntityRelationshipModel(tables);
		}
		finally
		{
			connection.close();
		}
	}
	

	@Override
	public boolean equalsType(ColumnMetaData clientColumn, ColumnMetaData dbColumn)
	{
		return original.equalsType(clientColumn,dbColumn);
	}
	

	@Override
	public Query[] synchronizeTables(ProgressMonitor monitor, TableChange... changes)
			throws DBException
	{
		if(!dataSource.canExport())
		{
			throw new UnsupportedOperationException();
		}
		
		ServletDBConnection connection = (ServletDBConnection)dataSource.openConnection();
		try
		{
			return connection.synchronizeTables(changes);
		}
		finally
		{
			connection.close();
		}
	}
}
