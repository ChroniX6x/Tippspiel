/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db.servlet;


import javax.crypto.SecretKey;


class SessionInfo
{
	private final ServletDBDataSource	dataSource;
	private final String				url;
	private final String				sessionID;
	private final String				authKey;
	private final SecretKey				secretKey;
	

	SessionInfo(ServletDBDataSource dataSource, String url, String sessionID, String authKey,
			SecretKey secretKey)
	{
		this.dataSource = dataSource;
		this.url = url;
		this.sessionID = sessionID;
		this.authKey = authKey;
		this.secretKey = secretKey;
	}
	

	ServletDBDataSource getDataSource()
	{
		return dataSource;
	}
	

	String getURL()
	{
		return url;
	}
	

	String getSessionID()
	{
		return sessionID;
	}
	

	String getAuthKey()
	{
		return authKey;
	}
	

	SecretKey getSecretKey()
	{
		return secretKey;
	}
}
