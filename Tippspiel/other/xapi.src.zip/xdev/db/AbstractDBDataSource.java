/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db;


import java.util.List;
import java.util.Random;
import java.util.Vector;

import xdev.db.event.DBDataSourceEvent;
import xdev.db.event.DBDataSourceListener;
import xdev.util.AbstractDataSource;
import xdev.util.auth.Password;


/**
 * 
 * 
 * @see DBDataSource
 * @see AbstractDataSource
 * 
 * @author XDEV Software
 * 
 */
// TODO javadoc (class description)
public abstract class AbstractDBDataSource<T extends DBDataSource<T>> extends AbstractDataSource<T>
		implements DBDataSource<T>
{
	public final static Parameter<String>	HOST;
	public final static Parameter<Integer>	PORT;
	public final static Parameter<String>	USERNAME;
	public final static Parameter<Password>	PASSWORD;
	public final static Parameter<String>	CATALOG;
	public final static Parameter<String>	SCHEMA;
	public final static Parameter<Integer>	CONNECTION_POOL_SIZE;
	public final static Parameter<Boolean>	KEEP_CONNECTIONS_ALIVE;
	public final static Parameter<Boolean>	IS_SERVER_DATASOURCE;
	public final static Parameter<String>	SERVER_URL;
	public final static Parameter<String>	AUTH_KEY;
	
	static
	{
		HOST = new Parameter("host","localhost");
		PORT = new Parameter("port",0);
		USERNAME = new Parameter("username","");
		PASSWORD = new Parameter("password",new Password(""));
		CATALOG = new Parameter("catalog","");
		SCHEMA = new Parameter("schema","");
		CONNECTION_POOL_SIZE = new Parameter("connectionPoolSize",-1);
		KEEP_CONNECTIONS_ALIVE = new Parameter("keepConnectionsAlive",true);
		IS_SERVER_DATASOURCE = new Parameter("isServerDataSource",false);
		SERVER_URL = new Parameter("serverURL","http://localhost:8080/servlet/");
		AUTH_KEY = new Parameter("authKey",Long.toHexString(System.nanoTime()).toUpperCase()
				.concat(Long.toHexString(new Random().nextLong()).toUpperCase()));
		
		rankParams(HOST,PORT,USERNAME,PASSWORD,CATALOG,SCHEMA,CONNECTION_POOL_SIZE,
				KEEP_CONNECTIONS_ALIVE,IS_SERVER_DATASOURCE,SERVER_URL,AUTH_KEY);
	}
	
	protected List<DBDataSourceListener>	listeners	= new Vector();
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void addDBDataSourceListener(DBDataSourceListener l)
	{
		listeners.add(l);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public void removeDBDataSourceListener(DBDataSourceListener l)
	{
		listeners.remove(l);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DBDataSourceListener[] getDBDataSourceListeners()
	{
		return listeners.toArray(new DBDataSourceListener[listeners.size()]);
	}
	

	/**
	 * Returns the host of this {@link AbstractDBDataSource}.
	 * 
	 * @return the host of this {@link AbstractDBDataSource}
	 */
	public String getHost()
	{
		return getParameterValue(HOST);
	}
	

	/**
	 * Returns the port of this {@link AbstractDBDataSource}.
	 * 
	 * @return the port of this {@link AbstractDBDataSource}
	 */
	public int getPort()
	{
		return getParameterValue(PORT);
	}
	

	/**
	 * Returns the user name of this {@link AbstractDBDataSource}.
	 * 
	 * @return the user name of this {@link AbstractDBDataSource}
	 */
	public String getUserName()
	{
		return getParameterValue(USERNAME);
	}
	

	/**
	 * Returns the password of this {@link AbstractDBDataSource}.
	 * 
	 * @return the password of this {@link AbstractDBDataSource}
	 */
	public Password getPassword()
	{
		return getParameterValue(PASSWORD);
	}
	

	/**
	 * Returns the catalog of this {@link AbstractDBDataSource}.
	 * 
	 * @return the catalog of this {@link AbstractDBDataSource}
	 */
	public String getCatalog()
	{
		return getParameterValue(CATALOG);
	}
	

	/**
	 * Returns the schema of this {@link AbstractDBDataSource}.
	 * 
	 * @return the schema of this {@link AbstractDBDataSource}
	 */
	public String getSchema()
	{
		return getParameterValue(SCHEMA);
	}
	

	/**
	 * Returns the connection pool size of this {@link AbstractDBDataSource}.
	 * 
	 * @return the connection pool size of this {@link AbstractDBDataSource}
	 */
	public int getConnectionPoolSize()
	{
		return getParameterValue(CONNECTION_POOL_SIZE);
	}
	

	/**
	 * Returns <code>true</code> if the connection of this
	 * {@link AbstractDataSource} is alive.
	 * 
	 * @return <code>true</code> if the connection of this
	 *         {@link AbstractDataSource} is alive, otherwise <code>false</code>
	 *         .
	 */
	public boolean keepConnectionsAlive()
	{
		return getParameterValue(KEEP_CONNECTIONS_ALIVE);
	}
	

	/**
	 * Determines if this data source is a distibuted client-server data source.
	 * 
	 * @return <code>true</code> if this data source is a distibuted
	 *         client-server data source, <code>false</code> otherwise
	 */
	public boolean isServerDataSource()
	{
		return getParameterValue(IS_SERVER_DATASOURCE);
	}
	

	/**
	 * Returns the password of this {@link AbstractDBDataSource}.
	 * 
	 * @return the password of this {@link AbstractDBDataSource}
	 */
	public String getServerURL()
	{
		return getParameterValue(SERVER_URL);
	}
	

	/**
	 * Returns the authentification key of this {@link AbstractDBDataSource}.
	 * 
	 * @return the authentification key of this {@link AbstractDBDataSource}
	 */
	public String getAuthKey()
	{
		return getParameterValue(AUTH_KEY);
	}
	

	/**
	 * Sets the key which is used to authentificate this client to communicate
	 * with the servlet-part of this data source.
	 * 
	 * @param authKey
	 *            the new authorization key
	 */
	public void setAuthKey(String authKey)
	{
		getParameter(AUTH_KEY).setValue(authKey);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean isParameterRequired(Parameter p)
	{
		if(SERVER_URL.equals(p) || AUTH_KEY.equals(p))
		{
			return isServerDataSource();
		}
		
		return super.isParameterRequired(p);
	}
	

	@Override
	public final DBConnection openConnection() throws DBException
	{
		DBConnection con = openConnectionImpl();
		
		if(listeners.size() > 0)
		{
			DBDataSourceEvent event = new DBDataSourceEvent(this,con);
			for(DBDataSourceListener listener : getDBDataSourceListeners())
			{
				listener.connectionOpened(event);
			}
		}
		
		return con;
	}
	

	protected abstract DBConnection openConnectionImpl() throws DBException;
}
