/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db;


import xdev.db.sql.SELECT;
import xdev.lang.Copyable;


/**
 * 
 * A wrapper class that holds information of a query.
 * 
 * 
 * @author XDEV Software Corp.
 */
public class QueryInfo implements Copyable<QueryInfo>
{
	private final SELECT	select;
	private final Object[]	params;
	

	/**
	 * Constructs a new {@link QueryInfo} with the given <code>select</code> and
	 * the <code>params</code>.
	 * 
	 * @param select
	 *            the {@link SELECT}
	 * @param params
	 *            the parameters for the {@link SELECT}
	 */
	public QueryInfo(SELECT select, Object... params)
	{
		this.select = select;
		this.params = params;
	}
	

	/**
	 * Returns the select object of this {@link QueryInfo}.
	 * 
	 * @return the {@link SELECT}
	 * 
	 */
	public SELECT getSelect()
	{
		return select;
	}
	

	/**
	 * Returns the parameter of this {@link QueryInfo}.
	 * 
	 * @return the parameters
	 */
	public Object[] getParameters()
	{
		return params;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public QueryInfo clone()
	{
		return new QueryInfo(select.clone(),params);
	}
}
