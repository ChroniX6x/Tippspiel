/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db.sql;


import net.jadoth.sqlengine.SQL;
import net.jadoth.sqlengine.internal.SqlCondition;


public class Condition extends SqlObject
{
	public static Condition valueOf(Object condition)
	{
		if(condition instanceof Condition)
		{
			return (Condition)condition;
		}
		return new Condition(SQL.condition(expose(condition)));
	}
	

	public static Condition par(Object condition)
	{
		return new Condition(SQL.par(expose(condition)));
	}
	
	private final SqlCondition	delegate;
	

	Condition(SqlCondition delegate)
	{
		this.delegate = delegate;
	}
	

	@Override
	SqlCondition delegate()
	{
		return delegate;
	}
	

	public Condition AND(Object condition)
	{
		return new Condition(delegate.AND(expose(condition)));
	}
	

	public Condition OR(Object condition)
	{
		return new Condition(delegate.OR(expose(condition)));
	}
}
