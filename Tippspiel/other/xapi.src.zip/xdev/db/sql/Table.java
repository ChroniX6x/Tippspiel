/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db.sql;


import net.jadoth.sqlengine.internal.tables.SqlTableIdentity;


public class Table extends SqlObject
{
	private final SqlTableIdentity	delegate;
	

	public Table(String name)
	{
		this(null,name,null);
	}
	

	public Table(String name, String alias)
	{
		this(null,name,alias);
	}
	

	public Table(String schema, String name, String alias)
	{
		this(new SqlTableIdentity(schema,name,alias));
	}
	

	Table(SqlTableIdentity delegate)
	{
		this.delegate = delegate;
	}
	

	@Override
	SqlTableIdentity delegate()
	{
		return delegate;
	}
	

	public Table AS(String alias)
	{
		return new Table(delegate.AS(alias));
	}
	

	public String getSchema()
	{
		return delegate.sql().schema;
	}
	

	public String getName()
	{
		return delegate.sql().name;
	}
	

	public String getAlias()
	{
		return delegate.sql().alias;
	}
}
