/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db.sql;


import xdev.lang.Copyable;


public class UPDATE extends WritingQuery implements Copyable<UPDATE>
{
	private final net.jadoth.sqlengine.UPDATE	delegate;
	

	public UPDATE(Table table)
	{
		this(new net.jadoth.sqlengine.UPDATE(table.delegate()));
	}
	

	public UPDATE(Sqlable<? extends Table> table)
	{
		this(new net.jadoth.sqlengine.UPDATE(table.toSqlObject().delegate()));
	}
	

	UPDATE(net.jadoth.sqlengine.UPDATE delegate)
	{
		super(delegate);
		this.delegate = delegate;
	}
	

	public UPDATE SET(Object column, Object value)
	{
		delegate.SET(expose(column),expose(value));
		return this;
	}
	

	public UPDATE AND(Object condition)
	{
		delegate.AND(expose(condition));
		return this;
	}
	

	public UPDATE OR(Object condition)
	{
		delegate.OR(expose(condition));
		return this;
	}
	

	public UPDATE FROM(SELECT select)
	{
		delegate.FROM(select.delegate());
		return this;
	}
	

	public UPDATE INNER_JOIN(Table table, Object condition)
	{
		delegate.INNER_JOIN(table.delegate(),expose(condition));
		return this;
	}
	

	public UPDATE OUTER_JOIN(Table table, Object condition)
	{
		delegate.OUTER_JOIN(table.delegate(),expose(condition));
		return this;
	}
	

	public UPDATE LEFT_JOIN(Table table, Object condition)
	{
		delegate.LEFT_JOIN(table.delegate(),expose(condition));
		return this;
	}
	

	public UPDATE RIGHT_JOIN(Table table, Object condition)
	{
		delegate.RIGHT_JOIN(table.delegate(),expose(condition));
		return this;
	}
	

	public UPDATE WHERE(Object condition)
	{
		delegate.WHERE(expose(condition));
		return this;
	}
	

	@Override
	public UPDATE clone()
	{
		return new UPDATE(delegate.copy());
	}
}
