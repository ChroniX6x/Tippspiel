/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db.sql;


import xdev.lang.Copyable;


public class DELETE extends WritingQuery implements Copyable<DELETE>
{
	private final net.jadoth.sqlengine.DELETE	delegate;
	

	public DELETE()
	{
		this(new net.jadoth.sqlengine.DELETE());
	}
	

	DELETE(net.jadoth.sqlengine.DELETE delegate)
	{
		super(delegate);
		this.delegate = delegate;
	}
	

	public DELETE FROM(Table table)
	{
		delegate.FROM(table.delegate());
		return this;
	}
	

	public DELETE FROM(SELECT select)
	{
		delegate.FROM(select.delegate());
		return this;
	}
	

	public DELETE FROM(Sqlable<? extends Table> table)
	{
		delegate.FROM(table.toSqlObject().delegate());
		return this;
	}
	

	public DELETE AND(Object condition)
	{
		delegate.AND(expose(condition));
		return this;
	}
	

	public DELETE OR(Object condition)
	{
		delegate.OR(expose(condition));
		return this;
	}
	

	public DELETE INNER_JOIN(Table table, Object condition)
	{
		delegate.INNER_JOIN(table.delegate(),expose(condition));
		return this;
	}
	

	public DELETE OUTER_JOIN(Table table, Object condition)
	{
		delegate.OUTER_JOIN(table.delegate(),expose(condition));
		return this;
	}
	

	public DELETE LEFT_JOIN(Table table, Object condition)
	{
		delegate.LEFT_JOIN(table.delegate(),expose(condition));
		return this;
	}
	

	public DELETE RIGHT_JOIN(Table table, Object condition)
	{
		delegate.RIGHT_JOIN(table.delegate(),expose(condition));
		return this;
	}
	

	public DELETE WHERE(Object condition)
	{
		delegate.WHERE(expose(condition));
		return this;
	}
	

	@Override
	public DELETE clone()
	{
		return new DELETE(delegate.copy());
	}
}
