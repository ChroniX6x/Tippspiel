/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db.sql;


import java.util.List;

import net.jadoth.sqlengine.internal.ORDER_BY;
import net.jadoth.sqlengine.internal.SqlColumn;
import net.jadoth.sqlengine.internal.SqlExpression;
import net.jadoth.sqlengine.internal.SqlOrderItem;
import net.jadoth.sqlengine.internal.interfaces.SelectItem;
import xdev.db.DBConnection;
import xdev.lang.Copyable;
import xdev.vt.VirtualTableColumn;


/**
 * A java representation of a SQL SELECT statement which is used by the
 * {@link DBConnection} class to perform reading queries.
 * <p>
 * {@link DBConnection#query(SELECT, Object...)}
 * <p>
 * The methods of the SELECT class return the object back so you can chain the
 * method calls:
 * 
 * <pre>
 * VirtualTable vt;
 * VirtualTableColumn column;
 * new SELECT().FROM(vt.toSqlTable()).WHERE(column.toSqlColumn().LIKE(&quot;Bla%&quot;));
 * </pre>
 * 
 * @author XDEV Software
 * @since 3.0
 */
public class SELECT extends SqlObject implements Copyable<SELECT>
{
	private final net.jadoth.sqlengine.SELECT	delegate;
	

	/**
	 * Creates a new empty SELECT object.
	 */
	public SELECT()
	{
		this(new net.jadoth.sqlengine.SELECT());
	}
	

	SELECT(net.jadoth.sqlengine.SELECT delegate)
	{
		this.delegate = delegate;
	}
	

	@Override
	net.jadoth.sqlengine.SELECT delegate()
	{
		return delegate;
	}
	

	/**
	 * Adds the distinct option to this SELECT statement.
	 */
	public SELECT DISTINCT()
	{
		delegate.DISTINCT();
		return this;
	}
	

	/**
	 * Adds columns to this SELECT statement.
	 * 
	 * @param columns
	 *            the columns to add
	 * @see VirtualTableColumn#toSqlColumn()
	 */
	public SELECT columns(Object... columns)
	{
		delegate.columns(expose(columns));
		return this;
	}
	

	public void ensureNameOfLastColumn(String name)
	{
		List<SelectItem> items = delegate.getSelectItems();
		if(items != null && items.size() > 0)
		{
			int index = items.size() - 1;
			SelectItem item = items.get(index);
			if(item instanceof SqlExpression)
			{
				char[] ch = name.toCharArray();
				for(int i = 0; i < ch.length; i++)
				{
					if(i == 0)
					{
						if(!Character.isJavaIdentifierStart(ch[i]))
						{
							ch[i] = '_';
						}
					}
					else
					{
						if(!Character.isJavaIdentifierPart(ch[i]))
						{
							ch[i] = '_';
						}
					}
				}
				name = new String(ch);
				if(!(item instanceof SqlColumn && name.equals(((SqlColumn)item).getColumnName())))
				{
					// Don't add alias if it has the same name
					items.set(index,((SqlExpression)item).AS(name));
				}
			}
		}
	}
	

	public SELECT FROM(Table table)
	{
		delegate.FROM(table.delegate());
		return this;
	}
	

	public SELECT FROM(SELECT select)
	{
		delegate.FROM(select.delegate);
		return this;
	}
	

	public SELECT FROM(Sqlable<? extends Table> table)
	{
		delegate.FROM(table.toSqlObject().delegate());
		return this;
	}
	

	public SELECT AND(Object condition)
	{
		delegate.AND(expose(condition));
		return this;
	}
	

	public SELECT OR(Object condition)
	{
		delegate.OR(expose(condition));
		return this;
	}
	

	public SELECT INNER_JOIN(Table table, Object condition)
	{
		delegate.INNER_JOIN(table.delegate(),expose(condition));
		return this;
	}
	

	public SELECT OUTER_JOIN(Table table, Object condition)
	{
		delegate.OUTER_JOIN(table.delegate(),expose(condition));
		return this;
	}
	

	public SELECT LEFT_JOIN(Table table, Object condition)
	{
		delegate.LEFT_JOIN(table.delegate(),expose(condition));
		return this;
	}
	

	public SELECT RIGHT_JOIN(Table table, Object condition)
	{
		delegate.RIGHT_JOIN(table.delegate(),expose(condition));
		return this;
	}
	

	public SELECT WHERE(Object condition)
	{
		delegate.WHERE(expose(condition));
		return this;
	}
	

	public WHERE getWhere()
	{
		net.jadoth.sqlengine.internal.WHERE where = delegate.getWhereClause();
		return where != null ? new WHERE(where) : null;
	}
	

	public SELECT ORDER_BY(Object item)
	{
		return ORDER_BY(item,null,null);
	}
	

	public SELECT ORDER_BY(Object item, Boolean desc)
	{
		return ORDER_BY(item,desc,null);
	}
	

	public SELECT ORDER_BY(Object item, Boolean desc, Boolean nullsFirst)
	{
		return orderByImpl(new SqlOrderItem(expose(item),desc,nullsFirst));
	}
	

	private SELECT orderByImpl(Object item)
	{
		ORDER_BY orderBy = delegate.getOrderByClause();
		if(orderBy == null)
		{
			delegate.setOrderByClause(orderBy = new ORDER_BY());
		}
		orderBy.add(expose(item));
		return this;
	}
	

	public SELECT GROUP_BY(Object... fields)
	{
		delegate.GROUP_BY(expose(fields));
		return this;
	}
	

	public SELECT HAVING(Object condition)
	{
		delegate.HAVING(expose(condition));
		return this;
	}
	

	public SELECT OFFSET(Integer offset)
	{
		delegate.OFFSET(offset);
		return this;
	}
	

	public Integer getOffsetSkipCount()
	{
		return delegate.getOffsetSkipCount();
	}
	

	public SELECT FETCH_FIRST(Integer limit)
	{
		delegate.FETCH_FIRST(limit);
		return this;
	}
	

	public Integer getFetchFirstRowCount()
	{
		return delegate.getFetchFirstRowCount();
	}
	

	public SELECT UNION(SELECT unionSelect)
	{
		delegate.UNION(unionSelect.delegate);
		return this;
	}
	

	public SELECT UNION_All(SELECT unionAllSelect)
	{
		delegate.UNION_All(unionAllSelect.delegate);
		return this;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public SELECT clone()
	{
		return new SELECT(delegate.copy());
	}
	

	@Override
	public String toString()
	{
		return delegate.toString();
	}
}
