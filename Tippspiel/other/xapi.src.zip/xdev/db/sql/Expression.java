/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db.sql;


import net.jadoth.sqlengine.SQL;
import net.jadoth.sqlengine.internal.SqlExpression;


public class Expression extends SqlObject
{
	public Expression valueOf(Object expression)
	{
		if(expression instanceof Expression)
		{
			return (Expression)expression;
		}
		return new Expression(SQL.exp(expose(expression)));
	}
	
	private final SqlExpression	delegate;
	

	Expression(SqlExpression delegate)
	{
		this.delegate = delegate;
	}
	

	@Override
	SqlExpression delegate()
	{
		return delegate;
	}
	

	public Expression as(String alias)
	{
		return new Expression(delegate.AS(alias));
	}
	

	public Condition eq(Object value)
	{
		return new Condition(delegate.eq(expose(value)));
	}
	

	public Condition ne(Object value)
	{
		return new Condition(delegate.ne(expose(value)));
	}
	

	public Condition gt(Object value)
	{
		return new Condition(delegate.gt(expose(value)));
	}
	

	public Condition lt(Object value)
	{
		return new Condition(delegate.lt(expose(value)));
	}
	

	public Condition gte(Object value)
	{
		return new Condition(delegate.gte(expose(value)));
	}
	

	public Condition lte(Object value)
	{
		return new Condition(delegate.lte(expose(value)));
	}
	

	public Condition IS_NULL()
	{
		return new Condition(delegate.IS_NULL());
	}
	

	public Condition IS_NOT_NULL()
	{
		return new Condition(delegate.IS_NOT_NULL());
	}
	

	public Condition IN(Object... values)
	{
		return new Condition(delegate.IN(expose(values)));
	}
	

	public Condition NOT_IN(Object... values)
	{
		return new Condition(delegate.NOT_IN(expose(values)));
	}
	

	public Condition LIKE(Object value)
	{
		return new Condition(delegate.LIKE(expose(value)));
	}
	

	public Condition NOT_LIKE(Object value)
	{
		return new Condition(delegate.NOT_LIKE(expose(value)));
	}
	

	public Condition BETWEEN(Object lower, Object upper)
	{
		return new Condition(delegate.BETWEEN(expose(lower),expose(upper)));
	}
	

	public Condition NOT_BETWEEN(Object lower, Object upper)
	{
		return new Condition(delegate.NOT_BETWEEN(expose(lower),expose(upper)));
	}
}
