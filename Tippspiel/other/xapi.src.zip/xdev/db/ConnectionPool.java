/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db;


import java.sql.Array;
import java.sql.Blob;
import java.sql.CallableStatement;
import java.sql.Clob;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.NClob;
import java.sql.PreparedStatement;
import java.sql.SQLClientInfoException;
import java.sql.SQLException;
import java.sql.SQLWarning;
import java.sql.SQLXML;
import java.sql.Savepoint;
import java.sql.Statement;
import java.sql.Struct;
import java.util.Enumeration;
import java.util.Map;
import java.util.Properties;
import java.util.Vector;

import net.jadoth.sqlengine.dbms.DbmsAdaptor;
import net.jadoth.sqlengine.interfaces.ConnectionProvider;


/**
 * A pool including one or more <code>PooledConnection</code> objects. The
 * <code>ConnectionPool</code> provides method�s to handle the
 * <code>PooledConnection</code>.
 * 
 * @author XDEV Software
 * 
 */
public class ConnectionPool implements ConnectionProvider
{
	private final long					timeout	= 5 * 60 * 1000;	// 5 minutes
																	
	private int							size;
	private boolean						keepConnectionsAlive;
	private DbmsAdaptor					adaptor;
	private ConnectionInformation		info;
	private Vector<PooledConnection>	pool;
	

	/**
	 * Construct a new {@link ConnectionPool} that is initialize with the given
	 * parameter.
	 * 
	 * @param size
	 *            the limit of concurrent connections, a <code>size</code> <= 0
	 *            means no limit
	 * 
	 * @param keepConnectionsAlive
	 *            <code>ture</code> to close the connection definitely or
	 *            <code>false</code> if the connection is no longer used
	 * 
	 * @param adaptor
	 *            the {@link DbmsAdaptor} for this {@link ConnectionPool}
	 * 
	 * @param info
	 *            the connection information
	 * 
	 */
	public ConnectionPool(int size, boolean keepConnectionsAlive, DbmsAdaptor adaptor,
			ConnectionInformation info)
	{
		this.size = size;
		this.keepConnectionsAlive = keepConnectionsAlive;
		this.adaptor = adaptor;
		this.info = info;
		this.pool = new Vector();
		
		// Thread reaper = new Thread("ConnectionPool")
		// {
		// @Override
		// public void run()
		// {
		// try
		// {
		// sleep(300000);
		// }
		// catch(InterruptedException e)
		// {
		// }
		//				
		// reapConnections();
		// }
		// };
		// reaper.setDaemon(true);
		// reaper.start();
	}
	

	private synchronized void reapConnections()
	{
		long stale = System.currentTimeMillis() - timeout;
		Enumeration<PooledConnection> connlist = pool.elements();
		while(connlist.hasMoreElements())
		{
			PooledConnection conn = connlist.nextElement();
			
			if(conn.inuse && stale > conn.timestamp && !conn.validate())
			{
				pool.removeElement(conn);
				conn.closeDefinite();
			}
		}
	}
	

	// /**
	// * Returns the first {@link Connection} of this {@link ConnectionPool}
	// that
	// * is not in use. If no {@link Connection} is available, a new
	// * {@link PooledConnection} is created and the method (
	// * {@link #getConnection()}) is called again.
	// *
	// * @return the {@link Connection}
	// */
	/**
	 * {@inheritDoc}
	 */
	public synchronized Connection getConnection()
	{
		for(PooledConnection connection : pool)
		{
			if(connection.lease() && connection.validate())
			{
				return connection;
			}
		}
		
		reapConnections();
		
		if(size <= 0 || pool.size() < size)
		{
			PooledConnection connection = new PooledConnection(info.createConnection(null));
			connection.lease();
			pool.add(connection);
			return connection;
		}
		
		try
		{
			Thread.sleep(1000);
		}
		catch(InterruptedException e)
		{
		}
		
		return getConnection();
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public DbmsAdaptor getDbmsAdaptor()
	{
		return adaptor;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public synchronized void closeConnection(Connection connection)
	{
		try
		{
			connection.close();
		}
		catch(Exception e)
		{
		}
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public synchronized void close()
	{
		for(PooledConnection connection : pool)
		{
			connection.closeDefinite();
		}
		pool.clear();
	}
	


	private class PooledConnection implements ConnectionWrapper
	{
		Connection	connection;
		boolean		inuse;
		long		timestamp;
		

		PooledConnection(Connection connection)
		{
			this.connection = connection;
			this.inuse = false;
			this.timestamp = 0;
		}
		

		@Override
		public Connection getActualConnection()
		{
			return connection;
		}
		

		synchronized boolean lease()
		{
			if(inuse)
			{
				return false;
			}
			else
			{
				inuse = true;
				timestamp = System.currentTimeMillis();
				return true;
			}
		}
		

		boolean validate()
		{
			return info.isConnectionValid(connection);
		}
		

		@Override
		public void close()
		{
			inuse = false;
			
			if(!keepConnectionsAlive)
			{
				closeDefinite();
			}
		}
		

		void closeDefinite()
		{
			inuse = false;
			
			try
			{
				connection.close();
			}
			catch(Exception e)
			{
			}
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void clearWarnings() throws SQLException
		{
			connection.clearWarnings();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void commit() throws SQLException
		{
			connection.commit();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Array createArrayOf(String typeName, Object[] elements) throws SQLException
		{
			return connection.createArrayOf(typeName,elements);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Blob createBlob() throws SQLException
		{
			return connection.createBlob();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Clob createClob() throws SQLException
		{
			return connection.createClob();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public NClob createNClob() throws SQLException
		{
			return connection.createNClob();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public SQLXML createSQLXML() throws SQLException
		{
			return connection.createSQLXML();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Statement createStatement() throws SQLException
		{
			return connection.createStatement();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Statement createStatement(int resultSetType, int resultSetConcurrency)
				throws SQLException
		{
			return connection.createStatement(resultSetType,resultSetConcurrency);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Statement createStatement(int resultSetType, int resultSetConcurrency,
				int resultSetHoldability) throws SQLException
		{
			return connection.createStatement(resultSetType,resultSetConcurrency,
					resultSetHoldability);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Struct createStruct(String typeName, Object[] attributes) throws SQLException
		{
			return connection.createStruct(typeName,attributes);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public boolean getAutoCommit() throws SQLException
		{
			return connection.getAutoCommit();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public String getCatalog() throws SQLException
		{
			return connection.getCatalog();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Properties getClientInfo() throws SQLException
		{
			return connection.getClientInfo();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public String getClientInfo(String name) throws SQLException
		{
			return connection.getClientInfo(name);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public int getHoldability() throws SQLException
		{
			return connection.getHoldability();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public DatabaseMetaData getMetaData() throws SQLException
		{
			return connection.getMetaData();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public int getTransactionIsolation() throws SQLException
		{
			return connection.getTransactionIsolation();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Map<String, Class<?>> getTypeMap() throws SQLException
		{
			return connection.getTypeMap();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public SQLWarning getWarnings() throws SQLException
		{
			return connection.getWarnings();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public boolean isClosed() throws SQLException
		{
			return connection.isClosed();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public boolean isReadOnly() throws SQLException
		{
			return connection.isReadOnly();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public boolean isValid(int timeout) throws SQLException
		{
			return connection.isValid(timeout);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public String nativeSQL(String sql) throws SQLException
		{
			return connection.nativeSQL(sql);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public CallableStatement prepareCall(String sql) throws SQLException
		{
			return connection.prepareCall(sql);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public CallableStatement prepareCall(String sql, int resultSetType, int resultSetConcurrency)
				throws SQLException
		{
			return connection.prepareCall(sql,resultSetType,resultSetConcurrency);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public CallableStatement prepareCall(String sql, int resultSetType,
				int resultSetConcurrency, int resultSetHoldability) throws SQLException
		{
			return connection.prepareCall(sql,resultSetType,resultSetConcurrency,
					resultSetHoldability);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public PreparedStatement prepareStatement(String sql) throws SQLException
		{
			return connection.prepareStatement(sql);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys)
				throws SQLException
		{
			return connection.prepareStatement(sql,autoGeneratedKeys);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public PreparedStatement prepareStatement(String sql, int[] columnIndexes)
				throws SQLException
		{
			return connection.prepareStatement(sql,columnIndexes);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public PreparedStatement prepareStatement(String sql, String[] columnNames)
				throws SQLException
		{
			return connection.prepareStatement(sql,columnNames);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public PreparedStatement prepareStatement(String sql, int resultSetType,
				int resultSetConcurrency) throws SQLException
		{
			return connection.prepareStatement(sql,resultSetType,resultSetConcurrency);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public PreparedStatement prepareStatement(String sql, int resultSetType,
				int resultSetConcurrency, int resultSetHoldability) throws SQLException
		{
			return connection.prepareStatement(sql,resultSetType,resultSetConcurrency,
					resultSetHoldability);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void releaseSavepoint(Savepoint savepoint) throws SQLException
		{
			connection.releaseSavepoint(savepoint);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void rollback() throws SQLException
		{
			connection.rollback();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void rollback(Savepoint savepoint) throws SQLException
		{
			connection.rollback(savepoint);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void setAutoCommit(boolean autoCommit) throws SQLException
		{
			connection.setAutoCommit(autoCommit);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void setCatalog(String catalog) throws SQLException
		{
			connection.setCatalog(catalog);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void setClientInfo(Properties properties) throws SQLClientInfoException
		{
			connection.setClientInfo(properties);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void setClientInfo(String name, String value) throws SQLClientInfoException
		{
			connection.setClientInfo(name,value);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void setHoldability(int holdability) throws SQLException
		{
			connection.setHoldability(holdability);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void setReadOnly(boolean readOnly) throws SQLException
		{
			connection.setReadOnly(readOnly);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Savepoint setSavepoint() throws SQLException
		{
			return connection.setSavepoint();
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public Savepoint setSavepoint(String name) throws SQLException
		{
			return connection.setSavepoint(name);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void setTransactionIsolation(int level) throws SQLException
		{
			connection.setTransactionIsolation(level);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public void setTypeMap(Map<String, Class<?>> map) throws SQLException
		{
			connection.setTypeMap(map);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public boolean isWrapperFor(Class<?> iface) throws SQLException
		{
			return connection.isWrapperFor(iface);
		}
		

		/**
		 * {@inheritDoc}
		 */
		@Override
		public <T> T unwrap(Class<T> iface) throws SQLException
		{
			return connection.unwrap(iface);
		}
	}
}
