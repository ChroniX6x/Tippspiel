/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db;


/**
 * 
 * 
 * 
 * @author XDEV Software
 * 
 */
//TODO javadoc (class description)
public abstract class Transaction
{	
	private final DBDataSource<?>	dataSource;
	private Savepoint				savepoint;
	

	/**
	 * Constructs a new <code>Transaction</code> with the current
	 * {@link DBDataSource}.
	 * 
	 * 
	 * @throws DBException
	 *             if the no DBDataSource is available
	 * 
	 * @see DBUtils#getCurrentDataSource()
	 */
	public Transaction() throws DBException
	{
		this(DBUtils.getCurrentDataSource());
	}
	

	/**
	 * Constructs a new <code>Transaction</code> with the specified
	 * <code>dataSource</code>.
	 * 
	 * 
	 * @param dataSource
	 *            the dataSource which provides the connections
	 */
	public Transaction(DBDataSource<?> dataSource)
	{
		this.dataSource = dataSource;
	}
	

	/**
	 * Returns the {@link DBDataSource} of this {@link Transaction}.
	 * 
	 * @return the current {@link DBDataSource}
	 */
	public DBDataSource getDataSource()
	{
		return dataSource;
	}
	

	/**
	 * Starts the transaction and executes the statements. If a error is occurs
	 * in the {@link #write(DBConnection)} method a rollback is done.
	 * 
	 * @throws DBException
	 *             if a database access error occurs
	 */
	public final void execute() throws DBException
	{
		DBConnection<?> connection = getConnection();
		try
		{
			connection.beginTransaction();
			write(connection);
			connection.commit();
		}
		catch(DBException dbe)
		{
			rollback(connection);
			throw dbe;
		}
		finally
		{
			connection.close();
		}
	}


	protected DBConnection<?> getConnection() throws DBException
	{
		return dataSource.openConnection();
	}
	

	protected abstract void write(DBConnection<?> connection) throws DBException;
	

	protected void setSavepoint(DBConnection<?> connection) throws DBException
	{
		savepoint = connection.setSavepoint();
	}
	

	protected void rollback(DBConnection<?> connection) throws DBException
	{
		if(savepoint != null)
		{
			connection.rollback(savepoint);
		}
		else
		{
			connection.rollback();
		}
	}
}
