/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db.jdbc;


import java.sql.Connection;

import net.jadoth.sqlengine.dbms.DbmsAdaptor;
import net.jadoth.sqlengine.exceptions.SQLEngineCouldNotConnectToDBException;
import net.jadoth.sqlengine.interfaces.ConnectionProvider;
import net.jadoth.sqlengine.internal.DatabaseGateway;
import xdev.db.AbstractDBDataSource;
import xdev.db.ConnectionInformation;
import xdev.db.ConnectionPool;
import xdev.db.DBException;


public abstract class JDBCDataSource<T extends JDBCDataSource<T, A>, A extends DbmsAdaptor<A>>
		extends AbstractDBDataSource<T>
{
	private final A				adaptor;
	private ConnectionProvider	connectionProvider;
	private DatabaseGateway<A>	gateway;
	

	public JDBCDataSource(A adaptor)
	{
		this.adaptor = adaptor;
	}
	

	@Override
	public abstract JDBCConnection openConnectionImpl() throws DBException;
	

	public A getDbmsAdaptor()
	{
		return adaptor;
	}
	

	@Override
	public void closeAllOpenConnections() throws DBException
	{
		if(connectionProvider != null)
		{
			connectionProvider.close();
			connectionProvider = null;
		}
	}
	

	@Override
	public void clearCaches()
	{
		connectionProvider = null;
		gateway = null;
	}
	

	public DatabaseGateway<A> getGateway()
	{
		if(gateway == null)
		{
			gateway = createGateway();
		}
		
		return gateway;
	}
	

	protected DatabaseGateway<A> createGateway()
	{
		return new DatabaseGateway(getConnectionProvider());
	}
	

	public ConnectionProvider<A> getConnectionProvider()
	{
		if(connectionProvider == null)
		{
			connectionProvider = createConnectionProvider();
		}
		
		return connectionProvider;
	}
	

	protected ConnectionProvider createConnectionProvider()
	{
		return new ConnectionPool(getConnectionPoolSize(),keepConnectionsAlive(),adaptor,
				getConnectionInformation());
	}
	

	protected abstract ConnectionInformation getConnectionInformation();
	

	final Connection connectImpl() throws DBException
	{
		try
		{
			return getConnectionProvider().getConnection();
		}
		catch(SQLEngineCouldNotConnectToDBException e)
		{
			Throwable cause = e.getCause();
			if(cause == null)
			{
				cause = e;
			}
			throw new DBException(this,cause.getMessage(),cause);
		}
	}
}
