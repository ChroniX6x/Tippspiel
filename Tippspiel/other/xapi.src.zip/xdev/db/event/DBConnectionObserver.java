/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db.event;


import xdev.db.DBDataSource;


/**
 * Combines {@link DBDataSourceListener} and {@link DBConnectionListener} for a
 * shorter way to observe connections of a {@link DBDataSource}.
 * 
 * <pre>
 * <code>
 * DBConnection con = ...;
 * con.addDBConnectionListener(new DBConnectionObserver()
 * {
 * 		public void queryPerformed(DBConnectionEvent event)
 * 		{
 * 			System.out.println(event.getQuery().getStatement());
 * 		}
 * 
 * 		public void writePerformed(DBConnectionEvent event)
 * 		{
 * 			System.out.println(event.getQuery().getStatement());
 * 		}
 * });
 * </code>
 * </pre>
 * 
 * @author XDEV Software
 * @since 3.0
 */
public abstract class DBConnectionObserver extends DBConnectionAdapter implements
		DBDataSourceListener
{
	/**
	 * {@inheritDoc}
	 */
	@Override
	public void connectionOpened(DBDataSourceEvent event)
	{
		event.getConnection().addDBConnectionListener(this);
	}
}
