/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.db;


import java.io.Serializable;

import xdev.util.ProgressMonitor;
import xdev.vt.EntityRelationshipModel;


/**
 * 
 * @author XDEV Software
 * 
 */
// TODO javadoc (class description)
public abstract class AbstractDBMetaData implements DBMetaData, Serializable
{
	private static final long	serialVersionUID	= -3760443801966056286L;
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		return getName() + " " + getVersion();
	}
	

	@Override
	public EntityRelationshipModel getEntityRelationshipModel(ProgressMonitor monitor)
			throws DBException
	{
		return getEntityRelationshipModel(monitor,getTableInfos(monitor,TableType.TABLES_AND_VIEWS));
	}
	

	protected boolean isColumnEqual(TableMetaData table1, ColumnMetaData column1,
			TableMetaData table2, ColumnMetaData column2)
	{
		// if(table1.isPrimaryKey(column1) != table2.isPrimaryKey(column2)
		// || table1.isUnique(column1) != table2.isUnique(column2))
		// {
		// return false;
		// }
		
		if(column1.getName().equals(column2.getName())
				&& column1.getType() == column2.getType()
				&& ColumnMetaData.areDefaultValuesEqual(column1.getDefaultValue(),column2
						.getDefaultValue()) && column1.isNullable() == column2.isNullable()
				&& column1.isAutoIncrement() == column2.isAutoIncrement())
		{
			DataType type = column1.getType();
			if(type.hasLength())
			{
				if(column1.getLength() != column2.getLength())
				{
					return false;
				}
				
				if(type.hasScale())
				{
					if(column1.getScale() != column2.getScale())
					{
						return false;
					}
				}
			}
			
			return true;
		}
		
		return false;
	}
}
