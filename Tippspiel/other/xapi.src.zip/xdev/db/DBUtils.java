/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.db;


import xdev.db.sql.Column;
import xdev.db.sql.Functions;
import xdev.db.sql.SELECT;
import xdev.db.sql.Table;
import xdev.db.sql.WHERE;
import xdev.db.sql.WritingQuery;
import xdev.lang.LibraryMember;
import xdev.util.DataSource;
import xdev.util.DataSources;
import xdev.vt.VirtualTable;


/**
 * <p>
 * The <code>DBUtils</code> class provides utility methods for handling database
 * access.
 * </p>
 * 
 * @since 2.0
 * 
 * @author XDEV Software
 */
@LibraryMember
public final class DBUtils
{
	
	/**
	 * <p>
	 * <code>DBUtils</code> instances can not be instantiated. The class should
	 * be used as utility class: <code>DBUtils.getDataSource("bar");</code>.
	 * </p>
	 */
	private DBUtils()
	{
	}
	
	/**
	 * holds the current {@link DBDataSource}.
	 */
	private static DBDataSource	currentDataSource	= null;
	
	static
	{
		DBDataSource[] dataSources = DataSources.getDataSources(DBDataSource.class);
		if(dataSources != null && dataSources.length > 0)
		{
			currentDataSource = dataSources[0];
		}
	}
	

	/**
	 * Sets the current {@link DBDataSource}.
	 * 
	 * @param name
	 *            name of the {@link DBDataSource} to be as current
	 *            {@link DBDataSource}
	 * @throws DBException
	 *             if there is no valid {@link DBDataSource} for the provided
	 *             <code>name</code>.
	 */
	public static void setDataSource(String name) throws DBException
	{
		setDataSource(getDataSource(name));
	}
	

	/**
	 * Sets the current {@link DBDataSource}.
	 * 
	 * @param dataSource
	 *            {@link DBDataSource} to be as current {@link DBDataSource}
	 * @throws DBException
	 *             if <code>dataSource</code> is not a valid
	 *             {@link DBDataSource}
	 */
	public static void setDataSource(DBDataSource dataSource) throws DBException
	{
		currentDataSource = dataSource;
	}
	

	/**
	 * Returns the {@link DBDataSource} for the provided <code>name</code>.
	 * 
	 * @param name
	 *            name to get the {@link DBDataSource} for
	 * @return the {@link DBDataSource} for the provided <code>name</code>.
	 * @throws DBException
	 *             if there is no valid {@link DBDataSource} for the provided
	 *             <code>name</code>.
	 */
	private static DBDataSource getDataSource(String name) throws DBException
	{
		if(name == null || name.length() == 0)
		{
			return currentDataSource;
		}
		
		DataSource dataSource = DataSources.getDataSource(name);
		
		if(dataSource == null)
		{
			throw new DBException(null,"DataSource '" + name + "' not found");
		}
		
		if(dataSource instanceof DBDataSource)
		{
			return (DBDataSource)dataSource;
		}
		
		throw new DBException(null,"DataSource '" + name + "' is not a DBDataSource");
	}
	

	/**
	 * Returns the current {@link DBDataSource}.
	 * 
	 * @return the current {@link DBDataSource}.
	 * 
	 * @throws DBException
	 *             if the current {@link DBDataSource} is not specified.
	 * 
	 * @see #setDataSource(DBDataSource)
	 * @see #setDataSource(String)
	 */
	public static DBDataSource getCurrentDataSource() throws DBException
	{
		ensureDataSourceSpecified();
		
		return currentDataSource;
	}
	

	/**
	 * Checks if {@value #currentDataSource} is specified.
	 * 
	 * 
	 * @throws DBException
	 *             if the current {@link DBDataSource} is not specified.
	 * 
	 * @see #setDataSource(DBDataSource)
	 * @see #setDataSource(String)
	 */
	private static void ensureDataSourceSpecified() throws DBException
	{
		if(currentDataSource == null)
		{
			throw new DBException(null,"No data connection specified");
		}
	}
	

	/**
	 * Returns the maximum value of the provided column <code>column</code> of
	 * table <code>table</code>.
	 * 
	 * @param table
	 *            name of the table where <code>column</code> is located
	 * @param column
	 *            name of the column to get the maximum value of
	 * @return the maximum value of the provided column <code>column</code> of
	 *         table <code>table</code>.
	 * @throws DBException
	 *             if the maximum value of the provided column could not be
	 *             obtained
	 */
	public static int getMaxValue(String table, String column) throws DBException
	{
		SELECT select = new SELECT().columns(Functions.MAX(new Column(column))).FROM(
				new Table(table));
		DBConnection connection = getCurrentDataSource().openConnection();
		try
		{
			Result rs = connection.query(select);
			try
			{
				return getSingleInt(rs);
			}
			finally
			{
				rs.close();
			}
		}
		finally
		{
			connection.close();
		}
	}
	

	/**
	 * Returns the row count of for the provided table <code>table</code>.
	 * 
	 * @param table
	 *            name of table to get the row count for
	 * 
	 * 
	 * @return Returns the row count of for the provided table
	 *         <code>table</code>.
	 * 
	 * @throws DBException
	 *             if the row count for the provided table could not be obtained
	 */
	public static int getRowCount(String table) throws DBException
	{
		return getRowCount(table,null);
	}
	

	/**
	 * Returns the row count of for the provided table <code>table</code>
	 * Including only records to which the provided <code>filter</code> apply.
	 * 
	 * @param table
	 *            name of table to get the row count for
	 * @param filter
	 *            {@link WHERE} condition to which the record must apply.
	 * @return Returns the row count of for the provided table
	 *         <code>table</code> Including only records to which the provided
	 *         <code>filter</code> apply.
	 * @throws DBException
	 *             if the row count for the provided table could not be obtained
	 */
	public static int getRowCount(String table, WHERE filter) throws DBException
	{
		SELECT select = new SELECT().columns(Functions.COUNT()).FROM(new Table(table));
		if(filter != null)
		{
			select.WHERE(filter);
		}
		DBConnection connection = getCurrentDataSource().openConnection();
		try
		{
			Result rs = connection.query(select);
			try
			{
				return getSingleInt(rs);
			}
			finally
			{
				rs.close();
			}
		}
		finally
		{
			connection.close();
		}
	}
	

	/**
	 * Fills the provided {@link VirtualTable} <code>vt</code> with the result
	 * of the provided sql statement <code>sql</code>.
	 * 
	 * @param vt
	 *            {@link VirtualTable} to fill
	 * @param sql
	 *            {@link String} sql statement
	 * @param params
	 *            parameters for the sql stement <code>sql</code> [optional]
	 * @return the filled {@link VirtualTable} <code>vt</code>
	 * @throws DBException
	 *             if an error occurs executing the sql statement
	 */
	public static VirtualTable query(VirtualTable vt, String sql, Object... params)
			throws DBException
	{
		return query(vt,query(sql,params));
	}
	

	/**
	 * Fills the provided {@link VirtualTable} <code>vt</code> with the result
	 * of the provided {@link SELECT} instance <code>select</code>.
	 * 
	 * @param vt
	 *            {@link VirtualTable} to fill
	 * @param select
	 *            {@link SELECT} sql statement
	 * @param params
	 *            parameters for the sql stement <code>select</code> [optional]
	 * @return the filled {@link VirtualTable} <code>vt</code>
	 * @throws DBException
	 *             if an error occurs executing the sql statement
	 */
	public static VirtualTable query(VirtualTable vt, SELECT select, Object... params)
			throws DBException
	{
		return query(vt,query(select,params));
	}
	

	/**
	 * Fills the provided {@link VirtualTable} <code>vt</code> with the provided
	 * result <code>rs</code>.
	 * 
	 * @param vt
	 *            {@link VirtualTable} to fill
	 * @param rs
	 *            {@link Result} result
	 * @return the filled {@link VirtualTable} <code>vt</code>
	 * @throws DBException
	 *             if a database related error occurs while iterating over the
	 *             result
	 */
	public static VirtualTable query(VirtualTable vt, Result rs) throws DBException
	{
		int[] colsToFill = null;
		
		if(vt == null)
		{
			int cc = rs.getColumnCount();
			colsToFill = new int[cc];
			vt = new VirtualTable(rs);
			for(int col = 0; col < colsToFill.length; col++)
			{
				colsToFill[col] = col;
			}
		}
		
		vt.addData(rs,colsToFill);
		
		return vt;
	}
	

	public static Result query(String sql, Object... params) throws DBException
	{
		ensureDataSourceSpecified();
		
		DBConnection connection = currentDataSource.openConnection();
		return connection.query(sql,params);
	}
	

	public static Result query(SELECT select, Object... params) throws DBException
	{
		ensureDataSourceSpecified();
		
		DBConnection connection = currentDataSource.openConnection();
		return connection.query(select,params);
	}
	

	public static Object querySingleValue(SELECT select, Object... params) throws DBException
	{
		Result rs = query(select,params);
		if(rs.next())
		{
			return rs.getObject(0);
		}
		
		return null;
	}
	

	public static Object querySingleValue(String sql, Object... params) throws DBException
	{
		Result rs = query(sql,params);
		if(rs.next())
		{
			return rs.getObject(0);
		}
		
		return null;
	}
	

	public static int getSingleInt(Result rs) throws DBException
	{
		int count = 0;
		
		try
		{
			if(rs.getColumnCount() > 0 && rs.next())
			{
				count = rs.getInt(0);
			}
			else
			{
				throw new DBException(rs.getDataSource(),"no data available");
			}
		}
		catch(DBException e)
		{
			throw e;
		}
		catch(Exception e)
		{
			throw new DBException(rs.getDataSource(),e);
		}
		finally
		{
			rs.close();
		}
		
		return count;
	}
	

	public static int write(String sql, Object... params) throws DBException
	{
		return write(sql,false,params).getAffectedRows();
	}
	

	public static WriteResult write(String sql, boolean returnGeneratedKeys, Object... params)
			throws DBException
	{
		return write(new WriteRequest(sql,returnGeneratedKeys,params))[0];
	}
	

	public static int write(WritingQuery query, Object... params) throws DBException
	{
		return write(query,false,params).getAffectedRows();
	}
	

	public static WriteResult write(WritingQuery query, boolean returnGeneratedKeys,
			Object... params) throws DBException
	{
		return write(new WriteRequest(query,returnGeneratedKeys,params))[0];
	}
	

	public static WriteResult[] write(WriteRequest... requests) throws DBException
	{
		ensureDataSourceSpecified();
		
		WriteResult[] results = new WriteResult[requests.length];
		DBConnection connection = currentDataSource.openConnection();
		try
		{
			for(int i = 0; i < requests.length; i++)
			{
				results[i] = requests[i].execute(connection);
			}
		}
		finally
		{
			if(!connection.isInTransaction())
			{
				connection.close();
			}
		}
		return results;
	}
	

	public static void callStoredProcedure(StoredProcedure procedure, Object... params)
			throws DBException
	{
		ensureDataSourceSpecified();
		
		DBConnection connection = currentDataSource.openConnection();
		try
		{
			connection.call(procedure,params);
		}
		finally
		{
			if(!connection.isInTransaction())
			{
				connection.close();
			}
		}
	}
}
