
package xdev;


/**
 * This exception is thrown if an error occurs through the initialization of an
 * {@link Extension}.
 * 
 * @see Extension#init(java.util.Map)
 * 
 * @author XDEV Software
 * @since 3.0
 */
public class ExtensionInitializationException extends Exception
{
	public ExtensionInitializationException()
	{
		super();
	}
	

	public ExtensionInitializationException(String message, Throwable cause)
	{
		super(message,cause);
	}
	

	public ExtensionInitializationException(String message)
	{
		super(message);
	}
	

	public ExtensionInitializationException(Throwable cause)
	{
		super(cause);
	}
}
