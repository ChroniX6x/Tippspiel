/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.vt;


import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import xdev.db.sql.Table;


class SqlGenerationContext
{
	private Set<EntityRelationship>			joinedRelations	= new HashSet();
	private Map<EntityRelationship, Table>	relationTables	= new HashMap();
	private Map<VirtualTable, Table>		tableCache		= new HashMap();
	private Map<VirtualTable, Integer>		aliasCounter	= new HashMap();
	

	boolean join(EntityRelationship relation)
	{
		if(joinedRelations.contains(relation))
		{
			return false;
		}
		
		joinedRelations.add(relation);
		return true;
	}
	

	Table getTableExpression(EntityRelationship relation, VirtualTable joinedTable)
	{
		Table table = relationTables.get(relation);
		if(table == null)
		{
			table = getTableExpression(joinedTable,true);
			relationTables.put(relation,table);
		}
		return table;
	}
	

	private Table getTableExpression(VirtualTable vt, boolean newAliasIfExists)
	{
		Table sqlTable = tableCache.get(vt);
		if(sqlTable == null || !newAliasIfExists)
		{
			sqlTable = vt.toSqlTable();
			tableCache.put(vt,sqlTable);
		}
		else if(newAliasIfExists)
		{
			Integer nr = aliasCounter.get(vt);
			if(nr == null)
			{
				nr = 2;
			}
			else
			{
				nr++;
			}
			aliasCounter.put(vt,nr);
			return sqlTable.AS(sqlTable.getName() + nr);
		}
		return sqlTable;
	}
}
