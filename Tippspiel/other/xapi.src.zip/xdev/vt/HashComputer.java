/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.vt;


import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import xdev.Application;


final class HashComputer
{
	private HashComputer()
	{
	}
	
	private static MessageDigest	digest;
	static
	{
		try
		{
			digest = MessageDigest.getInstance("SHA-1");
		}
		catch(NoSuchAlgorithmException e)
		{
			Application.getLogger().error(e);
		}
	}
	

	static String computeHash(Object[] values)
	{
		int c = values.length;
		if(c == 1)
		{
			return Integer.toString(hashCode(values[0]));
		}
		else
		{
			synchronized(digest)
			{
				digest.reset();
				
				for(Object obj : values)
				{
					int v = hashCode(obj);
					digest.update((byte)((v >>> 24) & 0xFF));
					digest.update((byte)((v >>> 16) & 0xFF));
					digest.update((byte)((v >>> 8) & 0xFF));
					digest.update((byte)((v >>> 0) & 0xFF));
				}
				
				return new BigInteger(1,digest.digest()).toString(Character.MAX_RADIX);
			}
		}
	}
	

	private static int hashCode(Object obj)
	{
		return obj == null ? Integer.MIN_VALUE : obj.hashCode();
	}
}
