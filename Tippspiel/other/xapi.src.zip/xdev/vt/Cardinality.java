/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.vt;


import xdev.vt.EntityRelationship.Entity;


/**
 * An enum specifying the possible cardinalities for entities within a
 * {@link EntityRelationship}.
 * 
 * @author TF
 * @see EntityRelationship
 * @see Entity
 */
public enum Cardinality
{
	/**
	 * The entities on the other side of the relation can reference at most one
	 * entity with this Cardinality.
	 */
	ONE("1"),

	/**
	 * The entities on the other side of the relation may reference 0 to many
	 * entites with this Cardinality.
	 */
	MANY("n");
	
	/**
	 * Returns the enum value for a specified shortcut.
	 * 
	 * @param shortcut
	 *            a valid shortcurt for a {@link Cardinality} value.
	 * @return a {@link Cardinality}
	 * @throws IllegalArgumentException
	 *             if an invalid <code>shortcut</code> was used.
	 */
	public static Cardinality get(String shortcut)
	{
		for(Cardinality c : values())
		{
			if(c.shortcut.equals(shortcut))
			{
				return c;
			}
		}
		
		throw new IllegalArgumentException("Cardinality '" + shortcut + "' not found");
	}
	
	private String	shortcut;
	

	private Cardinality(String shortcut)
	{
		this.shortcut = shortcut;
	}
	

	/**
	 * Returns the shortcut for this enum value.
	 * 
	 * @return the shortcut
	 */
	public String getShortcut()
	{
		return shortcut;
	}
	

	/**
	 * Returns a string representation of this enum value, consisting of the
	 * shortcut.
	 * 
	 * @return the shortcut
	 */
	@Override
	public String toString()
	{
		return shortcut;
	}
}
