/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.vt;


import java.util.Vector;

import javax.swing.table.AbstractTableModel;

import xdev.db.DataType;
import xdev.ui.XdevTable;


/**
 * This class acts as a model implementation for {@link XdevTable}s using a
 * {@link VirtualTable} as the underlying data model.
 * <p>
 * Calls for retrieving or modifying data are delegated to the
 * {@link VirtualTable}.
 * </p>
 * <p>
 * The number and order of columns of this Model and the {@link VirtualTable}
 * may differ. <code>modelColumnIndices</code> is used to map the columns of
 * this Model to the columns of the {@link VirtualTable}.
 * 
 * @author XDEV Software Corp.
 */
public class VirtualTableModel extends AbstractTableModel implements VirtualTableListener,
		VirtualTableWrapper
{
	private VirtualTable	vt;
	private int[]			columnIndices;


	/**
	 * Initializes a new {@link VirtualTableModel}.
	 * 
	 * @param vt
	 *            the {@link VirtualTable} to use
	 * @param columnIndices
	 *            an <code>int</code> array of column indices of the model. The
	 *            values of the array contain the indexes of the
	 *            {@link VirtualTable}.
	 */
	public VirtualTableModel(VirtualTable vt, int[] columnIndices)
	{
		this.vt = vt;
		this.columnIndices = columnIndices;

		vt.addVirtualTableListener(this);
	}


	/**
	 * Returns the wrapped {@link VirtualTable}.
	 * 
	 * @return a {@link VirtualTable}
	 */
	public VirtualTable getVT()
	{
		return vt;
	}


	/**
	 * {@inheritDoc}
	 */
	public int[] getModelColumnIndices()
	{
		return columnIndices;
	}


	/**
	 * Returns a value from the {@link VirtualTable} at the specified position.
	 * 
	 * @param row
	 *            the row index
	 * @param col
	 *            the model column index.
	 * @return a value
	 */
	public Object getValueAt(int row, int col)
	{
		return vt.getValueAt(row,columnIndices[col]);
	}


	/**
	 * Returns the number of columns of the model.
	 * 
	 * @return the number of columns
	 */
	public int getColumnCount()
	{
		return columnIndices.length;
	}


	/**
	 * Returns the number of rows in the {@link VirtualTable}.
	 * 
	 * @return the number of rows.
	 */
	public int getRowCount()
	{
		return vt.getRowCount();
	}


	/**
	 * Returns the column name using the caption of the underlying
	 * {@link VirtualTableColumn}.
	 * 
	 * @param col
	 *            the model column index.
	 * @return the column name of the column
	 */
	@Override
	public String getColumnName(int col)
	{
		return vt.getColumnCaption(columnIndices[col]);
	}


	/**
	 * Returns the class of the underlying {@link VirtualTableColumn}.
	 * 
	 * @param col
	 *            the model column index.
	 * @return the {@link DataType} of the column
	 */
	@Override
	public Class getColumnClass(int col)
	{
		return getClassForType(vt.columns[columnIndices[col]].getType());
	}


	/**
	 * Helper method for mapping {@link DataType}s to Java classes.
	 * 
	 * @param type
	 *            a {@link DataType} to get a class for.
	 * @return a {@link Class} for the <code>type</code>.
	 */
	public static Class getClassForType(DataType type)
	{
		if(type.isInt())
		{
			return Integer.class;
		}
		else if(type.isDecimal())
		{
			return Double.class;
		}
		else if(type.isDate())
		{
			return java.util.Date.class;
		}
		else if(type == DataType.BOOLEAN)
		{
			return Boolean.class;
		}
		else if(type.isBlob())
		{
			return XdevBlob.class;
		}

		return String.class;
	}


	/**
	 * Sets a value in the underlying {@link VirtualTable} at the specified
	 * position.
	 * 
	 * @param newValue
	 *            the new value to be set.
	 * @param row
	 *            the index of the row.
	 * @param col
	 *            the model column index.
	 */
	@Override
	public void setValueAt(Object newValue, int row, int col)
	{
		try
		{
			Object oldValue = getValueAt(row,col);
			if(!VirtualTable.equals(oldValue,newValue))
			{
				vt.setValueAt(newValue,row,columnIndices[col]);
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}


	/**
	 * Returns, if a cell is editables.
	 * 
	 * @param row
	 *            the index of the row.
	 * @param col
	 *            the model column index.
	 * @return if <code>true</code>, the cell can be edited.
	 */
	@Override
	public boolean isCellEditable(int row, int col)
	{
		return vt.getColumnAt(columnIndices[col]).isEditable();
	}


	/**
	 * {@inheritDoc}
	 */
	public VirtualTable getVirtualTable()
	{
		return vt;
	}


	/**
	 * {@inheritDoc}
	 */
	public int viewToModelColumn(int col)
	{
		return columnIndices[col];
	}


	/**
	 * Notifies listeners that all cell values in the {@link VirtualTable} may
	 * have changed.
	 * 
	 * @param event
	 *            a {@link VirtualTableEvent} with detailed information.
	 */
	@Override
	public void virtualTableDataChanged(VirtualTableEvent event)
	{
		fireTableDataChanged();
	}


	/**
	 * Notifies all listeners that a row in the {@link VirtualTable} has been
	 * deleted.
	 * 
	 * @param event
	 *            a {@link VirtualTableEvent} with detailed information.
	 */
	@Override
	public void virtualTableRowDeleted(VirtualTableEvent event)
	{
		int row = event.getRowIndex();
		fireTableRowsDeleted(row,row);
	}


	/**
	 * Notifies all listeners that a row in the {@link VirtualTable} has been
	 * inserted.
	 * 
	 * @param event
	 *            a {@link VirtualTableEvent} with detailed information.
	 */
	@Override
	public void virtualTableRowInserted(VirtualTableEvent event)
	{
		int row = event.getRowIndex();
		fireTableRowsInserted(row,row);
	}


	/**
	 * Notifies all listeners that a row in the {@link VirtualTable} has been
	 * updated.
	 * 
	 * @param event
	 *            a {@link VirtualTableEvent} with detailed information.
	 */
	@Override
	public void virtualTableRowUpdated(VirtualTableEvent event)
	{
		int row = event.getRowIndex();
		fireTableRowsUpdated(row,row);
	}


	/**
	 * Notifies all listeners that the structure of the {@link VirtualTable} has
	 * been changed and updates the model column indices.
	 * 
	 * @param event
	 *            a {@link VirtualTableEvent} with detailed information.
	 */
	@Override
	public void virtualTableStructureChanged(VirtualTableEvent event)
	{
		Vector v = new Vector(columnIndices.length);
		for(int i = 0; i < columnIndices.length; i++)
		{
			v.add(new Integer(columnIndices[i]));
		}

		for(int i = v.size() - 1; i >= 0; i--)
		{
			if(((Integer)v.get(i)).intValue() >= vt.getColumnCount())
			{
				v.remove(i);
			}
		}

		columnIndices = new int[v.size()];
		for(int i = 0; i < v.size(); i++)
		{
			columnIndices[i] = ((Integer)v.get(i)).intValue();
		}

		fireTableStructureChanged();
	}
}
