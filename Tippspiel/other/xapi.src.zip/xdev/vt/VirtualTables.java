/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.vt;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Collection;
import java.util.Hashtable;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import xdev.Application;


/**
 * 
 * Global registry of all {@link VirtualTable}s.
 * 
 * @author XDEV Software Corp.
 * 
 */
public final class VirtualTables
{
	private VirtualTables()
	{
	}
	
	public final static String					REGISTRY_PATH;
	private static Map<String, VirtualTable>	virtualTablesByName;
	private static Map<String, VirtualTable>	virtualTablesByQualifiedClassName;
	
	static
	{
		REGISTRY_PATH = "/" + VirtualTables.class.getName().replace('.','/');
		
		virtualTablesByName = new Hashtable();
		virtualTablesByQualifiedClassName = new Hashtable();
		
		URL url = EntityRelationships.class.getResource(REGISTRY_PATH);
		if(url != null)
		{
			try
			{
				boolean oldFormat = false;
				
				try
				{
					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
					DocumentBuilder builder = factory.newDocumentBuilder();
					Document doc = builder.parse(url.openStream());
					doc.getDocumentElement().normalize();
					NodeList children = doc.getElementsByTagName("vt");
					for(int i = 0, c = children.getLength(); i < c; i++)
					{
						Element child = (Element)children.item(i);
						String className = child.getAttribute("class");
						try
						{
							Class clazz = Class.forName(className);
							VirtualTable vt = (VirtualTable)clazz.getMethod("getInstance").invoke(
									null);
							registerVirtualTable(vt);
						}
						catch(Exception e)
						{
							Application.getLogger().error(e);
						}
					}
				}
				catch(SAXException e)
				{
					oldFormat = true;
				}
				
				if(oldFormat)
				{
					BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(),
							"UTF8"));
					String line;
					while((line = in.readLine()) != null)
					{
						line = line.trim();
						if(line.length() > 0)
						{
							try
							{
								Class clazz = Class.forName(line);
								VirtualTable vt = (VirtualTable)clazz.getMethod("getInstance")
										.invoke(null);
								registerVirtualTable(vt);
							}
							catch(Exception e)
							{
								Application.getLogger().error(e);
							}
						}
					}
					in.close();
				}
			}
			catch(Exception e)
			{
				Application.getLogger().error(e);
			}
		}
	}
	

	/**
	 * Registers another {@link VirtualTable} in this {@link VirtualTables}
	 * registry.
	 * 
	 * @param vt
	 *            the {@link VirtualTable} to register.
	 */
	public static void registerVirtualTable(VirtualTable vt)
	{
		String qualifiedName = vt.getName();
		String name = qualifiedName;
		int dot = name.lastIndexOf('.');
		if(dot > 0)
		{
			name = qualifiedName.substring(dot + 1);
		}
		virtualTablesByName.put(name,vt);
		virtualTablesByQualifiedClassName.put(qualifiedName,vt);
	}
	

	/**
	 * Returns a {@link VirtualTable} as specified by its table name.
	 * 
	 * @param name
	 *            the name of the table to return
	 * @return a {@link VirtualTable}, or <code>null</code>, if none found.
	 */
	public static VirtualTable getVirtualTable(String name)
	{
		VirtualTable vt = virtualTablesByQualifiedClassName.get(name);
		if(vt == null)
		{
			vt = virtualTablesByName.get(name);
		}
		return vt;
	}
	

	/**
	 * Returns a {@link VirtualTable} as specified by its db alias name.
	 * 
	 * @param name
	 *            the database alias.
	 * @return a {@link VirtualTable}, or <code>null</code>, if none found.
	 */
	public static VirtualTable getVirtualTableByDatabaseAlias(String name)
	{
		for(VirtualTable vt : virtualTablesByName.values())
		{
			if(name.equals(vt.getDatabaseAlias()))
			{
				return vt;
			}
		}
		
		return null;
	}
	

	/**
	 * Returns an <code>array</code> of all {@link VirtualTable} objects of this
	 * {@link VirtualTables} registry.
	 * 
	 * @return an <code>array</code> of {@link VirtualTable} objects.
	 */
	public static VirtualTable[] getVirtualTables()
	{
		Collection<VirtualTable> collection = virtualTablesByName.values();
		return collection.toArray(new VirtualTable[collection.size()]);
	}
}
