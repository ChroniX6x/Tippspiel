/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.vt;


/**
 * An enum specifying the possible modes for adding new data to a
 * {@link VirtualTable}.
 * 
 * @author XDEV Software Corp.
 * 
 */
public enum VirtualTableFillMethod
{
	/**
	 * Overwrite existing data with the new data.
	 */
	OVERWRITE,

	/**
	 * Append new data at the end of the existing data.
	 */
	APPEND,

	/**
	 * Prepend new data in front of the existing data.
	 */
	PREPEND
}
