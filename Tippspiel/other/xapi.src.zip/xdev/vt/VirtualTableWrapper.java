/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.vt;


/**
 * Specifies the contract of a wrapper implementation for {@link VirtualTable}s.
 * 
 * @author XDEV Software Corp.
 */
public interface VirtualTableWrapper
{
	/**
	 * Returns the wrapped {@link VirtualTable}.
	 * 
	 * @return a {@link VirtualTable}
	 */
	public VirtualTable getVirtualTable();
	

	/**
	 * Return the index of the wrapped {@link VirtualTable} corresponding to
	 * Parameter <code>col</code>.
	 * 
	 * @param col
	 *            the model column index
	 * @return a column index in the {@link VirtualTable}
	 */
	public int viewToModelColumn(int col);
	

	/**
	 * Returns the array of column indexes of the model.
	 * 
	 * @return an <code>int</code> array of indexed
	 */
	public int[] getModelColumnIndices();
}
