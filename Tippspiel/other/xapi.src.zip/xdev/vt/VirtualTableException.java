/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.vt;


/**
 * Thrown if something wents wrong, while processing methods on a
 * {@link VirtualTable}.
 * <p>
 * This is the base class for exception thrown in the context of
 * {@link VirtualTable}s.
 * </p>
 * 
 * @author XDEV Software Corp.
 */
public class VirtualTableException extends RuntimeException
{
	
	/**
	 * Helper method for throwing a {@link VirtualTableException}, when a
	 * {@link VirtualTable} wasn't found.
	 * 
	 * @param name
	 *            the name of the {@link VirtualTable} not found.
	 * @throws VirtualTableException
	 *             the exception to throw
	 */
	public static void throwVirtualTableNotFound(String name) throws VirtualTableException
	{
		throw new VirtualTableException("VirtualTable '" + name + "' not found");
	}
	

	/**
	 * Helper method for throwing a {@link VirtualTableException}, when a column
	 * name for a {@link VirtualTable} wasn't found.
	 * 
	 * @param vt
	 *            the {@link VirtualTable}.
	 * 
	 * @param columnName
	 *            the name of the column to search.
	 * 
	 * @throws VirtualTableException
	 *             the exception to throw
	 */
	public static void throwColumnNotFound(VirtualTable vt, String columnName)
			throws VirtualTableException
	{
		throw new VirtualTableException("Column '" + columnName + "' not found in VirtualTable '"
				+ vt.getName() + "'");
	}
	

	/**
	 * Initializes a new {@link VirtualTableException}.
	 */
	public VirtualTableException()
	{
		super();
	}
	

	/**
	 * Initializes a new {@link VirtualTableException}.
	 * 
	 * @param message
	 *            the message of the exception.
	 */
	public VirtualTableException(String message)
	{
		super(message);
	}
	

	/**
	 * Initializes a new {@link VirtualTableException}.
	 * 
	 * @param cause
	 *            the {@link Throwable} that caused this exception.
	 */
	public VirtualTableException(Throwable cause)
	{
		super(cause);
	}
	

	/**
	 * Initializes a new {@link VirtualTableException}.
	 * 
	 * @param message
	 *            the message of the exception.
	 * @param cause
	 *            the {@link Throwable} that caused this exception.
	 */
	public VirtualTableException(String message, Throwable cause)
	{
		super(message,cause);
	}
}
