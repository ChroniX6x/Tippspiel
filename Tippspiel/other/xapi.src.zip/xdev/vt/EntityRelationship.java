/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.vt;


import java.io.Serializable;

import xdev.db.sql.Condition;
import xdev.lang.Copyable;
import xdev.util.MathUtils;


/**
 * This class describes the relationship between two {@link Entity} objects.
 * 
 * @author XDEV Software Corp.
 * @see Entity
 * 
 */
public class EntityRelationship implements Copyable<EntityRelationship>, Serializable
{
	private static final long	serialVersionUID	= -8619356395478812452L;
	
	private final Entity		firstEntity;
	private final Entity		secondEntity;
	private final boolean		loop;
	private final int			hash;
	

	/**
	 * 
	 * @param tableName1
	 * @param columnName1
	 * @param cardinality1
	 * @param tableName2
	 * @param columnName2
	 * @param cardinality2
	 */
	public EntityRelationship(String tableName1, String columnName1, Cardinality cardinality1,
			String tableName2, String columnName2, Cardinality cardinality2)
	{
		this(new Entity(tableName1,columnName1,cardinality1),new Entity(tableName2,columnName2,
				cardinality2));
	}
	

	/**
	 * Initializes a new instance of {@link EntityRelationship}.
	 * 
	 * @param firstEntity
	 *            the first entity of the relationship.
	 * @param secondEntity
	 *            the second entity of the relationship.
	 */
	public EntityRelationship(Entity firstEntity, Entity secondEntity)
	{
		this.firstEntity = firstEntity;
		this.secondEntity = secondEntity;
		
		this.loop = firstEntity.getTableName().equals(secondEntity.getTableName());
		
		int hash1 = firstEntity.hashCode();
		int hash2 = secondEntity.hashCode();
		if(hash1 > hash2)
		{
			int tmp = hash1;
			hash1 = hash2;
			hash2 = tmp;
		}
		this.hash = MathUtils.computeHash(hash1,hash2);
	}
	

	/**
	 * Returns the first entity of this relationship.
	 * 
	 * @return a {@link Entity}
	 */
	public Entity getFirstEntity()
	{
		return firstEntity;
	}
	

	/**
	 * Returns the second entity of this relationship.
	 * 
	 * @return a {@link Entity}
	 */
	public Entity getSecondEntity()
	{
		return secondEntity;
	}
	

	/**
	 * Returns the {@link Entity} on the other side of the relationship.
	 * 
	 * @param entity
	 *            the {@link Entity}, which related {@link Entity} should be
	 *            returned
	 * @return the other {@link Entity} or <code>null</code> if none found.
	 */
	public Entity getOther(Entity entity)
	{
		if(firstEntity == entity)
		{
			return secondEntity;
		}
		else if(secondEntity == entity)
		{
			return firstEntity;
		}
		
		return null;
	}
	

	/**
	 * Returns the {@link Entity} for a specified tableName.
	 * 
	 * @param tableName
	 *            to get the {@link Entity} for.
	 * @return an {@link Entity}, or <code>null</code> if none found.
	 */
	public Entity getReferrer(String tableName)
	{
		if(firstEntity.refersTo(tableName))
		{
			return firstEntity;
		}
		
		if(secondEntity.refersTo(tableName))
		{
			return secondEntity;
		}
		
		return null;
	}
	

	/**
	 * Returns the {@link Entity} for a specified tableName and columnName.
	 * 
	 * @param tableName
	 *            to get the {@link Entity} for.
	 * @param columnName
	 *            to get the {@link Entity} for
	 * @return an {@link Entity}, or <code>null</code> if none found.
	 */
	public Entity getReferrer(String tableName, String columnName)
	{
		if(firstEntity.refersTo(tableName,columnName))
		{
			return firstEntity;
		}
		
		if(secondEntity.refersTo(tableName,columnName))
		{
			return secondEntity;
		}
		
		return null;
	}
	

	/**
	 * Checks if this relation is a loop, meaning it starts and ends at the same
	 * table.
	 * 
	 * @return <code>true</code> if the start end the end of this relation
	 *         points to the same table, <code>false</code> otherwise
	 */
	public boolean isLoop()
	{
		return loop;
	}
	

	/**
	 * Returns, if this {@link EntityRelationship} refers to the combination of
	 * the specified tablename and columnname.
	 * 
	 * @param tableName
	 *            the name of the table to check.
	 * @param columnName
	 *            the name of the column to check.
	 * @return true, if this {@link EntityRelationship} refers to the specified
	 *         parameters.
	 */
	public boolean refersTo(String tableName, String columnName)
	{
		return firstEntity.refersTo(tableName,columnName)
				|| secondEntity.refersTo(tableName,columnName);
	}
	

	/**
	 * Returns, if this {@link EntityRelationship} refers to the specified
	 * virtual table name.
	 * 
	 * @param tableName
	 *            the name of the virtual table to check.
	 * @return true, if this {@link EntityRelationship} refers to the specified
	 *         table name.
	 */
	public boolean refersTo(String tableName)
	{
		return firstEntity.refersTo(tableName) || secondEntity.refersTo(tableName);
	}
	

	/**
	 * Returns a copy of this {@link EntityRelationship}.
	 * 
	 * @return a copied {@link EntityRelationship}.
	 */
	public String getConnectedTable(String tableName)
	{
		Entity entity = getReferrer(tableName);
		if(entity != null)
		{
			return getOther(entity).getTableName();
		}
		
		return null;
	}
	

	@Override
	public EntityRelationship clone()
	{
		return new EntityRelationship(firstEntity.clone(),secondEntity.clone());
	}
	

	/**
	 * Checks this {@link EntityRelationship} with another
	 * {@link EntityRelationship} for equality.
	 * <p>
	 * Two {@link EntityRelationship} objects are considered equal, if its
	 * entities are equal.
	 * </p>
	 * 
	 * @param obj
	 *            the other Entity
	 * @return true if this Entity equals the other one.
	 */
	@Override
	public boolean equals(Object obj)
	{
		if(obj == this)
		{
			return true;
		}
		
		if(obj instanceof EntityRelationship)
		{
			return hash == ((EntityRelationship)obj).hash;
		}
		
		return false;
	}
	

	/**
	 * Determines if this relationship refers to the same tables and columns as
	 * the <code>other</code> relationship.
	 * 
	 * @param other
	 *            the relationship to check
	 * @return <code>true</code> if this relationship refers to the same tables
	 *         and columns as the <code>other</code> relationship,
	 *         <code>false</code> otherwise.
	 */
	public boolean equalsTablesAndColumns(EntityRelationship other)
	{
		Entity otherFirst = other.firstEntity;
		Entity otherSecond = other.secondEntity;
		return (firstEntity.refersTo(otherFirst) && secondEntity.refersTo(otherSecond))
				|| (firstEntity.refersTo(otherSecond) && secondEntity.refersTo(otherFirst));
	}
	

	/**
	 * Returns a hashcode built from the hashcodes of the related entities.
	 * 
	 * @return a hashcode
	 */
	@Override
	public int hashCode()
	{
		return hash;
	}
	

	/**
	 * Returns a {@link String} representation of this
	 * {@link EntityRelationship} containing both entities.
	 * 
	 * @return the relationship as {@link String}.
	 */
	@Override
	public String toString()
	{
		return new StringBuilder().append(firstEntity.tableName).append(".").append(
				firstEntity.columnName).append(" [ ").append(firstEntity.cardinality.toString())
				.append(" - ").append(secondEntity.cardinality.toString()).append(" ] ").append(
						secondEntity.tableName).append(".").append(secondEntity.columnName)
				.toString();
	}
	

	/**
	 * Creates a {@link Condition} that can be used for joining the entities of
	 * this {@link EntityRelationship} within SQL queries.
	 * 
	 * @return a {@link Condition}.
	 */
	public Condition getCondition()
	{
		String table1 = firstEntity.getTableName();
		String table2 = secondEntity.getTableName();
		
		VirtualTable vt1 = VirtualTables.getVirtualTable(table1);
		VirtualTable vt2 = VirtualTables.getVirtualTable(table2);
		
		if(vt1 == null || vt2 == null)
		{
			return null;
		}
		
		VirtualTableColumn col1 = vt1.getColumn(firstEntity.getColumnName());
		VirtualTableColumn col2 = vt2.getColumn(secondEntity.getColumnName());
		
		if(col1 == null || col2 == null)
		{
			return null;
		}
		
		return col1.toSqlColumn().eq(col2.toSqlColumn());
	}
	


	/**
	 * This class provides an abstraction for an entity within a
	 * {@link EntityRelationship}.
	 * 
	 * @author XDEV Software Corp.
	 * @see EntityRelationship
	 */
	public static class Entity implements Copyable<Entity>, Serializable
	{
		private static final long	serialVersionUID	= -4394075785300688603L;
		
		private final String		tableName;
		private final String		columnName;
		private final int			hash;
		private Cardinality			cardinality;
		

		/**
		 * Initializes a new {@link Entity}.
		 * 
		 * @param tableName
		 *            the table name of the entity.
		 * @param columnName
		 *            the column name used for the relationship to the other
		 *            entity.
		 * @param cardinality
		 *            the {@link Cardinality} of the entity.
		 */
		public Entity(String tableName, String columnName, Cardinality cardinality)
		{
			this.tableName = tableName;
			this.columnName = columnName;
			this.hash = MathUtils.computeHash(tableName,columnName);
			this.cardinality = cardinality;
		}
		

		/**
		 * Returns the table name.
		 * 
		 * @return the table name
		 */
		public String getTableName()
		{
			return tableName;
		}
		

		/**
		 * Returns the column name (name of the join column of the
		 * relationship).
		 * 
		 * @return the column name
		 */
		public String getColumnName()
		{
			return columnName;
		}
		

		/**
		 * Determines if this {@link Entity} refers to the specified table name.
		 * 
		 * @param tableName
		 *            name of the table to be checked.
		 * @return true, if this {@link Entity} refers to the specified
		 *         <code>tableName</code>, <code>false</code> otherwise.
		 */
		public boolean refersTo(String tableName)
		{
			return this.tableName.equals(tableName);
		}
		

		/**
		 * Determines if this {@link Entity} refers to the specified table and
		 * column name.
		 * 
		 * @param tableName
		 *            name of the table to be checked.
		 * @param columnName
		 *            name of the column to be checked.
		 * @return true, if this {@link Entity} refers to the specified
		 *         <code>tableName</code> and <code>columnName</code>,
		 *         <code>false</code> otherwise.
		 */
		public boolean refersTo(String tableName, String columnName)
		{
			return this.tableName.equals(tableName) && this.columnName.equals(columnName);
		}
		

		/**
		 * Determines if this {@link Entity} refers to the same table and column
		 * as <code>entity</code>.
		 * 
		 * @param entity
		 *            the {@link Entity} to check
		 * @return true, if this {@link Entity} refers to the same table and
		 *         column as <code>entity</code>, <code>false</code> otherwise.
		 */
		public boolean refersTo(Entity entity)
		{
			return refersTo(entity.tableName,entity.columnName);
		}
		

		/**
		 * Returns the fully qualified column name.
		 * 
		 * @return the column name
		 */
		public String getFullQualifiedName()
		{
			return tableName + "." + columnName;
		}
		

		/**
		 * Returns the {@link Cardinality} of the {@link Entity}.
		 * 
		 * @return a {@link Cardinality}
		 */
		public Cardinality getCardinality()
		{
			return cardinality;
		}
		

		/**
		 * Sets the {@link Cardinality} of the {@link Entity}.
		 * 
		 * @param cardinality
		 *            {@link Cardinality} to be set.
		 */
		public void setCardinality(Cardinality cardinality)
		{
			this.cardinality = cardinality;
		}
		

		/**
		 * Returns a copy of this {@link Entity}.
		 * 
		 * @return the copied {@link Entity}.
		 */
		@Override
		public Entity clone()
		{
			return new Entity(tableName,columnName,cardinality);
		}
		

		/**
		 * Checks this {@link Entity} with another {@link Entity} for equality.
		 * <p>
		 * The table name and the column name have to be equal to be considered
		 * equal.
		 * </p>
		 * 
		 * @param obj
		 *            the other Entity
		 * @return true if this Entity equals the other one.
		 */
		@Override
		public boolean equals(Object obj)
		{
			if(obj == this)
			{
				return true;
			}
			
			if(obj != null && obj instanceof Entity)
			{
				return ((Entity)obj).hash == hash;
			}
			
			return false;
		}
		

		/**
		 * Returns the hashcode of this {@link Entity} built from the name of
		 * the table and the name of the column.
		 * 
		 * @return a hashcode
		 */
		@Override
		public int hashCode()
		{
			return hash;
		}
		

		/**
		 * Returns an {@link String} representation for this {@link Entity}
		 * consisting of tablename, columnname and cardinality.
		 * 
		 * @return the entity as a String
		 */
		@Override
		public String toString()
		{
			return new StringBuilder().append(tableName).append(".").append(columnName)
					.append(" [").append(cardinality.toString()).append("]").toString();
		}
	}
}
