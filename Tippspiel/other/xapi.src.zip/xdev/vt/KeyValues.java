/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.vt;


import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import xdev.db.sql.Condition;
import xdev.db.sql.WHERE;
import xdev.vt.VirtualTable.VirtualTableRow;


/**
 * A container for the values of a {@link VirtualTableRow} which may belong to a
 * key of the according {@link VirtualTable}.
 * <p>
 * This class is not intended to be subclassed.<br>
 * All values are unmodifiable.
 * </p>
 * 
 * @author XDEV Software
 * @since 3.0
 */

public class KeyValues
{
	private final VirtualTable			virtualTable;
	private final Map<String, Object>	values;
	private boolean						isPrimaryKey	= false;
	private String						hash;
	

	/**
	 * Stores all values of the primary key columns of <code>record</code>.
	 * 
	 * @param record
	 *            The record of a {@link VirtualTable}
	 */
	
	public KeyValues(VirtualTableRow record)
	{
		if(record == null)
		{
			throw new IllegalArgumentException("record cannot be null");
		}
		
		this.virtualTable = record.getVirtualTable();
		VirtualTableColumn[] pkColumns = this.virtualTable.getPrimaryKeyColumns();
		if(pkColumns.length == 0)
		{
			throw new IllegalArgumentException("no primary key defined in '"
					+ this.virtualTable.getName() + "'");
		}
		
		Map<String, Object> values = new LinkedHashMap();
		for(VirtualTableColumn col : pkColumns)
		{
			values.put(col.getName(),record.get(this.virtualTable.getColumnIndex(col)));
		}
		this.values = Collections.unmodifiableMap(values);
		
		this.isPrimaryKey = true;
	}
	

	/**
	 * Stores a single primary key value pair and the {@link VirtualTable}.
	 * 
	 * @param virtualTable
	 *            The used {@link VirtualTable}
	 * @param singleKeyName
	 *            The column name of the single primary key column
	 * @param singleKeyValue
	 *            The value of the single primary key
	 */
	
	public KeyValues(VirtualTable virtualTable, String singleKeyName, Object singleKeyValue)
	{
		if(virtualTable == null)
		{
			throw new IllegalArgumentException("virtualTable cannot be null");
		}
		
		if(singleKeyName == null)
		{
			throw new IllegalArgumentException("singleKeyName cannot be null");
		}
		
		this.virtualTable = virtualTable;
		Map<String, Object> values = new HashMap();
		values.put(singleKeyName,singleKeyValue);
		this.values = Collections.unmodifiableMap(values);
	}
	

	/**
	 * Stores all <code>values</code> as the primary key.
	 * 
	 * @param virtualTable
	 *            The used {@link VirtualTable}
	 * @param values
	 *            The primary key value pairs
	 */
	
	public KeyValues(VirtualTable virtualTable, Map<String, Object> values)
	{
		if(virtualTable == null)
		{
			throw new IllegalArgumentException("virtualTable cannot be null");
		}
		
		if(values == null)
		{
			throw new IllegalArgumentException("values cannot be null");
		}
		
		this.virtualTable = virtualTable;
		this.values = Collections.unmodifiableMap(values);
	}
	

	/**
	 * Returns the {@link VirtualTable} to which this {@link KeyValues} refers.
	 * 
	 * @return The {@link VirtualTable} of this {@link KeyValues}
	 */
	
	public VirtualTable getVirtualTable()
	{
		return virtualTable;
	}
	

	/**
	 * Returns the column names of the primary key or an empty array if no
	 * values are set.
	 * 
	 * @return An array of the primary key's column names.
	 * @see #isEmpty()
	 */
	
	public String[] getColumnNames()
	{
		return values.keySet().toArray(new String[values.size()]);
	}
	

	/**
	 * Returns the column names of the primary key.
	 * 
	 * @return An {@link Iterable} over primary key's column names.
	 */
	
	public Iterable<String> columnNames()
	{
		return values.keySet();
	}
	

	/**
	 * Returns the primary key value mapped to <code>columnName</code>. If no
	 * column is found <code>null</code> is returned.
	 * 
	 * @param columnName
	 *            The column name of the primary key column
	 * @return The primary key value mapped to <code>columnName</code> or
	 *         <code>null</code>.
	 */
	
	public Object getValue(String columnName)
	{
		return values.get(columnName);
	}
	

	/**
	 * Returns <code>true</code> if no key-value mappings are present,
	 * <code>false</code> otherwise.
	 * 
	 * @return <code>true</code> if no key-value mappings are present
	 */
	
	public boolean isEmpty()
	{
		return values.isEmpty();
	}
	

	/**
	 * Returns the number of key-value pairs in this {@link KeyValues}.
	 * 
	 * @return The number of key-value pairs in this {@link KeyValues}
	 */
	public int getColumnCount()
	{
		return values.size();
	}
	

	/**
	 * Compares all values of this {@link KeyValues} to the according values in
	 * <code>record</code>.
	 * <p>
	 * Returns <code>true</code>, if and only if all values of the key columns
	 * are equal.
	 * 
	 * 
	 * @param record
	 *            The {@link VirtualTableRow} to check
	 * @return <code>true</code> if <code>record</code> matches this
	 *         {@link KeyValues}, <code>false</code> otherwise
	 */
	
	public boolean equals(VirtualTableRow record)
	{
		if(isPrimaryKey)
		{
			return hash().equals(record.primaryKeyHash);
		}
		
		for(String name : values.keySet())
		{
			Object thisVal = values.get(name);
			Object otherVal = record.get(virtualTable.getColumnIndex(name));
			if(!VirtualTable.equals(thisVal,otherVal))
			{
				return false;
			}
		}
		
		return true;
	}
	

	/**
	 * Appends the key-value pairs to the {@link WHERE} condition of query and
	 * the value-list.
	 */
	
	public void appendCondition(WHERE where, List values)
	{
		appendCondition(where,values,virtualTable);
	}
	

	public void appendCondition(WHERE where, List values, VirtualTable virtualTable)
	{
		boolean first = true;
		
		for(String name : this.values.keySet())
		{
			VirtualTableColumn col = virtualTable.getColumn(name);
			if(col != null)
			{
				if(first)
				{
					first = false;
					
					if(!where.isEmpty())
					{
						where.encloseWithPars();
					}
				}
				
				where.and(col.toSqlColumn().eq("?"));
				values.add(this.values.get(name));
			}
		}
	}
	

	public Condition getCondition(List values)
	{
		return getCondition(values,virtualTable);
	}
	

	public Condition getCondition(List values, VirtualTable virtualTable)
	{
		Condition condition = null;
		
		for(String name : this.values.keySet())
		{
			VirtualTableColumn col = virtualTable.getColumn(name);
			if(col != null)
			{
				Condition comparison = col.toSqlColumn().eq("?");
				if(condition == null)
				{
					condition = comparison;
				}
				else
				{
					condition.AND(comparison);
				}
				
				values.add(this.values.get(name));
			}
		}
		
		return condition;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object obj)
	{
		if(obj == this)
		{
			return true;
		}
		
		if(obj instanceof KeyValues)
		{
			KeyValues other = (KeyValues)obj;
			return virtualTable == other.virtualTable && values.equals(other.values);
		}
		
		return false;
	}
	

	private String hash()
	{
		if(hash == null)
		{
			hash = HashComputer.computeHash(values.values().toArray());
		}
		
		return hash;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode()
	{
		return hash().hashCode();
	}
}
