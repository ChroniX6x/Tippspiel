/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

package xdev.vt;


import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.io.Serializable;
import java.io.Writer;
import java.sql.Blob;
import java.sql.Clob;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;

import javax.swing.JFileChooser;
import javax.swing.JTable;
import javax.swing.event.EventListenerList;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.TableModel;
import javax.swing.tree.DefaultTreeModel;

import xdev.Application;
import xdev.db.ColumnMetaData;
import xdev.db.DBConnection;
import xdev.db.DBDataSource;
import xdev.db.DBException;
import xdev.db.DBMetaData.TableInfo;
import xdev.db.DBMetaData.TableMetaData;
import xdev.db.DBMetaData.TableType;
import xdev.db.DBUtils;
import xdev.db.Index;
import xdev.db.Index.IndexType;
import xdev.db.JoinType;
import xdev.db.QueryInfo;
import xdev.db.Result;
import xdev.db.Transaction;
import xdev.db.WriteRequest;
import xdev.db.WriteResult;
import xdev.db.sql.DELETE;
import xdev.db.sql.INSERT;
import xdev.db.sql.SELECT;
import xdev.db.sql.Sqlable;
import xdev.db.sql.Table;
import xdev.db.sql.UPDATE;
import xdev.db.sql.WHERE;
import xdev.db.sql.WritingQuery;
import xdev.io.ByteHolder;
import xdev.io.CharHolder;
import xdev.io.IOUtils;
import xdev.io.XdevObjectInputStream;
import xdev.io.XdevObjectOutputStream;
import xdev.io.csv.CSVReader;
import xdev.io.csv.CSVWriter;
import xdev.lang.Copyable;
import xdev.lang.XDEV;
import xdev.ui.ItemList;
import xdev.ui.UIUtils;
import xdev.ui.XdevFormular;
import xdev.ui.XdevTable;
import xdev.ui.XdevTree;
import xdev.ui.text.TextFormat;
import xdev.ui.tree.DefaultXdevTreeManager;
import xdev.ui.tree.XdevTreeNode;
import xdev.ui.tree.XdevTreeRenderer;
import xdev.util.ArrayUtils;
import xdev.util.DataSource;
import xdev.util.IntList;
import xdev.util.MathUtils;
import xdev.util.Settings;
import xdev.util.StringUtils;
import xdev.util.StringUtils.ParameterProvider;
import xdev.util.XdevList;
import xdev.vt.VirtualTableEvent.Type;


/**
 * A Virtual Table is the core element of the data layer of the XDEV Application
 * Framework and the connector of the presentation layer (GUI) and a
 * {@link DataSource}.
 * <p>
 * In most cases a Virtual Table has a similiar counterpart in a
 * {@link DataSource}, normally a table in a database which it can be
 * synchronized with.
 * </p>
 * <p>
 * The Virtual Table stores data in a relational way, organized in
 * {@link VirtualTableColumn}s and {@link VirtualTableRow}s.
 * </p>
 * <p>
 * Several connectors to gui beans are provided by default, e.g.
 * {@link VirtualTableModel}. All updates in the VirtualTable are automatically
 * reflected in the gui model and vice versa. To connect a Virtual Table with a
 * gui bean use the bean's setModel(...) methods, e.g.
 * {@link XdevTable#setModel(VirtualTable)}.
 * </p>
 * There are several ways to get data into a Virtual Table:<br>
 * - use one of the {@link #queryAndFill()} methods,<br>
 * - via the {@link XDEV#Query(xdev.lang.cmd.Query)} wizard of the XDEV IDE,<br>
 * - call the e.g. {@link XdevTable#setModel(VirtualTable, String, boolean)}
 * with the <code>queryData</code> parameter set to <code>true</code><br>
 * - and many more ...
 * <p>
 * To synchronize the Virtual Table with the underlying data source either<br>
 * - call the data manipulation methods, e.g {@link #addRow(List, boolean)} with
 * the <code>synchronizedDB</code> parameter set to <code>true</code><br>
 * - or invoke {@link #synchronizeChangedRows()}.
 * </p>
 * <p>
 * Virtual Tables can reflect an entire database. Therefor the tables can be
 * connected via {@link EntityRelationshipModel}s.
 * </p>
 * 
 * @see VirtualTableColumn
 * @see VirtualTableRow
 * @see KeyValues
 * @see EntityRelationships
 * @see DataSouce
 * @see DBDataSource
 * 
 * @author XDEV Software
 */
public class VirtualTable implements Serializable, Iterable<VirtualTableColumn>,
		Copyable<VirtualTable>, Sqlable<Table>
{
	private static final long						serialVersionUID				= -8132819103802989330L;
	
	/**
	 * the default Character set used within Virtual Tables.
	 */
	public final static String						CHARSET							= "UTF-8";
	/**
	 * the default DateFormat used within Virtual Tables.
	 */
	public final static String						DATE_FORMAT						= "yyyy-MM-dd HH:mm:ss";
	
	private final static String						FILE_HEADER						= "%CX VIRTUAL TABLE%";
	
	private String									name;
	private String									dbSchema;
	private String									dbAlias;
	private transient DBDataSource<?>				dataSource;
	private VirtualTableColumn						primaryColumn;
	
	private int										cursorpos						= -1;
	
	private VirtualTableData						data;
	
	private final static int						FLAG_UNIQUE						= 0x0001;
	
	// columns + info
	protected VirtualTableColumn[]					columns;
	// private long[] maxVal;
	private int[]									columnFlags;
	
	private List<VirtualTableIndex>					indices							= new ArrayList(
																							3);
	private boolean									checkUniqueIndexDoubleValues	= true;
	
	// caches
	private Map<Integer, List<VirtualTableIndex>>	columnToIndex					= new Hashtable();
	private Map<String, Integer>					columnNameToIndex				= new Hashtable();
	private Map<String, Integer>					columnSimpleNameToIndex			= new Hashtable();
	private String[]								autoValueColumns				= null;
	
	private EventListenerList						listenerList					= new EventListenerList();
	
	private transient QueryInfo						lastQuery;
	private transient int[]							lastQueryIndices;
	

	/**
	 * Constructor for creating a new instance of a {@link VirtualTable}.
	 * 
	 * @param rs
	 *            a {@link Result} containing the data to be wrapped by this
	 *            {@link VirtualTable}
	 */
	public VirtualTable(Result rs)
	{
		this(rs,false);
	}
	

	/**
	 * Constructor for creating a new instance of a {@link VirtualTable}.
	 * 
	 * @param rs
	 *            a {@link Result} containing the data to be wrapped by this
	 *            {@link VirtualTable}
	 * @param withData
	 *            boolean flag, indicating if the provided Result contains data
	 */
	public VirtualTable(Result rs, boolean withData)
	{
		name = "";
		
		data = new VirtualTableData(withData ? 100 : 10);
		
		int cols = rs.getColumnCount();
		// maxVal = new long[cols];
		columns = new VirtualTableColumn[cols];
		columnFlags = new int[cols];
		int[] columnIndices = new int[cols];
		for(int i = 0; i < cols; i++)
		{
			ColumnMetaData meta = rs.getMetadata(i);
			columns[i] = new VirtualTableColumn(meta);
			columns[i].setNullable(true);
			if(i == 0)
			{
				name = meta.getTable();
				if(name == null)
				{
					name = "";
				}
			}
			else if(name.length() > 0 && !name.equals(meta.getTable()))
			{
				name = "";
			}
			
			// maxVal[i] = 0l;
			columnFlags[i] = 0;
			columnIndices[i] = i;
		}
		connectWithColumns();
		
		dbAlias = name;
		
		primaryColumn = columns[0];
		
		if(withData)
		{
			try
			{
				addData(rs,columnIndices);
			}
			catch(Exception e)
			{
				throw new VirtualTableException(e);
			}
		}
	}
	

	/**
	 * Constructor for creating a new instance of a {@link VirtualTable}.
	 * 
	 * @param name
	 *            {@link String} containing the name of this Virtual Table.
	 * @param dbAlias
	 *            {@link String} containing the dbAlias
	 * @param columns
	 *            a number of {@link VirtualTableColumn} instances containing
	 *            all columns for this Virtual Table
	 */
	public VirtualTable(String name, String dbAlias, VirtualTableColumn... columns)
	{
		this(name,null,dbAlias,columns);
	}
	

	/**
	 * Constructor for creating a new instance of a {@link VirtualTable}.
	 * 
	 * @param name
	 *            {@link String} containing the name of this Virtual Table.
	 * @param dbSchema
	 *            {@link String} containing the dbSchema, may be
	 *            <code>null</code>
	 * @param dbAlias
	 *            {@link String} containing the dbAlias
	 * @param columns
	 *            a number of {@link VirtualTableColumn} instances containing
	 *            all columns for this Virtual Table
	 */
	public VirtualTable(String name, String dbSchema, String dbAlias, VirtualTableColumn... columns)
	{
		this(name,dbSchema,dbAlias,columns,columns[0],null);
	}
	

	/**
	 * Constructor for creating a new instance of a {@link VirtualTable}.
	 * 
	 * @param name
	 *            {@link String} containing the name of this Virtual Table.
	 * @param dbAlias
	 *            {@link String} containing the dbAlias
	 * @param columns
	 *            an array of {@link VirtualTableColumn} containing all columns
	 *            for this Virtual Table.
	 * @param primaryColumn
	 *            {@link VirtualTableColumn} containing the primary (key) column
	 *            for this Virtual Table
	 * @param data
	 *            a two-dimensional array of {@link Object} instances containing
	 *            the data for this Virtual Table
	 */
	public VirtualTable(String name, String dbAlias, VirtualTableColumn[] columns,
			VirtualTableColumn primaryColumn, Object[][] data)
	{
		this(name,null,dbAlias,columns,primaryColumn,data);
	}
	

	/**
	 * Constructor for creating a new instance of a {@link VirtualTable}.
	 * 
	 * @param name
	 *            {@link String} containing the name of this Virtual Table.
	 * @param dbSchema
	 *            {@link String} containing the dbSchema, may be
	 *            <code>null</code>
	 * @param dbAlias
	 *            {@link String} containing the dbAlias
	 * @param columns
	 *            an array of {@link VirtualTableColumn} containing all columns
	 *            for this Virtual Table.
	 * @param primaryColumn
	 *            {@link VirtualTableColumn} containing the primary (key) column
	 *            for this Virtual Table
	 * @param data
	 *            a two-dimensional array of {@link Object} instances containing
	 *            the data for this Virtual Table
	 */
	public VirtualTable(String name, String dbSchema, String dbAlias, VirtualTableColumn[] columns,
			VirtualTableColumn primaryColumn, Object[][] data)
	{
		this.name = name;
		this.dbSchema = "".equals(dbSchema) ? null : dbSchema;
		this.dbAlias = dbAlias;
		
		this.columns = columns;
		connectWithColumns();
		
		int cols = columns.length;
		
		// this.maxVal = new long[cols];
		this.columnFlags = new int[cols];
		for(int i = 0; i < cols; i++)
		{
			// this.maxVal[i] = 0l;
			this.columnFlags[i] = 0;
		}
		
		this.primaryColumn = primaryColumn != null ? primaryColumn : columns[0];
		
		if(data != null)
		{
			this.data = new VirtualTableData(data.length);
			for(int r = 0; r < data.length; r++)
			{
				VirtualTableRow row = new VirtualTableRow(cols,r);
				for(int c = 0; c < cols; c++)
				{
					row.set(c,data[r][c],false,false);
				}
				this.data.add(row,false);
			}
		}
		else
		{
			this.data = new VirtualTableData(10);
		}
	}
	

	/**
	 * This method returns a copy of this {@link VirtualTable} instance without
	 * the data.
	 * 
	 * @return a copied {@link VirtualTable} of this instance
	 */
	public VirtualTable copyHeader()
	{
		return clone(false);
	}
	

	/**
	 * This method returns a copy of this {@link VirtualTable} instance. The
	 * data of the table won't be copied
	 * 
	 * @return a copied {@link VirtualTable} of this instance
	 */
	@Override
	public VirtualTable clone()
	{
		return clone(false);
	}
	

	/**
	 * This method returns a copy of this {@link VirtualTable} instance.
	 * 
	 * @param withData
	 *            boolean flag, indicating if data should be copied, too.
	 * @return a copied {@link VirtualTable} of this instance
	 */
	public VirtualTable clone(boolean withData)
	{
		try
		{
			VirtualTable vt = (VirtualTable)getClass().newInstance();
			vt.takeValues(this,withData);
			
			// reconnect static columns (see issue 11929)
			connectWithColumns();
						
			return vt;
		}
		catch(Exception e)
		{
			// shouldn't happen
			Application.getLogger().error(e);
			throw new RuntimeException(e);
		}
	}
	

	@SuppressWarnings("unused")
	private VirtualTable()
	{
	}
	

	private void takeValues(VirtualTable vt, boolean withData)
	{
		name = vt.name;
		dataSource = vt.dataSource;
		dbSchema = vt.dbSchema;
		dbAlias = vt.dbAlias;
		
		columns = new VirtualTableColumn[vt.columns.length];
		for(int i = 0; i < vt.columns.length; i++)
		{
			columns[i] = vt.columns[i].clone();
		}
		connectWithColumns();
		
		primaryColumn = columns[vt.getColumnIndex(vt.primaryColumn)];
		
		// maxVal = new long[columns.length];
		columnFlags = new int[columns.length];
		
		for(int i = 0; i < columns.length; i++)
		{
			// maxVal[i] = 0l;
			columnFlags[0] = 0;
		}
		
		indices.clear();
		for(VirtualTableIndex vtIndex : vt.indices)
		{
			addIndex(vtIndex._originalIndex);
		}
		
		checkUniqueIndexDoubleValues = vt.checkUniqueIndexDoubleValues;
		
		if(withData)
		{
			int rc = vt.getRowCount();
			data = new VirtualTableData(rc);
			for(int i = 0; i < rc; i++)
			{
				data.add(vt.getRow(i).clone(),false);
			}
		}
		else
		{
			data = new VirtualTableData(10);
		}
	}
	

	private void connectWithColumns()
	{
		for(VirtualTableColumn column : columns)
		{
			column.setVirtualTable(this);
		}
	}
	

	/**
	 * Adds an {@link Index} to this {@link VirtualTable}.
	 * 
	 * @param index
	 *            the {@link Index} to be added.
	 * @throws NullPointerException
	 *             if the Index contains columns not found in this Virtual Table
	 */
	public void addIndex(Index index) throws NullPointerException
	{
		VirtualTableIndex vtIndex = new VirtualTableIndex(index);
		this.indices.add(vtIndex);
		for(String columnName : index.getColumns())
		{
			int colIndex = getColumnIndex(columnName);
			if(colIndex == -1)
			{
				throw new NullPointerException("Column '" + columnName + "' not found");
			}
			
			List<VirtualTableIndex> columnIndices = this.columnToIndex.get(colIndex);
			if(columnIndices == null)
			{
				columnIndices = new ArrayList(2);
				this.columnToIndex.put(colIndex,columnIndices);
			}
			columnIndices.add(vtIndex);
			
			if(index.isUnique())
			{
				columnFlags[colIndex] |= FLAG_UNIQUE;
			}
		}
	}
	

	/**
	 * Returns true if all elements of this {@link VirtualTableColumn} are
	 * unique.
	 * 
	 * @param column
	 *            the {@link VirtualTableColumn} to be checked.
	 * @return true, if unique
	 */
	public boolean isUnique(VirtualTableColumn column)
	{
		return (columnFlags[getColumnIndex(column)] & FLAG_UNIQUE) == FLAG_UNIQUE;
	}
	

	void checkColumnDefaults()
	{
		for(int i = 0; i < columns.length; i++)
		{
			Object def = columns[i].getDefaultValue();
			columns[i].setDefaultValue(checkValue(i,def));
		}
	}
	

	/**
	 * Adds a {@link VirtualTableListener} to this {@link VirtualTable}.
	 * <ul>
	 * <li>a row is inserted, updated or deleted</li>
	 * <li>the data of the Virtual Table changes</li>
	 * <li>a structural change of the Virtual Table happens, e.g. a column gets
	 * removed</li>
	 * </ul>
	 * 
	 * @param l
	 *            {@link VirtualTableListener} to be added
	 */
	public void addVirtualTableListener(VirtualTableListener l)
	{
		listenerList.add(VirtualTableListener.class,l);
	}
	

	/**
	 * Removes a {@link VirtualTableListener} from this {@link VirtualTable}.
	 * The listener gets notified, whenever:
	 * <ul>
	 * <li>a row is inserted, updated or deleted</li>
	 * <li>the data of the Virtual Table changes</li>
	 * <li>a structural change of the Virtual Table happens, e.g. a column gets
	 * removed</li>
	 * </ul>
	 * 
	 * @param l
	 *            {@link VirtualTableListener} to be removed
	 */
	public void removeVirtualTableListener(VirtualTableListener l)
	{
		listenerList.remove(VirtualTableListener.class,l);
	}
	

	/**
	 * This method notifies all registered listeners, whenever a row gets
	 * deleted.
	 * 
	 * @param row
	 *            the {@link VirtualTableRow} to be deleted,
	 * @param rowIndex
	 *            the index of the row to be deleted within the Virtual Table.
	 */
	protected void fireRowDeleted(VirtualTableRow row, int rowIndex)
	{
		cursorpos = -1;
		
		VirtualTableListener[] listeners = listenerList.getListeners(VirtualTableListener.class);
		if(listeners != null && listeners.length > 0)
		{
			VirtualTableEvent event = new VirtualTableEvent(this,Type.REMOVED,row,rowIndex);
			for(VirtualTableListener listener : listeners)
			{
				listener.virtualTableRowDeleted(event);
			}
		}
	}
	

	/**
	 * This method notifies all registered listeners, whenever a row gets
	 * inserted.
	 * 
	 * @param row
	 *            the {@link VirtualTableRow} to be deleted,
	 * @param rowIndex
	 *            the index where the row gets inserted to the Virtual Table.
	 */
	protected void fireRowInserted(VirtualTableRow row, int rowIndex)
	{
		cursorpos = -1;
		
		VirtualTableListener[] listeners = listenerList.getListeners(VirtualTableListener.class);
		if(listeners != null && listeners.length > 0)
		{
			VirtualTableEvent event = new VirtualTableEvent(this,Type.REMOVED,row,rowIndex);
			for(VirtualTableListener listener : listeners)
			{
				listener.virtualTableRowInserted(event);
			}
		}
	}
	

	/**
	 * This method notifies all registered listeners, whenever a row gets
	 * updated.
	 * 
	 * @param row
	 *            the {@link VirtualTableRow} to be updated,
	 * @param rowIndex
	 *            the index of the row to be updated within the Virtual Table.
	 */
	protected void fireRowUpdated(VirtualTableRow row, int rowIndex)
	{
		VirtualTableListener[] listeners = listenerList.getListeners(VirtualTableListener.class);
		if(listeners != null && listeners.length > 0)
		{
			VirtualTableEvent event = new VirtualTableEvent(this,Type.REMOVED,row,rowIndex);
			for(VirtualTableListener listener : listeners)
			{
				listener.virtualTableRowUpdated(event);
			}
		}
	}
	

	/**
	 * This method notifies all registered listeners, whenever the data of this
	 * Virtual Table changes.
	 */
	protected void fireDataChanged()
	{
		cursorpos = -1;
		
		VirtualTableListener[] listeners = listenerList.getListeners(VirtualTableListener.class);
		if(listeners != null && listeners.length > 0)
		{
			VirtualTableEvent event = new VirtualTableEvent(this);
			for(VirtualTableListener listener : listeners)
			{
				listener.virtualTableDataChanged(event);
			}
		}
	}
	

	/**
	 * This method notifies all registered listeners, whenever the structure of
	 * this Virtual Table is modified. One example for such a modification is
	 * the removal of a column.
	 */
	protected void fireStructureChanged()
	{
		cursorpos = -1;
		
		VirtualTableListener[] listeners = listenerList.getListeners(VirtualTableListener.class);
		if(listeners != null && listeners.length > 0)
		{
			VirtualTableEvent event = new VirtualTableEvent(this);
			for(VirtualTableListener listener : listeners)
			{
				listener.virtualTableStructureChanged(event);
			}
		}
	}
	

	/**
	 * Returns the name of this {@link VirtualTable}.
	 * 
	 * @return {@link String} containing the name
	 */
	public String getName()
	{
		return name;
	}
	

	/**
	 * Sets an explicit {@link DataSource} for this <code>VirtualTable</code>.
	 * 
	 * @param dataSource
	 *            the new data source, or <code>null</code> if the application's
	 *            default data source should be used
	 */
	public void setDataSource(DBDataSource<?> dataSource)
	{
		this.dataSource = dataSource;
	}
	

	/**
	 * Returns <code>true</code> if {@link #setDataSource(DBDataSource)} has
	 * been invoked with a non-null value., <code>false</code> otherwise.
	 * 
	 * @return <code>true</code> if {@link #setDataSource(DBDataSource)} has
	 *         been invoked with a non-null value.
	 */
	public boolean isDataSourceSet()
	{
		return dataSource != null;
	}
	

	/**
	 * Returns the {@link DBDataSource} of this {@link VirtualTable}. If this
	 * {@link VirtualTable} has no <code>DBDataSource</code>, the current
	 * <code>DBDataSource</code> will be returned.
	 * 
	 * @return a {@link DBDataSource}
	 * @throws DBException
	 */
	public DBDataSource<?> getDataSource() throws DBException
	{
		if(dataSource != null)
		{
			return dataSource;
		}
		
		return DBUtils.getCurrentDataSource();
	}
	

	/**
	 * Returns the database schema of this {@link VirtualTable}, may be
	 * <code>null</code>.
	 * 
	 * @return the database schema of this {@link VirtualTable}.
	 */
	public String getDatabaseSchema()
	{
		return dbSchema;
	}
	

	/**
	 * Returns the database alias of this {@link VirtualTable}.
	 * 
	 * @return the database alias of this {@link VirtualTable}.
	 */
	public String getDatabaseAlias()
	{
		return dbAlias;
	}
	

	/**
	 * Returns the primary column of this {@link VirtualTable}.
	 * 
	 * @return the {@link VirtualTableColumn} instance of the primary column.
	 *         May be null.
	 */
	public VirtualTableColumn<?> getPrimaryColumn()
	{
		return primaryColumn;
	}
	

	/**
	 * Sets the primary column of this {@link VirtualTable}. The previous value
	 * get overwritten.
	 * 
	 * @param primaryColumn
	 *            a {@link VirtualTableColumn} instance for the new primary
	 *            column
	 * @throws IllegalArgumentException
	 *             if the primary column is not contained in this Virtual Table.
	 */
	public void setPrimaryColumn(VirtualTableColumn primaryColumn) throws IllegalArgumentException
	{
		if(!ArrayUtils.contains(columns,primaryColumn))
		{
			throw new IllegalArgumentException("Not a column of this VirtualTable");
		}
		
		this.primaryColumn = primaryColumn;
	}
	

	/**
	 * Returns the number of columns.
	 * 
	 * @return the number of columns as int value.
	 */
	public int getColumnCount()
	{
		return columns.length;
	}
	

	/**
	 * Returns the {@link VirtualTableColumn} with the specified name.
	 * 
	 * @param name
	 *            as a {@link String}
	 * @return the {@link VirtualTableColumn} for the specified name, or null if
	 *         no column is found.
	 */
	public VirtualTableColumn<?> getColumn(String name)
	{
		int i = getColumnIndex(name);
		if(i == -1)
		{
			return null;
		}
		
		return columns[i];
	}
	

	/**
	 * Returns the index of the column with the specified name.
	 * 
	 * @param name
	 *            as a {@link String}
	 * @return the index for the specified column as int value, -1 is returned
	 *         if no column is found.
	 */
	public int getColumnIndex(String name)
	{
		name = name.toUpperCase();
		
		Integer index = columnNameToIndex.get(name);
		if(index != null)
		{
			return index;
		}
		
		int i;
		
		for(i = 0; i < columns.length; i++)
		{
			if(columns[i].getName().equalsIgnoreCase(name))
			{
				columnNameToIndex.put(name,i);
				return i;
			}
		}
		
		i = name.lastIndexOf('.');
		if(i >= 0)
		{
			name = name.substring(i + 1);
			
			index = columnSimpleNameToIndex.get(name);
			if(index != null)
			{
				return index;
			}
			
			for(i = 0; i < columns.length; i++)
			{
				if(columns[i].getName().equalsIgnoreCase(name))
				{
					columnSimpleNameToIndex.put(name,i);
					return i;
				}
			}
		}
		
		return -1;
	}
	

	/**
	 * Returns a {@link List} of {@link String} objects with the column names of
	 * this {@link VirtualTable}.
	 * 
	 * @param exceptCol
	 *            a index of a column, not to be included within the list of
	 *            columns.
	 * @return a {@link List} with all column names, except the one specified by
	 *         param exceptCol.
	 */
	public List<String> getColumnNames(int exceptCol)
	{
		List<String> v = new ArrayList(columns.length);
		for(int i = 0; i < columns.length; i++)
		{
			if(i != exceptCol)
			{
				v.add(columns[i].getName());
			}
		}
		
		return v;
	}
	

	/**
	 * Returns the name of the column with the specified index. The first column
	 * has the index 0.
	 * <p>
	 * Example:
	 * 
	 * <pre>
	 * ExampleVT.getColumnName(3);
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @param col
	 *            the index of the column, which name is to be returned
	 * @return the name of the column at the specified index
	 * @see #getCaptions()
	 * @see #getColumnIndex(String)
	 * @see #getRowCount()
	 */
	public String getColumnName(int col)
	{
		return columns[col].getName();
	}
	

	/**
	 * Returns the caption of the column with the specified index. The first
	 * column has index 0. If the caption is empty, the name of the column will
	 * be returned.
	 * 
	 * @param col
	 *            the index of the column, which name is to be returned
	 * @return the caption of the column at the specified index
	 */
	public String getColumnCaption(int col)
	{
		String caption = columns[col].getCaption();
		if(caption != null && caption.length() > 0)
		{
			return caption;
		}
		
		return columns[col].getName();
	}
	

	/**
	 * Returns a array of {@link String} objects with all captions.
	 * 
	 * @return all captions as String array.
	 */
	public String[] getColumnCaptions()
	{
		int len = columns.length;
		String[] s = new String[len];
		for(int col = 0; col < len; col++)
		{
			s[col] = getColumnCaption(col);
		}
		return s;
	}
	

	/**
	 * Return the index for the specified {@link VirtualTableColumn}.
	 * 
	 * @param col
	 *            the {@link VirtualTableColumn}, whose index is to be returned
	 * @return the index for the specified column. -1 is returned if
	 *         VirtualTableColumn is not found.
	 */
	public int getColumnIndex(VirtualTableColumn col)
	{
		for(int i = 0; i < columns.length; i++)
		{
			if(columns[i] == col)
			{
				return i;
			}
		}
		
		return -1;
	}
	

	/**
	 * Return the indices for the specified {@link VirtualTableColumn}.
	 * 
	 * @param columns
	 *            the {@link VirtualTableColumn}s, whose index is to be returned
	 * @return the indices for the specified columns.
	 */
	public int[] getColumnIndices(VirtualTableColumn... columns)
	{
		int[] indices = new int[columns.length];
		for(int i = 0; i < columns.length; i++)
		{
			indices[i] = getColumnIndex(columns[i]);
		}
		return indices;
	}
	

	/**
	 * Returns the {@link VirtualTableColumn} at the specified index position.
	 * 
	 * @param index
	 *            the index of the {@link VirtualTableColumn} to be returned
	 * @return the {@link VirtualTableColumn} at the specified index
	 * @throws ArrayIndexOutOfBoundsException
	 *             if <code>index &lt; -1</code> or
	 *             <code>index > getColumnCount-1</code>
	 */
	public VirtualTableColumn<?> getColumnAt(int index) throws ArrayIndexOutOfBoundsException
	{
		return columns[index];
	}
	

	/**
	 * Returns the {@link VirtualTableColumn}s at the specified positions.
	 * 
	 * @param indices
	 *            the indices of the {@link VirtualTableColumn}s to be returned
	 * @return the {@link VirtualTableColumn}s at the specified indices
	 * @throws ArrayIndexOutOfBoundsException
	 *             if <code>indices[i] &lt; -1</code> or
	 *             <code>indices[i] > getColumnCount-1</code>
	 */
	public VirtualTableColumn<?>[] getColumnsAt(int[] indices)
			throws ArrayIndexOutOfBoundsException
	{
		VirtualTableColumn[] columns = new VirtualTableColumn[indices.length];
		for(int i = 0; i < indices.length; i++)
		{
			columns[i] = this.columns[indices[i]];
		}
		return columns;
	}
	

	/**
	 * Returns an iterator over all columns of this VirtualTable in their
	 * natural order.
	 * <p>
	 * Note: The returned iterator doesn't support {@link Iterator#remove()}.
	 * </p>
	 * 
	 * 
	 * @return An interator over the columns
	 */
	
	public Iterator<VirtualTableColumn> iterator()
	{
		return ArrayUtils.getIterator(columns);
	}
	

	/**
	 * Returns an iterator over all columns of this VirtualTable in their
	 * natural order.
	 * <p>
	 * Note: The returned iterator doesn't support {@link Iterator#remove()}.
	 * </p>
	 * 
	 * 
	 * @return An interator over the columns
	 */
	
	public Iterable<VirtualTableColumn> columns()
	{
		return this;
	}
	

	/**
	 * Returns an iterator over all rows of this VirtualTable in their natural
	 * order.
	 * <p>
	 * Note: The returned iterator doesn't support {@link Iterator#remove()}.
	 * </p>
	 * 
	 * 
	 * @return An interator over the rows
	 */
	public Iterable<VirtualTableRow> rows()
	{
		return data;
	}
	

	/**
	 * Returns the number of rows for this {@link VirtualTable}.
	 * 
	 * @return the number of rows
	 */
	public int getRowCount()
	{
		return data.size();
	}
	

	/**
	 * Returns the value of the cell specified by column name and the row of the
	 * current cursor position.
	 * 
	 * @param columnName
	 *            the name of the column
	 * @return the value of the cell at the specified position.
	 */
	public Object getValueAt(String columnName)
	{
		return getValueAt(getColumnIndex(columnName));
	}
	

	/**
	 * Returns the value of the cell specified by column index and the row of
	 * the current cursor position.
	 * 
	 * @param col
	 *            the index of the column (0-based).
	 * @return the value of the cell at the specified position.
	 */
	public Object getValueAt(int col)
	{
		return getValueAt(cursorpos,col);
	}
	

	/**
	 * Returns the value of the cell specified by the row index and column
	 * index.
	 * <p>
	 * Example:
	 * 
	 * <pre>
	 * ExampleVT.addRow();
	 * ExampleVT.getValueAt(0,2);
	 * </pre>
	 * 
	 * </p>
	 * 
	 * @param row
	 *            the index of the row (0-based)
	 * @param col
	 *            the index of the column (0-based)
	 * @return the value of the cell at the specified position
	 */
	public Object getValueAt(int row, int col)
	{
		return data.get(row).get(col);
	}
	

	/**
	 * Returns the value of the cell specified by column name and the row of the
	 * current cursor position.
	 * 
	 * @param row
	 *            the index of the row (0-based)
	 * @param columnName
	 *            the name of the column
	 * @return the value of the cell at the specified position.
	 */
	public Object getValueAt(int row, String columnName)
	{
		int col = getColumnIndex(columnName);
		if(col == -1)
		{
			throw new IllegalArgumentException("Column '" + columnName + "' not found");
		}
		
		return getValueAt(row,col);
	}
	

	/**
	 * Returns the value of the cell specified by a {@link VirtualTableColumn}
	 * and the row of the current cursor position.
	 * 
	 * @param row
	 *            the index of the row (0-based)
	 * @param column
	 *            {@link VirtualTableColumn}
	 * 
	 * @return the value of the cell at the specified position.
	 * 
	 * @throws IllegalArgumentException
	 *             if column is not not within this Virtual Table
	 */
	public <T> T getValueAt(int row, VirtualTableColumn<T> column) throws IllegalArgumentException
	{
		int columnIndex = ArrayUtils.indexOf(columns,column);
		if(columnIndex == -1)
		{
			throw new IllegalArgumentException("Column doesn't belong to this VirtualTable");
		}
		
		return (T)getValueAt(row,columnIndex);
	}
	

	/**
	 * Returns a formatted representation for the value at the cell position
	 * specified by row and col. The {@link TextFormat} of the
	 * {@link VirtualTableColumn} at index col is used to format the value.
	 * 
	 * @param row
	 *            the index of the row (0-based)
	 * @param col
	 *            the index of the column (0-based)
	 * @return a formatted {@link String} representation of the specified value.
	 */
	public String getFormattedValueAt(int row, int col)
	{
		return formatValue(getValueAt(row,col),col);
	}
	

	/**
	 * Returns a formatted string, with the {@link VirtualTableRow} at
	 * <code>row</code> used as ParameterProvider.
	 * <p>
	 * This is a shortcut for <code>getRow(row).format(str)</code>.
	 * 
	 * @param row
	 *            the row index
	 * @param str
	 *            the {@link String} to format
	 * @return a formatted {@link String}
	 * @see VirtualTableRow#format(String)
	 */
	public String format(int row, String str)
	{
		return getRow(row).format(str);
	}
	

	/**
	 * Returns a formatted representation for the value at the cell position
	 * specified by row and column name. The {@link TextFormat} of the
	 * {@link VirtualTableColumn} with name columnName is used to format the
	 * value.
	 * 
	 * @param row
	 *            the index of the row (0-based)
	 * @param columnName
	 *            the name of the column
	 * @return a formatted {@link String} representation of the specified value.
	 */
	public String getFormattedValueAt(int row, String columnName)
	{
		int col = getColumnIndex(columnName);
		if(col == -1)
		{
			return "";
		}
		
		return getFormattedValueAt(row,col);
	}
	

	/**
	 * Returns a formatted representation for the value at the cell position
	 * specified by row and a {@link VirtualTableColumn}. The {@link TextFormat}
	 * of the {@link VirtualTableColumn} is used to format the value.
	 * 
	 * @param row
	 *            the index of the row (0-based)
	 * @param column
	 *            the {@link VirtualTableColumn}
	 * @return a formatted {@link String} representation of the specified value.
	 */
	public String getFormattedValueAt(int row, VirtualTableColumn column)
	{
		int columnIndex = ArrayUtils.indexOf(columns,column);
		if(columnIndex == -1)
		{
			throw new IllegalArgumentException("Column doesn't belong to this VirtualTable");
		}
		
		return getFormattedValueAt(row,columnIndex);
	}
	

	/**
	 * Returns a formatted representation of the specified value using the
	 * {@link TextFormat} of the {@link VirtualTableColumn} specified by index
	 * col.
	 * 
	 * @param value
	 *            the value to be formatted
	 * @param col
	 *            the index of the {@link VirtualTableColumn}
	 * @return a formatted {@link String} representation of the specified value.
	 */
	public String formatValue(Object value, int col)
	{
		if(value == null)
		{
			return "";
		}
		
		return columns[col].getTextFormat().format(value);
	}
	

	/**
	 * Sets the value of a cell at the position specified by the current cursor
	 * position and the column name.
	 * 
	 * @param val
	 *            the value to be set
	 * @param columnName
	 *            the name of the column
	 * @return the new value of the cell
	 * @throws VirtualTableException
	 *             if the value is not appropriate for the specified column
	 * @throws IllegalArgumentException
	 *             if the column <code>columnName</code> does not exist in this
	 *             {@link VirtualTable}
	 */
	public Object setValueAt(Object val, String columnName) throws VirtualTableException,
			IllegalArgumentException
	{
		return setValueAt(val,cursorpos,columnName);
	}
	

	/**
	 * Sets the value of a cell at the position specified by the row and the
	 * column name.
	 * 
	 * @param val
	 *            the value to be set
	 * @param row
	 *            the index of the row (0-based)
	 * @param columnName
	 *            the name of the column
	 * @return the new value of the the cell
	 * @throws VirtualTableException
	 *             if the value is not appropriate for the specified column
	 * @throws IllegalArgumentException
	 *             if the column <code>columnName</code> does not exist in this
	 *             {@link VirtualTable}
	 */
	public Object setValueAt(Object val, int row, String columnName) throws VirtualTableException,
			IllegalArgumentException
	{
		int col = getColumnIndex(columnName);
		if(col == -1)
		{
			throw new IllegalArgumentException("column '" + columnName + "' not found");
		}
		
		return setValueAt(val,row,col);
	}
	

	/**
	 * Sets the value of a cell at the position specified by the current cursor
	 * position and the column index.
	 * 
	 * @param val
	 *            the value to be set
	 * @param col
	 *            the index of the column (0-based)
	 * @return the new value of the cell
	 * @throws VirtualTableException
	 *             if the value is not appropriate for the specified column
	 */
	public Object setValueAt(Object val, int col) throws VirtualTableException
	{
		return setValueAt(val,cursorpos,col);
	}
	

	/**
	 * Sets the value of a cell at the position specified by the row index and
	 * the column index.
	 * 
	 * @param val
	 *            the value to be set
	 * @param row
	 *            the index of the row (0-based).
	 * @param col
	 *            the index of the column (0-based).
	 * 
	 * @return the new value of the cell
	 * 
	 * @throws VirtualTableException
	 *             if the value is not appropriate for the specified column
	 */
	public Object setValueAt(Object val, int row, int col) throws VirtualTableException
	{
		return setValueAt(val,row,col,false);
	}
	

	/**
	 * Sets the value of a cell at the position specified by the row index and
	 * the column index.
	 * 
	 * @param val
	 *            the value to be set
	 * @param row
	 *            the index of the row (0-based).
	 * @param col
	 *            the index of the column (0-based).
	 * @param synchronizeDB
	 *            boolean, if set to true, value will be written to the
	 *            underlying data source
	 * 
	 * @return the new value of the cell
	 * 
	 * @throws VirtualTableException
	 *             if <code>synchronizeDB</code> is <code>true</code> and no
	 *             primary key is specified for this Virtual Table, or if the
	 *             value is not appropriate for the specified column
	 */
	public Object setValueAt(Object val, int row, int col, boolean synchronizeDB)
			throws VirtualTableException
	{
		return setValueAt(val,row,col,synchronizeDB,true);
	}
	

	/**
	 * Sets the value of a cell at the position specified by the row index and
	 * the column index.
	 * 
	 * @param val
	 *            the value to be set
	 * 
	 * @param row
	 *            the index of the row (0-based).
	 * 
	 * @param col
	 *            the index of the column (0-based).
	 * 
	 * @param synchronizeDB
	 *            boolean, if set to true, value will be written to the
	 *            underlying data source
	 * 
	 * @param markAsUpdated
	 *            boolean, if set to true, the row containing the cell will be
	 *            marked as changed.
	 * 
	 * @return the new value of the cell
	 * 
	 * @throws VirtualTableException
	 *             if <code>synchronizeDB</code> is <code>true</code> and no
	 *             primary key is specified for this Virtual Table, or if the
	 *             value is not appropriate for the specified column
	 */
	public Object setValueAt(Object val, int row, int col, boolean synchronizeDB,
			boolean markAsUpdated) throws VirtualTableException
	{
		return setValueAt(val,row,col,synchronizeDB,markAsUpdated,true);
	}
	

	/**
	 * Sets the value of a cell at the position specified by the row index and
	 * the column index.
	 * 
	 * @param val
	 *            the value to be set
	 * 
	 * @param row
	 *            the index of the row (0-based).
	 * 
	 * @param col
	 *            the index of the column (0-based).
	 * 
	 * @param synchronizeDB
	 *            boolean, if set to true, value will be written to the
	 *            underlying data source
	 * 
	 * @param markAsUpdated
	 *            boolean, if set to true, the row containing the cell will be
	 *            marked as changed.
	 * 
	 * @param checkUnique
	 *            boolean, if set to true, the value will checked for
	 *            uniqueness. If the value ist not unique a
	 *            UniqueIndexDoubleValuesException is thrown.
	 * 
	 * @return the new value of the cell
	 * 
	 * @throws VirtualTableException
	 *             if <code>synchronizeDB</code> is <code>true</code> and no
	 *             primary key is specified for this Virtual Table, or if the
	 *             value is not appropriate for the specified column
	 */
	public Object setValueAt(Object val, int row, int col, boolean synchronizeDB,
			boolean markAsUpdated, boolean checkUnique) throws VirtualTableException
	{
		Object old = getValueAt(row,col);
		if(equals(val,old))
		{
			return old;
		}
		
		val = checkValue(col,val);
		
		VirtualTableRow vtRow = data.get(row);
		vtRow.set(col,val,markAsUpdated,checkUnique);
		
		fireRowUpdated(vtRow,row);
		
		if(synchronizeDB)
		{
			VirtualTableColumn[] pk = getPrimaryKeyColumns();
			if(pk.length > 0)
			{
				UPDATE update = new UPDATE(toSqlTable());
				List values = new ArrayList(pk.length);
				
				update.SET(columns[col].toSqlColumn(),"?");
				values.add(val);
				
				WHERE where = new WHERE();
				for(int i = 0; i < pk.length; i++)
				{
					where.and(pk[i].toSqlField().eq("?"));
					values.add(getValueAt(row,getColumnIndex(pk[i])));
				}
				update.WHERE(where);
				
				Object[] params = values.toArray(new Object[values.size()]);
				try
				{
					writeDB(null,update,false,params);
				}
				catch(DBException e)
				{
					throw new VirtualTableException(e);
				}
			}
			else
			{
				throw new VirtualTableException("No primary key specified");
			}
		}
		
		return val;
	}
	

	/**
	 * Clears the data of this {@link VirtualTable}.
	 * <P>
	 * This method is an alias for {@link #clearData()}.
	 * <p>
	 */
	public void clear()
	{
		clearData();
	}
	

	/**
	 * Clears the data of this {@link VirtualTable}.
	 */
	public void clearData()
	{
		data.clear();
		
		// for(int i = 0; i < maxVal.length; i++)
		// {
		// maxVal[i] = 0l;
		// }
		
		for(VirtualTableIndex index : this.indices)
		{
			index.clear();
		}
		
		fireDataChanged();
	}
	

	/**
	 * Returns the preferred column width within a JTable for a specified
	 * column. If the column has a preferred width set, this width gets used.
	 * Otherwise the maximum of the two following values gets returned:
	 * <ul>
	 * <li>a default value depending on the type of the specified column</li>
	 * <li>the width of the column of the specified JTable</li>
	 * </ul>
	 * 
	 * @param col
	 *            the index of the column (0-based)
	 * @param header
	 *            {@link JTableHeader} instance of the JTable
	 * 
	 * @param tableCol
	 *            the index of the column within the JTable
	 * 
	 * @return the preferred width
	 */
	public int getPreferredColWidth(int col, JTableHeader header, int tableCol)
	{
		int width = columns[col].getPreferredWidth();
		if(width > 0)
		{
			return width;
		}
		
		switch(columns[col].getType())
		{
			case CHAR:
			case VARCHAR:
			case LONGVARCHAR:
			case CLOB:
				width = (int)Math.min(300,Math.max(50,columns[col].getLength() * 7));
			break;
			
			case TINYINT:
			case SMALLINT:
				width = 50;
			break;
			
			case INTEGER:
			case BIGINT:
			case REAL:
			case FLOAT:
			case DOUBLE:
			case DECIMAL:
			case NUMERIC:
				width = 100;
			break;
			
			case DATE:
			case TIME:
				width = 100;
			break;
			
			case TIMESTAMP:
				width = 150;
			break;
			
			default:
				width = 100;
		}
		
		TableCellRenderer renderer = header.getColumnModel().getColumn(tableCol)
				.getHeaderRenderer();
		if(renderer == null)
		{
			renderer = header.getDefaultRenderer();
		}
		
		return Math.max(
				width,
				renderer.getTableCellRendererComponent(header.getTable(),getColumnCaption(col),
						false,false,0,tableCol).getPreferredSize().width);
	}
	

	/**
	 * Creates and returns a new {@link VirtualTableRow}. The values within the
	 * row get set to their default values. <br>
	 * Autoincremented values are set to -1.
	 * 
	 * @return a new {@link VirtualTableRow}
	 */
	public VirtualTableRow createRow()
	{
		return createRowImpl(null);
	}
	

	private VirtualTableRow createRowForInsert(List<VirtualTableColumn<?>> except)
	{
		return createRowImpl(except);
	}
	

	private VirtualTableRow createRowImpl(List<VirtualTableColumn<?>> except)
	{
		VirtualTableRow row = new VirtualTableRow(columns.length,data.size());
		
		for(int col = 0; col < columns.length; col++)
		{
			if(columns[col].isAutoIncrement())
			{
				row.set(col,getNextAutoVal(columns[col]),false,false);
			}
			else if(except == null || !except.contains(columns[col]))
			{
				// row.set(col,checkValue(col,columns[col].getDefaultValue()),false,false);
				// Don't check, this is done when the row is inserted in the VT
				row.set(col,columns[col].getDefaultValue(),false,false);
			}
		}
		
		return row;
	}
	

	/**
	 * Adds the data contained in the specified result to the
	 * {@link VirtualTable}.
	 * <p>
	 * Alias method for
	 * {@link #addData(Result, VirtualTableColumn[], VirtualTableFillMethod)}.
	 * </p>
	 * 
	 * @param result
	 *            a {@link Result} containing data to be added
	 * @param columns
	 *            array of {@link VirtualTableColumn} objects for retrieving
	 *            column indices to be used for this add operation. If columns
	 *            is null, the indices of the result are used.
	 * @throws VirtualTableException
	 * @throws DBException
	 *             if access to the result fails
	 * @see VirtualTableFillMethod
	 */
	public void addData(Result result, VirtualTableColumn[] columns) throws VirtualTableException,
			DBException
	{
		addData(result,columns,VirtualTableFillMethod.APPEND);
	}
	

	/**
	 * Adds the data contained in the specified result to the
	 * {@link VirtualTable}.
	 * <p>
	 * Alias method for {@link #addData(Result, int[], VirtualTableFillMethod)}.
	 * </p>
	 * 
	 * @param result
	 *            a {@link Result} containing data to be added
	 * @param columns
	 *            array of {@link VirtualTableColumn} objects for retrieving
	 *            column indices to be used for this add operation. If columns
	 *            is null, the indices of the result are used.
	 * @param method
	 *            depending of the value of this enum:
	 *            <ul>
	 *            <li>existing data get overwritten</li>
	 *            <li>new data gets prepended in front of existing data</li>
	 *            <li>new data gets appended after existing data</li>
	 *            </ul>
	 * @throws VirtualTableException
	 * @throws DBException
	 *             if access to the result fails
	 * @see VirtualTableFillMethod
	 */
	public void addData(Result result, VirtualTableColumn[] columns, VirtualTableFillMethod method)
			throws VirtualTableException, DBException
	{
		int[] colsToFill = new int[columns.length];
		for(int i = 0; i < columns.length; i++)
		{
			colsToFill[i] = getColumnIndex(columns[i]);
		}
		
		addData(result,colsToFill,method);
	}
	

	/**
	 * Adds the data contained in the specified result to the
	 * {@link VirtualTable}. The new data gets appended in front of existing
	 * data.
	 * <p>
	 * Alias method for {@link #addData(Result, VirtualTableFillMethod)}.
	 * </p>
	 * 
	 * @param result
	 *            a {@link Result} containing data to be added
	 * @throws VirtualTableException
	 * @throws DBException
	 *             if access to the result fails
	 */
	public void addData(Result result) throws VirtualTableException, DBException
	{
		addData(result,VirtualTableFillMethod.APPEND);
	}
	

	/**
	 * Adds the data contained in the specified result to the
	 * {@link VirtualTable}.
	 * <p>
	 * Alias method for {@link #addData(Result, int[], VirtualTableFillMethod)}.
	 * </p>
	 * 
	 * @param result
	 *            a {@link Result} containing data to be added
	 * @param method
	 *            depending of the value of this enum:
	 *            <ul>
	 *            <li>existing data get overwritten</li>
	 *            <li>new data gets prepended in front of existing data</li>
	 *            <li>new data gets appended after existing data</li>
	 *            </ul>
	 * 
	 * @throws VirtualTableException
	 * 
	 * @throws DBException
	 *             if access to the result fails
	 * 
	 * @see VirtualTableFillMethod
	 */
	public void addData(Result result, VirtualTableFillMethod method) throws VirtualTableException,
			DBException
	{
		addData(result,getColIndices(result),method);
	}
	

	private int[] getColIndices(Result result)
	{
		int cc = result.getColumnCount();
		int[] colIndices = new int[cc];
		for(int col = 0; col < colIndices.length; col++)
		{
			String colName = result.getMetadata(col).getCaption();
			colIndices[col] = getColumnIndex(colName);
			if(colIndices[col] == -1)
			{
				colName = result.getMetadata(col).getName();
				if(colName != null && colName.length() > 0)
				{
					colIndices[col] = getColumnIndex(colName);
				}
			}
		}
		return colIndices;
	}
	

	/**
	 * Adds the data contained in the specified result to the
	 * {@link VirtualTable}. The new data gets appended in front of existing
	 * data.
	 * <p>
	 * Alias method for
	 * {@link #addData(Result, VirtualTableColumn[], VirtualTableFillMethod)}.
	 * </p>
	 * 
	 * @param result
	 *            result a {@link Result} containing data to be added
	 * @param colIndices
	 *            column indices to be used for this add operation. If
	 *            colIndices is null, the indices of the result are used.
	 * @throws VirtualTableException
	 * @throws DBException
	 *             if access to the result fails
	 */
	public void addData(Result result, int[] colIndices) throws VirtualTableException, DBException
	{
		addData(result,colIndices,VirtualTableFillMethod.APPEND);
	}
	

	/**
	 * Adds the data contained in the specified result to the
	 * {@link VirtualTable}.
	 * 
	 * @param result
	 *            a {@link Result} containing data to be added
	 * @param colIndices
	 *            column indices to be used for this add operation. If
	 *            colIndices is null, the indices of the result are used.
	 * @param method
	 *            depending of the value of this enum:
	 *            <ul>
	 *            <li>existing data get overwritten</li>
	 *            <li>new data gets prepended in front of existing data</li>
	 *            <li>new data gets appended after existing data</li>
	 *            </ul>
	 * 
	 * @throws VirtualTableException
	 * 
	 * @throws DBException
	 *             if access to the result fails
	 * 
	 * @see VirtualTableFillMethod
	 */
	public void addData(Result result, int[] colIndices, VirtualTableFillMethod method)
			throws VirtualTableException, DBException
	{
		setLastQuery(result.getQueryInfo());
		
		if(colIndices == null)
		{
			colIndices = getColIndices(result);
		}
		lastQueryIndices = colIndices;
		
		int[] srcCols = new int[columns.length];
		// long[] nextAutoVal = new long[columns.length];
		
		for(int c = 0; c < columns.length; c++)
		{
			srcCols[c] = -1;
			// nextAutoVal[c] = 0;
		}
		
		for(int c = 0; c < colIndices.length; c++)
		{
			if(colIndices[c] != -1)
			{
				srcCols[colIndices[c]] = c;
			}
		}
		
		// for(int c = 0; c < columns.length; c++)
		// {
		// if(srcCols[c] == -1 && columns[c].isAutoIncrement())
		// {
		// nextAutoVal[c] = getNextAutoVal(c);
		// }
		// }
		
		if(method == VirtualTableFillMethod.OVERWRITE)
		{
			clear();
		}
		
		VirtualTableRow row;
		Object val;
		int index = 0;
		while(result.next())
		{
			row = new VirtualTableRow(columns.length,data.size());
			for(int c = 0; c < columns.length; c++)
			{
				if(srcCols[c] == -1)
				{
					if(columns[c].isAutoIncrement())
					{
						// long auto_val = nextAutoVal[c]++;
						row.set(c,getNextAutoVal(columns[c]),false,false);
					}
					else
					{
						row.set(c,columns[c].getDefaultValue(),false,false);
					}
				}
				else
				{
					val = result.getObject(srcCols[c]);
					
					row.set(c,checkValue(c,val),false,false);
				}
			}
			
			switch(method)
			{
				case PREPEND:
					data.insert(row,index,false);
				break;
				
				default:
					data.add(row,false);
				break;
			}
			
			index++;
		}
		
		fireDataChanged();
	}
	

	/**
	 * Returns always -1.<br>
	 * It's inconsistent with the database anyway -> get the original values.
	 * 
	 * @return -1
	 * @see VTWriteDBHandler
	 */
	private Number getNextAutoVal(VirtualTableColumn col)
	{
		switch(col.getType())
		{
			case TINYINT:
				return (byte)-1;
			case SMALLINT:
				return (short)-1;
			case INTEGER:
				return -1;
			case BIGINT:
				return (long)-1;
		}
		
		throw new VirtualTableException(col.getName() + "(" + col.getType()
				+ ") is not auto incrementable");
		// return ++maxVal[col];
	}
	

	/**
	 * Returns a {@link XdevList} of the column captions for this
	 * <codeVirtualTable</code>.
	 * 
	 * @return the column captions
	 */
	public XdevList getCaptions()
	{
		XdevList captions = new XdevList(columns.length);
		for(int i = 0; i < columns.length; i++)
		{
			captions.addElement(columns[i].getName());
		}
		
		return captions;
	}
	

	/**
	 * Fills the elements of a formular, with the values of a specified row.
	 * 
	 * @param formular
	 *            the {@link XdevFormular} to be filled
	 * @param rowForForm
	 *            the index (0-based) of the row, which value is to be used for
	 *            filling the formular
	 * 
	 * @throws VirtualTableException
	 * 
	 * @throws IndexOutOfBoundsException
	 *             if rowForForm is not within the range of rows for this
	 *             Virtual Table.
	 */
	public void fillFormular(XdevFormular formular, int rowForForm) throws VirtualTableException,
			IndexOutOfBoundsException
	{
		MathUtils.checkRange(rowForForm,0,getRowCount() - 1);
		formular.setModel(data.get(rowForForm));
	}
	

	/**
	 * Stores the data of this Virtual Table in a local file specified by the
	 * user. This method opens a file chosser and lets the user specify the
	 * file.
	 * 
	 * @throws IOException
	 * 
	 * @see #loadLocal()
	 */
	public void saveLocal() throws IOException
	{
		try
		{
			JFileChooser fc = UIUtils.getSharedFileChooser();
			if(fc.showSaveDialog(UIUtils.getActiveWindow()) == JFileChooser.APPROVE_OPTION)
			{
				File f = fc.getSelectedFile();
				
				XdevObjectOutputStream out = new XdevObjectOutputStream(new GZIPOutputStream(
						new FileOutputStream(f)));
				
				try
				{
					write(out);
				}
				finally
				{
					out.close();
				}
			}
		}
		catch(IOException e)
		{
			throw new IOException(e);
		}
	}
	

	/**
	 * Stores the data of this Virtual Table in a File specified by a handle.
	 * Data gets compressed
	 * <p>
	 * This is an alias method for {@link #save(int, boolean)}.
	 * </p>
	 * 
	 * @param handle
	 *            the handle to the target file
	 * 
	 * @throws IOException
	 * 
	 * @deprecated use {@link #write(XdevObjectOutputStream)} instead
	 */
	// @Deprecated
	// public void save(int handle) throws IOException
	// {
	// save(handle,true);
	// }
	
	/**
	 * Stores the data of this Virtual Table in a File specified by a handle.
	 * 
	 * @param handle
	 *            the handle to the target file
	 * @param compressed
	 *            boolean, if true, data gets compressed in GZip-format
	 * @throws IOException
	 * @deprecated use {@link #write(XdevObjectOutputStream)} instead
	 */
	// @Deprecated
	// public void save(int handle, boolean compressed) throws IOException
	// {
	// try
	// {
	// OutputStream out = IOUtils.getBinaryIO(handle).getDataOutput();
	//
	// if(compressed)
	// {
	// ByteArrayOutputStream bout = new ByteArrayOutputStream();
	// GZIPOutputStream gout = new GZIPOutputStream(bout);
	// XdevObjectOutputStream oout = new XdevObjectOutputStream(gout);
	// write(oout);
	// oout.close();
	//
	// bout.writeTo(out);
	// }
	// else
	// {
	// write(new XdevObjectOutputStream(out));
	// }
	// }
	// catch(IOException e)
	// {
	// throw new IOException(e);
	// }
	// }
	
	/**
	 * Writes the data of this VirtualTable to a specified
	 * XdevObjectOutputStream.
	 * 
	 * @param out
	 *            {@link XdevObjectOutputStream} to write the data to
	 * @throws IOException
	 *             if data can't be written
	 */
	public void write(XdevObjectOutputStream out) throws IOException
	{
		try
		{
			out.writeUTF(FILE_HEADER);
			out.writeInt(0);
			out.writeUTF(name);
			
			int rowc = getRowCount();
			out.writeInt(rowc);
			out.writeInt(columns.length);
			for(int ri = 0; ri < rowc; ri++)
			{
				for(int ci = 0; ci < columns.length; ci++)
				{
					try
					{
						out.writeObject(getValueAt(ri,ci));
					}
					catch(Exception e)
					{
						throw new IOException(e.getMessage());
					}
				}
			}
		}
		catch(IOException e)
		{
			throw new IOException(e);
		}
	}
	

	/**
	 * Loads stored data from a user specified file into this
	 * {@link VirtualTable}. This method opens a file chosser and lets the user
	 * specify the file.
	 * 
	 * @throws IOException
	 *             if data can't be read
	 * @see #saveLocal()
	 */
	public void loadLocal() throws IOException
	{
		try
		{
			JFileChooser fc = UIUtils.getSharedFileChooser();
			if(fc.showOpenDialog(UIUtils.getActiveWindow()) == JFileChooser.APPROVE_OPTION)
			{
				File f = fc.getSelectedFile();
				
				XdevObjectInputStream in = new XdevObjectInputStream(new GZIPInputStream(
						new FileInputStream(f)));
				
				try
				{
					read(in);
				}
				finally
				{
					in.close();
				}
			}
		}
		catch(IOException e)
		{
			throw new IOException(e);
		}
	}
	

	/**
	 * Loads data into this VirtualTable specified by a file-handle.
	 * <p>
	 * This method is an alias for {@link #load(int, boolean)} with compressed
	 * reading enabled.
	 * </p>
	 * <p>
	 * <b>Note:</b> The handle has to be opened for binary reading
	 * </p>
	 * 
	 * @param handle
	 *            the handle containing the data
	 * 
	 * @throws IOException
	 *             if file couldn't be opened for loading
	 * 
	 * @deprecated use {@link #read(XdevObjectInputStream)} instead
	 */
	// @Deprecated
	// public void load(int handle) throws IOException
	// {
	// load(handle,true);
	// }
	
	/**
	 * Loads data into this VirtualTable specified by a file-handle.
	 * <p>
	 * <b>Note:</b> The handle has to be opened for binary reading
	 * </p>
	 * 
	 * @param handle
	 *            the handle containing the data
	 * @param compressed
	 *            if set to true, reads GZIP compressed files
	 * @throws IOException
	 *             if file couldn't be opened for loading
	 * 
	 * @deprecated use {@link #read(XdevObjectInputStream)} instead
	 */
	// @Deprecated
	// public void load(int handle, boolean compressed) throws IOException
	// {
	// try
	// {
	// DataInputStream in = IOUtils.getBinaryIO(handle).getDataInput();
	// read(new XdevObjectInputStream(compressed ? (InputStream)new
	// GZIPInputStream(in) : in));
	// }
	// catch(IOException e)
	// {
	// throw new IOException(e);
	// }
	// }
	
	/**
	 * Reads data from an {@link XdevObjectInputStream}.
	 * 
	 * @param in
	 *            {@link XdevObjectInputStream} to read from
	 * @throws IOException
	 *             if file couldn't be opened for loading data
	 */
	public void read(XdevObjectInputStream in) throws IOException
	{
		try
		{
			String error = null;
			if(in.readUTF().equals(FILE_HEADER))
			{
				in.readInt();
				in.readUTF();
				
				int rowc = in.readInt(), colc = in.readInt();
				if(colc == columns.length)
				{
					data = new VirtualTableData(rowc);
					for(int i = 0; i < rowc; i++)
					{
						VirtualTableRow rowData = new VirtualTableRow(colc,data.size());
						for(int j = 0; j < colc; j++)
						{
							try
							{
								rowData.set(j,in.readObject(),false,false);
							}
							catch(Exception e)
							{
								throw new IOException(e.getMessage());
							}
						}
						data.add(rowData,false);
					}
				}
				else
				{
					error = "Wrong VT";
				}
			}
			else
			{
				error = "Invalid file";
			}
			
			if(error != null)
			{
				throw new IOException(error);
			}
		}
		catch(IOException e)
		{
			throw new IOException(e);
		}
	}
	

	/**
	 * Imports data from CSV (Comma Separated Values) information.
	 * <p>
	 * This is an alias for
	 * {@link #importCSV(Reader, char, String, boolean, int)}.
	 * </p>
	 * 
	 * @param reader
	 *            {@link Reader} to read the CSV information from
	 * @throws IOException
	 *             if reading of CSV file fails
	 * @throws VirtualTableException
	 */
	public void importCSV(Reader reader) throws IOException, VirtualTableException
	{
		importCSV(reader,',',"null",true,0);
	}
	

	/**
	 * Imports data from CSV (Comma Separated Values) information.
	 * <p>
	 * This is an alias for
	 * {@link #importCSV(Reader, char, String, boolean, int)}.
	 * </p>
	 * 
	 * @param reader
	 *            {@link Reader} to read the CSV information from
	 * @param separator
	 *            char used to separate the column values (defaults to comma)
	 * @throws IOException
	 *             if reading of CSV file fails
	 * @throws VirtualTableException
	 */
	public void importCSV(Reader reader, char separator) throws IOException, VirtualTableException
	{
		importCSV(reader,separator,"null",true,0);
	}
	

	/**
	 * Imports data from CSV (Comma Separated Values) information.
	 * <p>
	 * This is an alias for
	 * {@link #importCSV(Reader, char, String, boolean, int)}.
	 * </p>
	 * 
	 * @param reader
	 *            {@link Reader} to read the CSV information from
	 * @param separator
	 *            char used to separate the column values (defaults to comma)
	 * @param nullValue
	 *            a {@link String} which is interpreted as <code>null</code> by
	 *            the VirtualTable
	 * @throws IOException
	 *             if reading of CSV file fails
	 * @throws VirtualTableException
	 */
	public void importCSV(Reader reader, char separator, String nullValue) throws IOException,
			VirtualTableException
	{
		importCSV(reader,separator,nullValue,true,0);
	}
	

	/**
	 * Imports data from CSV (Comma Separated Values) information.
	 * <p>
	 * This is an alias for
	 * {@link #importCSV(Reader, char, String, boolean, int)}.
	 * </p>
	 * 
	 * @param reader
	 *            {@link Reader} to read the CSV information from
	 * @param separator
	 *            char used to separate the column values (defaults to comma)
	 * @param nullValue
	 *            a {@link String} which is interpreted as <code>null</code> by
	 *            the VirtualTable
	 * @param useCsvHeaders
	 *            if set to true, the first line of the CSV file is interpreted
	 *            as column names
	 * @throws IOException
	 *             if reading of CSV file fails
	 * @throws VirtualTableException
	 */
	public void importCSV(Reader reader, char separator, String nullValue, boolean useCsvHeaders)
			throws IOException, VirtualTableException
	{
		importCSV(reader,separator,nullValue,useCsvHeaders,0);
	}
	

	/**
	 * Imports data from CSV (Comma Separated Values) information.
	 * 
	 * @param reader
	 *            {@link Reader} to read the CSV information from
	 * @param separator
	 *            char used to separate the column values (defaults to comma)
	 * @param nullValue
	 *            a {@link String} which is interpreted as <code>null</code> by
	 *            the VirtualTable
	 * @param useCsvHeaders
	 *            if set to true, the first line of the CSV file is interpreted
	 *            as column names
	 * @param skipLines
	 *            int value, skips the specified number of lines at the start,
	 *            when reading the CSV file
	 * @throws IOException
	 *             if reading of CSV file fails
	 * 
	 * @throws VirtualTableException
	 * 
	 * @see #exportCSV(Writer, int, String, char, List, boolean)
	 */
	public synchronized void importCSV(Reader reader, char separator, String nullValue,
			boolean useCsvHeaders, int skipLines) throws IOException, VirtualTableException
	{
		CSVReader csvReader = new CSVReader(reader,separator);
		
		List<VirtualTableColumn<?>> columns = new ArrayList();
		if(useCsvHeaders)
		{
			String[] record = csvReader.readNext();
			if(record == null)
			{
				return;
			}
			
			for(String name : record)
			{
				VirtualTableColumn<?> col = getColumn(name);
				if(col != null)
				{
					columns.add(col);
				}
			}
		}
		else
		{
			for(int i = 0; i < this.columns.length; i++)
			{
				columns.add(this.columns[i]);
			}
		}
		
		for(int i = 0; i < skipLines; i++)
		{
			if(csvReader.readNext() == null)
			{
				return;
			}
		}
		
		int vtColumnCount = columns.size();
		int[] vtColumnIndex = new int[vtColumnCount];
		for(int i = 0; i < vtColumnCount; i++)
		{
			vtColumnIndex[i] = getColumnIndex(columns.get(i));
		}
		
		List rowData = new ArrayList();
		String[] record;
		while((record = csvReader.readNext()) != null)
		{
			VirtualTableRow row = createRowForInsert(columns);
			
			int readerColumnCount = record.length;
			for(int i = 0; i < readerColumnCount; i++)
			{
				Object value;
				String str = record[i];
				if(nullValue.equals(str))
				{
					value = null;
				}
				else
				{
					value = checkValue(vtColumnIndex[i],str);
				}
				
				row.set(vtColumnIndex[i],value,false,true);
			}
			
			data.add(row,true);
			fireRowInserted(row,data.size() - 1);
			
			rowData.clear();
		}
	}
	

	/**
	 * @deprecated use {@link #importCSV(int, int, String)} instead
	 */
	// @Deprecated
	// public void parseAsciiStream(int handle, int start, String separator)
	// throws IOException,
	// VirtualTableException
	// {
	// importCSV(handle,start,separator);
	// }
	
	/**
	 * @deprecated use {@link #importCSV(int, int, String, String)} instead
	 */
	// @Deprecated
	// public void parseAsciiStream(int handle, int start, String separator,
	// String nullValue)
	// throws IOException, VirtualTableException
	// {
	// importCSV(handle,start,separator,nullValue);
	// }
	
	/**
	 * @deprecated use {@link #importCSV(Reader)} or successive instead
	 */
	// @Deprecated
	// public void importCSV(int handle, int start, String separator) throws
	// IOException,
	// VirtualTableException
	// {
	// importCSV(handle,start,separator,"");
	// }
	
	/**
	 * @deprecated use {@link #importCSV(Reader)} or succeessive instead
	 */
	// @Deprecated
	// public void importCSV(int handle, int start, String separator, String
	// nullValue)
	// throws IOException, VirtualTableException
	// {
	// AsciiIO io = IOUtils.getAsciiIO(handle);
	// if(io != null)
	// {
	// List rowData = new ArrayList();
	// List except = new ArrayList();
	// for(int i = 0; i < columns.length; i++)
	// {
	// except.add(columns[i]);
	// }
	//
	// Object NULL = new Object();
	//
	// String line = io.readLine();
	// for(int i = 0; i < start && line != null; i++)
	// {
	// line = io.readLine();
	// }
	//
	// while(line != null)
	// {
	// StringTokenizer st = new StringTokenizer(line,separator,true);
	// String lastToken = separator;
	// while(st.hasMoreTokens())
	// {
	// String token = st.nextToken();
	// if(token.equals(separator))
	// {
	// if(lastToken.equals(separator))
	// {
	// rowData.add(NULL);
	// }
	// }
	// else
	// {
	// rowData.add(token.equals(nullValue) ? null : token);
	// }
	// lastToken = token;
	// }
	//
	// while(rowData.size() < columns.length)
	// {
	// rowData.add(NULL);
	// }
	//
	// VirtualTableRow row = createRowForInsert(except);
	//
	// for(int i = 0; i < rowData.size(); i++)
	// {
	// Object val = rowData.get(i);
	//
	// if(val == NULL)
	// {
	// val = columns[i].getDefaultValue();
	// }
	//
	// if(val != null)
	// {
	// val = checkValue(i,val);
	// row.set(i,val,false,false);
	// }
	// }
	//
	// data.add(row,true);
	// fireRowInserted(row,data.size() - 1);
	//
	// rowData.clear();
	//
	// line = io.readLine();
	// }
	//
	// IOUtils.close(io);
	// }
	// }
	
	/**
	 * Exports data as CSV information to a specified {@link Writer}.
	 * <p>
	 * This is an alias for {@link #exportCSV(Writer, int)}.
	 * </p>
	 * 
	 * @param writer
	 *            a {@link Writer} to write CSV information to
	 * @throws IOException
	 *             if CSV file couldn't be written
	 */
	public void exportCSV(Writer writer) throws IOException
	{
		exportCSV(writer,0);
	}
	

	/**
	 * Exports data as CSV information to a specified {@link Writer}.
	 * <p>
	 * This is an alias for {@link #exportCSV(Writer, int, String)}.
	 * </p>
	 * 
	 * @param writer
	 *            a {@link Writer} to write CSV information to
	 * @param startRow
	 *            the start row within the data of the Virtual Table
	 * @throws IOException
	 *             if CSV file couldn't be written
	 */
	public void exportCSV(Writer writer, int startRow) throws IOException
	{
		exportCSV(writer,startRow,"null");
	}
	

	/**
	 * Exports data as CSV information to a specified {@link Writer}.
	 * <p>
	 * This is an alias for {@link #exportCSV(Writer, int, String, char)}.
	 * </p>
	 * 
	 * @param writer
	 *            a {@link Writer} to write CSV information to
	 * @param startRow
	 *            the start row within the data of the Virtual Table
	 * @param nullValue
	 *            a {@link String} representation for <code>null</code>-values
	 *            in the VirtualTable
	 * @throws IOException
	 *             if CSV file couldn't be written
	 */
	public void exportCSV(Writer writer, int startRow, String nullValue) throws IOException
	{
		exportCSV(writer,startRow,nullValue,',');
	}
	

	/**
	 * Exports data as CSV information to a specified {@link Writer}.
	 * <p>
	 * This is an alias for {@link #exportCSV(Writer, int, String, char, List)}.
	 * </p>
	 * 
	 * @param writer
	 *            a {@link Writer} to write CSV information to
	 * @param startRow
	 *            the start row within the data of the Virtual Table
	 * @param nullValue
	 *            a {@link String} representation for <code>null</code>-values
	 *            in the VirtualTable
	 * @param delimiter
	 *            the delimiter used to separate fields in the CSV file
	 * @throws IOException
	 *             if CSV file couldn't be written
	 */
	public void exportCSV(Writer writer, int startRow, String nullValue, char delimiter)
			throws IOException
	{
		exportCSV(writer,startRow,nullValue,delimiter,getColumnNames(-1));
	}
	

	/**
	 * Exports data as CSV information to a specified {@link Writer}.
	 * <p>
	 * This is an alias for
	 * {@link #exportCSV(Writer, int, String, char, List, boolean)}.
	 * </p>
	 * 
	 * @param writer
	 *            a {@link Writer} to write CSV information to
	 * @param startRow
	 *            the start row within the data of the Virtual Table
	 * @param nullValue
	 *            a {@link String} representation for <code>null</code>-values
	 *            in the VirtualTable
	 * @param delimiter
	 *            the delimiter used to separate fields in the CSV file
	 * @param columnNames
	 *            a list of the columnNames used as headers in the CSV file. No
	 *            header is generated if this value is <code>null</code>.
	 * @throws IOException
	 *             if CSV file couldn't be written
	 */
	public void exportCSV(Writer writer, int startRow, String nullValue, char delimiter,
			List<String> columnNames) throws IOException
	{
		exportCSV(writer,startRow,nullValue,delimiter,columnNames,true);
	}
	

	/**
	 * Exports data as CSV information to a specified {@link Writer}.
	 * 
	 * @param writer
	 *            a {@link Writer} to write CSV information to
	 * @param startRow
	 *            the start row within the data of the Virtual Table
	 * @param nullValue
	 *            a {@link String} representation for <code>null</code>-values
	 *            in the VirtualTable
	 * @param delimiter
	 *            the delimiter used to separate fields in the CSV file
	 * @param columnNames
	 *            a list of the columnNames used as headers in the CSV file. No
	 *            header is generated if this value is <code>null</code>.
	 * @param writeColumnNames
	 *            if set to true, a header line is generated in the CSV-file
	 * @throws IOException
	 *             if CSV file couldn't be written
	 */
	public synchronized void exportCSV(Writer writer, int startRow, String nullValue,
			char delimiter, List<String> columnNames, boolean writeColumnNames) throws IOException
	{
		CSVWriter csvWriter = new CSVWriter(writer,delimiter);
		if(columnNames == null)
		{
			writeColumnNames = false;
			columnNames = getColumnNames(-1);
		}
		
		int columnCount = columnNames.size();
		int[] colIndices = new int[columnCount];
		for(int i = 0; i < columnCount; i++)
		{
			String columnName = columnNames.get(i).toString();
			colIndices[i] = getColumnIndex(columnName);
			if(colIndices[i] == -1)
			{
				throw new VirtualTableException("Column '" + columnName + "' not found");
			}
		}
		
		if(writeColumnNames)
		{
			csvWriter.writeNext(columnNames.toArray(new String[columnNames.size()]));
		}
		
		String[] line = new String[columnCount];
		int rowCount = getRowCount();
		for(int row = startRow; row < rowCount; row++)
		{
			for(int col = 0; col < columnCount; col++)
			{
				Object o = getValueAt(row,colIndices[col]);
				line[col] = o == null ? nullValue : formatValue(o,colIndices[col]);
			}
			csvWriter.writeNext(line);
		}
	}
	

	/**
	 * @deprecated use {@link #exportCSV(Writer)} or successive instead
	 */
	// @Deprecated
	// public void exportCSV(int handle, int start, String separator, List
	// columnNames)
	// throws IOException, VirtualTableException
	// {
	// exportCSV(handle,start,separator,columnNames,"");
	// }
	
	/**
	 * @deprecated use {@link #exportCSV(Writer)} or successive instead
	 */
	// @Deprecated
	// public void exportCSV(int handle, int start, String separator, List
	// columnNames,
	// String nullValue) throws IOException, VirtualTableException
	// {
	// if(columnNames == null)
	// {
	// columnNames = getColumnNames(-1);
	// }
	//
	// int[] colIndices = new int[columnNames.size()];
	// for(int i = 0; i < columnNames.size(); i++)
	// {
	// String columnName = columnNames.get(i).toString();
	// colIndices[i] = getColumnIndex(columnName);
	// if(colIndices[i] == -1)
	// {
	// throw new VirtualTableException("Column '" + columnName + "' not found");
	// }
	// }
	//
	// AsciiIO io = IOUtils.getAsciiIO(handle);
	// if(io != null)
	// {
	// int rc = getRowCount();
	// Object o;
	// for(int row = start; row < rc; row++)
	// {
	// for(int col = 0; col < colIndices.length; col++)
	// {
	// o = getValueAt(row,colIndices[col]);
	// io.print(o == null ? nullValue : formatValue(o,colIndices[col]));
	// if(col < colIndices.length - 1)
	// {
	// io.print(separator);
	// }
	// }
	// io.printLine("");
	// }
	//
	// IOUtils.close(io);
	// }
	// }
	
	/**
	 * Returns the current cursor position (row number) of this
	 * {@link VirtualTable}.
	 * 
	 * @return the current cursor position
	 */
	public int getCursorPos()
	{
		return cursorpos;
	}
	

	/**
	 * Sets the current cursor position (row number) for this
	 * {@link VirtualTable}.
	 * 
	 * @param cursorpos
	 *            the current cursor position
	 */
	public void setCursorPos(int cursorpos)
	{
		if(cursorpos < -1)
		{
			cursorpos = -1;
		}
		
		this.cursorpos = cursorpos;
	}
	

	/**
	 * Resets the current cursor position (row number) for this
	 * {@link VirtualTable}. This positions the cursor in front of the first row
	 * in the table
	 */
	public void resetCursor()
	{
		cursorpos = -1;
	}
	

	/**
	 * Positions the cursor at the next row.
	 * 
	 * @return true, if the next position points at a valid row
	 */
	public boolean next()
	{
		cursorpos++;
		return cursorpos < getRowCount();
	}
	

	/**
	 * Returns the row index of the first occurence of the specified value
	 * within the specified column.
	 * 
	 * @param columnName
	 *            the name of the column to search for the value
	 * @param val
	 *            the value to search for
	 * @return the row index or -1, if no occurence of value is found
	 */
	public int getRowIndex(String columnName, Object val)
	{
		return getRowIndex(columnName,val,0);
	}
	

	/**
	 * Returns the row index of the first occurence of the specified value
	 * within the specified column.
	 * 
	 * @param columnName
	 *            the name of the column to search for the value
	 * @param val
	 *            the value to search for
	 * @param startIndex
	 *            the row index to start the search from
	 * @return the row index or -1, if no occurence of value is found
	 */
	public int getRowIndex(String columnName, Object val, int startIndex)
	{
		int index = -1, col = getColumnIndex(columnName);
		if(col != -1)
		{
			int max = getRowCount();
			Object o;
			for(int row = startIndex; row < max && index == -1; row++)
			{
				o = getValueAt(row,col);
				if(equals(o,val))
				{
					index = row;
				}
			}
		}
		return index;
	}
	

	/**
	 * Returns an array of all primary key columns for this {@link VirtualTable}
	 * .
	 * 
	 * @return an array of {@link VirtualTableColumn} instances representing all
	 *         primary key columns
	 */
	public VirtualTableColumn<?>[] getPrimaryKeyColumns()
	{
		for(VirtualTableIndex vtIndex : indices)
		{
			if(vtIndex.type == IndexType.PRIMARY_KEY)
			{
				return vtIndex.columns;
			}
		}
		
		return VirtualTableColumn.NO_COLUMN;
	}
	

	public void fillTree(XdevTree tree, String rootsColumnName, Object rootsID,
			String idColumnName, String ownerColumnName, String captionColumnName,
			String dataColumnName)
	{
		setModelFor(tree,rootsColumnName,rootsID,idColumnName,ownerColumnName,captionColumnName,
				dataColumnName);
	}
	

	public void setModelFor(XdevTree tree, String rootsColumnName, Object rootsID,
			String idColumnName, String ownerColumnName, String captionColumnName,
			String dataColumnName)
	{
		if(tree == null)
		{
			throw new NullPointerException();
		}
		
		XdevTreeNode root = createTree(rootsColumnName,rootsID,idColumnName,ownerColumnName,
				captionColumnName,dataColumnName);
		if(root != null)
		{
			root.setModel(new DefaultTreeModel(root));
			tree.setCellRenderer(new XdevTreeRenderer(new DefaultXdevTreeManager(tree)));
			tree.setModel(root.getModel());
		}
	}
	

	public XdevTreeNode createTree(String rootsColumnName, Object rootsID, String idColumnName,
			String ownerColumnName, String captionColumnName, String dataColumnName)
	{
		int rootsCol = getColumnIndex(rootsColumnName);
		if(rootsCol >= 0)
		{
			int rootsRow = -1;
			Object o;
			for(int i = 0; i < getRowCount() && rootsRow < 0; i++)
			{
				o = getValueAt(i,rootsCol);
				if(equals(o,rootsID))
				{
					rootsRow = i;
				}
			}
			
			if(rootsRow >= 0)
			{
				int idCol = getColumnIndex(idColumnName);
				if(idCol >= 0)
				{
					int ownerCol = getColumnIndex(ownerColumnName);
					if(ownerCol >= 0)
					{
						int captionCol = getColumnIndex(captionColumnName);
						if(captionCol >= 0)
						{
							int dataCol = getColumnIndex(dataColumnName);
							
							XdevTreeNode root = new XdevTreeNode(dataCol >= 0 ? getValueAt(
									rootsRow,dataCol) : "",getFormattedValueAt(rootsRow,captionCol));
							
							createTree(root,getValueAt(rootsRow,idCol),idCol,ownerCol,captionCol,
									dataCol);
							
							return root;
						}
					}
				}
			}
		}
		
		return null;
	}
	

	private void createTree(XdevTreeNode owner, Object id, int idCol, int ownerCol, int captionCol,
			int dataCol)
	{
		Object o;
		for(int row = 0; row < getRowCount(); row++)
		{
			o = getValueAt(row,ownerCol);
			if(equals(o,id))
			{
				XdevTreeNode node = new XdevTreeNode(dataCol >= 0 ? getValueAt(row,dataCol) : "",
						getFormattedValueAt(row,captionCol));
				owner.add(node);
				createTree(node,getValueAt(row,idCol),idCol,ownerCol,captionCol,dataCol);
			}
		}
	}
	

	/**
	 * Creates and set the table model for a specified JTable.
	 * <p>
	 * This is an alias for {@link #setModelFor(JTable)}.
	 * </p>
	 * 
	 * @param table
	 *            the {@link JTable} to set the model for.
	 */
	public void fillTable(JTable table)
	{
		setModelFor(table);
	}
	

	/**
	 * Creates and set the table model for a specified JTable.
	 * <p>
	 * This is an alias for {@link #setModelFor(JTable)}.
	 * </p>
	 * 
	 * @param table
	 *            the {@link JTable} to set the model for.
	 */
	public void setModelFor(JTable table)
	{
		table.setModel(createTableModel());
	}
	

	/**
	 * Creates and returns a {@link TableModel} for this {@link VirtualTable}.
	 * Only Visible Columns are included.
	 * 
	 * @return the {@link TableModel}
	 */
	public TableModel createTableModel()
	{
		return createTabelModel(getVisibleColumnIndices());
	}
	

	/**
	 * Creates and returns a {@link TableModel} for this {@link VirtualTable}.
	 * 
	 * @param columnNames
	 *            a array of columnNames to be included in the
	 *            {@link TableModel}.
	 * 
	 * @return a {@link TableModel}
	 */
	public TableModel createTableModel(String... columnNames)
	{
		IntList list = new IntList();
		
		for(String name : columnNames)
		{
			int columnIndex = getColumnIndex(name);
			if(columnIndex >= 0)
			{
				list.add(columnIndex);
			}
		}
		
		return createTabelModel(list.toArray());
	}
	

	/**
	 * Creates and returns a {@link TableModel} for this {@link VirtualTable}.
	 * 
	 * @param columnNames
	 *            a {@link List} of columnNames to be included in the
	 *            {@link TableModel}.
	 * 
	 * @return a {@link TableModel}
	 */
	public TableModel createTableModel(List<String> columnNames)
	{
		IntList list = new IntList();
		
		for(String name : columnNames)
		{
			int columnIndex = getColumnIndex(name);
			if(columnIndex >= 0)
			{
				list.add(columnIndex);
			}
		}
		
		return createTabelModel(list.toArray());
	}
	

	/**
	 * Creates and returns a {@link TableModel} for this {@link VirtualTable}.
	 * 
	 * @param columnIndices
	 *            the column indexed to be included in the {@link TableModel}.
	 * @return a {@link TableModel}
	 */
	public TableModel createTabelModel(int... columnIndices)
	{
		return new VirtualTableModel(this,columnIndices);
	}
	


	/**
	 * Helper method interface to select columns.
	 * 
	 * @see VirtualTable#getColumns(ColumnSelector)
	 * @see VirtualTable#getColumnIndices(ColumnSelector)
	 */
	public static interface ColumnSelector
	{
		/**
		 * @return <code>true</code> if the column should be selected,
		 *         <code>false</code> otherwise
		 */
		public boolean select(VirtualTableColumn<?> column);
	}
	

	/**
	 * Returns all {@link VirtualTableColumn}s of this VirtualTable according to
	 * <code>selector</code>.
	 * 
	 * @param selector
	 *            the {@link ColumnSelector}
	 * @return an array of {@link VirtualTableColumn}s according to
	 *         <code>selector</code>
	 */
	public VirtualTableColumn<?>[] getColumns(ColumnSelector selector)
	{
		List<VirtualTableColumn<?>> list = new ArrayList();
		
		for(VirtualTableColumn<?> column : columns)
		{
			if(selector.select(column))
			{
				list.add(column);
			}
		}
		
		return list.toArray(new VirtualTableColumn<?>[list.size()]);
	}
	

	/**
	 * Returns all colum indices of this VirtualTable's columns according to
	 * <code>selector</code>.
	 * 
	 * @param selector
	 *            the {@link ColumnSelector}
	 * @return the column's indices according to <code>selector</code>
	 */
	public int[] getColumnIndices(ColumnSelector selector)
	{
		IntList list = new IntList();
		
		for(int i = 0; i < columns.length; i++)
		{
			if(selector.select(columns[i]))
			{
				list.add(i);
			}
		}
		
		return list.toArray();
	}
	

	/**
	 * Returns an array with all indexes of the visible columns.
	 * 
	 * @return an int array with indexes of visible columns
	 * @see VirtualTableColumn#isVisible()
	 */
	public int[] getVisibleColumnIndices()
	{
		return getColumnIndices(new ColumnSelector()
		{
			@Override
			public boolean select(VirtualTableColumn<?> column)
			{
				return column.isVisible();
			}
		});
	}
	

	/**
	 * Returns an array with all indexes of the persistent columns.
	 * 
	 * @return an int array with indexes of persistent columns
	 * @see VirtualTableColumn#isPersistent()
	 */
	public int[] getPersistentColumnIndices()
	{
		return getColumnIndices(new ColumnSelector()
		{
			@Override
			public boolean select(VirtualTableColumn<?> column)
			{
				return column.isPersistent();
			}
		});
	}
	

	/**
	 * Returns an array with all indexes of the non persistent columns.
	 * 
	 * @return an int array with indexes of non persistent columns
	 * @see VirtualTableColumn#isPersistent()
	 */
	public int[] getNonPersistentColumnIndices()
	{
		return getColumnIndices(new ColumnSelector()
		{
			@Override
			public boolean select(VirtualTableColumn<?> column)
			{
				return !column.isPersistent();
			}
		});
	}
	

	/**
	 * Returns an array with all indexes of the visible and non persistent
	 * columns.
	 * 
	 * @return an int array with indexes of visible and non persistent columns
	 * @see VirtualTableColumn#isPersistent()
	 * @see VirtualTableColumn#isVisible()
	 */
	public int[] getNonPersistentVisibleColumnIndices()
	{
		return getColumnIndices(new ColumnSelector()
		{
			@Override
			public boolean select(VirtualTableColumn<?> column)
			{
				return !column.isPersistent() && column.isVisible();
			}
		});
	}
	

	/**
	 * Checks if this VirtualTable has a non persistent column.
	 * 
	 * @return <code>true</code> if this VirtualTable has a non persistent
	 *         column, <code>false</code> otherwise
	 * @see VirtualTableColumn#isPersistent()
	 */
	
	public boolean hasNonPersistentColumns()
	{
		for(VirtualTableColumn column : columns)
		{
			if(!column.isPersistent())
			{
				return true;
			}
		}
		
		return false;
	}
	

	/**
	 * Override of Objects toString method.
	 * 
	 * @return the name of the {@link VirtualTable}, or "VirtualTable" if name
	 *         is empty
	 */
	@Override
	public String toString()
	{
		return name != null && name.length() > 0 ? name : "VirtualTable";
	}
	

	/**
	 * Returns a {@link String} representation for this {@link VirtualTable}.
	 * The first line of the array contains the captions of the columns
	 * 
	 * @return a two dimensional array of Strings with the captions and data for
	 *         this VirtualTable.
	 */
	public String[][] toFormattedStrings()
	{
		String[][] s = new String[getRowCount() + 1][];
		s[0] = getColumnCaptions();
		return data.putFormattedStrings(s,1);
	}
	

	/**
	 * Returns a {@link TableMetaData} representation of this
	 * {@link VirtualTable}.
	 */
	public TableMetaData toTableMetaData()
	{
		TableInfo tableInfo = new TableInfo(TableType.TABLE,dbSchema,dbAlias);
		
		List<ColumnMetaData> columnMeta = new ArrayList();
		for(VirtualTableColumn column : columns)
		{
			if(column.isPersistent())
			{
				columnMeta.add(column.toColumnMetaData(this));
			}
		}
		
		int c = indices.size();
		Index[] indexMeta = new Index[c];
		for(int i = 0; i < c; i++)
		{
			indexMeta[i] = indices.get(i)._originalIndex.clone();
		}
		
		return new TableMetaData(tableInfo,
				columnMeta.toArray(new ColumnMetaData[columnMeta.size()]),indexMeta);
	}
	

	/**
	 * Returns a {@link XdevList} for all rows containing further XdevLists for
	 * all values of the rows.
	 * <p>
	 * This is an alias for {@link #toLists()}
	 * </p>
	 * 
	 * @return a {@link XdevList} of {@link XdevList}s containing the data of
	 *         the Virtual Table
	 */
	public XdevList getValues()
	{
		return toLists();
	}
	

	/**
	 * Returns a {@link XdevList} containing all rows as further XdevLists
	 * containing all values of the rows.
	 * 
	 * @return a {@link XdevList} of {@link XdevList}s containing the data of
	 *         the Virtual Table
	 */
	public XdevList toLists()
	{
		return toLists(-1);
	}
	

	/**
	 * Returns a {@link XdevList} containing all rows as further XdevLists
	 * containing all values of the rows.
	 * 
	 * @param exceptCol
	 *            a column index to be excluded from the lists of values
	 * @return a {@link XdevList} of {@link XdevList}s containing the data of
	 *         the Virtual Table
	 */
	public XdevList toLists(int exceptCol)
	{
		XdevList all = new XdevList();
		for(int i = 0; i < data.size(); i++)
		{
			all.addElement(getRow(i,exceptCol));
		}
		return all;
	}
	

	/**
	 * Returns the {@link VirtualTableRow} for the specified row index.
	 * 
	 * @param index
	 *            the row index
	 * 
	 * @return a {@link VirtualTableRow}
	 * 
	 * @throws IndexOutOfBoundsException
	 *             if index is not within range of row indices
	 */
	public VirtualTableRow getRow(int index) throws IndexOutOfBoundsException
	{
		return data.get(index);
	}
	

	/**
	 * Returns all rows of this VirtualTable. If this VirtualTable has no data
	 * an empty array is returned.
	 * 
	 * @return all rows of this VirtualTable.
	 */
	public VirtualTableRow[] getRows()
	{
		return data.getAll();
	}
	

	/**
	 * Returns a subset of rows of this VirtualTable.
	 * 
	 * @param startIndex
	 *            the start index, inclusive
	 * @param endIndex
	 *            the end index, exclusive
	 * @return a subset of rows.
	 * 
	 * @throws IndexOutOfBoundsException
	 *             if index is not within range of row indices
	 */
	public VirtualTableRow[] getRows(int startIndex, int endIndex) throws IndexOutOfBoundsException
	{
		return data.get(startIndex,endIndex);
	}
	

	/**
	 * Returns the last row of this {@link VirtualTable}.
	 * 
	 * @return the last {@link VirtualTableRow}
	 */
	public VirtualTableRow getLastRow()
	{
		return data.get(data.size() - 1);
	}
	

	/**
	 * Returns the {@link VirtualTableRow} for the specified primary key values.
	 * 
	 * @param pkValues
	 *            {@link KeyValues} instance with the primary key values of the
	 *            row
	 * 
	 * @return a {@link VirtualTableRow}, or <code>null</code> if no row is
	 *         found
	 */
	public VirtualTableRow getRow(KeyValues pkValues)
	{
		for(int i = 0; i < data.size(); i++)
		{
			VirtualTableRow row = data.get(i);
			if(pkValues.equals(row))
			{
				return row;
			}
		}
		
		return null;
	}
	

	/**
	 * Returns a {@link XdevList} representing the row at the current cursor
	 * position.
	 * <p>
	 * This is an alias for {@link #getRowAsList(int)}.
	 * </p>
	 * 
	 * @return a {@link XdevList}
	 */
	public XdevList getRowAsList()
	{
		return getRowAsList(cursorpos);
	}
	

	/**
	 * Returns a {@link XdevList} representing a specified row.
	 * <p>
	 * This is an alias for {@link #getRow(int, int)}.
	 * </p>
	 * 
	 * @param row
	 *            the index of the row to be returned as a XdevList
	 * @return a {@link XdevList}
	 */
	public XdevList getRowAsList(int row)
	{
		return getRow(row,-1);
	}
	

	/**
	 * Returns a {@link XdevList} representing a specified row.
	 * <p>
	 * This is an alias for {@link #getRowData(int, int)}.
	 * </p>
	 * 
	 * @param row
	 *            the index of the row to be returned as a XdevList
	 * @param exceptCol
	 *            the index of a column to be excluded from the XdevList
	 * @return a {@link XdevList}
	 */
	private XdevList getRow(int row, int exceptCol)
	{
		return getRowData(row,exceptCol);
	}
	

	/**
	 * Returns a {@link XdevList} representing a specified row.
	 * 
	 * @param row
	 *            the index of the row to be returned as a XdevList
	 * @param exceptCol
	 *            the index of a column to be excluded from the XdevList
	 * @return a {@link XdevList}
	 */
	public XdevList getRowData(int row, int exceptCol)
	{
		int columnCount = getColumnCount();
		XdevList rowData = new XdevList(columnCount);
		for(int col = 0; col < columnCount; col++)
		{
			if(col != exceptCol)
			{
				rowData.addElement(getValueAt(row,col));
			}
		}
		
		return rowData;
	}
	

	/**
	 * Returns a {@link XdevList} with all values for a specified column index.
	 * 
	 * @param col
	 *            the index of the column to be returned as a list
	 * @return a {@link XdevList} with all values of the specified column.
	 */
	public XdevList getColumnData(int col)
	{
		int rowCount = getRowCount();
		XdevList colData = new XdevList(rowCount);
		for(int row = 0; row < rowCount; row++)
		{
			colData.add(getValueAt(row,col));
		}
		
		return colData;
	}
	

	/**
	 * @deprecated replaced by {@link #getRowAsMap()} because
	 *             {@link XdevHashtable} doesn't support <code>null</code>
	 *             values
	 */
	// @Deprecated
	// public XdevHashtable<String, Object> getRowAsHashtable()
	// {
	// return getRowAsHashtable(cursorpos);
	// }
	
	/**
	 * @deprecated replaced by {@link #getRowAsMap(int)} because
	 *             {@link XdevHashtable} doesn't support <code>null</code>
	 *             values
	 */
	// @Deprecated
	// public XdevHashtable<String, Object> getRowAsHashtable(int row)
	// {
	// XdevHashtable<String, Object> rowData = new XdevHashtable<String,
	// Object>(columns.length);
	// fillInHashtable(row,rowData);
	// return rowData;
	// }
	
	/**
	 * @deprecated replaced by {@link #fillInMap(int, Map)} because
	 *             {@link Hashtable} doesn't support <code>null</code> values
	 */
	// @Deprecated
	// public void fillInHashtable(int row, Hashtable<String, Object> ht)
	// {
	// for(int col = 0; col < columns.length; col++)
	// {
	// ht.put(columns[col].getName(),getValueAt(row,col));
	// }
	// }
	
	/**
	 * Creates and returns a {@link Map} representation of a specified row. The
	 * keys of the map are the column names, the entries are the values of the
	 * row.
	 * 
	 * @return a {@link Map} for the specified row
	 */
	public Map<String, Object> getRowAsMap()
	{
		return getRowAsMap(cursorpos);
	}
	

	/**
	 * Creates and returns a {@link Map} representation of a specified row. The
	 * keys of the map are the column names, the entries are the values of the
	 * <code>row</code>.
	 * 
	 * @param row
	 *            the index of the row to return as a map
	 * @return a {@link Map} for the specified <code>row</code>
	 */
	public Map<String, Object> getRowAsMap(int row)
	{
		Map<String, Object> rowData = new HashMap<String, Object>(columns.length);
		fillInMap(row,rowData);
		return rowData;
	}
	

	/**
	 * Fills the provided {@link Map} with data from the given <code>row</code>.
	 * 
	 * @param row
	 *            row index to get the data from
	 * @param ht
	 *            {@link Map} to fill
	 */
	public void fillInMap(int row, Map<String, Object> ht)
	{
		for(int col = 0; col < columns.length; col++)
		{
			ht.put(columns[col].getName(),getValueAt(row,col));
		}
	}
	

	/**
	 * Adds all row data (formatted) of this {@link VirtualTable} to a specified
	 * {@link ItemList}.
	 * <p>
	 * This is an alias method for
	 * {@link ItemList#setModel(VirtualTable, String, String)}
	 * </p>
	 * 
	 * @param list
	 *            {@link ItemList}
	 * 
	 * @param itemCol
	 *            columnname to fill <code>item</code> from or string with
	 *            variables like <code>"{%SURNAME} {%NAME} - {%AGE}"</code>
	 * 
	 * @param dataCol
	 *            columnname to fill <code>data</code> from
	 * 
	 * @see ItemList#setModel(VirtualTable, String, String)
	 */
	public void fillInItemList(ItemList list, String itemCol, String dataCol)
	{
		list.setModel(this,itemCol,dataCol);
	}
	

	/**
	 * @deprecated use {@link #getRow(int)} instead
	 * 
	 */
	// @Deprecated
	// public VirtualTableRow getVTRow(int index)
	// {
	// return data.get(index);
	// }
	
	/**
	 * Returns a {@link List} of {@link String} representations of column values
	 * for a specified column index.
	 * 
	 * @param col
	 *            the column index
	 * @return the column values as a List of Strings
	 */
	public List<String> getColumnAsString(int col)
	{
		int c = getRowCount();
		List<String> list = new ArrayList(c);
		for(int i = 0; i < c; i++)
		{
			list.add(getFormattedValueAt(i,col));
		}
		
		return list;
	}
	

	/**
	 * Sorts the data of a {@link VirtualTable} for a specified column name. The
	 * sort order depends on the {@link Comparator} of the selected
	 * {@link VirtualTableColumn}.
	 * 
	 * @param columnName
	 *            the name of the column to sort
	 * @param ascending
	 *            if set to <code>true</code>, sort order will be ascending,
	 *            else descending
	 */
	public void sortByCol(String columnName, boolean ascending)
	{
		int col = getColumnIndex(columnName);
		if(col != -1)
		{
			sortByCol(col,ascending);
		}
	}
	

	/**
	 * Sorts the data of a {@link VirtualTable} for a specified column name. The
	 * sort order depends on the {@link Comparator} of the selected
	 * {@link VirtualTableColumn}.
	 * 
	 * @param col
	 *            the index of the column to sort
	 * @param ascending
	 *            if set to <code>true</code>, sort order will be ascending,
	 *            else descending
	 */
	public void sortByCol(int col, boolean ascending)
	{
		data.sortByCol(col,ascending);
	}
	

	/**
	 * Sorts the data of a {@link VirtualTable} The sort order depends on the
	 * specified {@link Comparator}.
	 * 
	 * @param comparator
	 *            a {@link Comparator} of Type {@link VirtualTableRow} for
	 *            specifying a custom sort order
	 */
	public void sort(Comparator<VirtualTableRow> comparator)
	{
		data.sortByCol(comparator);
	}
	

	/**
	 * Creates a new, empty {@link VirtualTableRow} and adds it at the end of
	 * this {@link VirtualTable}
	 */
	public VirtualTableRow addRow()
	{
		VirtualTableRow row = createRowForInsert(null);
		
		data.add(row,true);
		
		fireRowInserted(row,data.size() - 1);
		
		return row;
	}
	

	/**
	 * @deprecated use {@link #addRow()}
	 */
	// @Deprecated
	// public VirtualTableRow appendRow()
	// {
	// return addRow();
	// }
	
	/**
	 * Creates a new {@link VirtualTableRow} and adds it to this
	 * {@link VirtualTable}.
	 * <p>
	 * <b>Note:</b> The order of the values has to match the order of the
	 * columns in the {@link VirtualTable}.
	 * </p>
	 * 
	 * 
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the new row will be inserted in
	 *            the database automatically.
	 * 
	 * @param values
	 *            a number of values to be inserted as a new row
	 * 
	 * @throws VirtualTableException
	 *             thrown if a column of the map was not found in the
	 *             {@link VirtualTable}
	 * 
	 * @throws DBException
	 *             thrown if synchronization with database failed.
	 */
	public VirtualTableRow addRow(boolean synchronizeDB, Object... values)
			throws VirtualTableException, DBException
	{
		Map ht = new HashMap(columns.length);
		for(int ci = 0, li = 0; ci < columns.length && li < values.length; ci++)
		{
			if(!columns[ci].isAutoIncrement())
			{
				ht.put(columns[ci].getName(),values[li++]);
			}
		}
		
		return addRow(ht,synchronizeDB);
	}
	

	/**
	 * Creates a new {@link VirtualTableRow} and adds it to this
	 * {@link VirtualTable}.
	 * <p>
	 * <b>Note:</b> The order of the entries in the <code>list</code> has to
	 * match the order of the columns in the {@link VirtualTable}.
	 * </p>
	 * 
	 * @param list
	 *            a {@link List} of values to be inserted as a new row
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the new row will be inserted in
	 *            the database automatically.
	 * @throws VirtualTableException
	 *             thrown if a column of the map was not found in the
	 *             {@link VirtualTable}
	 * @throws DBException
	 *             thrown if synchronization with database failed.
	 */
	public VirtualTableRow addRow(List list, boolean synchronizeDB) throws VirtualTableException,
			DBException
	{
		Map ht = new HashMap(columns.length);
		for(int ci = 0, li = 0; ci < columns.length && li < list.size(); ci++)
		{
			if(!columns[ci].isAutoIncrement())
			{
				ht.put(columns[ci].getName(),list.get(li++));
			}
		}
		
		return addRow(ht,synchronizeDB);
	}
	

	/**
	 * Creates a new {@link VirtualTableRow} and adds it to this
	 * {@link VirtualTable}.
	 * 
	 * @param formular
	 *            a {@link XdevFormular}, which values are to be added as a new
	 *            row.
	 * 
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the new row will be inserted in
	 *            the database automatically.
	 * 
	 * @throws VirtualTableException
	 *             thrown if a column of the map was not found in the
	 *             {@link VirtualTable}
	 * 
	 * @throws DBException
	 *             thrown if synchronization with database failed.
	 */
	public VirtualTableRow addRow(XdevFormular formular, boolean synchronizeDB)
			throws VirtualTableException, DBException
	{
		return addRow(formular.getData(true),synchronizeDB);
	}
	

	/**
	 * Creates a new {@link VirtualTableRow} and adds it to this
	 * {@link VirtualTable}.
	 * <p>
	 * This is an alias for <code>addRow(map,synchronizeDB,false)</code>.
	 * </p>
	 * 
	 * @param map
	 *            a {@link Map} of {@link String} keys and {@link Object} as
	 *            values, containing the column names and values for the new
	 *            row.
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the new row will be inserted in
	 *            the database automatically.
	 * @throws VirtualTableException
	 *             thrown if a column of the map was not found in the
	 *             {@link VirtualTable}
	 * @throws DBException
	 *             thrown if synchronization with database failed.
	 */
	public VirtualTableRow addRow(Map<String, Object> map, boolean synchronizeDB)
			throws VirtualTableException, DBException
	{
		return addRow(map,synchronizeDB,false);
	}
	

	/**
	 * Creates a new {@link VirtualTableRow} and adds it to this
	 * {@link VirtualTable}.
	 * <p>
	 * This is an alias for
	 * <code>addRow(null,map,synchronizeDB,ignoreWarnings)</code>.
	 * </p>
	 * 
	 * @param map
	 *            a {@link Map} of {@link String} keys and {@link Object} as
	 *            values, containing the column names and values for the new
	 *            row.
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the new row will be inserted in
	 *            the database automatically.
	 * @param ignoreWarnings
	 *            if set to <code>true</code>, warnings because of unmapped
	 *            columns get ignored.
	 * @throws VirtualTableException
	 *             thrown if a column of the map was not found in the
	 *             {@link VirtualTable} and ignoreWarning is set to
	 *             <code>false</code>
	 * @throws DBException
	 *             thrown if synchronization with database failed.
	 */
	public VirtualTableRow addRow(Map<String, Object> map, boolean synchronizeDB,
			boolean ignoreWarnings) throws VirtualTableException, DBException
	{
		return addRow(null,map,synchronizeDB,ignoreWarnings);
	}
	

	/**
	 * Adds the {@link VirtualTableRow} row to this {@link VirtualTable}.
	 * <p>
	 * This is an alias for <code>addRow(row,synchronizeDB,false)</code>.
	 * </p>
	 * 
	 * @param row
	 *            the row to add
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the new row will be inserted in
	 *            the database automatically.
	 * @throws DBException
	 *             thrown if synchronization with database failed.
	 */
	public VirtualTableRow addRow(VirtualTableRow row, boolean synchronizeDB)
			throws VirtualTableException, DBException
	{
		return addRow(row,synchronizeDB,false);
	}
	

	/**
	 * Adds the {@link VirtualTableRow} row to this {@link VirtualTable}.
	 * 
	 * @param row
	 *            the row to add
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the new row will be inserted in
	 *            the database automatically.
	 * @param ignoreWarnings
	 *            if set to <code>true</code>, warnings because of unmapped
	 *            columns get ignored.
	 * @throws VirtualTableException
	 *             if <code>row</code> doesn't belong to this
	 *             {@link VirtualTable}.
	 * @throws DBException
	 *             thrown if synchronization with database failed.
	 */
	public VirtualTableRow addRow(VirtualTableRow row, boolean synchronizeDB, boolean ignoreWarnings)
			throws VirtualTableException, DBException
	{
		return addRow(row,null,synchronizeDB,ignoreWarnings);
	}
	

	/**
	 * Adds a new {@link VirtualTableRow} to this {@link VirtualTable}.
	 * 
	 * @param row
	 *            the {@link VirtualTableRow} to add. If it is <code>null</code>
	 *            , a new VirtualTableRow will be created.
	 * @param map
	 *            a {@link Map} of {@link String} keys and {@link Object} as
	 *            values, containing the column names and values for the new
	 *            row.
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the new row will be inserted in
	 *            the database automatically.
	 * @param ignoreWarnings
	 *            if set to <code>true</code>, warnings because of unmapped
	 *            columns get ignored.
	 * @throws VirtualTableException
	 *             thrown if a column of the map was not found in the
	 *             {@link VirtualTable} and ignoreWarning is set to
	 *             <code>false</code>
	 * @throws VirtualTableException
	 *             if <code>row</code> doesn't belong to this
	 *             {@link VirtualTable}.
	 * @throws DBException
	 *             thrown if synchronization with database failed.
	 */
	private VirtualTableRow addRow(VirtualTableRow row, Map<String, Object> map,
			boolean synchronizeDB, boolean ignoreWarnings) throws VirtualTableException,
			DBException
	{
		return addRow(row,map,synchronizeDB,ignoreWarnings,null);
	}
	

	private VirtualTableRow addRow(VirtualTableRow row, Map<String, Object> map,
			boolean synchronizeDB, boolean ignoreWarnings, DBConnection connection)
			throws VirtualTableException, DBException
	{
		INSERT insert = null;
		List values = null;
		if(synchronizeDB)
		{
			insert = new INSERT().INTO(toSqlTable());
			values = new ArrayList();
		}
		
		if(row != null)
		{
			if(row.getVirtualTable() != this)
			{
				if(!row.getVirtualTable().getName().equals(getName()))
				{
					throw new VirtualTableException("The row does not belong to this VirtualTable");
				}
				
				map = row.toMap();
				row = createRow();
			}
		}
		else
		{
			List<VirtualTableColumn<?>> used = new ArrayList();
			for(int i = 0; i < columns.length; i++)
			{
				Object key = getKey(columns[i].getName(),map);
				if(key != null)
				{
					used.add(columns[i]);
				}
			}
			row = createRowForInsert(used);
		}
		
		if(map != null)
		{
			for(int i = 0; i < columns.length; i++)
			{
				Object key = getKey(columns[i].getName(),map);
				if(key != null)
				{
					VirtualTableColumn column = columns[i];
					Object value = map.remove(key);
					if(value == null)
					{
						if(column.isAutoIncrement())
						{
							value = getNextAutoVal(column);
						}
						else
						{
							value = column.getDefaultValue();
						}
					}
					
					value = checkValue(i,value);
					
					if(synchronizeDB && !column.isAutoIncrement() && column.isPersistent())
					{
						insert.assign(column.toSqlColumn(),"?");
						values.add(value);
					}
					
					row.set(i,value,false,false);
				}
			}
			
			if(map.size() > 0 && !ignoreWarnings)
			{
				StringBuffer sb = new StringBuffer("Column(s) not found: ");
				sb.append(StringUtils.concat(", ",map.keySet()));
				throw new VirtualTableException(sb.toString());
			}
		}
		else if(synchronizeDB)
		{
			for(int i = 0; i < columns.length; i++)
			{
				VirtualTableColumn column = columns[i];
				if(synchronizeDB && !column.isAutoIncrement() && column.isPersistent())
				{
					insert.assign(column.toSqlColumn(),"?");
					values.add(row.get(i));
				}
			}
		}
		
		boolean markAsAdded = true;
		
		try
		{
			if(synchronizeDB && values.size() > 0)
			{
				Object[] params = values.toArray(new Object[values.size()]);
				WriteResult result = writeDB(connection,insert,getAutoValueColumns(),params);
				try
				{
					if(result.hasGeneratedKeys())
					{
						row.updateKeys(result.getGeneratedKeys());
					}
				}
				finally
				{
					result.close();
				}
				
				markAsAdded = false;
				row.state = STATE_UNCHANGED;
			}
		}
		finally
		{
			data.add(row,markAsAdded);
			fireRowInserted(row,data.size() - 1);
		}
		
		return row;
	}
	

	/**
	 * Removes a specified row from this {@link VirtualTable}.
	 * <p>
	 * The corresponding row in the database table gets deleted too.
	 * </p>
	 * <p>
	 * This is a synonym for: <code>removeRow(row,true);</code>
	 * </p>
	 * 
	 * @param row
	 *            the index of the row to remove
	 * @throws VirtualTableException
	 *             thrown if no primary key is specified for this
	 *             {@link VirtualTable}.
	 * @throws DBException
	 *             thrown if deletion of row in database failed.
	 */
	public void deleteRow(int row) throws VirtualTableException, DBException
	{
		removeRow(row,true);
	}
	

	/**
	 * Removes a specified row from this {@link VirtualTable}.
	 * 
	 * @param row
	 *            the index of the row to remove
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the corresponding row in the
	 *            database table gets deleted too.
	 * @throws VirtualTableException
	 *             thrown if no primary key is specified for this
	 *             {@link VirtualTable}.
	 * @throws DBException
	 *             thrown if deletion of row in database failed.
	 */
	public void removeRow(int row, boolean synchronizeDB) throws VirtualTableException, DBException
	{
		VirtualTableColumn[] pk = getPrimaryKeyColumns();
		if(synchronizeDB && pk.length == 0)
		{
			throw new VirtualTableException("No primary key specified");
		}
		
		KeyValues pkValue = null;
		if(synchronizeDB)
		{
			pkValue = new KeyValues(data.get(row));
		}
		
		data.remove(row);
		
		if(synchronizeDB)
		{
			deleteDB(pkValue);
		}
	}
	

	/**
	 * @deprecated use {@link #removeRows(KeyValues, boolean)} instead
	 */
	// @Deprecated
	// public void removeRows(String columnName, Object val, boolean
	// synchronizeDB)
	// throws VirtualTableException, DBException
	// {
	// removeRows(new KeyValues(this,columnName,val),synchronizeDB);
	// }
	
	/**
	 * Removes rows from the {@link VirtualTable} as specified by a
	 * {@link KeyValues} object.
	 * <p>
	 * The corresponding rows in the database table get deleted too.
	 * </p>
	 * <p>
	 * This is a synonym for: <code>removeRows(keyValues,true);</code>
	 * </p>
	 * 
	 * @param keyValues
	 *            the {@link KeyValues} object specifying the condition for the
	 *            removal of rows.
	 * 
	 * @throws VirtualTableException
	 * 
	 * @throws DBException
	 *             thrown if deletion of row in database failed.
	 */
	public void deleteRows(KeyValues keyValues) throws VirtualTableException, DBException
	{
		removeRows(keyValues,true);
	}
	

	/**
	 * Removes rows from the {@link VirtualTable} as specified by a
	 * {@link KeyValues} object.
	 * 
	 * @param keyValues
	 *            the {@link KeyValues} object specifying the condition for the
	 *            removal of rows.
	 * 
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the corresponding rows in the
	 *            database table get deleted too.
	 * 
	 * @throws VirtualTableException
	 * 
	 * @throws DBException
	 *             thrown if deletion of row in database failed.
	 */
	public void removeRows(KeyValues keyValues, boolean synchronizeDB)
			throws VirtualTableException, DBException
	{
		checkKeyValues(keyValues);
		
		for(int r = getRowCount() - 1; r >= 0; r--)
		{
			if(keyValues.equals(data.get(r)))
			{
				data.remove(r);
			}
		}
		
		if(synchronizeDB)
		{
			deleteDB(keyValues);
		}
	}
	

	private void deleteDB(KeyValues keyValues) throws DBException, VirtualTableException
	{
		if(keyValues.isEmpty())
		{
			throw new VirtualTableException(
					"Cannot synchronize with database: No primary key defined");
		}
		
		WHERE where = new WHERE();
		List values = new ArrayList();
		
		keyValues.appendCondition(where,values);
		
		DELETE delete = new DELETE().FROM(toSqlTable()).WHERE(where);
		Object[] params = values.toArray(new Object[values.size()]);
		writeDB(null,delete,false,params);
	}
	

	/**
	 * @deprecated use {@link #updateRows(XdevFormular, KeyValues, boolean)}
	 *             instead
	 */
	// @Deprecated
	// public int updateRows(XdevFormular formular, String columnName, Object
	// val,
	// boolean synchronizeDB) throws VirtualTableException, DBException
	// {
	// return updateRows(formular,new
	// KeyValues(this,columnName,val),synchronizeDB);
	// }
	
	/**
	 * Updates rows from the {@link VirtualTable} as specified by a
	 * {@link XdevFormular}.
	 * 
	 * @param formular
	 *            {@link XdevFormular}, which values are to be used to update
	 *            the rows.
	 * @param keyValues
	 *            the {@link KeyValues} object specifying the condition for the
	 *            rows to update.
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the corresponding rows in the
	 *            database table get updated too.
	 * @return the number of updated rows
	 * @throws VirtualTableException
	 * @throws DBException
	 *             thrown if the update of rows in database failed.
	 */
	public int updateRows(XdevFormular formular, KeyValues keyValues, boolean synchronizeDB)
			throws VirtualTableException, DBException
	{
		return updateRows(formular.getData(true),keyValues,synchronizeDB);
	}
	

	/**
	 * @deprecated use {@link #updateRows(List, KeyValues, boolean)} instead
	 */
	// @Deprecated
	// public int updateRows(List list, String columnName, Object val, boolean
	// synchronizeDB)
	// throws VirtualTableException, DBException
	// {
	// return updateRows(list,new KeyValues(this,columnName,val),synchronizeDB);
	// }
	
	/**
	 * Updates rows from the {@link VirtualTable} as specified by a
	 * {@link KeyValues} object.
	 * <p>
	 * <b>Note:</b> The order of the items in the list has to match the order of
	 * the columns in the {@link VirtualTable}.
	 * </p>
	 * 
	 * @param list
	 *            a {@link List} of values containing the new values for the
	 *            updated columns
	 * 
	 * @param keyValues
	 *            the {@link KeyValues} object specifying the condition for the
	 *            rows to update.
	 * 
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the corresponding rows in the
	 *            database table get updated too.
	 * 
	 * @return the number of updated rows
	 * 
	 * @throws VirtualTableException
	 * 
	 * @throws DBException
	 *             thrown if the update of rows in database failed.
	 */
	public int updateRows(List list, KeyValues keyValues, boolean synchronizeDB)
			throws VirtualTableException, DBException
	{
		Map ht = new HashMap();
		int max = Math.min(list.size(),columns.length);
		for(int i = 0; i < max; i++)
		{
			ht.put(columns[i].getName(),list.get(i));
		}
		
		return updateRows(ht,keyValues,synchronizeDB);
	}
	

	/**
	 * @deprecated use {@link #updateRows(Map, KeyValues, boolean)} instead
	 */
	// @Deprecated
	// public int updateRows(Map<String, Object> map, String columnName, Object
	// val,
	// boolean synchronizeDB) throws VirtualTableException, DBException
	// {
	// return updateRows(map,new KeyValues(this,columnName,val),synchronizeDB);
	// }
	
	/**
	 * Updates rows from the {@link VirtualTable} as specified by a
	 * {@link KeyValues} object.
	 * 
	 * @param map
	 *            a {@link Map} of {@link String} keys and {@link Object}
	 *            values, containing the column names and values for the updated
	 *            row.
	 * @param keyValues
	 *            the {@link KeyValues} object specifying the condition for the
	 *            rows to update.
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the corresponding rows in the
	 *            database table get updated too.
	 * @return the number of updated rows
	 * @throws VirtualTableException
	 * @throws DBException
	 *             thrown if the update of rows in database failed.
	 */
	public int updateRows(Map<String, Object> map, KeyValues keyValues, boolean synchronizeDB)
			throws VirtualTableException, DBException
	{
		return updateRows(map,keyValues,synchronizeDB,null);
	}
	

	private int updateRows(Map<String, Object> map, KeyValues keyValues, boolean synchronizeDB,
			DBConnection connection) throws VirtualTableException, DBException
	{
		checkKeyValues(keyValues);
		
		IntList updatedRows = new IntList();
		
		int max = getRowCount();
		for(int row = 0; row < max; row++)
		{
			if(keyValues.equals(data.get(row)))
			{
				updatedRows.add(row);
				
				for(int c = 0; c < columns.length; c++)
				{
					if(!columns[c].isAutoIncrement())
					{
						String key = getKey(columns[c].getName(),map);
						if(key != null)
						{
							setValueAt(map.get(key),row,c);
						}
					}
				}
			}
		}
		
		int updateCount = updatedRows.size();
		if(synchronizeDB && updateCount > 0)
		{
			UPDATE update = new UPDATE(toSqlTable());
			List values = new ArrayList();
			
			boolean write = false;
			
			for(int c = 0; c < columns.length; c++)
			{
				VirtualTableColumn column = columns[c];
				if(column.isPersistent() && !column.isAutoIncrement())
				{
					Object key = getKey(column.getName(),map);
					if(key != null)
					{
						write = true;
						update.SET(column.toSqlField(),"?");
						values.add(map.get(key));
					}
				}
			}
			
			if(write)
			{
				WHERE where = new WHERE();
				keyValues.appendCondition(where,values);
				update.WHERE(where);
				Object[] params = values.toArray(new Object[values.size()]);
				writeDB(connection,update,false,params);
				
				for(int i = 0; i < updateCount; i++)
				{
					data.get(updatedRows.get(i)).state = STATE_UNCHANGED;
				}
			}
		}
		
		return updateCount;
	}
	

	/**
	 * Updates a row from the {@link VirtualTable} as specified by a row index.
	 * 
	 * @param map
	 *            a {@link Map} of {@link String} keys and {@link Object}
	 *            values, containing the column names and values for the updated
	 *            row.
	 * @param row
	 *            the index of the row to update
	 * @param synchronizeDB
	 *            if set to <code>true</code>, the corresponding row in the
	 *            database table gets updated too.
	 * 
	 * @throws VirtualTableException
	 * 
	 * @throws DBException
	 *             thrown if deletion of row in database failed.
	 */
	public void updateRow(Map<String, Object> map, int row, boolean synchronizeDB)
			throws VirtualTableException, DBException
	{
		updateRow(map,row,synchronizeDB,null);
	}
	

	private void updateRow(Map<String, Object> map, int row, boolean synchronizeDB,
			DBConnection connection) throws VirtualTableException, DBException
	{
		if(row < 0 || row >= data.size)
		{
			throw new NullPointerException("Row not found in '" + name + "'");
		}
		
		UPDATE update = null;
		List values = null;
		if(synchronizeDB)
		{
			update = new UPDATE(toSqlTable());
			values = new ArrayList();
		}
		
		boolean write = false;
		
		for(int c = 0; c < columns.length; c++)
		{
			VirtualTableColumn cd = columns[c];
			if(cd.isPersistent() && !cd.isAutoIncrement())
			{
				Object key = getKey(cd.getName(),map);
				if(key != null)
				{
					setValueAt(map.get(key),row,c);
					write = true;
					
					if(synchronizeDB)
					{
						update.SET(cd.toSqlField(),"?");
						values.add(checkValue(c,map.get(key)));
					}
				}
			}
		}
		
		if(write && synchronizeDB)
		{
			VirtualTableColumn[] pk = getPrimaryKeyColumns();
			if(pk.length == 0)
			{
				throw new VirtualTableException(
						"Cannot synchronize with database: No primary key defined");
			}
			
			WHERE where = new WHERE();
			for(int i = 0; i < pk.length; i++)
			{
				where.and(pk[i].toSqlColumn().eq("?"));
				values.add(getValueAt(row,getColumnIndex(pk[i])));
			}
			update.WHERE(where);
			Object[] params = values.toArray(new Object[values.size()]);
			writeDB(connection,update,false,params);
			
			data.get(row).state = STATE_UNCHANGED;
		}
	}
	

	private void checkKeyValues(KeyValues values) throws VirtualTableException
	{
		if(values.getVirtualTable() != this)
		{
			throw new IllegalArgumentException("KeyValues does not refer to this VirtualTable");
		}
		
		if(values.isEmpty())
		{
			throw new IllegalArgumentException("KeyValues are empty");
		}
	}
	

	/**
	 * Synchronizes all updated and added rows with the current data source.
	 * <p>
	 * This action is embedded in a transaction, meaning a rollback is performed
	 * if an error occurs.
	 * 
	 * @throws VirtualTableException
	 *             If a error in this VirtualTable occurs
	 * @throws DBException
	 *             If an error occurs while writing the database
	 * 
	 * @see #synchronizeChangedRows(DBConnection)
	 */
	public void synchronizeChangedRows() throws VirtualTableException, DBException
	{
		synchronizeChangedRows(null);
	}
	

	/**
	 * Synchronizes all updated and added rows via <code>connection</code>.
	 * <p>
	 * If you want to embed this action in a transaction automatically, use
	 * {@link #synchronizeChangedRows()}.
	 * 
	 * @param connection
	 *            A connection to the underlying data source.
	 * @throws VirtualTableException
	 *             If a error in this VirtualTable occurs
	 * @throws DBException
	 *             If an error occurs while writing the database
	 * 
	 * @see #synchronizeChangedRows()
	 */
	public void synchronizeChangedRows(DBConnection<?> connection) throws VirtualTableException,
			DBException
	{
		synchronizeChangedRows(connection,columns);
	}
	

	private void synchronizeChangedRows(DBConnection<?> connection, VirtualTableColumn[] columns)
			throws VirtualTableException, DBException
	{
		VirtualTableColumn[] pk = getPrimaryKeyColumns();
		if(pk.length == 0)
		{
			throw new VirtualTableException("Cannot synchronize: No primary key defined");
		}
		int[] pkIndices = getColumnIndices(pk);
		
		// remove non persistant columns
		List<VirtualTableColumn> list = new ArrayList();
		for(VirtualTableColumn column : columns)
		{
			if(column.isPersistent())
			{
				list.add(column);
			}
		}
		columns = new VirtualTableColumn[list.size()];
		list.toArray(columns);
		int[] colIndices = getColumnIndices(columns);
		
		final List<WriteRequest> updateStatements = new ArrayList();
		final List<WriteRequest> insertStatements = new ArrayList();
		final IntList updateIndices = new IntList();
		final IntList insertIndices = new IntList();
		
		Table table = toSqlTable();
		
		for(int i = 0; i < data.size(); i++)
		{
			VirtualTableRow r = data.get(i);
			if(r.state == STATE_UPDATED)
			{
				UPDATE update = new UPDATE(table);
				List values = new ArrayList();
				
				for(int c = 0; c < columns.length; c++)
				{
					VirtualTableColumn cd = columns[c];
					// Don't update auto incremented primary key columns
					if(!(Arrays.binarySearch(pkIndices,c) >= 0 && cd.isAutoIncrement()))
					{
						update.SET(cd.toSqlField(),"?");
						values.add(r.get(colIndices[c]));
					}
				}
				
				WHERE where = new WHERE();
				for(int pi = 0; pi < pk.length; pi++)
				{
					where.and(pk[pi].toSqlColumn().eq("?"));
					values.add(r.get(pkIndices[pi]));
				}
				update.WHERE(where);
				
				updateStatements.add(new WriteRequest(update,false,values.toArray()));
				updateIndices.add(i);
			}
			else if(r.state == STATE_ADDED)
			{
				INSERT insert = new INSERT().INTO(table);
				List values = new ArrayList();
				
				for(int c = 0; c < columns.length; c++)
				{
					VirtualTableColumn cd = columns[c];
					
					if(!cd.isAutoIncrement())
					{
						insert.assign(cd.toSqlColumn(),"?");
						values.add(r.get(colIndices[c]));
					}
				}
				
				insertStatements
						.add(new WriteRequest(insert,getAutoValueColumns(),values.toArray()));
				insertIndices.add(i);
			}
		}
		
		class Writer
		{
			void write(DBConnection connection) throws DBException
			{
				int statementCount = updateStatements.size();
				if(statementCount > 0)
				{
					WriteRequest[] updates = updateStatements
							.toArray(new WriteRequest[statementCount]);
					writeDB(connection,updates);
					
					for(int i = 0; i < statementCount; i++)
					{
						data.get(updateIndices.get(i)).state = STATE_UNCHANGED;
					}
				}
				
				statementCount = insertStatements.size();
				if(statementCount > 0)
				{
					WriteRequest[] inserts = insertStatements
							.toArray(new WriteRequest[statementCount]);
					
					int insertIndex = 0;
					for(WriteResult result : writeDB(connection,inserts))
					{
						if(result.hasGeneratedKeys())
						{
							Result rs = result.getGeneratedKeys();
							int columnCount = rs.getColumnCount();
							try
							{
								while(rs.next())
								{
									int row = insertIndices.get(insertIndex++);
									for(int c = 0; c < columnCount; c++)
									{
										int col = getColumnIndex(rs.getMetadata(c).getName());
										if(col == -1 && columnCount == 1)
										{
											col = getAutoValue(c);
										}
										if(col != -1)
										{
											setValueAt(rs.getObject(c),row,col,false,false,false);
										}
									}
								}
							}
							finally
							{
								result.close();
							}
						}
					}
					
					for(int i = 0; i < statementCount; i++)
					{
						data.get(insertIndices.get(i)).state = STATE_UNCHANGED;
					}
				}
			}
		}
		final Writer writer = new Writer();
		
		if(connection != null)
		{
			writer.write(connection);
		}
		else
		{
			new Transaction(getDataSource())
			{
				@Override
				protected void write(DBConnection connection) throws DBException
				{
					writer.write(connection);
				}
			}.execute();
		}
	}
	

	private WriteResult writeDB(DBConnection connection, WritingQuery query, String[] columnNames,
			Object... params) throws DBException
	{
		boolean close = false;
		
		if(connection == null)
		{
			connection = getDataSource().openConnection();
			close = true;
		}
		
		try
		{
			return connection.write(query,columnNames,params);
		}
		finally
		{
			if(close)
			{
				connection.close();
			}
		}
	}
	

	private WriteResult writeDB(DBConnection connection, WritingQuery query,
			boolean returnGeneratedKeys, Object... params) throws DBException
	{
		boolean close = false;
		
		if(connection == null)
		{
			connection = getDataSource().openConnection();
			close = true;
		}
		
		try
		{
			return connection.write(query,returnGeneratedKeys,params);
		}
		finally
		{
			if(close)
			{
				connection.close();
			}
		}
	}
	

	private WriteResult[] writeDB(DBConnection connection, WriteRequest... requests)
			throws DBException
	{
		WriteResult[] results = new WriteResult[requests.length];
		
		for(int i = 0; i < requests.length; i++)
		{
			results[i] = requests[i].execute(connection);
		}
		
		return results;
	}
	

	/**
	 * Removes a {@link VirtualTableColumn} from this {@link VirtualTable}.
	 * 
	 * @param columnName
	 *            the name of the column to be removed.
	 * 
	 * @throws VirtualTableException
	 *             if no column with this name was found.
	 */
	public void removeColumn(String columnName) throws VirtualTableException
	{
		int col = getColumnIndex(columnName);
		if(col < 0)
		{
			throw new VirtualTableException("Column '" + columnName + "' not found");
		}
		
		removeColumn(col);
	}
	

	/**
	 * Removes a {@link VirtualTableColumn} from this {@link VirtualTable}.
	 * 
	 * @param col
	 *            the index of the column to be removed.
	 * 
	 * @throws ArrayIndexOutOfBoundsException
	 *             if <code>col &lt; -1</code> or
	 *             <code>col > getColumnCount-1</code>
	 */
	public void removeColumn(int col) throws ArrayIndexOutOfBoundsException
	{
		VirtualTableColumn vtCol = getColumnAt(col);
		vtCol.setVirtualTable(null);
		
		columnNameToIndex.clear();
		columnSimpleNameToIndex.clear();
		autoValueColumns = null;
		
		columns = ArrayUtils.remove(VirtualTableColumn.class,columns,col);
		// maxVal = ArrayUtils.remove(maxVal,col);
		columnFlags = ArrayUtils.remove(columnFlags,col);
		
		columnToIndex.remove(col);
		for(VirtualTableIndex index : indices)
		{
			index.removeCol(vtCol);
		}
		
		data.removeColumn(col);
		
		fireStructureChanged();
	}
	

	private String getKey(String key, Map<String, Object> map)
	{
		for(String retKey : map.keySet())
		{
			String s = retKey;
			int i = s.lastIndexOf('.');
			if(i > 0)
			{
				s = s.substring(i + 1);
			}
			
			if(s.equalsIgnoreCase(key))
			{
				return retKey;
			}
		}
		return null;
	}
	

	/**
	 * Returns the index of the nth column in this {@link VirtualTable} that is
	 * auto incremented.
	 * <p>
	 * Defaults to the value of the first auto incremented column, if none war
	 * found for <code>nr</code>.
	 * </p>
	 * 
	 * @param nr
	 *            the nr of the auto incremented column, which index should be
	 *            returned
	 * @return a column index, or -1 if no auto incremented column was found.
	 */
	public int getAutoValue(int nr)
	{
		int found = 0;
		for(int i = 0; i < columns.length; i++)
		{
			if(columns[i].isAutoIncrement())
			{
				if(found == nr)
				{
					return i;
				}
				else
				{
					found++;
				}
			}
		}
		
		return getFirstAutoValue();
	}
	

	/**
	 * Returns the index of the first column in this {@link VirtualTable} that
	 * is auto incremented.
	 * 
	 * @return a column index, or -1 if no auto incremented column was found.
	 */
	public int getFirstAutoValue()
	{
		for(int i = 0; i < columns.length; i++)
		{
			if(columns[i].isAutoIncrement())
			{
				return i;
			}
		}
		
		return -1;
	}
	

	/**
	 * Returns an array of column names for all auto incremented columns.
	 * 
	 * @return array of column names
	 */
	public String[] getAutoValueColumns()
	{
		if(autoValueColumns == null)
		{
			List<String> list = new ArrayList();
			for(int i = 0; i < columns.length; i++)
			{
				if(columns[i].isAutoIncrement())
				{
					list.add(columns[i].getName());
				}
			}
			
			autoValueColumns = list.toArray(new String[list.size()]);
		}
		
		return autoValueColumns;
	}
	

	/**
	 * Checks and returns a value.
	 * <p>
	 * Checks for:
	 * <ul>
	 * <li><code>null</code> value for NotNull columns</li>
	 * <li>correct type according to the specified column</li>
	 * </ul>
	 * 
	 * @param columnIndex
	 *            the index of the column for the value
	 * 
	 * @param value
	 *            the value to be checked
	 * 
	 * @return the checked value
	 * 
	 * @throws VirtualTableException
	 *             if check failed or the <code>value</code> is null but the
	 *             column isn't nullable
	 */
	public Object checkValue(int columnIndex, Object value) throws VirtualTableException
	{
		VirtualTableColumn column = columns[columnIndex];
		
		if(value == null)
		{
			if(column.isNullable())
			{
				return null;
			}
			else
			{
				/*
				 * (22.02.2010 TM)NOTE: extended exception message
				 * "null not allowed" with more details after request for more
				 * detailed exception messages.
				 */
				throw new VirtualTableException("null not allowed: column " + columnIndex + " ("
						+ column.getName() + ") is not nullable but value is null.");
			}
		}
		else if(value.toString().length() == 0 && column.isNullable()
				&& !column.getType().isString())
		{
			return null;
		}
		
		return createValue(value,columnIndex);
	}
	

	private Object createValue(Object value, int col) throws VirtualTableException
	{
		VirtualTableColumn cd = columns[col];
		
		switch(cd.getType())
		{
			case TINYINT:
				return createByte(col,value);
				
			case SMALLINT:
				return createShort(col,value);
				
			case INTEGER:
				return createInt(col,value);
				
			case BIGINT:
				return createLong(col,value);
				
			case REAL:
				return createFloat(col,value);
				
			case FLOAT:
			case DOUBLE:
			case NUMERIC:
			case DECIMAL:
				return createDouble(col,value);
				
			case CHAR:
			case VARCHAR:
			case LONGVARCHAR:
				return createString(col,value);
				
			case CLOB:
			{
				XdevClob clob = createClob(col,value);
				try
				{
					clob.readFully();
				}
				catch(DBException e)
				{
					throw new VirtualTableException(e);
				}
				return clob;
			}
				
			case BINARY:
			case VARBINARY:
			case LONGVARBINARY:
				return createBytes(col,value);
				
			case BLOB:
			{
				XdevBlob blob = createBlob(col,value);
				try
				{
					blob.readFully();
				}
				catch(DBException e)
				{
					throw new VirtualTableException(e);
				}
				return blob;
			}
				
			case DATE:
			case TIME:
			case TIMESTAMP:
				return createDate(col,value);
				
			case BOOLEAN:
				return createBoolean(col,value);
		}
		
		throw new VirtualTableException("Unkown type");
	}
	

	private Byte createByte(int col, Object value) throws VirtualTableException
	{
		if(value == null)
		{
			return null;
		}
		
		if(value instanceof Byte)
		{
			if(value instanceof Byte)
			{
				return (Byte)value;
			}
			else
			{
				return ((Number)value).byteValue();
			}
		}
		else
		{
			try
			{
				return Byte.parseByte(value.toString());
			}
			catch(NumberFormatException e)
			{
				try
				{
					Object o = columns[col].getTextFormat().getFormat()
							.parseObject(value.toString());
					if(o instanceof Byte)
					{
						return (Byte)o;
					}
					else
					{
						return ((Number)o).byteValue();
					}
				}
				catch(Exception e2)
				{
					try
					{
						return new Byte((byte)getBooleanNumericValue(col,value));
					}
					catch(Exception e3)
					{
					}
				}
			}
		}
		
		throw new VirtualTableException("Not a byte: '" + value + "' -> " + name + "."
				+ columns[col].getName());
	}
	

	private Short createShort(int col, Object value) throws VirtualTableException
	{
		if(value == null)
		{
			return null;
		}
		
		if(value instanceof Short)
		{
			if(value instanceof Short)
			{
				return (Short)value;
			}
			else
			{
				return ((Number)value).shortValue();
			}
		}
		else
		{
			try
			{
				return Short.parseShort(value.toString());
			}
			catch(NumberFormatException e)
			{
				try
				{
					Object o = columns[col].getTextFormat().getFormat()
							.parseObject(value.toString());
					if(o instanceof Short)
					{
						return (Short)o;
					}
					else
					{
						return ((Number)o).shortValue();
					}
				}
				catch(Exception e2)
				{
					try
					{
						return new Short((short)getBooleanNumericValue(col,value));
					}
					catch(Exception e3)
					{
					}
				}
			}
		}
		
		throw new VirtualTableException("Not a short: '" + value + "' -> " + name + "."
				+ columns[col].getName());
	}
	

	private Integer createInt(int col, Object value) throws VirtualTableException
	{
		if(value == null)
		{
			return null;
		}
		
		if(value instanceof Number)
		{
			if(value instanceof Integer)
			{
				return (Integer)value;
			}
			else
			{
				return ((Number)value).intValue();
			}
		}
		else
		{
			try
			{
				return Integer.parseInt(value.toString());
			}
			catch(NumberFormatException e)
			{
				try
				{
					Object o = columns[col].getTextFormat().getFormat()
							.parseObject(value.toString());
					if(o instanceof Integer)
					{
						return (Integer)o;
					}
					else
					{
						return ((Number)o).intValue();
					}
				}
				catch(Exception e2)
				{
					try
					{
						return new Integer(getBooleanNumericValue(col,value));
					}
					catch(Exception e3)
					{
					}
				}
			}
		}
		
		throw new VirtualTableException("Not an int: '" + value + "' -> " + name + "."
				+ columns[col].getName());
	}
	

	private Long createLong(int col, Object value) throws VirtualTableException
	{
		if(value == null)
		{
			return null;
		}
		
		if(value instanceof Number)
		{
			if(value instanceof Long)
			{
				return (Long)value;
			}
			else
			{
				return ((Number)value).longValue();
			}
		}
		else
		{
			try
			{
				return Long.parseLong(value.toString());
			}
			catch(NumberFormatException e)
			{
				try
				{
					Object o = columns[col].getTextFormat().getFormat()
							.parseObject(value.toString());
					if(o instanceof Long)
					{
						return (Long)o;
					}
					else
					{
						return ((Number)o).longValue();
					}
				}
				catch(Exception e2)
				{
					try
					{
						return new Long(getBooleanNumericValue(col,value));
					}
					catch(Exception e3)
					{
					}
				}
			}
		}
		
		throw new VirtualTableException("Not a long: '" + value + "' -> " + name + "."
				+ columns[col].getName());
	}
	

	private Float createFloat(int col, Object value) throws VirtualTableException
	{
		if(value == null)
		{
			return null;
		}
		
		if(value instanceof Number)
		{
			if(value instanceof Float)
			{
				return (Float)value;
			}
			else
			{
				return ((Number)value).floatValue();
			}
		}
		else
		{
			try
			{
				return Float.parseFloat(value.toString());
			}
			catch(NumberFormatException e)
			{
				try
				{
					Object o = columns[col].getTextFormat().getFormat()
							.parseObject(value.toString());
					if(o instanceof Float)
					{
						return (Float)o;
					}
					else
					{
						return ((Number)o).floatValue();
					}
				}
				catch(Exception e2)
				{
					try
					{
						return new Float(getBooleanNumericValue(col,value));
					}
					catch(Exception e3)
					{
					}
				}
			}
		}
		
		throw new VirtualTableException("Not a float: '" + value + "' -> " + name + "."
				+ columns[col].getName());
	}
	

	private Double createDouble(int col, Object value) throws VirtualTableException
	{
		if(value == null)
		{
			return null;
		}
		
		if(value instanceof Number)
		{
			if(value instanceof Double)
			{
				return (Double)value;
			}
			else
			{
				return new Double(((Number)value).doubleValue());
			}
		}
		else
		{
			try
			{
				return Double.parseDouble(value.toString());
			}
			catch(NumberFormatException e)
			{
				try
				{
					Object o = columns[col].getTextFormat().getFormat()
							.parseObject(value.toString());
					if(o instanceof Double)
					{
						return (Double)o;
					}
					else
					{
						return ((Number)o).doubleValue();
					}
				}
				catch(Exception e2)
				{
					try
					{
						return new Double(getBooleanNumericValue(col,value));
					}
					catch(Exception e3)
					{
					}
				}
			}
		}
		
		throw new VirtualTableException("Not a double: '" + value + "' -> " + name + "."
				+ columns[col].getName());
	}
	

	private int getBooleanNumericValue(int col, Object value) throws VirtualTableException
	{
		return createBoolean(col,value) ? 1 : 0;
	}
	

	private String createString(int col, Object value) throws VirtualTableException
	{
		if(value == null)
		{
			return null;
		}
		
		String str = "";
		if(value.getClass() == String.class) // most common case
		{
			str = (String)value;
		}
		else if(value instanceof char[])
		{
			try
			{
				str = new String((char[])value);
			}
			catch(Exception e)
			{
			}
		}
		else if(value instanceof Clob)
		{
			try
			{
				str = IOUtils.readString(((Clob)value).getCharacterStream(),true);
			}
			catch(Exception e)
			{
				throw new VirtualTableException(e);
			}
		}
		else if(value instanceof byte[])
		{
			try
			{
				str = new String((byte[])value,"UTF-8");
			}
			catch(Exception e)
			{
			}
		}
		else if(value instanceof InputStream)
		{
			try
			{
				InputStream in = (InputStream)value;
				str = IOUtils.readString(in,true);
			}
			catch(IOException ioe)
			{
				throw new VirtualTableException(ioe);
			}
		}
		else if(value instanceof Reader)
		{
			try
			{
				Reader in = (Reader)value;
				str = IOUtils.readString(in,true);
			}
			catch(IOException ioe)
			{
				throw new VirtualTableException(ioe);
			}
		}
		else
		{
			str = value.toString();
		}
		
		int length = columns[col].getLength();
		if(length >= 0 && str.length() > length)
		{
			return str.substring(0,length);
		}
		else
		{
			return str;
		}
	}
	

	private XdevClob createClob(int col, Object value) throws VirtualTableException
	{
		if(value == null)
		{
			return null;
		}
		
		if(value instanceof XdevClob)
		{
			return (XdevClob)value;
		}
		else if(value instanceof Clob)
		{
			try
			{
				return new XdevClob((Clob)value);
			}
			catch(DBException e)
			{
				throw new VirtualTableException(e);
			}
		}
		else if(value instanceof char[])
		{
			return new XdevClob((char[])value);
		}
		else if(value instanceof CharHolder)
		{
			return new XdevClob(((CharHolder)value).toCharArray());
		}
		else if(value instanceof String)
		{
			return new XdevClob(((String)value).toCharArray());
		}
		else if(value instanceof Reader)
		{
			try
			{
				Reader in = (Reader)value;
				return new XdevClob(IOUtils.readString(in,true).toCharArray());
			}
			catch(IOException ioe)
			{
				throw new VirtualTableException(ioe);
			}
		}
		else if(value instanceof InputStream)
		{
			try
			{
				InputStream in = (InputStream)value;
				return new XdevClob(IOUtils.readString(in,true).toCharArray());
			}
			catch(IOException ioe)
			{
				throw new VirtualTableException(ioe);
			}
		}
		
		throw new VirtualTableException("Not a CLOB: '" + value + "' -> " + name + "."
				+ columns[col].getName());
	}
	

	private byte[] createBytes(int col, Object value) throws VirtualTableException
	{
		if(value == null)
		{
			return null;
		}
		
		if(value instanceof byte[])
		{
			return (byte[])value;
		}
		else if(value instanceof Blob)
		{
			try
			{
				Blob blob = (Blob)value;
				return blob.getBytes(1,(int)blob.length());
			}
			catch(SQLException e)
			{
				throw new VirtualTableException(e);
			}
		}
		else if(value instanceof InputStream)
		{
			try
			{
				InputStream in = (InputStream)value;
				byte[] bytes = IOUtils.readData(in);
				IOUtils.closeSilent(in);
				return bytes;
			}
			catch(IOException e)
			{
				throw new VirtualTableException(e);
			}
		}
		else if(value instanceof ByteHolder)
		{
			return ((ByteHolder)value).toByteArray();
		}
		
		throw new VirtualTableException("Not a BLOB: '" + value + "' -> " + name + "."
				+ columns[col].getName());
	}
	

	private XdevBlob createBlob(int col, Object value) throws VirtualTableException
	{
		if(value == null)
		{
			return null;
		}
		
		if(value instanceof XdevBlob)
		{
			return (XdevBlob)value;
		}
		else if(value instanceof Blob)
		{
			try
			{
				return new XdevBlob((Blob)value);
			}
			catch(DBException e)
			{
				throw new VirtualTableException(e);
			}
		}
		else if(value instanceof byte[])
		{
			return new XdevBlob((byte[])value);
		}
		else if(value instanceof ByteHolder)
		{
			return new XdevBlob(((ByteHolder)value).toByteArray());
		}
		else if(value instanceof InputStream)
		{
			try
			{
				InputStream in = (InputStream)value;
				XdevBlob blob = new XdevBlob(IOUtils.readData(in));
				IOUtils.closeSilent(in);
				return blob;
			}
			catch(IOException e)
			{
				throw new VirtualTableException(e);
			}
		}
		
		throw new VirtualTableException("Not a BLOB: '" + value + "' -> " + name + "."
				+ columns[col].getName());
	}
	

	/**
	 * Creates and returns a {@link Date} object, that fits the type of the
	 * specified column.
	 * 
	 * @param col
	 *            the {@link VirtualTableColumn} to create a date for
	 * 
	 * @param value
	 *            the Object to create the new {@link Date} from
	 * 
	 * @return a {@link Date} object
	 * 
	 * @throws VirtualTableException
	 *             thrown if the creation of the {@link Date} failed.
	 */
	public Date createDate(VirtualTableColumn col, Object value) throws VirtualTableException
	{
		return createDate(getColumnIndex(col),value);
	}
	

	/**
	 * Creates and returns a {@link Date} object, that fits the type of the
	 * specified column.
	 * 
	 * @param col
	 *            the index of the {@link VirtualTableColumn} to create a date
	 *            for
	 * 
	 * @param value
	 *            the Object to create the new {@link Date} from
	 * 
	 * @return a {@link Date} object
	 * 
	 * @throws VirtualTableException
	 *             thrown if the creation of the {@link Date} failed.
	 */
	private Date createDate(int col, Object value) throws VirtualTableException
	{
		Date date = createUtilDate(col,value);
		if(date != null)
		{
			switch(columns[col].getType())
			{
				case DATE:
					return new java.sql.Date(date.getTime());
					
				case TIME:
					return new java.sql.Time(date.getTime());
					
				case TIMESTAMP:
					return new java.sql.Timestamp(date.getTime());
			}
		}
		
		throw new VirtualTableException("Not a date: '" + value + "' -> " + name + "."
				+ columns[col].getName());
	}
	
	private final static SimpleDateFormat	SIMPLE_DATETIME_FORMAT;
	private final static SimpleDateFormat	SIMPLE_DATE_FORMAT;
	private final static SimpleDateFormat	SIMPLE_TIME_FORMAT;
	private final static int[]				DATE_STYLE_CHECK_ORDER;
	static
	{
		SIMPLE_DATETIME_FORMAT = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		SIMPLE_DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
		SIMPLE_TIME_FORMAT = new SimpleDateFormat("HH:mm:ss");
		DATE_STYLE_CHECK_ORDER = new int[]{DateFormat.MEDIUM,DateFormat.SHORT,DateFormat.LONG,
			DateFormat.FULL};
	}
	

	private Date createUtilDate(int col, Object value)
	{
		if(value == null)
		{
			return null;
		}
		
		if(value instanceof Date)
		{
			return (Date)value;
		}
		
		if(value instanceof Calendar)
		{
			return ((Calendar)value).getTime();
		}
		
		String string = value.toString();
		
		try
		{
			return columns[col].getTextFormat().parseDate(string);
		}
		catch(ParseException e)
		{
		}
		
		try
		{
			return SIMPLE_DATETIME_FORMAT.parse(string);
		}
		catch(ParseException e)
		{
		}
		
		try
		{
			return SIMPLE_DATE_FORMAT.parse(string);
		}
		catch(ParseException e)
		{
		}
		
		try
		{
			return SIMPLE_TIME_FORMAT.parse(string);
		}
		catch(ParseException e)
		{
		}
		
		for(int date : DATE_STYLE_CHECK_ORDER)
		{
			for(int time : DATE_STYLE_CHECK_ORDER)
			{
				try
				{
					return DateFormat.getDateTimeInstance(date,time).parse(string);
				}
				catch(ParseException e)
				{
				}
			}
		}
		
		return null;
	}
	

	private Boolean createBoolean(int col, Object value)
	{
		if(value == null)
		{
			return null;
		}
		
		if(value instanceof Boolean)
		{
			return (Boolean)value;
		}
		else if(value instanceof Number)
		{
			return ((Number)value).intValue() > 0;
		}
		else
		{
			String str = value.toString();
			if("true".equals(str))
			{
				return true;
			}
			else if("false".equals(str))
			{
				return false;
			}
		}
		
		throw new VirtualTableException("Not a boolean: '" + value + "' -> " + name + "."
				+ columns[col].getName());
	}
	


	// private Map<String, List> group_values = new HashMap();
	//
	//
	// public void group_resetValues()
	// {
	// for(int i = 0; i < columns.length; i++)
	// {
	// group_values.put(columns[i].getName(),new ArrayList());
	// }
	// }
	//
	//
	// public void group_addValues(int row)
	// {
	// for(String name : group_values.keySet())
	// {
	// group_values.get(name).add(getValueAt(row,name));
	// }
	// }
	//
	//
	// public void group_removeValues()
	// {
	// group_values.clear();
	// }
	//
	//
	// public List group_getValues(String columnName)
	// {
	// if(group_values.containsKey(columnName))
	// {
	// return group_values.get(columnName);
	// }
	// List list = new ArrayList();
	// int col = getColumnIndex(columnName);
	// if(col >= 0)
	// {
	// for(int i = 0; i < getRowCount(); i++)
	// {
	// list.add(getValueAt(i,col));
	// }
	// }
	// return list;
	// }
	
	private class VirtualTableData implements Iterable<VirtualTableRow>, Serializable
	{
		private static final long	serialVersionUID	= 5587743513073942290L;
		
		VirtualTableRow[]			data;
		int							size;
		

		VirtualTableData(int initialCapacity)
		{
			data = new VirtualTableRow[initialCapacity];
			size = 0;
		}
		

		synchronized void add(VirtualTableRow row, boolean markAsAdded)
		{
			tryInsertInIndex(row);
			
			ensureCapacity(size + 1);
			data[size++] = row;
			
			if(markAsAdded)
			{
				row.state = STATE_ADDED;
			}
		}
		

		synchronized void insert(VirtualTableRow row, int index, boolean markAsAdded)
		{
			tryInsertInIndex(row);
			
			ensureCapacity(size + 1);
			System.arraycopy(data,index,data,index + 1,size - index);
			data[index] = row;
			size++;
			
			if(markAsAdded)
			{
				row.state = STATE_ADDED;
			}
		}
		

		void tryInsertInIndex(VirtualTableRow row)
		{
			for(VirtualTableIndex vtIndex : indices)
			{
				if(!vtIndex.put(row) && vtIndex.isUnique)
				{
					reportUniqueIndexDoubleValues(row,vtIndex);
				}
			}
		}
		

		void ensureCapacity(int minCapacity)
		{
			int oldCapacity = data.length;
			if(minCapacity > oldCapacity)
			{
				Object oldData[] = data;
				int newCapacity = (oldCapacity * 3) / 2 + 1;
				if(newCapacity < minCapacity)
				{
					newCapacity = minCapacity;
				}
				data = new VirtualTableRow[newCapacity];
				System.arraycopy(oldData,0,data,0,size);
			}
		}
		

		synchronized VirtualTableRow get(int i)
		{
			return data[i];
		}
		

		synchronized VirtualTableRow[] getAll()
		{
			VirtualTableRow[] array = new VirtualTableRow[size];
			System.arraycopy(data,0,array,0,size);
			return array;
		}
		

		synchronized VirtualTableRow[] get(int startIndex, int endIndex)
		{
			VirtualTableRow[] array = new VirtualTableRow[endIndex - startIndex];
			System.arraycopy(data,startIndex,array,0,endIndex - startIndex);
			return array;
		}
		

		synchronized int size()
		{
			return size;
		}
		

		synchronized void remove(int i)
		{
			VirtualTableRow row = data[i];
			for(VirtualTableIndex vtIndex : indices)
			{
				vtIndex.remove(row);
			}
			
			int numMoved = size - i - 1;
			if(numMoved > 0)
			{
				System.arraycopy(data,i + 1,data,i,numMoved);
			}
			data[--size] = null;
			
			fireRowDeleted(row,i);
		}
		

		synchronized void removeColumn(int col)
		{
			for(int i = 0; i < size; i++)
			{
				data[i].remove(col);
			}
			
			for(VirtualTableIndex vtIndex : indices)
			{
				vtIndex.clear();
				for(int i = 0; i < size; i++)
				{
					vtIndex.put(data[i]);
				}
			}
		}
		

		synchronized void clear()
		{
			for(int i = 0; i < size; i++)
			{
				data[i] = null;
			}
			size = 0;
		}
		

		synchronized int indexOf(VirtualTableRow row)
		{
			for(int i = row.index; i < size; i++)
			{
				if(data[i] == row)
				{
					return i;
				}
			}
			
			for(int i = row.index - 1; i >= 0; i--)
			{
				if(data[i] == row)
				{
					return i;
				}
			}
			
			return -1;
		}
		

		/**
		 * Returns an iterator over all rows of this VirtualTable in their
		 * natural order.
		 * <p>
		 * Note: The returned iterator doesn't support {@link Iterator#remove()}
		 * .
		 * </p>
		 * 
		 * 
		 * @return An interator over the rows
		 */
		
		public Iterator<VirtualTableRow> iterator()
		{
			return ArrayUtils.getIterator(data,0,size);
		}
		

		synchronized void sortByCol(final int columnIndex, final boolean ascending)
		{
			final Comparator columnComparator = columns[columnIndex].getComparator();
			Comparator comparator = new Comparator<VirtualTableRow>()
			{
				public int compare(VirtualTableRow row1, VirtualTableRow row2)
				{
					int value = columnComparator.compare(row1.data[columnIndex],
							row2.data[columnIndex]);
					if(!ascending)
					{
						value *= -1;
					}
					return value;
				}
			};
			sortByCol(comparator);
		}
		

		synchronized void sortByCol(Comparator<VirtualTableRow> comparator)
		{
			Arrays.sort(data,0,size,comparator);
			fireDataChanged();
		}
		

		@Override
		public String toString()
		{
			return Arrays.toString(data);
		}
		

		public String[][] putFormattedStrings(String[][] s, int arrayOffset)
		{
			for(int row = 0; row < size && arrayOffset < s.length; row++)
			{
				s[arrayOffset++] = data[row].toFormattedStrings();
			}
			return s;
		}
	}
	
	private final static int	STATE_UNCHANGED	= 0;
	private final static int	STATE_UPDATED	= 1;
	private final static int	STATE_ADDED		= 2;
	


	/**
	 * Represents a single row within a {@link VirtualTable}.
	 * 
	 * @author XDEV Software Corp.
	 */
	public class VirtualTableRow implements Serializable, Copyable<VirtualTableRow>
	{
		private static final long	serialVersionUID	= 136292046887180787L;
		
		private Object[]			data;
		private int					state				= STATE_UNCHANGED;
		private int					index;
		String						primaryKeyHash;
		

		private VirtualTableRow(int initialCapacity, int index)
		{
			data = new Object[initialCapacity];
			this.index = index;
		}
		

		/**
		 * Returns the surrounding {@link VirtualTable} of this
		 * {@link VirtualTableRow}.
		 * 
		 * @return a {@link VirtualTable}
		 */
		public VirtualTable getVirtualTable()
		{
			return VirtualTable.this;
		}
		

		/**
		 * Sets a value for this {@link VirtualTableRow} at the specified column
		 * index.
		 * 
		 * @param columnName
		 *            the name of the column
		 * @param value
		 *            the new value of the column
		 * 
		 * @return the new value
		 * 
		 * @throws VirtualTableException
		 *             if the value is not appropriate for the specified column
		 * @throws IllegalArgumentException
		 *             if the column <code>columnName</code> does not exist in
		 *             this {@link VirtualTable}
		 */
		public synchronized Object set(String columnName, Object value)
				throws VirtualTableException, IllegalArgumentException
		{
			int col = getColumnIndex(columnName);
			if(col == -1)
			{
				throw new IllegalArgumentException("column '" + columnName + "' not found");
			}
			
			return set(col,value);
		}
		

		/**
		 * Sets a value for this {@link VirtualTableRow} at the specified column
		 * index.
		 * 
		 * @param index
		 *            the index of the column to set
		 * @param value
		 *            the new value of the column
		 * 
		 * @return the new value
		 * 
		 * @throws VirtualTableException
		 *             if the value is not appropriate for the specified column
		 */
		public synchronized Object set(int index, Object value) throws VirtualTableException
		{
			int rowIndex = VirtualTable.this.data.indexOf(this);
			if(rowIndex >= 0)
			{
				return VirtualTable.this.setValueAt(value,rowIndex,index);
			}
			else
			{
				Object old = data[index];
				if(VirtualTable.equals(value,old))
				{
					return old;
				}
				
				return data[index] = optConvertValue(checkValue(index,value));
			}
		}
		

		private synchronized void set(int index, Object value, boolean changeToUpdated,
				boolean updateIndex) throws VirtualTableException
		{
			value = optConvertValue(value);
			
			if(VirtualTable.equals(data[index],value))
			{
				return;
			}
			
			if(updateIndex)
			{
				for(VirtualTableIndex vtIndex : indices)
				{
					if(vtIndex.hasCol(index))
					{
						vtIndex.remove(this);
						String newHash = vtIndex.computeHash(this,index,value);
						if(!vtIndex.put(newHash) && vtIndex.isUnique)
						{
							reportUniqueIndexDoubleValues(this,vtIndex);
						}
						if(vtIndex.type == IndexType.PRIMARY_KEY)
						{
							primaryKeyHash = newHash;
						}
					}
				}
			}
			
			data[index] = value;
			
			// if(columns[index].isAutoIncrement() && value != null && value
			// instanceof Number)
			// {
			// long l = ((Number)value).longValue();
			// if(l > maxVal[index])
			// {
			// maxVal[index] = l;
			// }
			// }
			
			if(changeToUpdated && state == STATE_UNCHANGED)
			{
				state = STATE_UPDATED;
			}
		}
		

		private Object optConvertValue(Object value)
		{
			if(value instanceof byte[])
			{
				value = new XdevBlob((byte[])value);
			}
			else if(value instanceof char[])
			{
				value = new XdevClob((char[])value);
			}
			
			if(value != null && value instanceof String && Settings.trimData())
			{
				value = value.toString().trim();
			}
			
			return value;
		}
		

		/**
		 * Returns the value at the specified column index.
		 * 
		 * @param i
		 *            the index of the column
		 * @return a value
		 */
		public synchronized Object get(int i)
		{
			return data[i];
		}
		

		/**
		 * Returns the value at the specified column.
		 * 
		 * @param column
		 *            {@link VirtualTableColumn}
		 * @return the value of the cell at the specified position.
		 */
		public synchronized <T> T get(VirtualTableColumn<T> column)
		{
			return (T)data[getColumnIndex(column)];
		}
		

		/**
		 * Returns a formatted representation for the value at <code>col</code>.
		 * The TextFormat of the VirtualTableColumn at index <code>col</code> is
		 * used to format the value.
		 * 
		 * 
		 * @param col
		 *            the index of the column (0-based)
		 * 
		 * @return a formatted {@link String} representation of the specified
		 *         value.
		 */
		public synchronized String getFormattedValue(int col)
		{
			return formatValue(data[col],col);
		}
		

		/**
		 * Returns a formatted string, with this row used as
		 * {@link ParameterProvider}.
		 * 
		 * @param str
		 *            the {@link String} to identify the value's in the
		 *            {@link ParameterProvider}
		 * 
		 * @return a formatted string
		 * 
		 * @see StringUtils#format(String, ParameterProvider)
		 * @see VirtualTable#formatValue(Object, int)
		 */
		public synchronized String format(String str)
		{
			return StringUtils.format(str,new ParameterProvider()
			{
				@Override
				public String getValue(String key)
				{
					int index = getColumnIndex(key);
					if(index == -1)
					{
						return "";
					}
					return formatValue(data[index],index);
				}
			});
		}
		

		/**
		 * Removes a column from this {@link VirtualTableColumn}.
		 * <p>
		 * <b>Note:</b> The value at this position is lost.
		 * </p>
		 * 
		 * @param i
		 *            the index of the column to be removed
		 */
		private synchronized void remove(int i)
		{
			data = ArrayUtils.remove(Object.class,data,i);
		}
		

		/**
		 * Returns the number of columns of this {@link VirtualTableRow}.
		 * 
		 * @return the number of columns
		 */
		public int size()
		{
			return data.length;
		}
		

		/**
		 * Checks if this {@link VirtualTableRow} exists in the
		 * {@link VirtualTable}.
		 * 
		 * @return <code>false</code> if this {@link VirtualTableRow} exists in
		 *         the {@link VirtualTable}, <code>true</code> otherwise
		 */
		public boolean isNew()
		{
			return VirtualTable.this.data.indexOf(this) == -1;
		}
		

		/**
		 * Saves a {@link VirtualTableRow}.
		 * <p>
		 * If the {@link VirtualTableRow} is already part of a
		 * {@link VirtualTable}, an update is performed. Otherwise an insert
		 * will be done.
		 * </p>
		 * 
		 * @param data
		 *            a {@link Map} of {@link String} keys and {@link Object} as
		 *            values, containing the column names and values for the
		 *            row.
		 * @param synchronizeDB
		 *            if set to <code>true</code>, changes will be propagated to
		 *            the underlying data source.
		 * @throws VirtualTableException
		 * @throws DBException
		 *             thrown if database access failed.
		 */
		public void save(Map<String, Object> data, boolean synchronizeDB)
				throws VirtualTableException, DBException
		{
			save(data,synchronizeDB,null);
		}
		

		/**
		 * Saves a {@link VirtualTableRow}.
		 * <p>
		 * If the {@link VirtualTableRow} is already part of a
		 * {@link VirtualTable}, an update is performed. Otherwise an insert
		 * will be done.
		 * </p>
		 * 
		 * @param data
		 *            a {@link Map} of {@link String} keys and {@link Object} as
		 *            values, containing the column names and values for the
		 *            row.
		 * @param synchronizeDB
		 *            if set to <code>true</code>, changes will be propagated to
		 *            the underlying data source.
		 * @param connection
		 *            An already open connection, e.g. in a transaction, or
		 *            <code>null</code>
		 * @throws VirtualTableException
		 * @throws DBException
		 *             thrown if database access failed.
		 */
		public void save(Map<String, Object> data, boolean synchronizeDB, DBConnection connection)
				throws VirtualTableException, DBException
		{
			if(isNew())
			{
				insert(data,synchronizeDB,connection);
			}
			else
			{
				update(data,synchronizeDB,connection);
			}
		}
		

		/**
		 * Updates a {@link VirtualTableRow}.
		 * 
		 * @param data
		 *            a {@link Map} of {@link String} keys and {@link Object} as
		 *            values, containing the column names and values for the
		 *            row.
		 * @param synchronizeDB
		 *            if set to <code>true</code>, changes will be propagated to
		 *            database.
		 * @throws VirtualTableException
		 * @throws DBException
		 *             thrown if database access failed.
		 */
		public void update(Map<String, Object> data, boolean synchronizeDB)
				throws VirtualTableException, DBException
		{
			update(data,synchronizeDB,null);
		}
		

		/**
		 * Updates a {@link VirtualTableRow}.
		 * 
		 * @param data
		 *            a {@link Map} of {@link String} keys and {@link Object} as
		 *            values, containing the column names and values for the
		 *            row.
		 * @param synchronizeDB
		 *            if set to <code>true</code>, changes will be propagated to
		 *            database.
		 * @param connection
		 *            An already open connection, e.g. in a transaction, or
		 *            <code>null</code>
		 * @throws VirtualTableException
		 * @throws DBException
		 *             thrown if database access failed.
		 */
		public void update(Map<String, Object> data, boolean synchronizeDB, DBConnection connection)
				throws VirtualTableException, DBException
		{
			updateRow(data,VirtualTable.this.data.indexOf(this),synchronizeDB,connection);
		}
		

		/**
		 * Inserts a {@link VirtualTableRow} into its {@link VirtualTable}.
		 * 
		 * @param data
		 *            a {@link Map} of {@link String} keys and {@link Object} as
		 *            values, containing the column names and values for the
		 *            row.
		 * @param synchronizeDB
		 *            if set to <code>true</code>, changes will be propagated to
		 *            database.
		 * @throws VirtualTableException
		 * @throws DBException
		 *             thrown if database access failed.
		 */
		public void insert(Map<String, Object> data, boolean synchronizeDB)
				throws VirtualTableException, DBException
		{
			insert(data,synchronizeDB,null);
		}
		

		/**
		 * Inserts a {@link VirtualTableRow} into its {@link VirtualTable}.
		 * 
		 * @param data
		 *            a {@link Map} of {@link String} keys and {@link Object} as
		 *            values, containing the column names and values for the
		 *            row.
		 * @param synchronizeDB
		 *            if set to <code>true</code>, changes will be propagated to
		 *            database.
		 * @param connection
		 *            An already open connection, e.g. in a transaction, or
		 *            <code>null</code>
		 * @throws VirtualTableException
		 * @throws DBException
		 *             thrown if database access failed.
		 */
		public void insert(Map<String, Object> data, boolean synchronizeDB, DBConnection connection)
				throws VirtualTableException, DBException
		{
			addRow(this,data,synchronizeDB,false,connection);
		}
		

		/**
		 * Deletes a {@link VirtualTableRow} from its {@link VirtualTable}.
		 * 
		 * @param synchronizeDB
		 *            if set to <code>true</code>, changes will be propagated to
		 *            database.
		 * @throws VirtualTableException
		 * @throws DBException
		 *             thrown if database access failed.
		 */
		public void delete(boolean synchronizeDB) throws VirtualTableException, DBException
		{
			removeRow(VirtualTable.this.data.indexOf(this),synchronizeDB);
		}
		

		/**
		 * Reloads the contents of this {@link VirtualTableRow} from the
		 * database.
		 * <p>
		 * This is an alias for {@link #reload(DBDataSource)}.
		 * </p>
		 * 
		 * @throws VirtualTableException
		 * @throws DBException
		 *             thrown if database access failed.
		 */
		public void reload() throws VirtualTableException, DBException
		{
			reload(getDataSource());
		}
		

		/**
		 * Reloads the contents of this {@link VirtualTableRow} from the
		 * database.
		 * <p>
		 * This is an alias for {@link #reload(DBDataSource)}.
		 * </p>
		 * 
		 * @param dataSource
		 *            the {@link DBDataSource} to be used to do the reloads
		 * @throws VirtualTableException
		 * @throws DBException
		 *             thrown if database access failed.
		 */
		public void reload(DBDataSource dataSource) throws VirtualTableException, DBException
		{
			KeyValues keyValues = new KeyValues(this);
			
			SELECT select;
			List values;
			if(lastQuery != null)
			{
				select = lastQuery.getSelect().clone();
				values = new XdevList(lastQuery.getParameters());
			}
			else
			{
				select = getSelect();
				values = new XdevList();
			}
			
			WHERE where = select.getWhere();
			if(where == null)
			{
				where = new WHERE();
				select.WHERE(where);
			}
			
			keyValues.appendCondition(where,values);
			
			DBConnection connection = dataSource.openConnection();
			try
			{
				Result result = connection.query(select,values.toArray());
				try
				{
					if(!result.next())
					{
						throw new VirtualTableRowDeletedInDbException();
					}
					
					for(VirtualTableIndex vtIndex : indices)
					{
						vtIndex.remove(this);
					}
					
					int[] colIndices = getColIndices(result);
					for(int i = 0; i < colIndices.length; i++)
					{
						if(colIndices[i] != -1)
						{
							Object val = result.getObject(i);
							set(colIndices[i],checkValue(colIndices[i],val),false,false);
						}
					}
					
					for(VirtualTableIndex vtIndex : indices)
					{
						vtIndex.put(this);
					}
				}
				finally
				{
					result.close();
				}
			}
			finally
			{
				connection.close();
			}
		}
		

		/**
		 * Returns a copy of this VirtualTableRow.
		 * 
		 * @return a {@link VirtualTableRow}
		 */
		public VirtualTableRow clone()
		{
			VirtualTableRow row = new VirtualTableRow(data.length,index);
			System.arraycopy(data,0,row.data,0,data.length);
			return row;
		}
		

		/**
		 * Custom toString Implementation for {@link VirtualTableRow}.
		 * <p>
		 * The String contains all elements of the VirtualTableRow in a comma
		 * separated list
		 * </p>
		 * 
		 * @return a {@link String} representation of this
		 *         {@link VirtualTableRow}.
		 */
		@Override
		public String toString()
		{
			return Arrays.toString(data);
		}
		

		/**
		 * Returns an array of formatted {@link String} representations for this
		 * {@link VirtualTableRow}.
		 * 
		 * @return an array of Strings
		 */
		public String[] toFormattedStrings()
		{
			int len = data.length;
			String[] s = new String[len];
			for(int col = 0; col < len; col++)
			{
				s[col] = formatValue(data[col],col);
			}
			return s;
		}
		

		/**
		 * Returns all values of this row as an {@link Map}. The keys of the map
		 * are the column names, the entries are the values.
		 * 
		 * @return all values of this row as an {@link Map}.
		 */
		public Map<String, Object> toMap()
		{
			Map<String, Object> map = new HashMap<String, Object>(columns.length);
			for(int col = 0; col < columns.length; col++)
			{
				map.put(columns[col].getName(),data[col]);
			}
			return map;
		}
		

		/**
		 * Returns all values of this row as a {@link XdevList}.
		 * 
		 * @return all values of this row as a {@link XdevList}.
		 */
		public XdevList toList()
		{
			int c = columns.length;
			XdevList list = new XdevList(c);
			for(int i = 0; i < c; i++)
			{
				list.add(data[i]);
			}
			return list;
		}
		

		/**
		 * Returns all values of this row as an array.
		 * 
		 * @return all values of this row as an array.
		 */
		public Object[] getValues()
		{
			Object[] values = new Object[columns.length];
			System.arraycopy(data,0,values,0,columns.length);
			return values;
		}
		

		/**
		 * Checks if the values of this row are the same as the values of an
		 * <code>other</code> row.
		 * 
		 * @param other
		 *            The row to compare
		 * @return <code>true</code> if the values of both rows are equal,
		 *         <code>false</code> otherwise
		 * @see VirtualTable#equals(Object, Object)
		 */
		public boolean equalsValues(VirtualTableRow other)
		{
			Object[] data1 = this.data;
			Object[] data2 = other.data;
			
			int length = data1.length;
			if(length != data2.length)
			{
				return false;
			}
			
			for(int i = 0; i < length; i++)
			{
				if(!VirtualTable.equals(data1[i],data2[i]))
				{
					return false;
				}
			}
			
			return true;
		}
		

		public void updateKeys(Result generatedKeys) throws DBException
		{
			int columnCount = generatedKeys.getColumnCount();
			try
			{
				if(generatedKeys.next())
				{
					for(int c = 0; c < columnCount; c++)
					{
						int col = getColumnIndex(generatedKeys.getMetadata(c).getName());
						if(col == -1 && columnCount == 1)
						{
							col = getAutoValue(c);
						}
						if(col != -1)
						{
							Object generatedKey = generatedKeys.getObject(c);
							generatedKey = checkValue(col,generatedKey);
							set(col,generatedKey,false,false);
						}
					}
				}
			}
			finally
			{
				generatedKeys.close();
			}
		}
	}
	


	/**
	 * Hash values are only computed and stored if the index is unique.
	 */
	private class VirtualTableIndex implements Serializable
	{
		private static final long	serialVersionUID	= 7320439821022328063L;
		
		final Index					_originalIndex;
		
		final String				name;
		final IndexType				type;
		VirtualTableColumn[]		columns;
		int[]						columnIndices;
		final boolean				isUnique;
		HashSet<String>				set;
		transient Object			hashLock;
		transient Object[]			hashTemp;
		

		VirtualTableIndex(Index index)
		{
			this._originalIndex = index;
			
			this.name = index.getName();
			this.type = index.getType();
			String[] columnNames = index.getColumns();
			List<VirtualTableColumn> columns = new ArrayList(columnNames.length);
			for(int i = 0; i < columnNames.length; i++)
			{
				VirtualTableColumn col = getColumn(columnNames[i]);
				if(col != null)
				{
					columns.add(col);
				}
			}
			
			boolean onlyAutoValues = true;
			int cc = columns.size();
			this.columns = new VirtualTableColumn[cc];
			this.columnIndices = new int[cc];
			for(int i = 0; i < cc; i++)
			{
				this.columns[i] = columns.get(i);
				this.columnIndices[i] = getColumnIndex(this.columns[i]);
				if(!this.columns[i].isAutoIncrement())
				{
					onlyAutoValues = false;
				}
			}
			Arrays.sort(this.columnIndices);
			
			boolean unique = false;
			if(index.isUnique())
			{
				this.set = new HashSet();
				if(!onlyAutoValues)
				{
					unique = true;
				}
			}
			this.isUnique = unique;
		}
		

		void removeCol(VirtualTableColumn column)
		{
			int index = ArrayUtils.indexOf(columns,column);
			if(index >= 0)
			{
				columns = ArrayUtils.remove(VirtualTableColumn.class,columns,index);
				columnIndices = ArrayUtils.remove(columnIndices,index);
			}
			else
			// update column indices
			{
				for(int i = 0; i < columns.length; i++)
				{
					this.columnIndices[i] = getColumnIndex(this.columns[i]);
				}
			}
		}
		

		boolean hasCol(int index)
		{
			for(int i = 0; i < columnIndices.length; i++)
			{
				if(columnIndices[i] == index)
				{
					return true;
				}
			}
			
			return false;
		}
		

		private Object getHashLock()
		{
			if(hashLock == null)
			{
				hashLock = new Object();
			}
			return hashLock;
		}
		

		String computeHash(VirtualTableRow row)
		{
			synchronized(getHashLock())
			{
				int c = columns.length;
				if(hashTemp == null || hashTemp.length != c)
				{
					hashTemp = new Object[c];
				}
				Object[] values = hashTemp;
				for(int i = 0; i < c; i++)
				{
					values[i] = row.data[columnIndices[i]];
				}
				
				String hash = HashComputer.computeHash(values);
				
				if(type == IndexType.PRIMARY_KEY)
				{
					row.primaryKeyHash = hash;
				}
				
				return hash;
			}
		}
		

		String computeHash(VirtualTableRow row, int index, Object replacement)
		{
			synchronized(getHashLock())
			{
				int c = columns.length;
				if(hashTemp == null || hashTemp.length != c)
				{
					hashTemp = new Object[c];
				}
				Object[] values = hashTemp;
				for(int i = 0; i < c; i++)
				{
					values[i] = columnIndices[i] == index ? replacement
							: row.data[columnIndices[i]];
				}
				
				return HashComputer.computeHash(values);
			}
		}
		

		/**
		 * @return <code>true</code> if row is new, <code>false</code> otherwise
		 */
		boolean put(VirtualTableRow row)
		{
			if(set != null)
			{
				return set.add(computeHash(row));
			}
			
			return true;
		}
		

		/**
		 * 
		 * @param hash
		 * @return <code>true</code> if hash is new, <code>false</code>
		 *         otherwise
		 */
		
		boolean put(String hash)
		{
			if(set != null)
			{
				return set.add(hash);
			}
			
			return true;
		}
		

		void remove(VirtualTableRow row)
		{
			if(set != null)
			{
				set.remove(computeHash(row));
			}
		}
		

		synchronized void clear()
		{
			if(set != null)
			{
				set.clear();
			}
		}
	}
	

	public boolean getCheckUniqueIndexDoubleValues()
	{
		return checkUniqueIndexDoubleValues;
	}
	

	public void setCheckUniqueIndexDoubleValues(boolean checkUniqueIndexDoubleValues)
	{
		this.checkUniqueIndexDoubleValues = checkUniqueIndexDoubleValues;
	}
	

	private void reportUniqueIndexDoubleValues(VirtualTableRow row, VirtualTableIndex index)
			throws UniqueIndexDuplicateValuesException
	{
		if(checkUniqueIndexDoubleValues)
		{
			StringBuilder sb = new StringBuilder();
			sb.append(getClass().getName());
			sb.append(": Duplicate values in unique index ");
			sb.append(index.name);
			for(int columnIndex : index.columnIndices)
			{
				sb.append(", ");
				sb.append(columns[columnIndex].getName());
				sb.append(" = ");
				sb.append(row.getFormattedValue(columnIndex));
			}
			
			throw new UniqueIndexDuplicateValuesException(sb.toString());
		}
	}
	

	@Override
	public Table toSqlObject()
	{
		return toSqlTable();
	}
	

	/**
	 * Returns a {@link Table} for this {@link VirtualTable}.
	 * 
	 * @return a {@link Table}
	 */
	public Table toSqlTable()
	{
		return new Table(dbSchema != null && dbSchema.length() > 0 ? dbSchema : null,dbAlias,null);
	}
	

	/**
	 * Stores the {@link QueryInfo} of the last executed query.
	 * 
	 * @param lastQuery
	 *            a {@link QueryInfo}
	 */
	public void setLastQuery(QueryInfo lastQuery)
	{
		this.lastQuery = lastQuery;
	}
	

	/**
	 * Returns the last executed query.
	 * 
	 * @return a {@link QueryInfo}
	 */
	public QueryInfo getLastQuery()
	{
		if(lastQuery != null)
		{
			return lastQuery.clone();
		}
		
		return null;
	}
	

	/**
	 * Creates the default {@link SELECT} for this {@link VirtualTable}.
	 * 
	 * <pre>
	 * SELECT [all columns...] FROM[tableName]
	 * </pre>
	 * 
	 * @return the created {@link SELECT}
	 */
	public SELECT getDefaultSelect()
	{
		SELECT select = new SELECT().FROM(toSqlTable());
		
		for(VirtualTableColumn col : columns)
		{
			if(col.isPersistent())
			{
				select.columns(col.toSqlColumn(this));
			}
		}
		
		return select;
	}
	

	/**
	 * Creates the extended {@link SELECT} for this {@link VirtualTable} with
	 * the joined, non persistent columns.
	 * <p>
	 * Alias for <code>getExtendedSelect(JoinType.LEFT_JOIN)</code>.
	 * </p>
	 * 
	 * @return the created {@link SELECT}
	 * 
	 * @throws VirtualTableException
	 * 
	 * @see #getExtendedSelect(JoinType)
	 */
	public SELECT getExtendedSelect() throws VirtualTableException
	{
		return getExtendedSelect(JoinType.LEFT_JOIN);
	}
	

	/**
	 * Creates the extended {@link SELECT} for this {@link VirtualTable} with
	 * the joined, non persistent columns.
	 * 
	 * @param joinType
	 *            the way linked tables should be joined
	 * 
	 * @return the created {@link SELECT}
	 */
	public SELECT getExtendedSelect(JoinType joinType) throws VirtualTableException
	{
		SELECT select = new SELECT().FROM(toSqlTable());
		SqlGenerationContext context = null;
		
		for(VirtualTableColumn column : columns)
		{
			TableColumnLink link = column.getTableColumnLink();
			if(link != null)
			{
				if(context == null)
				{
					context = new SqlGenerationContext();
				}
				link.addColumn(select,this,column,joinType,context);
			}
			else
			{
				select.columns(column.toSqlColumn());
			}
		}
		
		return select;
	}
	

	/**
	 * Returns {@link #getExtendedSelect()} if this {@link VirtualTable} has non
	 * persistent columns, {@link #getDefaultSelect()} otherwise.
	 * 
	 * @return The best fitting select to query data for this VirtualTable
	 * @see #hasNonPersistentColumns()
	 */
	public SELECT getSelect()
	{
		return hasNonPersistentColumns() ? getExtendedSelect() : getDefaultSelect();
	}
	

	/**
	 * Reloads the contents of this {@link VirtualTable} applying the search
	 * conditions of the last executed query.
	 * 
	 * @throws VirtualTableException
	 * @throws DBException
	 *             thrown if database access fails
	 */
	public void reload() throws VirtualTableException, DBException
	{
		if(lastQuery != null)
		{
			queryAndFill(getDataSource(),lastQueryIndices,lastQuery.getSelect(),
					lastQuery.getParameters());
		}
	}
	

	/**
	 * Executes the default select for this {@link VirtualTable}.
	 * <p>
	 * This is an alias for
	 * {@link #queryAndFill(DBDataSource, SELECT, Object...)}.
	 * </p>
	 * 
	 * @throws VirtualTableException
	 * @throws DBException
	 *             thrown if database access failed.
	 */
	public void queryAndFill() throws VirtualTableException, DBException
	{
		queryAndFill(getDataSource(),getSelect());
	}
	

	/**
	 * Executes the default select for this {@link VirtualTable}.
	 * <p>
	 * This is an alias for
	 * {@link #queryAndFill(DBDataSource, SELECT, Object...)}.
	 * </p>
	 * 
	 * @param dataSource
	 *            the {@link DBDataSource} used for querying the database
	 * @throws VirtualTableException
	 * @throws DBException
	 *             thrown if database access failed.
	 */
	public void queryAndFill(DBDataSource dataSource) throws VirtualTableException, DBException
	{
		queryAndFill(dataSource,getSelect());
	}
	

	/**
	 * Executes the default select for this {@link VirtualTable}.
	 * <p>
	 * This is an alias for
	 * {@link #queryAndFill(DBDataSource, SELECT, Object...)}.
	 * </p>
	 * 
	 * @param select
	 *            the SELECT to be executed for querying the database
	 * @param params
	 *            dynamic parameters, that can be used optionally
	 * @throws VirtualTableException
	 * @throws DBException
	 *             thrown if database access failed.
	 */
	public void queryAndFill(SELECT select, Object... params) throws VirtualTableException,
			DBException
	{
		queryAndFill(getDataSource(),select,params);
	}
	

	/**
	 * Executes the default select for this {@link VirtualTable}.
	 * 
	 * @param dataSource
	 *            the {@link DBDataSource} used for querying the database
	 * @param select
	 *            the SELECT to be executed for querying the database
	 * @param params
	 *            dynamic parameters, that can be used optionally
	 * @throws VirtualTableException
	 * @throws DBException
	 *             thrown if database access failed.
	 */
	public void queryAndFill(DBDataSource dataSource, SELECT select, Object... params)
			throws VirtualTableException, DBException
	{
		queryAndFill(dataSource,null,select,params);
	}
	

	private void queryAndFill(DBDataSource dataSource, int[] columnIndices, SELECT select,
			Object... params) throws VirtualTableException, DBException
	{
		DBConnection connection = dataSource.openConnection();
		try
		{
			Result result = connection.query(select,params);
			try
			{
				addData(result,columnIndices,VirtualTableFillMethod.OVERWRITE);
			}
			finally
			{
				result.close();
			}
		}
		finally
		{
			connection.close();
		}
	}
	

	/**
	 * Executes a query and appends its results at the end of this
	 * {@link VirtualTable}.
	 * <p>
	 * This is an alias for {@link #queryAndAppend(DBDataSource, KeyValues)}.
	 * </p>
	 * 
	 * @param pkValue
	 *            the {@link KeyValues} for specifying the filter condition
	 * 
	 * @return <code>true</code> if values were appended, <code>false</code>
	 *         otherwise.
	 * 
	 * @throws VirtualTableException
	 * 
	 * @throws DBException
	 *             thrown if database access failed.
	 */
	public boolean queryAndAppend(KeyValues pkValue) throws VirtualTableException, DBException
	{
		return queryAndAppend(getDataSource(),pkValue);
	}
	

	/**
	 * Executes a query and appends its results at the end of this
	 * {@link VirtualTable}.
	 * 
	 * @param dataSource
	 *            the {@link DBDataSource} used for querying the database
	 * 
	 * @param pkValue
	 *            the {@link KeyValues} for specifying the filter condition
	 * 
	 * @return <code>true</code> if values were appended, <code>false</code>
	 *         otherwise.
	 * 
	 * @throws VirtualTableException
	 * 
	 * @throws DBException
	 *             thrown if database access failed.
	 */
	public boolean queryAndAppend(DBDataSource dataSource, KeyValues pkValue)
			throws VirtualTableException, DBException
	{
		SELECT select;
		List values;
		if(lastQuery != null)
		{
			select = lastQuery.getSelect();
			values = new XdevList(lastQuery.getParameters());
		}
		else
		{
			select = getSelect();
			values = new XdevList();
		}
		WHERE where = select.getWhere();
		if(where == null)
		{
			where = new WHERE();
			select.WHERE(where);
		}
		pkValue.appendCondition(where,values,this);
		
		boolean appended = false;
		
		DBConnection connection = dataSource.openConnection();
		try
		{
			Result result = connection.query(select,values.toArray());
			try
			{
				if(result.next())
				{
					VirtualTableRow row = new VirtualTableRow(columns.length,data.size());
					int[] colIndices = getColIndices(result);
					for(int i = 0; i < colIndices.length; i++)
					{
						if(colIndices[i] != -1)
						{
							Object val = result.getObject(i);
							row.set(colIndices[i],checkValue(colIndices[i],val),false,false);
						}
					}
					data.add(row,false);
					
					appended = true;
				}
			}
			finally
			{
				result.close();
			}
		}
		finally
		{
			connection.close();
		}
		
		return appended;
	}
	

	/**
	 * Compares two values with each other.
	 * 
	 * @param value1
	 *            first value to be compared
	 * @param value2
	 *            second value to be compared
	 * @return <code>true</code>, if both values are equal
	 */
	public static boolean equals(Object value1, Object value2)
	{
		if(value1 == value2)
		{
			return true;
		}
		
		if(value1 == null || value2 == null)
		{
			return false;
		}
		
		if(value1.equals(value2))
		{
			return true;
		}
		
		if(value1 instanceof Number && value2 instanceof Number)
		{
			return ((Number)value1).doubleValue() == ((Number)value2).doubleValue();
		}
		else if((value1 instanceof String && value2 instanceof Number)
				|| (value2 instanceof String && value1 instanceof Number))
		{
			return value1.toString().equals(value2.toString());
		}
		
		return false;
	}
}
