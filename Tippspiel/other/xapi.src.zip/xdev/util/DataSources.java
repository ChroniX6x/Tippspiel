/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.util;


import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Array;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Hashtable;
import java.util.List;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import xdev.Application;


public final class DataSources
{
	private DataSources()
	{
	}
	
	public final static String				REGISTRY_PATH;
	static
	{
		REGISTRY_PATH = "/" + DataSources.class.getName().replace('.','/');
	}
	
	private static Map<String, DataSource>	dataSources;
	
	static
	{
		dataSources = new Hashtable();
		
		URL url = DataSources.class.getResource(REGISTRY_PATH);
		if(url != null)
		{
			try
			{
				boolean oldFormat = false;
				
				try
				{
					DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
					DocumentBuilder builder = factory.newDocumentBuilder();
					Document doc = builder.parse(url.openStream());
					doc.getDocumentElement().normalize();
					NodeList children = doc.getElementsByTagName("datasource");
					for(int i = 0, c = children.getLength(); i < c; i++)
					{
						Element child = (Element)children.item(i);
						String className = child.getAttribute("class");
						try
						{
							Class clazz = Class.forName(className);
							DataSource dataSource = (DataSource)clazz.getMethod("getInstance")
									.invoke(null);
							registerDataSource(dataSource);
						}
						catch(Exception e)
						{
							Application.getLogger().error(e);
						}
					}
				}
				catch(SAXException e)
				{
					oldFormat = true;
				}
				
				if(oldFormat)
				{
					BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream(),
							"UTF8"));
					String line;
					while((line = in.readLine()) != null)
					{
						line = line.trim();
						if(line.length() > 0)
						{
							try
							{
								Class clazz = Class.forName(line);
								DataSource dataSource = (DataSource)clazz.getMethod("getInstance")
										.invoke(null);
								registerDataSource(dataSource);
							}
							catch(Exception e)
							{
								Application.getLogger().error(e);
							}
						}
					}
					in.close();
				}
			}
			catch(Exception e)
			{
				Application.getLogger().error(e);
			}
		}
	}
	

	public static void registerDataSource(DataSource dataSource)
	{
		dataSources.put(dataSource.getName(),dataSource);
	}
	

	public static DataSource getDataSource(String name)
	{
		return dataSources.get(name);
	}
	

	public static DataSource[] getDataSources()
	{
		Collection<DataSource> collection = dataSources.values();
		return collection.toArray(new DataSource[collection.size()]);
	}
	

	public static <T extends DataSource> T[] getDataSources(Class<T> type)
	{
		List<T> list = new ArrayList();
		for(DataSource dataSource : dataSources.values())
		{
			if(type.isInstance(dataSource))
			{
				list.add((T)dataSource);
			}
		}
		T[] e = (T[])Array.newInstance(type,list.size());
		return list.toArray(e);
	}
}
