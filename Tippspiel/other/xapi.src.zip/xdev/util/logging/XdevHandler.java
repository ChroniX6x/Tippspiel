/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.util.logging;


import java.util.LinkedList;
import java.util.logging.Formatter;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.SimpleFormatter;


class XdevHandler extends Handler
{
	private final int					maxSize;
	private final LinkedList<LogRecord>	store;
	private final Formatter				formatter;


	public XdevHandler()
	{
		int maxSize;
		try
		{
			maxSize = Integer.parseInt(System.getProperty("Logger.storageSize","100"));
		}
		catch(NumberFormatException e)
		{
			maxSize = 100;
		}
		this.maxSize = maxSize;

		store = new LinkedList();
		formatter = new SimpleFormatter();
	}


	@Override
	public void publish(LogRecord record)
	{
		synchronized(store)
		{
			store.add(record);

			while(store.size() > maxSize)
			{
				store.removeFirst();
			}
		}

		System.err.print(formatter.format(record));
	}


	@Override
	public void close() throws SecurityException
	{
		setLevel(Level.OFF);
	}


	@Override
	public void flush()
	{
	}


	LogRecord[] getRecords()
	{
		synchronized(store)
		{
			return store.toArray(new LogRecord[store.size()]);
		}
	}


	public int getRecordCount()
	{
		return store.size();
	}


	public LogRecord getRecord(int index)
	{
		return store.get(index);
	}
}
