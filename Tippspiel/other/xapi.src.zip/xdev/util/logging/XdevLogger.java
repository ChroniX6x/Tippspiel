/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.util.logging;


import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogRecord;
import java.util.logging.Logger;


public class XdevLogger
{
	private final XdevHandler	handler;
	private Logger				logger;


	public XdevLogger()
	{
		handler = new XdevHandler();
	}


	public void error(Throwable thrown)
	{
		error(thrown,null);
	}


	public void error(Throwable thrown, String msg)
	{
		log(Level.SEVERE,msg,thrown);
	}


	public void error(String msg, Object... args)
	{
		log(Level.SEVERE,msg,args);
	}


	public void warning(Throwable thrown)
	{
		warning(thrown,null);
	}


	public void warning(Throwable thrown, String msg)
	{
		log(Level.WARNING,msg,thrown);
	}


	public void warning(String msg, Object... args)
	{
		log(Level.WARNING,msg,args);
	}


	public void info(Throwable thrown)
	{
		info(thrown,null);
	}


	public void info(Throwable thrown, String msg)
	{
		log(Level.INFO,msg,thrown);
	}


	public void info(String msg, Object... args)
	{
		log(Level.INFO,msg,args);
	}


	public void debug(Throwable thrown)
	{
		debug(thrown,null);
	}


	public void debug(Throwable thrown, String msg)
	{
		log(Level.FINE,msg,thrown);
	}


	public void debug(String msg, Object... args)
	{
		log(Level.FINE,msg,args);
	}


	private void log(Level level, String msg, Object... args)
	{
		log0(level,msg,null,args);
	}


	private void log(Level level, String msg, Throwable ex)
	{
		log0(level,msg,ex,(Object[])null);
	}


	private void log0(Level level, String msg, Throwable ex, Object... args)
	{
		Logger logger = getLogger();
		if(logger.isLoggable(level) && log(ex))
		{
			if(msg == null)
			{
				msg = "";
			}

			StackTraceElement locations[] = new Throwable().getStackTrace();

			String sourceClass = "[unknown]";
			String sourceMethod = "[unknown]";
			if(locations != null && locations.length > 3)
			{
				StackTraceElement caller = locations[3];
				sourceClass = caller.getClassName();
				sourceMethod = caller.getMethodName();
			}

			if(ex != null)
			{
				logger.logp(level,sourceClass,sourceMethod,msg,ex);
			}
			else if(args != null && args.length > 0)
			{
				logger.logp(level,sourceClass,sourceMethod,msg,args);
			}
			else
			{
				logger.logp(level,sourceClass,sourceMethod,msg);
			}
		}
	}


	/**
	 * XXX filters JRE bugs/messages with no effect
	 * 
	 * @param t
	 * @return
	 */
	protected boolean log(Throwable t)
	{
		if(t instanceof SecurityException
				&& t.getMessage().equals(
						"this KeyboardFocusManager is not "
								+ "installed in the current thread's context"))
		{
			return false;
		}

		return true;
	}


	public void setLogger(Logger logger)
	{
		this.logger = logger;
	}


	public Logger getLogger()
	{
		if(logger == null)
		{
			logger = new Logger("XDEV Platform Logger",null)
			{
				@Override
				public synchronized void removeHandler(Handler handler) throws SecurityException
				{
				}
			};
			logger.setUseParentHandlers(false);
			logger.addHandler(handler);
		}

		return logger;
	}


	public LogRecord[] getRecords()
	{
		return handler.getRecords();
	}


	public int getRecordCount()
	{
		return handler.getRecordCount();
	}


	public LogRecord getRecord(int index)
	{
		return handler.getRecord(index);
	}
}
