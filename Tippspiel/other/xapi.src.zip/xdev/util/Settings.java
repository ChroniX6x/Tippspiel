/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.util;


import java.awt.*;


public class Settings
{
	public final static String	QUALITY_PAINT			= "xdev.qualityPaint";
//	public final static String	IGNORE_BROWSER_BUTTONS	= "xdev.ignoreBrowserButtons";
	public final static String	TRIM_DATA				= "xdev.trimData";
	public final static String	SELECT_ALL_ON_FOCUS		= "xdev.selectAllOnFocus";
	public final static String	SERVER_SIDE_SUFFIX		= "xdev.serverSideSuffix";
	

	private Settings()
	{
	}
	

	public static boolean useQualityPaint()
	{
		String value = System.getProperty(QUALITY_PAINT);
		return value != null && checkUserSetting(value);
	}
	

	public static int getImageScaleMode()
	{
		return useQualityPaint() ? Image.SCALE_SMOOTH : Image.SCALE_FAST;
	}
	

//	public static boolean ignoreBrowserButtons()
//	{
//		String value = System.getProperty(IGNORE_BROWSER_BUTTONS);
//		return value != null && checkUserSetting(value);
//	}
	

	public static boolean trimData()
	{
		String value = System.getProperty(TRIM_DATA);
		return value != null && checkUserSetting(value);
	}
	

	public static boolean selectAllOnFocus()
	{
		String value = System.getProperty(SELECT_ALL_ON_FOCUS);
		return value != null && checkUserSetting(value);
	}
	

	public static String getServerSideSuffix()
	{
		String suffix = System.getProperty(SERVER_SIDE_SUFFIX);
		if(suffix != null)
		{
			return suffix;
		}
		
		return "jsp";
	}
	

	public static boolean checkUserSetting(Object value)
	{
		return value != null
				&& (value.toString().equalsIgnoreCase("true") || value.toString().equals("1"));
	}
}
