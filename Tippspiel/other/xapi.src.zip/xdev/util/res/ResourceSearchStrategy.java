/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.util.res;


import java.util.*;


/**
 * A ResourceSearchStrategy is the way how resources are searched through the
 * class hierarchy or the file system.
 * 
 * @author XDEV Software
 * 
 * @since 2.0
 * 
 */

public interface ResourceSearchStrategy
{
	/**
	 * Searches for a resource entry according to <code>key</code>.<br>
	 * The <code>requestor</code> may be crucial how the strategy is looking for
	 * the ressource.<br>
	 * <br>
	 * If <code>requestor</code> is <code>null</code> only the default resource
	 * bundle is searched through.
	 * 
	 * @param key
	 *            the key of the resource's value pair
	 * @param locale
	 *            to lookup the String for
	 * @param requestor
	 *            the origin of the call to this method or <code>null</code>
	 * @return the value mapped to <code>key</code>
	 * @throws MissingResourceException
	 *             if no resource bundle can be found - depending on this search
	 *             strategy - or if the key can not be found in one of the
	 *             resource files
	 * @throws NullPointerException
	 *             if <code>key</code> is <code>null</code>
	 */
	
	public String lookupResourceString(String key, Locale locale, Object requestor)
			throws MissingResourceException, NullPointerException;
}
