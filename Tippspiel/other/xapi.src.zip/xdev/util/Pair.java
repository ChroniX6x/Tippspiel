/*
 * Copyright (C) 2007-2011 by XDEV Software, All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License version 3.0 as published by the Free Software Foundation.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
 
package xdev.util;

//TODO class description
public class Pair<A, B>
{
	private final A		first;
	private final B		second;
	private final int	hash;
	

	/**
	 * Create a new {@link Pair} Object.
	 * 
	 * @param first
	 *            the first parameter
	 * 
	 * @param second
	 *            the second parameter
	 */
	public Pair(A first, B second)
	{
		this.first = first;
		this.second = second;
		this.hash = MathUtils.computeHash(first,second);
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public int hashCode()
	{
		return hash;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public boolean equals(Object other)
	{
		if(other instanceof Pair)
		{
			Pair otherPair = (Pair)other;
			return ObjectUtils.equals(first,otherPair.first)
					&& ObjectUtils.equals(second,otherPair.second);
		}
		
		return false;
	}
	

	/**
	 * {@inheritDoc}
	 */
	@Override
	public String toString()
	{
		return "(" + first + ", " + second + ")";
	}
	

	/**
	 * Returns the first parameter of this {@link Pair}.
	 * 
	 * @return the first parameter
	 */
	public A getFirst()
	{
		return first;
	}
	

	/**
	 * Returns the second parameter of this {@link Pair}.
	 * 
	 * @return the second parameter
	 */
	public B getSecond()
	{
		return second;
	}
}
